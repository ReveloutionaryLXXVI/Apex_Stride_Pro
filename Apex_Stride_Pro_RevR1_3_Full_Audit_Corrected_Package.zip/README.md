> **CURRENT REVISION — Rev R1.3 (2026-10-16).** Active CAD: `revision/Apex_Stride_Pro_RevR.scad` (identical to `Apex_Stride_Pro_RevR1_3_Corrected.scad` and the print-prep source). Start with `REV_R1_3_FULL_AUDIT_REPORT.md`, `REV_R1_3_CORRECTION_INDEX.md`, `REV_R1_3_QA.json`, and `REV_R1_3_STRUCTURAL_SCREEN.csv`. The forefoot pocket roof is 10.1 mm with a 5 mm center web. The design remains **NOT CLEARED FOR HUMAN WEAR**; no material-specific FEA or physical qualification has occurred. Previous R1.2 reports are historical snapshots.


# Apex Stride Pro — Rev R integrated core-cavity package

## Current release files

- Editable OpenSCAD: `revision/Apex_Stride_Pro_RevR.scad`
- Synchronized print-prep source: `PRINT_READY_BENCH_FIT_KIT_REV_R/source/Apex_Stride_Pro_RevR_PrintPrep.scad`
- **Current full audit:** `REV_R1_3_FULL_AUDIT_REPORT.md`
- Engineering report (historical Rev R/R1.2 snapshot): `FINAL_ENGINEERING_REPORT_REV_R.md`
- Consolidated tests: `FINAL_CLOSURE_TEST_REGISTER.md`
- Quick package verification: `FINAL_PACKAGE_VERIFICATION.md`
- Release gate: `PROJECT_STATUS_AND_RELEASE_GATE_REV_R.md`
- Consolidated validation register: `FINAL_CLOSURE_TEST_REGISTER.md`
- Assembly/manual: `revision/docs/ASSEMBLY_MANUAL_REV_R.md`
- 72-row file map: `revision/docs/ASSEMBLY_FILE_MAP_REV_R.csv`
- 60-row BOM: `revision/docs/BILL_OF_MATERIALS_REV_R.csv`
- Material, interface/fastener and pneumatic schedules: `revision/docs/MATERIAL_PROPERTY_TABLE_REV_R.csv`, `revision/docs/COMPONENT_INTERFACE_FASTENER_SCHEDULE_REV_R.csv`, `revision/docs/PNEUMATIC_CIRCUIT_PRESSURE_SCHEDULE_REV_R.csv`
- **Current 66 kg load screen:** `revision/docs/LOAD_ASSESSMENT_66KG_REV_R1_3.md`
- Historical load note: `revision/docs/LOAD_ASSESSMENT_66KG_REV_R.md`
- 20-item component physical validation checklist: `revision/docs/PHYSICAL_VALIDATION_CHECKLIST_REV_R.csv`
- Native verification records: `revision/verification_results/revR_core_integration/` and `reports/REV_R_CORE_INTEGRATION/`

## Geometry change

Rev R replaces the earlier ribbed under-deck reserve with a continuous **55×23×10.5 mm** cavity in the fixed heel deck, retaining the 20.6 mm outside sole thickness while thickening the local roof to **10.1 mm** (up from 5.5 mm; nominal side web to rail channel 2.5 mm). Rev R1.2 reduces the custom bladder body height target to 9 mm to maintain 1.5 mm vertical clearance. Native OpenSCAD geometry tests verify cavity/roof ray intersections and show that the cavity remains when optional lightening is disabled. This is a geometric integration fix only; no real spring, bladder, pneumatic ports or valves are selected or validated.

## Included mesh assets

- **42 fit/mockup parts** (14 per size EU42/EU44/EU46) under `PRINT_READY_BENCH_FIT_KIT_REV_R/stl/`.
- **21 upper concept meshes**; not sewn patterns and not foot-retention components.
- **9 optional 3.2 mm outsole study meshes**; non-wearable study only. The default modeled outsole stays 4.0 mm.
- Polymer rail/pin/ring meshes are gauges only. Do not use them as load-bearing hardware.

## Material basis and estimates

Rigid heel/toe deck candidate is the specified Materialise PA12 SLS process/card, not generic FDM or MJF. TPU 95A data apply only to the cited manufacturer/process and non-primary flexible items. Metal, spring, actual bladder/circuit, EVA, outsole compound and upper construction still need exact supplier decisions. The fresh CAD mass table includes only modeled rigid parts plus outsole using an explicitly illustrative 1.20 g/cm³ density; it excludes footbed, actual ring, fasteners, upper, spring, bladder/lines/fittings/valves and adhesive. It shows Rev R approximately 4.5–4.6 g heavier than Rev K in the comparable scope; no default mass reduction is claimed.

## Reproduce / verify

Requires OpenSCAD, Python 3, NumPy and trimesh. From package root:

```bash
python3 revision/tools/export_print_fit_kit_revR.py
python3 revision/tools/recalculate_mass_materials_revR.py
python3 revision/tools/run_revr_kinematic_clearance_sweep.py
python3 revision/tools/test_revr_locked_stop_intersections.py
python3 revision/tools/verify_revr_core_cavity.py
python3 revision/tools/run_revr_source_compile_checks.py
```

The checks cover source/print-prep parity, CAD exports, mesh integrity, nominal kinematics/CSG intersections, cavity geometry, file map and mass arithmetic. They do **not** establish structural capacity, fatigue, pneumatic safety or wear authorization. No material-specific FEA, `.FCStd`, validated STEP or physical test is included. The original uploaded baseline and historical revisions are retained for traceability.

## Release status

**Non-wearable engineering-review and dimensional mockup only. Human wear is NOT CLEARED.** Complete supplier-specific design, structural/tolerance analysis, guarded load/fatigue/retention/pneumatic/outsole/upper tests and independent sign-off before any human walking or running trial.


## Prior Rev R1.2 roof/pressure/load-path correction (historical; R1.3 supersedes this geometry snapshot)

The full 55×23 mm cavity must not be treated as bladder effective area. The Rev R1.2 RFQ target bladder body is ≤27×22×9 mm (594 mm² projected rectangle). The corrected bladder-only pressure demand is 1.090 MPa at 66 kg one-foot static load and 2.180 MPa at 2×; therefore a small bladder cannot be the sole body-load support with the candidate 1.0 MPa fittings. Provisional low-pressure auxiliary targets are 0.40 MPa working / 0.50 MPa nominal relief. See `REV_R1_PRESSURE_AND_LOAD_PATH_CORRECTION.md`, the corrected load-screen JSON/CSV, and circuit schedule. The targets are not approved for pressurization until the OEM bladder rating, relief overshoot, and structural zero-pressure load path are qualified.

## Rev R1.3 forefoot reinforcement and final regression

Rev R1.3 thickens the forefoot lightening-pocket roof from 5.5 to 10.1 mm and increases the inter-row web from 1 to 5 mm. The original 155 mm rail and 90 mm slot remain unchanged. Final regression: source/package 130/130, cavity 9/9, kinematic 250/250, rail-stop CSG 6/6, screw-interface CSG 24/24, fit-kit exports 42/42, all active meshes 72/72, assembly map 72 rows with zero missing paths. See `REV_R1_3_FULL_AUDIT_REPORT.md`. The structural screen still has hold points including pin span sensitivity, bridge head-pocket cap, pneumatic support share, outsole skin, FEA and physical qualification.
