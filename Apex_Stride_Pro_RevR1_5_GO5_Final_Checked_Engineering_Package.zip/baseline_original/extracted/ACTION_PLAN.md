# Next gate — engineering validation, not another cosmetic revision

1. Choose exact materials/processes and get supplier properties/allowables.
2. Put the rail cavity, index-hole edge ligaments, bridge, pin, stop and deck bosses through independent material-specific structural FEA and tolerance review.
3. Manufacture a bench specimen; gauge channel, rails, holes, pin, bridge overlap, surface finish and actual masses.
4. Execute guarded static/eccentric load, pin retention/stop impact, adjustment-cycle, outsole flex/tear/abrasion and fastener-retention tests under engineering supervision.
5. Fix failures and repeat all affected tests. Obtain a verified last and finish the upper pattern/fit validation.
6. No child-worn trial or running/sprinting test until independent review and all required gates pass.
