# Apex Stride Pro — speed expectation (not a prediction)

A published study of young male football players aged 12–16 reported 30 m sprint times for the age-12 group of 4.862 s at the median, 4.554 s at the 90th percentile, and 4.395 s at the 97th percentile. Average speeds over 30 m are approximately 22.2, 23.7 and 24.6 km/h. These are a trained academy-player comparison group, not a prediction for one child, and average 30 m speed is not instantaneous peak speed.

Source: Nowak et al., *Normative and limit values of speed, endurance and power tests results of young football players*, Frontiers in Physiology (2025), https://doi.org/10.3389/fphys.2024.1502694

## No evidence-based speed gain for this design

Apex Stride Pro has not been physically built and safety-tested. There is no defensible number for a speed boost; the shoe could help, do nothing, or make performance worse. A 2025 systematic review of footwear studies discusses running economy in adult distance-running contexts, not speed gains for this adjustable shoe or for children sprinting. Source: Xu et al., *The role of footwear in improving running economy: a systematic review with meta-analysis of controlled trials*, Scientific Reports (2025), https://doi.org/10.1038/s41598-025-88271-2

After independent clearance of a physical design, establish a baseline with several supervised 30 m runs in the same normal shoes and use the same course, surface and timing method. Do not run in the current prototype.
