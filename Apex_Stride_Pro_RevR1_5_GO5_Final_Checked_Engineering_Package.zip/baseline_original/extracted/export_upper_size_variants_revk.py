#!/usr/bin/env python3
"""Export and audit Rev K upper mockup components for EU42 and EU46."""
from pathlib import Path
import subprocess, csv, json, time
import trimesh
ROOT=Path(__file__).resolve().parent
SRC=ROOT/'Apex_Stride_Pro_RevK.scad'
OUT=ROOT/'generated'/'upper_mockup'
RES=ROOT/'verification_results'; RES.mkdir(exist_ok=True)
parts={
 'toe_vamp_shell':'toe_vamp_shell',
 'heel_counter_shell':'heel_counter_shell',
 'upper_wall_shell':'upper_wall_shell',
 'upper_lateral_overlays':'upper_lateral_overlays',
 'upper_velcro_straps':'upper_velcro_straps',
 'upper_strap_anchor_doublers':'upper_strap_anchor_doublers',
 'upper_tongue':'upper_tongue',
}
rows=[]
for size in (42,46):
    for stem,sel in parts.items():
        dst=OUT/f'EU{size}'/f'{stem}.stl'; dst.parent.mkdir(parents=True,exist_ok=True)
        t0=time.time()
        cp=subprocess.run(['openscad','--export-format','binstl','-o',str(dst),'-D',f'eu_size={size}','-D','width_scale=1.00','-D',f'part="{sel}"',str(SRC)],capture_output=True,text=True,timeout=120)
        if cp.returncode or not dst.exists() or dst.stat().st_size<500:
            raise RuntimeError(f'OpenSCAD export failed EU{size} {sel}: {cp.stdout[-1000:]} {cp.stderr[-1000:]}')
        m=trimesh.load_mesh(dst,force='mesh',process=True)
        good=bool(m.is_watertight and m.is_winding_consistent and m.volume>0)
        bounds=m.bounds
        rows.append({'size':f'EU{size}','part':stem,'file':str(dst.relative_to(ROOT)),'bytes':dst.stat().st_size,'faces':len(m.faces),'watertight':bool(m.is_watertight),'winding_consistent':bool(m.is_winding_consistent),'positive_volume':bool(m.volume>0),'volume_cm3':round(float(m.volume)/1000,5),'x_min_mm':round(float(bounds[0,0]),3),'x_max_mm':round(float(bounds[1,0]),3),'y_min_mm':round(float(bounds[0,1]),3),'y_max_mm':round(float(bounds[1,1]),3),'z_min_mm':round(float(bounds[0,2]),3),'z_max_mm':round(float(bounds[1,2]),3),'seconds':round(time.time()-t0,2),'status':'PASS' if good else 'FAIL'})
        print(f'EU{size} {stem}: {"PASS" if good else "FAIL"}',flush=True)
outcsv=RES/'REV_K_UPPER_SIZE_EXPORT_CHECKS.csv'
with outcsv.open('w',newline='',encoding='utf-8') as f:
    w=csv.DictWriter(f,fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
assert len(rows)==14 and all(r['status']=='PASS' for r in rows)
(RES/'REV_K_UPPER_SIZE_EXPORT_SUMMARY.json').write_text(json.dumps({'count':len(rows),'pass_count':sum(r['status']=='PASS' for r in rows),'fail_count':sum(r['status']!='PASS' for r in rows),'all_watertight':all(r['watertight'] for r in rows),'all_winding_consistent':all(r['winding_consistent'] for r in rows),'all_positive_volume':all(r['positive_volume'] for r in rows),'sizes':['EU42','EU46'],'parts_per_size':len(parts)},indent=2)+'\n')
