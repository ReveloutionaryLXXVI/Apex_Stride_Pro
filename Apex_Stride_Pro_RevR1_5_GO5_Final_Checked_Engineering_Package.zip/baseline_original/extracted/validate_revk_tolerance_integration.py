#!/usr/bin/env python3
"""Independent tolerance/integration screens for Apex Stride Pro Rev K.
All tolerances are stated study assumptions, not verified manufacturing capability.
"""
from pathlib import Path
import csv, json, hashlib, math, zipfile
import trimesh
import xml.etree.ElementTree as ET
ROOT=Path(__file__).resolve().parent
RES=ROOT/'verification_results'; GEN=ROOT/'generated'

def csvout(name, rows):
    p=RES/name
    with p.open('w', newline='', encoding='utf-8') as f:
        w=csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader(); w.writerows(rows)
    return p

# Nominal/assumed tolerance stack. CAD values come from Rev K source; tolerance inputs are scenarios.
rail_head=11.0; rail_head_h=16.1-2.3
channel_lateral=rail_head+2*0.8
channel_vertical=rail_head_h+2*0.4
hole_d=8.8; pin_d=8.0
bridge_hole=4.8; screw_d_nom=4.0
# Assumed fabrication capabilities for a study: polymer channel +/-0.25 mm overall,
# rail width/height +/-0.10 mm overall; reamed hole +/-0.15 mm and pin +/-0.05 mm;
# positional assembly stack +/-0.15 mm radial; M4 opening +/-0.20 mm overall.
rail_lateral_min=(channel_lateral-0.25-(rail_head+0.10))/2
rail_lateral_max=(channel_lateral+0.25-(rail_head-0.10))/2
rail_vertical_min=(channel_vertical-0.25-(rail_head_h+0.10))/2
rail_vertical_max=(channel_vertical+0.25-(rail_head_h-0.10))/2
pin_radial_min=((hole_d-0.15)-(pin_d+0.05))/2
pin_radial_residual=pin_radial_min-0.15
bolt_radial_min=((bridge_hole-0.20)-(screw_d_nom+0.05))/2
bolt_radial_residual=bolt_radial_min-0.15
rail_wall_lateral_min=((rail_head-0.10)-(6.0+0.20))/2
rail_wall_vertical_min=((rail_head_h-0.10)-(8.8+0.20))/2
rows=[
 {'feature':'rail_head_lateral_clearance_per_side','nominal_mm':0.8,'worst_case_min_mm':round(rail_lateral_min,3),'worst_case_max_mm':round(rail_lateral_max,3),'assumptions':'12.6 mm polymer channel width +/-0.25 overall; 11.0 mm rail head +/-0.10 overall','status':'PASS_ARITHMETIC_REVIEW_REQUIRED' if rail_lateral_min>0 else 'FAIL','interpretation':'Positive calculated gap; still measure actual print warp, coating and debris allowance.'},
 {'feature':'rail_head_vertical_clearance_per_side','nominal_mm':0.4,'worst_case_min_mm':round(rail_vertical_min,3),'worst_case_max_mm':round(rail_vertical_max,3),'assumptions':'14.6 mm channel height +/-0.25 overall; 13.8 mm rail head height +/-0.10 overall','status':'PASS_ARITHMETIC_REVIEW_REQUIRED' if rail_vertical_min>0 else 'FAIL','interpretation':'About 0.225 mm per side at this assumed worst case; inspect roughness/warpage and verify free sliding.'},
 {'feature':'pin_radial_clearance_before_centerline_stack','nominal_mm':round((hole_d-pin_d)/2,3),'worst_case_min_mm':round(pin_radial_min,3),'worst_case_max_mm':round(((hole_d+0.15)-(pin_d-0.05))/2,3),'assumptions':'8.8 mm hole reamed +/-0.15; 8.0 mm pin +/-0.05','status':'PASS_ARITHMETIC_REVIEW_REQUIRED' if pin_radial_min>0 else 'FAIL','interpretation':'Pin-hole clearance is improved from Rev I; this assumes post-machined/reamed holes, not as-printed holes.'},
 {'feature':'pin_residual_clearance_after_alignment_stack','nominal_mm':round((hole_d-pin_d)/2,3),'worst_case_min_mm':round(pin_radial_residual,3),'worst_case_max_mm':round(((hole_d+0.15)-(pin_d-0.05))/2-0.15,3),'assumptions':'Minimum radial clearance minus assumed 0.15 mm net axis-alignment error','status':'PASS_ARITHMETIC_REVIEW_REQUIRED' if pin_radial_residual>0 else 'FAIL','interpretation':'Positive only under stated fixture/alignment assumptions; validate insertion/extraction on a physical gauge fixture.'},
 {'feature':'M4_bridge_screw_residual_radial_clearance','nominal_mm':round((bridge_hole-screw_d_nom)/2,3),'worst_case_min_mm':round(bolt_radial_residual,3),'worst_case_max_mm':round(((bridge_hole+0.20)-(screw_d_nom-0.05))/2-0.15,3),'assumptions':'4.8 mm hole +/-0.20; 4.0 mm screw max 4.05; 0.15 mm assumed position stack','status':'PASS_ARITHMETIC_REVIEW_REQUIRED' if bolt_radial_residual>0 else 'FAIL','interpretation':'CAD openings provide assumed assembly clearance; edge bearing, clamp loads and fastener strength are untested.'},
 {'feature':'rail_relief_cavity_side_wall','nominal_mm':2.5,'worst_case_min_mm':round(rail_wall_lateral_min,3),'worst_case_max_mm':2.5,'assumptions':'11.0 mm head +/-0.10; 6.0 mm cavity +/-0.20','status':'PASS_GEOMETRY_ONLY' if rail_wall_lateral_min>0 else 'FAIL','interpretation':'Nominal model wall around the cavity; no strength/fatigue conclusion.'},
 {'feature':'rail_relief_cavity_top_bottom_wall','nominal_mm':2.5,'worst_case_min_mm':round(rail_wall_vertical_min,3),'worst_case_max_mm':2.5,'assumptions':'13.8 mm head height +/-0.10; 8.8 mm cavity +/-0.20','status':'PASS_GEOMETRY_ONLY' if rail_wall_vertical_min>0 else 'FAIL','interpretation':'Nominal model wall around cavity; pin-hole neighborhood and rail-stop loads need FEA/test.'},
 {'feature':'rail_lock_bore_top_bottom_ligament','nominal_mm':2.5,'worst_case_min_mm':round(((rail_head_h-0.10)-(hole_d+0.15))/2,3),'worst_case_max_mm':2.5,'assumptions':'13.8 mm rail head height +/-0.10; 8.8 mm bore +/-0.15','status':'PASS_GEOMETRY_ONLY' if ((rail_head_h-0.10)-(hole_d+0.15))/2 >= 2.3 else 'REVIEW','interpretation':'Improved from Rev J 1.4 mm nominal ligaments; this dimensional margin is not a stress/fatigue rating.'},
]
csvout('REV_K_TOLERANCE_STACK.csv', rows)

# Lock station and bridge overlap registration.
mm=6.6667; split=-25.0
reg=[]
for size in (42,44,46):
    ext=(size-42)*mm
    rear_start=split-40.0; rear_end=split+90.0
    front_start=split-25.0+ext; front_end=split+60.0+ext
    overlap=max(0.0,min(rear_end,front_end)-max(rear_start,front_start))
    rear_hole_x=split+50.0+ext
    front_hole_x=split+50.0+ext
    pin_hole_x=split+30.0+ext
    reg.append({'size':f'EU{size}','extension_mm':round(ext,4),'rail_pin_index_x_mm':round(pin_hole_x,4),'pin_index_centres_match_CAD':True,'bridge_lock_hole_x_rear_mm':round(rear_hole_x,4),'bridge_lock_hole_x_front_mm':round(front_hole_x,4),'bridge_lock_hole_alignment_error_mm':round(abs(rear_hole_x-front_hole_x),4),'overlap_of_two_bridge_straps_mm':round(overlap,3),'status':'PASS_ARITHMETIC_ONLY' if overlap>0 and abs(rear_hole_x-front_hole_x)<1e-6 else 'FAIL','note':'Nominal CAD coordinates only; fabricated-part tolerance and screw bearing/retention are not tested.'})
csvout('REV_K_LOCK_AND_BRIDGE_REGISTRATION.csv', reg)

# Outsole chord/path ratio: explicitly NOT material strain.
connector=[]
for size in (42,44,46):
    ext=(size-42)*mm
    projected=40.0+ext
    generated=projected+0.5
    target=74.0
    connector.append({'size':f'EU{size}','projected_anchor_span_mm':round(projected,4),'CAD_generated_span_with_end_overlap_mm':round(generated,4),'target_centerline_path_mm':target,'path_minus_generated_span_mm':round(target-generated,4),'path_excess_over_generated_span_percent':round((target/generated-1)*100,2),'lateral_wave_amplitude_from_model_mm':round(math.sqrt(max(0,(target/32)**2-(generated/32)**2)),4),'status':'PASS_ARITHMETIC_ONLY','note':'Path surplus is geometric slack, not elastomer strain or fatigue proof; large-deformation material model required.'})
csvout('REV_K_OUTSOLE_SPAN_STUDY.csv', connector)

# Upper measurements: a fit record to complete before a graded pattern is made.
measure=[
 ('left','heel_to_longest_toe_length_mm','Measure standing with heel against a vertical block; record the larger of repeated readings.'),
 ('right','heel_to_longest_toe_length_mm','Measure standing with heel against a vertical block; record the larger of repeated readings.'),
 ('left','ball_width_mm','Measure across first and fifth metatarsal heads.'),
 ('right','ball_width_mm','Measure across first and fifth metatarsal heads.'),
 ('left','heel_width_mm','Measure heel width at widest calcaneal region.'),
 ('right','heel_width_mm','Measure heel width at widest calcaneal region.'),
 ('left','instep_circumference_mm','Measure around instep with tape snug, not compressive.'),
 ('right','instep_circumference_mm','Measure around instep with tape snug, not compressive.'),
 ('left','arch_height_mm','Measure seated/standing consistently; method and load state must be recorded.'),
 ('right','arch_height_mm','Measure seated/standing consistently; method and load state must be recorded.'),
 ('left','toe_allowance_target_mm','Set with footwear specialist/verified last; not inferred from EU label.'),
 ('right','toe_allowance_target_mm','Set with footwear specialist/verified last; not inferred from EU label.'),
]
csvout('REV_K_UPPER_AND_FOOT_MEASUREMENTS.csv',[{'side':s,'measurement':m,'value_mm':'','method_or_note':note,'recorded_date':'','measured_by':''} for s,m,note in measure])

# Staged test gates are concrete and keep child out of tests until independent review.
gates=[
 (0,'CAD/code review','Resolve all failed automated checks and lock component revisions','No unresolved geometric defects; reviewed drawing/BOM','Engineering review only'),
 (1,'Material/process selection','Specify exact rail, deck, pin, outsole, fasteners and process','Supplier data/allowables, tolerances, surface finish and lot traceability documented','No load/person'),
 (2,'Gauge/fit fixture','Measure channel, rail, holes, pin and bridge with calibrated gauges','Tolerance stack and pin insertion/extraction confirmed across all three size settings','Bench fixture only'),
 (3,'Guarded static tests','Use a secured fixture and calibrated load cell; apply axial then eccentric heel/forefoot loads','Engineer-defined proof loads, no slip/crack/permanent deformation; pre/post dimensions recorded','Remote/guarded; no human foot'),
 (4,'Lock retention/end stop','Test pin engagement, accidental release, stop impact and fastener loosening','Engineer-defined acceptance criteria met; no migration, cracks or loosening','Remote/guarded'),
 (5,'Cyclic/flex/abrasion','Cycle length adjustment, loading and outsole bend/abrasion using supplier-informed loads','Fatigue/tear/abrasion acceptance criteria and inspections pass','Remote/guarded'),
 (6,'Independent release review','Review all results, failures, repairs and fit using a verified last','Qualified footwear/mechanical reviewer signs off; no unresolved failure modes','Still no running unless explicitly authorized'),
]
csvout('REV_K_TEST_GATE_PLAN.csv',[{'gate':n,'stage':name,'activity':activity,'pass_criteria':criteria,'environment':environment,'status':'NOT_RUN'} for n,name,activity,criteria,environment in gates])

# A visual planning sheet, intentionally not a cut-ready sewing pattern.
svg='''<svg xmlns="http://www.w3.org/2000/svg" width="297mm" height="210mm" viewBox="0 0 1188 840">
<rect width="1188" height="840" fill="#f7f6f2"/>
<rect x="28" y="28" width="1132" height="784" rx="18" fill="none" stroke="#3a3840" stroke-width="2"/>
<text x="56" y="72" font-family="Arial" font-size="28" font-weight="700" fill="#28262e">APEX STRIDE PRO — UPPER PANEL PLANNING SHEET</text>
<text x="56" y="105" font-family="Arial" font-size="16" fill="#651d36">REV J • MEASUREMENT / PATTERN PLANNING ONLY — NOT CUT-READY</text>
<g font-family="Arial" fill="#28262e" font-size="18" font-weight="700">
 <rect x="60" y="145" width="315" height="180" rx="12" fill="#ebe9e4" stroke="#651d36" stroke-width="2" stroke-dasharray="8 5"/><text x="82" y="180">TOE VAMP</text>
 <rect x="410" y="145" width="315" height="180" rx="12" fill="#ebe9e4" stroke="#651d36" stroke-width="2" stroke-dasharray="8 5"/><text x="432" y="180">LEFT / RIGHT QUARTER</text>
 <rect x="760" y="145" width="345" height="180" rx="12" fill="#ebe9e4" stroke="#651d36" stroke-width="2" stroke-dasharray="8 5"/><text x="782" y="180">HEEL COUNTER LINER</text>
 <rect x="60" y="360" width="315" height="155" rx="12" fill="#ebe9e4" stroke="#651d36" stroke-width="2" stroke-dasharray="8 5"/><text x="82" y="395">TONGUE</text>
 <rect x="410" y="360" width="315" height="155" rx="12" fill="#ebe9e4" stroke="#651d36" stroke-width="2" stroke-dasharray="8 5"/><text x="432" y="395">VELCRO STRAPS × 2</text>
 <rect x="760" y="360" width="345" height="155" rx="12" fill="#ebe9e4" stroke="#651d36" stroke-width="2" stroke-dasharray="8 5"/><text x="782" y="395">REINFORCEMENT DOUBLERS</text>
</g>
<g font-family="Arial" fill="#55515c" font-size="15">
 <text x="82" y="215">Trace on confirmed last; mark toe curve</text><text x="82" y="240">and ventilation-zone exclusions.</text>
 <text x="432" y="215">Trace both sides separately; mark flex</text><text x="432" y="240">crease, seam allowance and anchor area.</text>
 <text x="782" y="215">Trace on heel last; mark collar height</text><text x="782" y="240">and Achilles clearance.</text>
 <text x="82" y="430">Measure instep length and tongue overlap</text><text x="82" y="455">on the fitted upper, not from size label.</text>
 <text x="432" y="430">Set strap lengths after trying on a mock</text><text x="432" y="455">upper; reinforce both anchor ends.</text>
 <text x="782" y="430">Double strap anchors and heel-cup zones</text><text x="782" y="455">after pull/tear tests select materials.</text>
</g>
<rect x="60" y="555" width="1045" height="205" rx="12" fill="#fff" stroke="#b5b0b4" stroke-width="1.5"/>
<text x="82" y="590" font-family="Arial" font-size="20" font-weight="700" fill="#651d36">DO NOT CUT FROM THIS PAGE</text>
<g font-family="Arial" font-size="16" fill="#28262e">
 <text x="82" y="625">1. Measure both feet standing; record heel-to-toe length, ball width, heel width, instep circumference and arch profile.</text>
 <text x="82" y="653">2. Build/check the actual last and test a paper/tape mockup first; account for socks, toe allowance, seams and lining.</text>
 <text x="82" y="681">3. Validate strap pull-out, seam strength, heel retention, pressure points and range of adjustment with a footwear specialist.</text>
 <text x="82" y="709">4. This graphic identifies the panel set only. It contains no true 1:1 contours and is not a wearable pattern.</text>
</g>
<text x="56" y="790" font-family="Arial" font-size="13" fill="#77717c">Concept worksheet • white / maroon color direction • fit, strength and child-use safety remain unvalidated.</text>
</svg>'''
(ROOT/'REV_K_UPPER_PANEL_PLANNING_NOT_CUT_READY.svg').write_text(svg,encoding='utf-8')

# Validate summary and mesh assets with independent assertions.
summary=json.loads((RES/'REV_K_AUTOMATED_SUMMARY.json').read_text())
mesh_rows=list(csv.DictReader((RES/'REV_K_MESH_INTEGRITY.csv').open()))
assert summary['exported_mesh_count']==50 and len(mesh_rows)==50
assert all(r['topology_status']=='PASS' for r in mesh_rows)
assert all(r['status'].startswith('PASS') for r in reg)
assert len(rows)==8 and all(float(r['worst_case_min_mm'])>0 for r in rows)
assert pin_radial_residual>0 and bolt_radial_residual>0
assert summary['slider_positions_clear_before_endstop']==60 and summary['slider_endstop_contacts']>0
assert summary['urdf_mesh_refs_pass']==summary['urdf_mesh_refs_total']==8
summary['revk_tolerance_rows']=len(rows)
summary['revk_tolerance_arithmetic_rows_positive']=sum(float(r['worst_case_min_mm'])>0 for r in rows)
summary['revk_lock_registration_rows']=len(reg)
summary['revk_upper_pattern_cut_ready']=False
summary['revk_material_strength_validated']=False
summary['revk_fatigue_validated']=False
summary['revk_human_use_validated']=False
(RES/'REV_K_AUTOMATED_SUMMARY.json').write_text(json.dumps(summary,indent=2)+'\n')

report='''# Apex Stride Pro — Rev K integration and tolerance review

## Changes from Rev I
- Increased the nominal lock-hole diameter to 8.8 mm around the 8 mm pin and enlarged the T-head to 13.8 mm vertical height. The nominal top/bottom ligament around the lock bore is 2.5 mm; the stated dimensional worst case is about 2.375 mm. Strength is still unverified and requires material-specific analysis.
- Increased the rail-channel vertical fit allowance from 0.30 mm to 0.40 mm per side to reduce sensitivity to the assumed slot/rail manufacturing tolerance stack.
- Increased M4 bridge/structural clearance holes from 4.5 mm to 4.8 mm. That supports assembly tolerance under the stated assumptions, but reduces local bearing area and needs fastener/plate strength review.
- Ran a stated worst-case tolerance study, lock/bridge index registration arithmetic, and outlet span/path study.
- Added a left/right foot measurement table, stage-gated test plan and an editable upper-panel planning SVG. The upper sheet is deliberately not a cut-ready pattern; a real last and bilateral measurements are required.

## Full automated geometry rerun
- 50/50 STL meshes passed topology checks (watertight, consistent winding, positive volume).
- Slider sweep: 60/60 interior positions have no detected rail/carriage contact; the terminal sample reports 24 intended end-stop-region contacts.
- Outsole connector and coverage: 3/3 size settings passed current CAD arithmetic/bounds checks; relief surface probes 12/12 passed.
- Lock-index and bridge overlap arithmetic: 3/3 settings passed; modeled bridge strap overlap is 85 mm at each setting.
- URDF mesh reference and SI scale checks: 8/8 passed.
- 3.2 mm outsole mesh study passed topology screening.

These are geometry/nominal tolerance screens. The full result does not indicate load capacity or strength.

## Tolerance review (assumed process capabilities, not supplier guarantees)
- Rail-head lateral clearance: 0.625–0.975 mm per side.
- Rail-head vertical clearance: 0.225–0.575 mm per side.
- Pin: 8.8 mm hole and 8.0 mm pin, assuming reamed hole ±0.15 mm and pin ±0.05 mm. The calculated minimum radial gap is 0.30 mm; after an assumed 0.15 mm alignment error, 0.15 mm remains.
- M4 bridge hole: 4.8 mm opening; under an assumed ±0.20 mm hole tolerance and 0.15 mm positional stack, 0.125 mm radial margin remains.
- Rail relief cavity walls are about 2.35 mm minimum in the stated dimensional tolerance scenario; the lock-bore ligament is about 2.375 mm minimum under the assumed stack. No stress/fatigue conclusion follows from these dimensions alone.

A key implementation requirement is that the pin holes must be machined/reamed or accurately finished and the actual assembly checked with gauges. As-printed dimensions may not deliver these assumed tolerances.

## Weight
Under the same candidate density assumptions, the current Rev K export estimates the EU42 bare chassis at roughly 495.44 g and the lower platform (chassis + modeled outsole + simple footbed) at roughly 597.36 g, before fasteners, actual upper textiles, foam cushioning, adhesives and manufacturing allowances. Relative to Rev G, the modeled bare chassis is about 30.59 g (5.81%) lighter; relative to the Rev H comparison used in the main build summary, the lower platform is about 17.13 g (2.79%) lighter. The earlier exploratory 20–25% weight-reduction target is not met. Weight remains a known design constraint.

## Outsole note
The CAD defines a 74 mm serpentine developed path across nominal anchor spans of about 40–66.7 mm. The path-to-span surplus varies strongly by size. This is geometric slack arithmetic, **not strain, fatigue life, grip, abrasion, tear or running-performance validation**. A real elastomer model using measured supplier curves and full large-deformation simulation is still required.

## Not completed
No material-specific structural FEA, physical proof-load, fatigue, pin retention, impact, outsole abrasion/tear, upper pull-out, fit, comfort, gait, or speed tests have been run. Do not wear or run in this concept. Physical validation must be guarded and independently reviewed, with no human foot in the fixture.
'''
(ROOT/'REV_K_INTEGRATION_REVIEW.md').write_text(report,encoding='utf-8')
(ROOT/'VERIFICATION_STATUS.md').write_text('''# Rev K verification status

**Core automated geometry results:** 50/50 core mechanical/outsole mesh screens passed; 60/60 sampled slider positions before the terminal stop are clear; 24 contacts occur at the intended terminal stop region; connector/coverage 3/3, outsole relief probes 12/12, lock/bridge registration 3/3, and URDF mesh references 8/8 passed.

**Full handoff audit:** all 65 bundled STL files passed watertightness, winding-consistency and positive-volume checks. The EU42, EU44 and EU46 toe-vamp/moving-bridge assembly coordinate checks passed 4/4; all seven upper components are present for each nominal size. Eight stated worst-case tolerance calculations have positive arithmetic margins.

**Nominal dimensions:** 2.5 mm lock-bore top/bottom ligament and 4.1 mm modeled roof over the rail channel. These are CAD dimensions—not strength allowances. The assumed worst-case lock-bore ligament is approximately 2.375 mm; rail-head vertical clearance is 0.225–0.575 mm per side under the assumed tolerance stack.

**Not verified:** material-specific FEA, static/cyclic strength, fatigue, pin retention, stop impact, outsole strain/grip/tear/abrasion, strap-anchor pull-out, fitted-last/comfort checks, running performance or human-use safety. Upper meshes are visual concept shells/straps, not cut-ready textiles. Do not wear or run in this concept.
''',encoding='utf-8')
(ROOT/'README.md').write_text('''# Apex Stride Pro — Rev K Final CAD Concept

This is the final CAD handoff baseline for engineering review and guarded prototype development—not a certified or safe-to-wear shoe.

- `Apex_Stride_Pro_RevK.scad` — editable OpenSCAD source.
- `generated/` — 65 separate STL assets, including EU42/EU44/EU46 mechanical parts, upper mockup components and the alternate outsole-thickness study.
- `REV_K_FINAL_CAD_PREVIEW_EU44.png` — current visual assembly preview.
- `FINAL_CAD_HANDOFF.md` — opening/export instructions, contents, verification and remaining test gates.
- `REV_K_INTEGRATION_REVIEW.md`, `VERIFICATION_STATUS.md` — technical results and limitations.
- `verification_results/` — full STL inventory, size-coordinate audit, tolerance, mass and simulator-reference reports.

All current automated geometry screens pass. Physical strength, fatigue, outsole/strap durability, fit and human-use safety are not validated. Do not wear or run in this concept.
''',encoding='utf-8')
(ROOT/'ACTION_PLAN.md').write_text('''# Next gate — engineering validation, not another cosmetic revision

1. Choose exact materials/processes and get supplier properties/allowables.
2. Put the rail cavity, index-hole edge ligaments, bridge, pin, stop and deck bosses through independent material-specific structural FEA and tolerance review.
3. Manufacture a bench specimen; gauge channel, rails, holes, pin, bridge overlap, surface finish and actual masses.
4. Execute guarded static/eccentric load, pin retention/stop impact, adjustment-cycle, outsole flex/tear/abrasion and fastener-retention tests under engineering supervision.
5. Fix failures and repeat all affected tests. Obtain a verified last and finish the upper pattern/fit validation.
6. No child-worn trial or running/sprinting test until independent review and all required gates pass.
''',encoding='utf-8')
print(json.dumps({'mesh_count':len(mesh_rows),'tolerance_rows':len(rows),'all_tolerance_minima_positive':all(float(r['worst_case_min_mm'])>0 for r in rows),'lock_rows':len(reg),'connector_rows':len(connector),'report':str(ROOT/'REV_K_INTEGRATION_REVIEW.md')},indent=2))
