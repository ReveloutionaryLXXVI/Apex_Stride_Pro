from pathlib import Path
import trimesh, numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d.art3d import Poly3DCollection

ROOT=Path(__file__).resolve().parent
D=ROOT/'generated'/'EU44'
OUT=ROOT/'REV_K_FINAL_CAD_PREVIEW_EU44.png'

# Explicit color palette for the requested white-and-maroon concept.
parts = [
    ('outsole_assembly.stl', '#292a2e', 'Outsole'),
    ('heel_deck.stl', '#62656a', 'Chassis'),
    ('toe_carriage.stl', '#777a80', 'Chassis'),
    ('bridge_rear.stl', '#55585e', 'Bridge'),
    ('bridge_front.stl', '#55585e', 'Bridge'),
    ('rail_left.stl', '#41434a', 'Rails'),
    ('rail_right.stl', '#41434a', 'Rails'),
    ('locking_pin_solid.stl', '#a1a2a5', 'Pin'),
    ('footbed_insert.stl', '#d6d3cc', 'Footbed'),
    ('upper_wall_shell.stl', '#e7e4de', 'Upper sidewall'),
    ('toe_vamp_shell.stl', '#f3f3f0', 'Toe vamp'),
    ('heel_counter_shell.stl', '#651d36', 'Maroon heel counter'),
    ('upper_lateral_overlays.stl', '#751e3b', 'Maroon overlays'),
    ('upper_velcro_straps.stl', '#6d1b37', 'Velcro straps'),
    ('upper_strap_anchor_doublers.stl', '#651d36', 'Strap anchor doublers'),
    ('upper_tongue.stl', '#dededb', 'Tongue'),
]

fig=plt.figure(figsize=(16,8), dpi=170, facecolor='#f5f4f0')
ax=fig.add_subplot(1,2,1,projection='3d',facecolor='#f5f4f0')
ax2=fig.add_subplot(1,2,2,projection='3d',facecolor='#f5f4f0')

def add_mesh(ax, fn, color, alpha=1.0, max_faces=10000):
    m=trimesh.load(D/fn,force='mesh',process=False)
    faces=m.faces
    if len(faces)>max_faces:
        # Deterministic uniform sampling keeps rendering bounded while preserving coverage.
        ix=np.linspace(0,len(faces)-1,max_faces,dtype=int); faces=faces[ix]
    tris=m.vertices[faces]
    coll=Poly3DCollection(tris, facecolor=color, edgecolor=(0,0,0,0.05), linewidth=0.06, alpha=alpha)
    coll.set_zsort('average'); ax.add_collection3d(coll)
    return m

# Main assembled conceptual side/top view.
for fn,color,_ in parts:
    if (D/fn).exists(): add_mesh(ax,fn,color,alpha=0.98,max_faces=7500)
ax.view_init(elev=68,azim=-90)
ax.set_xlim(-160,170); ax.set_ylim(-68,68); ax.set_zlim(-31,32)
ax.set_box_aspect((330,136,63)); ax.set_axis_off()
ax.set_title('APEX STRIDE PRO  ·  REV K', fontsize=15, fontweight='bold', pad=8, color='#22242a')
# arrows are avoided to keep it clean; add a small subtitle in the 2D figure frame.

# Outsole underside perspective, with the relief zones visible.
out=trimesh.load(D/'outsole_assembly.stl',force='mesh',process=False)
tris=out.vertices[out.faces]
coll=Poly3DCollection(tris, facecolor='#292a2e', edgecolor='#77797d', linewidth=0.12, alpha=1.0)
ax2.add_collection3d(coll)
ax2.view_init(elev=76,azim=-90)
ax2.set_xlim(-160,170); ax2.set_ylim(-58,58); ax2.set_zlim(-26, -19)
ax2.set_box_aspect((330,116,7)); ax2.set_axis_off()
ax2.set_title('OUTSOLE UNDERSIDE · RELIEF CHANNELS', fontsize=13, fontweight='bold', pad=8, color='#22242a')
fig.text(0.5,0.035,'Concept visualization only — not a manufacturing drawing or proof of fit/strength.',ha='center',fontsize=10,color='#55565b')
fig.tight_layout(rect=(0.02,0.06,0.98,0.97), w_pad=2)
fig.savefig(OUT,bbox_inches='tight',facecolor=fig.get_facecolor())
print(OUT, OUT.stat().st_size)
