@echo off
setlocal
python build_and_validate_revk.py || exit /b 1
python export_upper_size_variants_revk.py || exit /b 1
python validate_revk_tolerance_integration.py || exit /b 1
python audit_final_cad_revk.py || exit /b 1
endlocal
