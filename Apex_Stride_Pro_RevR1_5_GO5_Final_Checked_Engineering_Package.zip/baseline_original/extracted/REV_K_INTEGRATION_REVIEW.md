# Apex Stride Pro — Rev K integration and tolerance review

## Changes from Rev I
- Increased the nominal lock-hole diameter to 8.8 mm around the 8 mm pin and enlarged the T-head to 13.8 mm vertical height. The nominal top/bottom ligament around the lock bore is 2.5 mm; the stated dimensional worst case is about 2.375 mm. Strength is still unverified and requires material-specific analysis.
- Increased the rail-channel vertical fit allowance from 0.30 mm to 0.40 mm per side to reduce sensitivity to the assumed slot/rail manufacturing tolerance stack.
- Increased M4 bridge/structural clearance holes from 4.5 mm to 4.8 mm. That supports assembly tolerance under the stated assumptions, but reduces local bearing area and needs fastener/plate strength review.
- Ran a stated worst-case tolerance study, lock/bridge index registration arithmetic, and outlet span/path study.
- Added a left/right foot measurement table, stage-gated test plan and an editable upper-panel planning SVG. The upper sheet is deliberately not a cut-ready pattern; a real last and bilateral measurements are required.

## Full automated geometry rerun
- 50/50 STL meshes passed topology checks (watertight, consistent winding, positive volume).
- Slider sweep: 60/60 interior positions have no detected rail/carriage contact; the terminal sample reports 24 intended end-stop-region contacts.
- Outsole connector and coverage: 3/3 size settings passed current CAD arithmetic/bounds checks; relief surface probes 12/12 passed.
- Lock-index and bridge overlap arithmetic: 3/3 settings passed; modeled bridge strap overlap is 85 mm at each setting.
- URDF mesh reference and SI scale checks: 8/8 passed.
- 3.2 mm outsole mesh study passed topology screening.

These are geometry/nominal tolerance screens. The full result does not indicate load capacity or strength.

## Tolerance review (assumed process capabilities, not supplier guarantees)
- Rail-head lateral clearance: 0.625–0.975 mm per side.
- Rail-head vertical clearance: 0.225–0.575 mm per side.
- Pin: 8.8 mm hole and 8.0 mm pin, assuming reamed hole ±0.15 mm and pin ±0.05 mm. The calculated minimum radial gap is 0.30 mm; after an assumed 0.15 mm alignment error, 0.15 mm remains.
- M4 bridge hole: 4.8 mm opening; under an assumed ±0.20 mm hole tolerance and 0.15 mm positional stack, 0.125 mm radial margin remains.
- Rail relief cavity walls are about 2.35 mm minimum in the stated dimensional tolerance scenario; the lock-bore ligament is about 2.375 mm minimum under the assumed stack. No stress/fatigue conclusion follows from these dimensions alone.

A key implementation requirement is that the pin holes must be machined/reamed or accurately finished and the actual assembly checked with gauges. As-printed dimensions may not deliver these assumed tolerances.

## Weight
Under the same candidate density assumptions, the current Rev K export estimates the EU42 bare chassis at roughly 495.44 g and the lower platform (chassis + modeled outsole + simple footbed) at roughly 597.36 g, before fasteners, actual upper textiles, foam cushioning, adhesives and manufacturing allowances. Relative to Rev G, the modeled bare chassis is about 30.59 g (5.81%) lighter; relative to the Rev H comparison used in the main build summary, the lower platform is about 17.13 g (2.79%) lighter. The earlier exploratory 20–25% weight-reduction target is not met. Weight remains a known design constraint.

## Outsole note
The CAD defines a 74 mm serpentine developed path across nominal anchor spans of about 40–66.7 mm. The path-to-span surplus varies strongly by size. This is geometric slack arithmetic, **not strain, fatigue life, grip, abrasion, tear or running-performance validation**. A real elastomer model using measured supplier curves and full large-deformation simulation is still required.

## Not completed
No material-specific structural FEA, physical proof-load, fatigue, pin retention, impact, outsole abrasion/tear, upper pull-out, fit, comfort, gait, or speed tests have been run. Do not wear or run in this concept. Physical validation must be guarded and independently reviewed, with no human foot in the fixture.
