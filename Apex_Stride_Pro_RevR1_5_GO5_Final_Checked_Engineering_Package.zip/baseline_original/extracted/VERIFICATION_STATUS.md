# Rev K verification status

**Core automated geometry results:** 50/50 core mechanical/outsole mesh screens passed; 60/60 sampled slider positions before the terminal stop are clear; 24 contacts occur at the intended terminal stop region; connector/coverage 3/3, outsole relief probes 12/12, lock/bridge registration 3/3, and URDF mesh references 8/8 passed.

**Full handoff audit:** all 65 bundled STL files passed watertightness, winding-consistency and positive-volume checks. The EU42, EU44 and EU46 toe-vamp/moving-bridge assembly coordinate checks passed 4/4; all seven upper components are present for each nominal size. Eight stated worst-case tolerance calculations have positive arithmetic margins.

**Nominal dimensions:** 2.5 mm lock-bore top/bottom ligament and 4.1 mm modeled roof over the rail channel. These are CAD dimensions—not strength allowances. The assumed worst-case lock-bore ligament is approximately 2.375 mm; rail-head vertical clearance is 0.225–0.575 mm per side under the assumed tolerance stack.

**Not verified:** material-specific FEA, static/cyclic strength, fatigue, pin retention, stop impact, outsole strain/grip/tear/abrasion, strap-anchor pull-out, fitted-last/comfort checks, running performance or human-use safety. Upper meshes are visual concept shells/straps, not cut-ready textiles. Do not wear or run in this concept.
