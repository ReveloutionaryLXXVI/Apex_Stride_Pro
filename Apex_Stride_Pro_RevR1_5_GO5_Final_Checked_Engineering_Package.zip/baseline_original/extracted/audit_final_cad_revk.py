#!/usr/bin/env python3
"""Final inventory/topology/coordinate audit for Apex Stride Pro Rev K CAD handoff."""
from pathlib import Path
import csv, json, re, hashlib
import trimesh

ROOT = Path(__file__).resolve().parent
GEN = ROOT / 'generated'
RES = ROOT / 'verification_results'
RES.mkdir(exist_ok=True)

stls = sorted(GEN.rglob('*.stl'))
rows = []
failures = []
for path in stls:
    try:
        mesh = trimesh.load_mesh(path, force='mesh', process=True)
        bounds = mesh.bounds
        watertight = bool(mesh.is_watertight)
        winding = bool(mesh.is_winding_consistent)
        positive = bool(mesh.volume > 0)
        good = watertight and winding and positive
        row = {
            'relative_path': str(path.relative_to(ROOT)).replace('\\','/'),
            'bytes': path.stat().st_size,
            'faces': int(len(mesh.faces)),
            'watertight': watertight,
            'winding_consistent': winding,
            'positive_volume': positive,
            'volume_cm3': round(float(mesh.volume)/1000, 6),
            'xmin_mm': round(float(bounds[0,0]), 4),
            'xmax_mm': round(float(bounds[1,0]), 4),
            'ymin_mm': round(float(bounds[0,1]), 4),
            'ymax_mm': round(float(bounds[1,1]), 4),
            'zmin_mm': round(float(bounds[0,2]), 4),
            'zmax_mm': round(float(bounds[1,2]), 4),
            'status': 'PASS' if good else 'FAIL',
        }
        if not good: failures.append(row['relative_path'])
        rows.append(row)
    except Exception as exc:
        failures.append(str(path.relative_to(ROOT)))
        rows.append({'relative_path':str(path.relative_to(ROOT)),'status':'ERROR','error':repr(exc)})

with (RES/'FINAL_CAD_MESH_INVENTORY.csv').open('w', newline='', encoding='utf-8') as f:
    w = csv.DictWriter(f, fieldnames=list(rows[0]) if rows else ['relative_path','status'])
    w.writeheader(); w.writerows(rows)

# Confirm the actual expected upper component exports exist for all three sizes.
upper_parts = ['toe_vamp_shell','heel_counter_shell','upper_wall_shell','upper_lateral_overlays',
               'upper_velcro_straps','upper_strap_anchor_doublers','upper_tongue']
upper_paths = {}
for size in (42, 44, 46):
    base = GEN/'EU44' if size == 44 else GEN/'upper_mockup'/f'EU{size}'
    upper_paths[str(size)] = {}
    for part in upper_parts:
        p = base/f'{part}.stl'
        # EU44 is the main size folder; EU42 and EU46 are under upper_mockup.
        if size != 44 and not p.exists():
            p = GEN/f'EU{size}'/f'{part}.stl'
        upper_paths[str(size)][part] = p.exists()

# Confirm moving parts have matching size-dependent X offset in exported assembly coordinates.
def bounds(path):
    m=trimesh.load_mesh(path, force='mesh', process=True)
    return m.bounds
vamp_paths = {
    42: GEN/'upper_mockup'/'EU42'/'toe_vamp_shell.stl',
    44: GEN/'EU44'/'toe_vamp_shell.stl',
    46: GEN/'upper_mockup'/'EU46'/'toe_vamp_shell.stl',
}
vamp_bounds = {size: bounds(p) for size,p in vamp_paths.items()}
bridge_bounds = {size: bounds(GEN/f'EU{size}'/'bridge_front.stl') for size in (42,44,46)}
mm_per_size = 6.6667
coord_rows=[]
for part, bmap in [('toe_vamp',vamp_bounds),('bridge_front',bridge_bounds)]:
    for a,b in [(42,44),(44,46)]:
        dxmin=float(bmap[b][0,0]-bmap[a][0,0])
        dxmax=float(bmap[b][1,0]-bmap[a][1,0])
        ok=abs(dxmin-2*mm_per_size) <= 0.15 and abs(dxmax-2*mm_per_size) <= 0.15
        coord_rows.append({'part':part,'from_size':f'EU{a}','to_size':f'EU{b}',
                           'xmin_delta_mm':round(dxmin,4),'xmax_delta_mm':round(dxmax,4),
                           'expected_delta_mm':round(2*mm_per_size,4),'status':'PASS' if ok else 'FAIL'})
with (RES/'FINAL_CAD_SIZE_COORDINATE_CHECKS.csv').open('w',newline='',encoding='utf-8') as f:
    w=csv.DictWriter(f,fieldnames=list(coord_rows[0])); w.writeheader(); w.writerows(coord_rows)

source=(ROOT/'Apex_Stride_Pro_RevK.scad').read_text(encoding='utf-8')
def num(pattern):
    m=re.search(pattern, source)
    if not m: raise AssertionError('Source parameter missing: '+pattern)
    return float(m.group(1))
rail_height=num(r'\brail_height\s*=\s*([0-9.]+)')
rail_neck=num(r'\brail_neck_height\s*=\s*([0-9.]+)')
lock_d=num(r'\block_hole_d\s*=\s*([0-9.]+)')
sole_thickness=num(r'\bsole_thickness\s*=\s*([0-9.]+)')
fit_vertical=0.4
nominal_ligament=round((rail_height-rail_neck-lock_d)/2,4)
nominal_roof=round(sole_thickness-rail_height-fit_vertical,4)
assert nominal_ligament >= 2.5 - 1e-5, nominal_ligament
assert nominal_roof >= 4.0 - 1e-5, nominal_roof

core_csv = RES/'REV_K_MESH_INTEGRITY.csv'
with core_csv.open(newline='',encoding='utf-8') as f: core_count=sum(1 for _ in csv.DictReader(f))
upper_summary_path=RES/'REV_K_UPPER_SIZE_EXPORT_SUMMARY.json'
upper_sum=json.loads(upper_summary_path.read_text()) if upper_summary_path.exists() else {}
tol_rows=list(csv.DictReader((RES/'REV_K_TOLERANCE_STACK.csv').open(newline='',encoding='utf-8')))
lock_rows=list(csv.DictReader((RES/'REV_K_LOCK_AND_BRIDGE_REGISTRATION.csv').open(newline='',encoding='utf-8')))
summary={
    'revision':'Rev K final CAD handoff',
    'stl_file_count':len(stls),
    'stl_topology_pass_count':sum(1 for r in rows if r.get('status')=='PASS'),
    'stl_failures':failures,
    'core_mechanical_outsole_mesh_count':core_count,
    'upper_size_variant_expected_14_pass': upper_sum.get('count')==14 and upper_sum.get('pass_count')==14 and upper_sum.get('fail_count')==0,
    'upper_component_exports_by_size':upper_paths,
    'all_upper_component_files_present':all(all(parts.values()) for parts in upper_paths.values()),
    'assembly_coordinate_checks':coord_rows,
    'all_assembly_coordinate_checks_pass':all(r['status']=='PASS' for r in coord_rows),
    'nominal_lock_bore_top_bottom_ligament_mm':nominal_ligament,
    'nominal_rail_channel_roof_mm':nominal_roof,
    'tolerance_rows':len(tol_rows),
    'all_tolerance_arithmetic_rows_positive':all(float(r['worst_case_min_mm'])>0 for r in tol_rows),
    'lock_registration_rows':len(lock_rows),
    'preview_png_present':(ROOT/'REV_K_FINAL_CAD_PREVIEW_EU44.png').exists(),
    'no_combined_full_mockup_stl':not any(p.name=='full_mockup.stl' for p in stls),
    'known_not_completed':['material-specific structural FEA','physical proof-load','fatigue/cyclic validation','pin retention/stop impact','outsole grip/abrasion/tear testing','actual last/fit and textile patterning','strap-anchor pull-out testing','human-use/running validation'],
}
(RES/'FINAL_CAD_AUDIT_SUMMARY.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
print(json.dumps(summary,indent=2))
if len(stls)!=65: raise SystemExit(f'Expected 65 generated STL files, found {len(stls)}')
if failures: raise SystemExit(f'{len(failures)} STL topology failures: {failures[:5]}')
if not summary['upper_size_variant_expected_14_pass']: raise SystemExit('EU42/EU46 upper-size mesh export summary missing or failed')
if not summary['all_upper_component_files_present']: raise SystemExit('Missing upper components for one or more nominal sizes')
if not summary['all_assembly_coordinate_checks_pass']: raise SystemExit('Assembly coordinate checks failed')
if not summary['all_tolerance_arithmetic_rows_positive']: raise SystemExit('Tolerance arithmetic includes non-positive margins')
if len(lock_rows)!=3: raise SystemExit('Expected 3 lock registration rows')
if not summary['preview_png_present']: raise SystemExit('Final preview image missing')
if not summary['no_combined_full_mockup_stl']: raise SystemExit('Combined visual-only mockup STL must not be packaged as a single-body print')
print('FINAL CAD AUDIT: PASS')
