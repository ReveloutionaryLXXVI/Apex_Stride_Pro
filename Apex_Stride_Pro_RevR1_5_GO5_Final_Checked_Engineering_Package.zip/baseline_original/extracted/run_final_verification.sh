#!/usr/bin/env bash
set -euo pipefail
python build_and_validate_revk.py
python export_upper_size_variants_revk.py
python validate_revk_tolerance_integration.py
python audit_final_cad_revk.py
