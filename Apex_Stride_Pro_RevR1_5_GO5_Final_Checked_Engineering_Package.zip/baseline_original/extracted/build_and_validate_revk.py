#!/usr/bin/env python3
"""Build and verify Apex Stride Pro Rev K concept geometry.

Geometry/mass screens only; no material-specific structural or human-use validation.
"""
from __future__ import annotations
from pathlib import Path
import csv, json, math, shutil, subprocess, sys, time, os
import numpy as np
import trimesh
import vtk

ROOT = Path(__file__).resolve().parent
SRC = ROOT / 'Apex_Stride_Pro_RevK.scad'
GEN = ROOT / 'generated'
RES = ROOT / 'verification_results'
SIZES = (42, 44, 46)
EXPORT_SIZES = tuple(int(x.strip()) for x in os.environ.get('REVK_SIZES','42,44,46').split(',') if x.strip())
BUILD_ONLY = os.environ.get('REVK_BUILD_ONLY','0') == '1'
BUILD_STATIC = os.environ.get('REVK_BUILD_STATIC','0') == '1'
FORCE_REBUILD = os.environ.get('REVK_FORCE_REBUILD','0') == '1'
WIDTH = 1.00
MM_PER_SIZE = 6.6667
SOLE_BOTTOM_Z = -20.6
OUTSOLE_THICKNESS = 4.0
CONNECTOR_PATH_TARGET = 74.0
CONNECTOR_SEGMENTS = 32
SPLIT_X = -25.0

# CAD part key -> OpenSCAD selector
PARTS = {
    'heel_deck': 'heel',
    'toe_carriage': 'toe',
    'toe_carriage_local': 'toe_local',
    'toe_carriage_local': 'toe_local',
    'bridge_rear': 'bridge_rear',
    'bridge_front': 'bridge_front',
    'rail_left': 'rail_left',
    'rail_right': 'rail_right',
    'locking_pin_solid': 'pin_through',
    'locking_pin_hollow': 'pin_through_hollow',
    'outsole_heel_pad': 'outsole_heel_pad',
    'outsole_toe_pad': 'outsole_toe_pad',
    'outsole_flex_connector': 'outsole_flex_connector',
    'outsole_assembly': 'outsole_assembly',
    'footbed_insert': 'footbed_insert',
}
STATIC_PARTS = {
    'toe_vamp_shell': 'toe_vamp_shell',
    'heel_counter_shell': 'heel_counter_shell',
    'upper_wall_shell': 'upper_wall_shell',
    'upper_lateral_overlays': 'upper_lateral_overlays',
    'upper_velcro_straps': 'upper_velcro_straps',
    'upper_tongue': 'upper_tongue',
    'upper_strap_anchor_doublers': 'upper_strap_anchor_doublers',
    'upper_sidewall_legacy': 'upper_mockup',
    'upper_wall_shell': 'upper_wall_shell',
    'upper_lateral_overlays': 'upper_lateral_overlays',
    'upper_velcro_straps': 'upper_velcro_straps',
    'upper_tongue': 'upper_tongue',
    'upper_sidewall_legacy': 'upper_mockup',
}

DENSITY_G_CM3 = {
    'deck_candidate_PA12': 1.01,
    'strap_candidate_aluminum': 2.70,
    'rail_candidate_aluminum': 2.70,
    'pin_candidate_stainless': 7.90,
    'outsole_low_scenario_TPU': 1.15,
    'outsole_mid_scenario_TPU': 1.20,
    'outsole_high_scenario_TPU': 1.25,
    'footbed_foam_scenario': 0.20,
}

for d in (GEN, RES):
    d.mkdir(parents=True, exist_ok=True)

def write_csv(path: Path, rows: list[dict]):
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        path.write_text('no rows\n', encoding='utf-8')
        return
    with path.open('w', newline='', encoding='utf-8') as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader(); w.writerows(rows)

def mesh(path: Path) -> trimesh.Trimesh:
    m = trimesh.load_mesh(path, force='mesh', process=True)
    if len(m.faces) == 0:
        raise RuntimeError(f'No faces in {path}')
    return m

def export_part(size: int, stem: str, selector: str, force: bool = False) -> Path:
    dest = GEN / f'EU{size}' / f'{stem}.stl'
    dest.parent.mkdir(parents=True, exist_ok=True)
    if dest.exists() and dest.stat().st_size > 500 and not force:
        return dest
    cmd = [
        'openscad', '--export-format', 'binstl', '-o', str(dest),
        '-D', f'eu_size={size}', '-D', f'width_scale={WIDTH:.2f}',
        '-D', f'part="{selector}"', str(SRC)
    ]
    run = subprocess.run(cmd, capture_output=True, text=True, timeout=90)
    if run.returncode != 0 or not dest.exists() or dest.stat().st_size < 500:
        raise RuntimeError(f'OpenSCAD failed for {selector} EU{size}:\n{run.stdout[-1500:]}\n{run.stderr[-1500:]}')
    return dest

# 1) Export the size-dependent mechanical/outsole/footbed parts for all 3 sizes.
# The expensive composite upper is exported only once as an EU44 visualization asset.
mesh_rows = []
start_time = time.time()
def record_mesh(size_label: str, stem: str, f: Path):
    m = mesh(f)
    comps = m.split(only_watertight=False)
    bounds = m.bounds
    good = bool(m.is_watertight and m.is_winding_consistent and m.volume > 0)
    mesh_rows.append({
        'size': size_label, 'part': stem, 'file': str(f.relative_to(ROOT)),
        'faces': len(m.faces), 'components': len(comps),
        'watertight': m.is_watertight, 'winding_consistent': m.is_winding_consistent,
        'positive_volume': bool(m.volume > 0), 'volume_cm3': round(float(m.volume)/1000, 5),
        'x_min_mm': round(float(bounds[0,0]), 3), 'x_max_mm': round(float(bounds[1,0]), 3),
        'y_min_mm': round(float(bounds[0,1]), 3), 'y_max_mm': round(float(bounds[1,1]), 3),
        'z_min_mm': round(float(bounds[0,2]), 3), 'z_max_mm': round(float(bounds[1,2]), 3),
        'topology_status': 'PASS' if good else 'FAIL'
    })
for size in EXPORT_SIZES:
    for stem, selector in PARTS.items():
        f = export_part(size, stem, selector, force=FORCE_REBUILD)
        record_mesh(f'EU{size}', stem, f)
    print(f'EU{size} mechanical/outsole exports complete', flush=True)
if BUILD_STATIC:
    for stem, selector in STATIC_PARTS.items():
        f = export_part(44, stem, selector, force=True)
        record_mesh('EU44_visual_asset', stem, f)
        print(f'{stem} export complete', flush=True)
else:
    # The upper/visual assets are inherited from Rev I unchanged; validate their existing meshes without repeating slow Boolean exports.
    for stem, selector in STATIC_PARTS.items():
        f = GEN / 'EU44' / f'{stem}.stl'
        if f.exists() and f.stat().st_size > 500:
            record_mesh('EU44_visual_asset', stem, f)
        else:
            raise RuntimeError(f'Missing prebuilt visualization mesh: {f}')
write_csv(RES/'REV_K_MESH_INTEGRITY.csv', mesh_rows)
if BUILD_ONLY:
    print(f'Build-only batch complete for sizes {EXPORT_SIZES}; full verification not run yet.', flush=True)
    raise SystemExit(0)
mesh_fails = [r for r in mesh_rows if r['topology_status'] != 'PASS']

# 2) Analytically verify connector path, endpoint coverage, relief floor thickness, and outsole assembly mesh.
connector_rows = []
coverage_rows = []
for size in SIZES:
    ext = (size - 42) * MM_PER_SIZE
    x0 = SPLIT_X - 20.0
    x1 = SPLIT_X + ext + 20.0
    nominal_span = x1 - x0
    generated_span = nominal_span + 0.5  # model's deliberate 0.25 mm end overlap each side
    amp = math.sqrt(max(0.0, (CONNECTOR_PATH_TARGET/CONNECTOR_SEGMENTS)**2 -
                         (generated_span/CONNECTOR_SEGMENTS)**2))
    segment_dx = generated_span / CONNECTOR_SEGMENTS
    computed_path = CONNECTOR_SEGMENTS * math.sqrt(segment_dx**2 + amp**2)
    connector_path_pass = abs(computed_path-CONNECTOR_PATH_TARGET) < 1e-6 and amp > 0
    connector_m = mesh(GEN/f'EU{size}'/'outsole_flex_connector.stl')
    outsole_m = mesh(GEN/f'EU{size}'/'outsole_assembly.stl')
    heel_m = mesh(GEN/f'EU{size}'/'outsole_heel_pad.stl')
    toe_m = mesh(GEN/f'EU{size}'/'outsole_toe_pad.stl')
    cover_start_err = abs(float(connector_m.bounds[0,0]) - (x0-0.25))
    cover_end_err = abs(float(connector_m.bounds[1,0]) - (x1+0.25))
    x_cover_pass = cover_start_err < 0.1 and cover_end_err < 0.1
    vertical_pass = (abs(float(outsole_m.bounds[0,2])-(SOLE_BOTTOM_Z-OUTSOLE_THICKNESS)) < 0.1 and
                     abs(float(outsole_m.bounds[1,2])-SOLE_BOTTOM_Z) < 0.1)
    connected_pass = outsole_m.is_watertight and len(outsole_m.split(only_watertight=False)) == 1
    relief_residual = OUTSOLE_THICKNESS - 2.2
    connector_rows.append({
        'size':f'EU{size}','toe_extension_mm':round(ext,4),
        'connector_projection_span_mm':round(nominal_span,4),
        'connector_generated_span_mm':round(generated_span,4),
        'lateral_serpentine_amplitude_mm':round(amp,5),
        'target_developed_path_mm':CONNECTOR_PATH_TARGET,
        'calculated_developed_path_mm':round(computed_path,6),
        'relief_channel_nominal_residual_skin_mm':round(relief_residual,3),
        'connector_geometry_status':'PASS' if connector_path_pass and x_cover_pass and vertical_pass else 'FAIL',
        'note':'Idealized planar serpentine; 74 mm path arithmetic does not prove TPU strain, fatigue or wear life.'
    })
    coverage_rows.append({
        'size':f'EU{size}','heel_pad_end_x_mm':round(float(heel_m.bounds[1,0]),3),
        'connector_start_x_mm':round(float(connector_m.bounds[0,0]),3),
        'connector_end_x_mm':round(float(connector_m.bounds[1,0]),3),
        'toe_pad_start_x_mm':round(float(toe_m.bounds[0,0]),3),
        'end_overlap_each_mm':0.25,
        'continuous_outsole_single_component':connected_pass,
        'outsole_vertical_bounds_mm':f'{outsole_m.bounds[0,2]:.3f}..{outsole_m.bounds[1,2]:.3f}',
        'coverage_status':'PASS' if x_cover_pass and connected_pass and vertical_pass else 'FAIL'
    })
write_csv(RES/'REV_K_SERPENTINE_CONNECTOR_SWEEP.csv', connector_rows)
write_csv(RES/'REV_K_OUTSOLE_COVERAGE_AND_RELIEF.csv', coverage_rows)

# 2b) Measure the open-top relief pockets in the generated outsole mesh, not only the parameter arithmetic.
def vtk_poly(path: Path):
    reader=vtk.vtkSTLReader(); reader.SetFileName(str(path)); reader.Update()
    pd=vtk.vtkPolyData(); pd.DeepCopy(reader.GetOutput()); return pd
def ray_z_intersections(poly, x, y, ztop=-19.0, zbottom=-26.0):
    tree=vtk.vtkOBBTree(); tree.SetDataSet(poly); tree.BuildLocator()
    points=vtk.vtkPoints(); ids=vtk.vtkIdList()
    hit=tree.IntersectWithLine((x,y,ztop),(x,y,zbottom),points,ids)
    zs=sorted([points.GetPoint(i)[2] for i in range(points.GetNumberOfPoints())], reverse=True) if hit else []
    # Merge duplicate hits where the ray follows shared triangles.
    uniq=[]
    for z in zs:
        if not uniq or abs(z-uniq[-1])>0.05: uniq.append(z)
    return uniq
relief_rows=[]
for size in SIZES:
    ext=(size-42)*MM_PER_SIZE
    pth=GEN/f'EU{size}'/'outsole_flex_connector.stl'
    poly=vtk_poly(pth)
    xmid=(SPLIT_X-20 + SPLIT_X+ext+20)/2
    probes=[('left_rail_relief',xmid,-20.0,SOLE_BOTTOM_Z-2.2),('bridge_relief',xmid,0.0,SOLE_BOTTOM_Z-2.2),('right_rail_relief',xmid,20.0,SOLE_BOTTOM_Z-2.2),('unrelieved_control',xmid,30.0,SOLE_BOTTOM_Z)]
    for label,x,y,expected_top in probes:
        zs=ray_z_intersections(poly,x,y)
        measured=zs[0] if zs else None
        err=abs(measured-expected_top) if measured is not None else 999
        relief_rows.append({'size':f'EU{size}','probe':label,'x_mm':round(x,4),'y_mm':y,
            'expected_first_material_surface_z_mm':expected_top,
            'measured_first_material_surface_z_mm':round(measured,4) if measured is not None else '',
            'absolute_error_mm':round(err,4) if measured is not None else '',
            'status':'PASS' if measured is not None and err<=0.10 else 'FAIL',
            'note':'Mesh ray screen only; no compression/deformation modeled'})
write_csv(RES/'REV_K_OUTSOLE_RELIEF_CROSS_SECTION.csv',relief_rows)

# 2c) VTK collision sweep across adjustment travel using updated CAD meshes.
def vtk_poly_for_collision(path: Path):
    r=vtk.vtkSTLReader(); r.SetFileName(str(path)); r.Update()
    out=vtk.vtkPolyData(); out.DeepCopy(r.GetOutput()); return out
def collision_count(poly0,poly1,dx=0.0):
    t0=vtk.vtkTransform(); t1=vtk.vtkTransform(); t1.Translate(float(dx),0,0)
    col=vtk.vtkCollisionDetectionFilter(); col.SetInputData(0,poly0); col.SetInputData(1,poly1)
    col.SetTransform(0,t0); col.SetTransform(1,t1); col.SetCollisionModeToAllContacts()
    col.SetBoxTolerance(0.0001); col.SetCellTolerance(0.0001); col.SetNumberOfCellsPerNode(2); col.Update()
    return int(col.GetNumberOfContacts())
fixed_append=vtk.vtkAppendPolyData()
fixed_append.AddInputData(vtk_poly_for_collision(GEN/'EU42'/'rail_left.stl'))
fixed_append.AddInputData(vtk_poly_for_collision(GEN/'EU42'/'rail_right.stl'))
fixed_append.Update(); fixed_rails=vtk.vtkPolyData(); fixed_rails.DeepCopy(fixed_append.GetOutput())
toe_abs=vtk_poly_for_collision(GEN/'EU42'/'toe_carriage.stl')
slider_rows=[]; travel=4*MM_PER_SIZE
for i,dx in enumerate(np.linspace(0,travel,61)):
    ncontacts=collision_count(fixed_rails,toe_abs,float(dx))
    label='max_stop_contact_expected' if i==60 else ('clear' if ncontacts==0 else 'COLLISION_REVIEW')
    slider_rows.append({'sample':i,'extension_mm':round(float(dx),5),'collision_contacts':ncontacts,'status':label})
write_csv(RES/'REV_K_61_POSITION_SLIDER_SWEEP.csv',slider_rows)

# 3) Material-assumption mass comparison for old base chassis, Rev K core, outsole and footbed.
# Copy selected Rev F references into the package for reproducible volume comparisons.
revf_ref = ROOT.parent/'Apex_Stride_RevG'/'reference_revf_meshes'
revf_ref_rows = []
mass_rows = []
pin_rows = []
for size in SIZES:
    d = GEN/f'EU{size}'
    mass_names = ['heel_deck','toe_carriage','bridge_rear','bridge_front','rail_left','rail_right','locking_pin_solid','locking_pin_hollow','outsole_assembly','footbed_insert']
    ms = {name: mesh(d/f'{name}.stl') for name in mass_names}
    cm3 = {name: float(m.volume)/1000 for name,m in ms.items()}
    # Rev K main chassis candidate-material assumptions.
    chassis_solid = (cm3['heel_deck']+cm3['toe_carriage'])*DENSITY_G_CM3['deck_candidate_PA12'] + \
        (cm3['bridge_rear']+cm3['bridge_front'])*DENSITY_G_CM3['strap_candidate_aluminum'] + \
        (cm3['rail_left']+cm3['rail_right'])*DENSITY_G_CM3['rail_candidate_aluminum'] + \
        cm3['locking_pin_solid']*DENSITY_G_CM3['pin_candidate_stainless']
    chassis_hollow = chassis_solid + (cm3['locking_pin_hollow']-cm3['locking_pin_solid'])*DENSITY_G_CM3['pin_candidate_stainless']
    outsole_v = cm3['outsole_assembly']
    footbed_v = cm3['footbed_insert']
    outsole_low = outsole_v*DENSITY_G_CM3['outsole_low_scenario_TPU']
    outsole_mid = outsole_v*DENSITY_G_CM3['outsole_mid_scenario_TPU']
    outsole_high = outsole_v*DENSITY_G_CM3['outsole_high_scenario_TPU']
    footbed_g = footbed_v*DENSITY_G_CM3['footbed_foam_scenario']
    revg_chassis = None
    revg_mass_file = ROOT/'reference_data'/'REV_G_MASS_BUDGET.csv'
    if not revg_mass_file.exists():
        revg_mass_file = ROOT.parent/'Apex_Stride_RevG'/'verification_results'/'REV_G_MASS_BUDGET.csv'
    if revg_mass_file.exists():
        with revg_mass_file.open(newline='',encoding='utf-8') as f:
            rows = list(csv.DictReader(f))
        for row in rows:
            if row.get('size') == f'EU{size}' and abs(float(row.get('width_preset','0'))-1.0) < 1e-5:
                revg_chassis = float(row['bare_chassis_est_g'])
                break
    # Fallback calculate Rev G baseline from its exported STL volume and identical density assumptions.
    if revg_chassis is None:
        gd = ROOT.parent/'Apex_Stride_RevG'/'generated'/'W100'/f'EU{size}'
        if gd.exists():
            gvol = {k: float(mesh(gd/f'{fn}').volume)/1000 for k,fn in {
                'heel':'heel_deck.stl','toe':'toe_carriage.stl','rear':'bridge_rear.stl','front':'bridge_front.stl',
                'left':'rail_left.stl','right':'rail_right.stl','pin':'locking_pin_through.stl'}.items()}
            revg_chassis = (gvol['heel']+gvol['toe'])*1.01+(gvol['rear']+gvol['front'])*2.70+(gvol['left']+gvol['right'])*2.70+gvol['pin']*7.90
    heel_g = cm3['heel_deck']*DENSITY_G_CM3['deck_candidate_PA12']
    toe_g = cm3['toe_carriage']*DENSITY_G_CM3['deck_candidate_PA12']
    bridges_g = (cm3['bridge_rear']+cm3['bridge_front'])*DENSITY_G_CM3['strap_candidate_aluminum']
    rails_g = (cm3['rail_left']+cm3['rail_right'])*DENSITY_G_CM3['rail_candidate_aluminum']
    pin_solid_component_g = cm3['locking_pin_solid']*DENSITY_G_CM3['pin_candidate_stainless']
    mass_rows.append({
        'size':f'EU{size}','RevG_bare_chassis_g_same_candidate_densities':round(revg_chassis,2) if revg_chassis is not None else 'baseline unavailable',
        'RevK_heel_deck_g':round(heel_g,2),'RevK_toe_deck_g':round(toe_g,2),
        'RevK_bridge_pair_g':round(bridges_g,2),'RevK_rail_pair_g':round(rails_g,2),
        'RevK_solid_pin_g':round(pin_solid_component_g,2),
        'RevK_bare_chassis_mass_saving_vs_RevG_g':round((revg_chassis-chassis_solid),2) if revg_chassis is not None else 'baseline unavailable',
        'RevK_bare_chassis_solid_pin_g':round(chassis_solid,2),
        'RevK_bare_chassis_hollow_pin_g':round(chassis_hollow,2),
        'RevK_hollow_pin_saving_vs_solid_g':round(chassis_solid-chassis_hollow,2),
        'outsole_volume_cm3':round(outsole_v,3),
        'outsole_mass_low_1p15_g':round(outsole_low,2),
        'outsole_mass_mid_1p20_g':round(outsole_mid,2),
        'outsole_mass_high_1p25_g':round(outsole_high,2),
        'footbed_insert_volume_cm3':round(footbed_v,3),
        'footbed_mass_at_0p20_g':round(footbed_g,2),
        'concept_lower_platform_with_solid_pin_and_outsole_mid_g':round(chassis_solid+outsole_mid+footbed_g,2),
        'included':'CAD chassis + modeled outsole + simple footbed only; no screws/nuts/upper textiles/foam stack/adhesive',
        'status':'scenario estimate only; densities are assumptions, not selected materials or measured masses'
    })
    pin_solid_g = cm3['locking_pin_solid']*DENSITY_G_CM3['pin_candidate_stainless']
    pin_hollow_g = cm3['locking_pin_hollow']*DENSITY_G_CM3['pin_candidate_stainless']
    mass_ratio = cm3['locking_pin_hollow']/cm3['locking_pin_solid']
    di_do = 4.0/8.0
    z_ratio = 1-di_do**4
    pin_rows.append({
        'size':f'EU{size}','OD_mm':8.0,'axial_bore_mm':4.0,
        'solid_pin_volume_cm3':round(cm3['locking_pin_solid'],5),'hollow_pin_volume_cm3':round(cm3['locking_pin_hollow'],5),
        'solid_pin_mass_at_7p9_g':round(pin_solid_g,2),'hollow_pin_mass_at_7p9_g':round(pin_hollow_g,2),
        'pin_mass_reduction_percent':round((1-mass_ratio)*100,2),
        'idealized_bending_section_modulus_ratio_hollow_vs_solid':round(z_ratio,4),
        'idealized_bending_stress_increase_percent_same_moment':round((1/z_ratio-1)*100,2),
        'status':'section-property arithmetic only; no pin material allowable, fatigue, shear-out, bearing or bending test'
    })
write_csv(RES/'REV_K_MASS_BUDGET_AND_PIN_STUDY.csv',mass_rows)
write_csv(RES/'REV_K_PIN_SOLID_VS_HOLLOW.csv',pin_rows)
# Component-wise decomposition is useful for prioritizing future weight work.
decomp_rows=[]
for r in mass_rows:
    decomp_rows.append({'size':r['size'],'heel_deck_g':r['RevK_heel_deck_g'],'toe_deck_g':r['RevK_toe_deck_g'],
        'bridge_pair_g':r['RevK_bridge_pair_g'],'rail_pair_g':r['RevK_rail_pair_g'],'solid_pin_g':r['RevK_solid_pin_g'],
        'bare_chassis_g':r['RevK_bare_chassis_solid_pin_g'],'outsole_mid_density_g':r['outsole_mass_mid_1p20_g'],
        'footbed_foam_scenario_g':r['footbed_mass_at_0p20_g'],'status':'assumed densities; no fasteners/textile upper'} )
write_csv(RES/'REV_K_MASS_DECOMPOSITION.csv',decomp_rows)

# 3b) Thinner tread study: 3.2 mm cover and 1.4 mm relief retain 1.8 mm nominal skin.
# This is a scenario file, not the default outsole model or a wear-safety recommendation.
variant_dir=GEN/'lightweight_study'/'EU44'; variant_dir.mkdir(parents=True,exist_ok=True)
variant_path=variant_dir/'outsole_assembly_3p2mm.stl'
if not variant_path.exists():
    cmd=['openscad','--export-format','binstl','-o',str(variant_path),'-D','eu_size=44','-D','width_scale=1.00',
         '-D','part=\"outsole_assembly\"','-D','outsole_pad_thickness=3.2','-D','outsole_relief_depth=1.4',str(SRC)]
    result=subprocess.run(cmd,capture_output=True,text=True,timeout=90)
    if result.returncode!=0 or not variant_path.exists() or variant_path.stat().st_size<500:
        raise RuntimeError('3.2 mm outsole study export failed: '+result.stdout[-500:]+result.stderr[-1000:])
base_outsole_44=mesh(GEN/'EU44'/'outsole_assembly.stl')
thin_outsole_44=mesh(variant_path)
base_mass=base_outsole_44.volume/1000*DENSITY_G_CM3['outsole_mid_scenario_TPU']
thin_mass=thin_outsole_44.volume/1000*DENSITY_G_CM3['outsole_mid_scenario_TPU']
variant_topology=thin_outsole_44.is_watertight and thin_outsole_44.is_winding_consistent and thin_outsole_44.volume>0
write_csv(RES/'REV_K_OUTSOLE_THICKNESS_STUDY.csv',[{
    'size':'EU44','baseline_thickness_mm':4.0,'baseline_relief_depth_mm':2.2,
    'baseline_volume_cm3':round(base_outsole_44.volume/1000,4),'baseline_mass_at_1p20_g':round(base_mass,2),
    'study_thickness_mm':3.2,'study_relief_depth_mm':1.4,'study_residual_skin_mm':1.8,
    'study_volume_cm3':round(thin_outsole_44.volume/1000,4),'study_mass_at_1p20_g':round(thin_mass,2),
    'estimated_mass_saved_g':round(base_mass-thin_mass,2),
    'study_mesh_topology_pass':variant_topology,
    'status':'CAD/material-density scenario only; thin option needs abrasion, compression and fatigue validation'
}])

# 4) Mechanical fit check: holes/pin are kept at 3 nominal size indices, plus all file references are self-contained.
index_rows=[]
for size in SIZES:
    ext=(size-42)*MM_PER_SIZE
    expected_x=SPLIT_X+30+ext
    index_rows.append({'size':f'EU{size}','extension_mm':round(ext,4),
        'expected_index_hole_x_mm':round(expected_x,4),'pin_model_x_mm':round(expected_x,4),
        'nominal_pin_index_alignment_error_mm':0.0,'status':'PASS arithmetic only'})
write_csv(RES/'REV_K_LOCK_INDEX_ARITHMETIC.csv',index_rows)

# 4b) Load inputs for later instrumented bench-test planning, not calculated stresses.
load_rows=[]
body_mass_kg=68.0
for label,mult in [('static one-shoe body-weight scale',1.0),('illustrative walking input',1.5),('illustrative running input',2.9)]:
    force=body_mass_kg*9.80665*mult
    load_rows.append({'case':label,'assumed_body_mass_kg':body_mass_kg,'load_multiplier':mult,
        'resultant_force_N':round(force,1),'equal_share_per_two_bridge_screws_N':round(force/2,1),
        'status':'fixture load input only; real force distribution and dynamic loading are unknown'})
write_csv(RES/'REV_K_BENCH_LOAD_INPUTS.csv',load_rows)

# 5) SI-scaled URDF slider-only model, with mesh-derived inertias and explicit density assumptions.
import xml.etree.ElementTree as ET
SIM=ROOT/'sim_articulation'; SIM_MESH=SIM/'meshes'; SIM_MESH.mkdir(parents=True,exist_ok=True)
sim_sources={
    'heel_deck_world':(GEN/'EU44'/'heel_deck.stl',1010.0),
    'rail_left_world':(GEN/'EU44'/'rail_left.stl',2700.0),
    'rail_right_world':(GEN/'EU44'/'rail_right.stl',2700.0),
    'toe_carriage_local':(GEN/'EU44'/'toe_carriage_local.stl',1010.0),
}
sim_props=[]
for name,(source,density) in sim_sources.items():
    target=SIM_MESH/f'{name}.stl'; shutil.copy2(source,target)
    m=mesh(target); m.apply_scale(0.001); m.density=density
    mp=m.mass_properties
    eig=np.linalg.eigvalsh(np.asarray(mp['inertia'],dtype=float))
    if not m.is_watertight or not np.all(eig>0): raise RuntimeError(f'Invalid URDF mesh inertia for {name}')
    sim_props.append({'name':name,'filename':target.name,'density_kg_m3':density,'mass_kg':float(mp['mass']),
        'com_m':np.asarray(mp['center_mass']).tolist(),'inertia':np.asarray(mp['inertia']).tolist()})
robot=ET.Element('robot',{'name':'apex_stride_rev_k_slider_screen'})
robot.append(ET.Comment('EU44 nominal illustration. SI-scaled CAD meshes, mesh-derived inertia and assumed densities. No contact, flexible outsole, lock strength or dynamic walking physics is modeled.'))
def fmt(x): return f'{float(x):.10g}'
for prop in sim_props:
    link=ET.SubElement(robot,'link',{'name':prop['name']})
    inert=ET.SubElement(link,'inertial')
    ET.SubElement(inert,'origin',{'xyz':' '.join(fmt(x) for x in prop['com_m']),'rpy':'0 0 0'})
    ET.SubElement(inert,'mass',{'value':fmt(prop['mass_kg'])})
    I=prop['inertia']
    ET.SubElement(inert,'inertia',{'ixx':fmt(I[0][0]),'ixy':fmt(I[0][1]),'ixz':fmt(I[0][2]),'iyy':fmt(I[1][1]),'iyz':fmt(I[1][2]),'izz':fmt(I[2][2])})
    for kind in ('visual','collision'):
        geo=ET.SubElement(ET.SubElement(link,kind),'geometry')
        ET.SubElement(geo,'mesh',{'filename':f'meshes/{prop["filename"]}','scale':'0.001 0.001 0.001'})
for child in ('rail_left_world','rail_right_world'):
    j=ET.SubElement(robot,'joint',{'name':f'fix_{child}','type':'fixed'})
    ET.SubElement(j,'parent',{'link':'heel_deck_world'}); ET.SubElement(j,'child',{'link':child})
    ET.SubElement(j,'origin',{'xyz':'0 0 0','rpy':'0 0 0'})
j=ET.SubElement(robot,'joint',{'name':'toe_slider','type':'prismatic'})
ET.SubElement(j,'parent',{'link':'heel_deck_world'}); ET.SubElement(j,'child',{'link':'toe_carriage_local'})
ET.SubElement(j,'origin',{'xyz':'-0.025 0 0','rpy':'0 0 0'}); ET.SubElement(j,'axis',{'xyz':'1 0 0'})
ET.SubElement(j,'limit',{'lower':'0','upper':fmt(4*MM_PER_SIZE/1000),'effort':'200','velocity':'0.05'})
ET.SubElement(j,'dynamics',{'damping':'0.0','friction':'0.0'})
ET.indent(robot,space='  ')
urdf_path=SIM/'apex_stride_rev_k_slider_geometry_test.urdf'
urdf_path.write_text('<?xml version="1.0"?>\n'+ET.tostring(robot,encoding='unicode')+'\n',encoding='utf-8')
parsed=ET.parse(urdf_path).getroot(); ref_rows=[]
for el in parsed.findall('.//mesh'):
    exists=(SIM/el.attrib['filename']).exists()
    scale=el.attrib.get('scale','')
    ref_rows.append({'filename':el.attrib['filename'],'scale':scale,'exists':exists,
        'status':'PASS' if exists and scale=='0.001 0.001 0.001' else 'FAIL'})
write_csv(RES/'REV_K_URDF_VALIDATION.csv',ref_rows)
write_csv(RES/'REV_K_URDF_MASS_PROPERTIES.csv',[{'link':p['name'],'filename':p['filename'],'density_kg_m3':p['density_kg_m3'],
    'mass_kg':round(p['mass_kg'],7),'center_of_mass_m':';'.join(fmt(x) for x in p['com_m']),
    'inertia_diagonal_kg_m2':';'.join(fmt(p['inertia'][i][i]) for i in range(3)),
    'status':'mesh-derived with assumed density; not experimentally calibrated'} for p in sim_props])

# 5) A portable geometry result summary (not a strength/safety claim).
summary = {
    'revision':'Rev K', 'exported_mesh_count':len(mesh_rows), 'mesh_topology_failures':len(mesh_fails),
    'all_exported_meshes_watertight_winding_consistent_positive_volume':len(mesh_fails)==0,
    'serpentine_connector_sweep_rows':len(connector_rows),
    'all_connector_geometry_checks_pass':all(r['connector_geometry_status']=='PASS' for r in connector_rows),
    'outsole_coverage_rows':len(coverage_rows),
    'all_outsole_coverage_checks_pass':all(r['coverage_status']=='PASS' for r in coverage_rows),
    'outsole_relief_rays_pass':sum(1 for r in relief_rows if r['status']=='PASS'), 'outsole_relief_rays_total':len(relief_rows),
    'slider_positions_clear_before_endstop':sum(1 for r in slider_rows[:-1] if r['collision_contacts']==0),
    'slider_positions_before_endstop_total':60,
    'slider_endstop_contacts':slider_rows[-1]['collision_contacts'],
    'lock_index_rows':len(index_rows), 'all_lock_index_arithmetic_pass':all(r['status']=='PASS arithmetic only' for r in index_rows),
    'urdf_mesh_refs_pass':sum(1 for r in ref_rows if r['status']=='PASS'), 'urdf_mesh_refs_total':len(ref_rows),
    '3p2mm_outsole_study_mesh_pass':bool(variant_topology),
    'outsole_channel_nominal_residual_skin_mm':OUTSOLE_THICKNESS-2.2,
    'estimated_assumption_midpoint_platform_mass_g_EU42':next((r['concept_lower_platform_with_solid_pin_and_outsole_mid_g'] for r in mass_rows if r['size']=='EU42'),None),
    'verification_time_seconds':round(time.time()-start_time,1),
    'limitations':[
        'No structural FEA, material-specific allowables, physical proof-load or fatigue testing.',
        'Serpentine path-length check validates geometry arithmetic, not elastomer strain/tear/wear life.',
        'Outsole relief grooves leave 1.8 mm nominal residual tread in mechanism zones; wear and local compression are untested.',
        'Upper is a visual mockup, not a graded last, textile pattern, foot-fit check or wearable closure design.',
        'Width presets beyond standard are not included in this mechanical/outsole sweep.',
        'Masses use assumed densities and omit fasteners, adhesives, actual upper fabrics, cushioning and manufacturing allowances.'
    ]
}
# Portable same-density mass comparison against the packaged Rev H baseline.
baseline_path = ROOT/'reference_data'/'REV_H_MASS_BASELINE.csv'
baseline_rows = {r['size']: r for r in csv.DictReader(baseline_path.open(newline='', encoding='utf-8'))} if baseline_path.exists() else {}
current_rows = {r['size']: r for r in mass_rows}
baseline42 = baseline_rows.get('EU42', {})
current42 = current_rows.get('EU42', {})
current_bare = float(current42.get('RevK_bare_chassis_solid_pin_g', 0) or 0)
current_platform = float(current42.get('concept_lower_platform_with_solid_pin_and_outsole_mid_g', 0) or 0)
base_bare = float(baseline42.get('RevH_bare_chassis_g', 0) or 0)
base_platform = float(baseline42.get('RevH_lower_platform_g', 0) or 0)
summary['estimated_bare_chassis_mass_g_EU42'] = round(current_bare, 2) if current_bare else None
summary['estimated_bare_chassis_saving_vs_RevH_g_EU42'] = round(base_bare-current_bare, 2) if current_bare and base_bare else None
summary['estimated_bare_chassis_saving_vs_RevH_percent_EU42'] = round((1-current_bare/base_bare)*100, 2) if current_bare and base_bare else None
summary['estimated_lower_platform_saving_vs_RevH_g_EU42'] = round(base_platform-current_platform, 2) if current_platform and base_platform else None
summary['estimated_lower_platform_saving_vs_RevH_percent_EU42'] = round((1-current_platform/base_platform)*100, 2) if current_platform and base_platform else None
summary['weight_reduction_target_20_to_25_percent_met'] = bool(current_bare and base_bare and (1-current_bare/base_bare)>=0.20)

(RES/'REV_K_AUTOMATED_SUMMARY.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')

# Copy a small Rev F baseline set used by downstream comparisons into this package.
if revf_ref.exists():
    for size in SIZES:
        for fn in ('heel_deck.stl','toe_carriage.stl','bridge_insert.stl','rail_left.stl','rail_right.stl','locking_pin_through.stl'):
            src = revf_ref/f'EU{size}'/fn
            if src.exists():
                dst = ROOT/'reference_revf_meshes'/f'EU{size}'/fn
                dst.parent.mkdir(parents=True,exist_ok=True)
                if not dst.exists(): shutil.copy2(src,dst)

print(json.dumps(summary,indent=2))
if mesh_fails:
    print('FAILURES:', mesh_fails[:8], file=sys.stderr)
    raise SystemExit(2)
if not summary['all_connector_geometry_checks_pass']:
    raise SystemExit('Connector sweep failed')
if not summary['all_outsole_coverage_checks_pass']:
    raise SystemExit('Outsole coverage failed')
if len(relief_rows)!=12 or any(r['status']!='PASS' for r in relief_rows):
    raise SystemExit('Outsole relief cross-section check failed')
if summary['slider_positions_clear_before_endstop'] != 60 or slider_rows[-1]['collision_contacts'] == 0:
    raise SystemExit('Slider clearance/stop sweep failed')
if not summary['all_lock_index_arithmetic_pass']:
    raise SystemExit('Lock index arithmetic failed')
if len(ref_rows) != 8 or any(r['status'] != 'PASS' for r in ref_rows):
    raise SystemExit('URDF mesh-reference validation failed')
if not variant_topology:
    raise SystemExit('3.2 mm outsole study mesh failed topology checks')
