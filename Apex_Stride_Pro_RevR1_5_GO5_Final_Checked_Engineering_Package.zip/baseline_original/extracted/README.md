# Apex Stride Pro — Rev K integration package

- `Apex_Stride_Pro_RevK.scad`: editable CAD concept.
- `generated/EU42`, `EU44`, `EU46`: size-setting meshes.
- `sim_articulation/`: SI-scaled slider geometry/mass model; no realistic walking/running dynamics.
- `build_and_validate_revk.py`: full geometry build and automated screens (OpenSCAD + listed Python dependencies required).
- `validate_revk_tolerance_integration.py`: independent tolerance, lock registration, outsole span, measurement and package checks.
- `REV_K_INTEGRATION_REVIEW.md`, `VERIFICATION_STATUS.md`: interpretation and limitations.
- `REV_K_UPPER_PANEL_PLANNING_NOT_CUT_READY.svg`: panel planning sheet only; not a sewing/cutting pattern.

**Not for wearing/running.** Positive geometry checks are not proof of structural safety or fit. All test gates remain unperformed.
