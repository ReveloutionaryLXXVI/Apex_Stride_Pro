# Rev R1.4 GO 1 + GO 2 package integrity statement

This revision includes `REV_R1_4_SHA256_MANIFEST.txt`, which inventories SHA-256 hashes for every project file in this tree except the manifest itself. The companion delivered ZIP is built from this exact tree. Its entry contents are independently compared against the manifest after archive creation; the ZIP CRC test is also run.

The active authoritative CAD, print-preparation CAD and standalone corrected source must be byte-identical. Current-source regression evidence is included in `revision/verification_results/revR1_4_go1_go2/`.

The integrity checks establish file consistency only. They do not constitute a manufacturing release, structural certification, FEA, physical proof testing or permission for human wear.
