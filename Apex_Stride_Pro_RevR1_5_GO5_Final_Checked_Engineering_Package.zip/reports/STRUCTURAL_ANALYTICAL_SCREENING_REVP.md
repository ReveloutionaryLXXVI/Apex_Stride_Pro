# Rev P C3 — 66 kg load and structural-demand screen

**Scope:** current source dimensions and closed-form sensitivity calculations only. This is **not finite-element analysis, proof testing, fatigue validation, or a release-to-wear certificate**.

## Applied body load

\(F=mg=66\;\mathrm{kg}	imes9.81\;\mathrm{m/s^2}=647.46\;\mathrm{N}\).

An ideal equal bilateral static split is 323.73 N/foot. During single-foot support, one shoe may carry about 647.46 N before transient effects. The 10%, 20%, 50% and 100% body-weight horizontal-lock cases below are transparent sensitivity assumptions—not measured gait forces or a validated dynamic-load envelope.

## Corrected C3 pin/rail/bridge screening model

The current source places the two rail bearing stations at Y=±20.3 mm and simplified pin support points at ±45.0 mm. Each rail carries H/2 in the model; the lever is 24.7 mm. The maximum moment in this assumed model is on the **unnotched Ø8.0 mm shaft** between the rail loads, with \(Z=\pi d^3/32=50.2655\;\mathrm{mm^3}\) and \(\sigma=M/Z\). The 7.6 mm groove root is used for a separate average-shear sensitivity and retaining-ring shoulder calculation, not as the maximum-moment bending section.

| Horizontal sensitivity | H (N) | Unnotched shaft nominal bending (MPa) | Kt=2 illustrative sensitivity (MPa) | 1170 MPa reference / nominal stress | Rail bearing per rail (MPa) | Adjacent-hole tear-out average per rail (MPa) | One bridge strap net tension if it carries all H (MPa) |
|---:|---:|---:|---:|---:|---:|---:|---:|
| 10% body weight | 64.75 | 15.91 | 31.82 | 73.55 | 0.368 | 0.585 | 1.61 |
| 20% body weight | 129.49 | 31.82 | 63.63 | 36.77 | 0.736 | 1.169 | 3.22 |
| 50% body weight | 323.73 | 79.54 | 159.08 | 14.71 | 1.839 | 2.923 | 8.05 |
| 100% body weight | 647.46 | 159.08 | 318.16 | 7.35 | 3.679 | 5.847 | 16.11 |

The 1170 MPa figure is a **typical/reference yield value for a wrought 17-4PH H900 candidate**, not a certified property of the custom grooved pin and not an allowable. Kt=2 is a sensitivity only, not a calculated notch factor. The actual groove radius, residual finish, boss contact, impacts, corrosion and fatigue are not modeled. This calculation cannot be used to approve the pin.

The adjacent-hole ligament is 5.033 mm between Ø8.3 mm bores at 13.333 mm pitch; this creates a 2.5165 mm half-ligament on each side for the idealized tear-out area. Per-rail projected pin-bearing area is 8.0×11.0=88.0 mm². Bridge net section is (23−2×4.8)×3=40.2 mm². These are average stress demands only, without contact, prying, screw preload, or real force sharing.

## Retaining-ring pull sensitivity

For an Ø8.0 mm shaft and Ø7.6 mm groove root, the calculated annular shoulder area is 4.9009 mm². Hypothetical 50/100/250/500 N pin-extraction demands yield 10.20/20.40/51.01/102.02 MPa nominal shoulder stress. The actual DIN 471 ring capacity, ring deflection, plastic boss capacity and whether the ring remains seated during impact are unknown. **These are demand values, not proof of retention.** See `revision/verification_results/REV_P_C3_SAFETY_CORRECTION/C3_AXIAL_PIN_RETENTION_SENSITIVITY.csv`.

## C3 structural-interface correction

The rail-relief cavities had crossed the two Ø3.3 mm attachment pilots. C3 segments those cavities to preserve a minimum **2.5 mm solid land beyond each pilot radius**. Calculated cavity-center keepout is 4.15 mm from each Ø3.3 pilot center. The authoritative and print-prep CAD agree; all six current native rail exports (three sizes × left/right) are watertight and positive-volume. This checks geometry only; thread engagement and metal fatigue remain unvalidated. Evidence: `revision/verification_results/REV_P_C3_SAFETY_CORRECTION/C3_CORRECTIVE_TEST_REGISTER.csv`.

## Static vertical load path is not solved

The nominal vertical path is outsole → outsole/deck attachment → heel/toe decks → captured rails/bridge → foot. The source does not define a validated outsole joint, real cushioning system, fastener grades/preload, actual rail material/process or a qualified fitted upper. Vertical pressure distribution, eccentric foot loading, plate bending, channel contact, local deck bending, screw pull-out and failure interactions are therefore not calculable with defensible accuracy from the present data alone. No material-specific FEA solver is installed here, and no manufactured specimen or physical test equipment was supplied.

The source contains **no modeled pneumatic chamber, air line, valve, coil spring, piston or damper**. The serpentine outsole piece is not a validated spring or pneumatic cushion. The actual footwear mechanism cannot be certified or assigned stiffness/energy return from this CAD.

## Geometry and test status

Nominal geometry/arithmetic checks include 2.75 mm rail top/bottom ligament, 2.15 mm rail/channel-to-bridge web, 4.1 mm deck roof, Ø8.3 mm indexed bores, Ø8.0 mm pin, Ø8.8 mm carriage passage, 0.25 mm radial ring-recess clearance, 1.4 mm nominal ring-boss wall, and C3 solid rail-screw lands. Values are nominal source geometry, not manufacturing tolerance capability or strength allowables.

**Completed analytical checks:** 66 kg force calculation; pin, rail-hole, and bridge-demand equations under explicit simplified loads; four pin-pull sensitivity calculations; current rail-cavity land arithmetic and rail meshes; current CAD compile/mesh/kinematic/selected CSG checks.

**Not run:** material-specific FEA with mesh convergence and realistic contacts; a fully solved vertical contact/load path; physical proof, impact, fatigue, pin/ring retention, fastener pull-out, outsole bond/traction/wear, upper retention, fit and human trials. There is no approved safety factor because the material/process and load case are not validated.

**Wear status: NOT CLEARED.** Do not wear this prototype until production drawings/materials are frozen, a material-specific analysis is reviewed, guarded physical tests pass, and independent engineering approval is documented.
