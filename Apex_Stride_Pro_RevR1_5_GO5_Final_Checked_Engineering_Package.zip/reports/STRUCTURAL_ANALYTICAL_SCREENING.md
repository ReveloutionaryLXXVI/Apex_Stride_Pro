> HISTORICAL REPORT — Rev O C2. Superseded by `reports/STRUCTURAL_ANALYTICAL_SCREENING_REVP.md` (current Rev P C3). Do not use this older load table as the current calculation.

# Rev O C2 — 66 kg analytical structural screen

**Type:** closed-form analytical screening from dimensions parsed from the current OpenSCAD source. **Not FEA. Not a physical test. Not safety approval.**

Body weight: **66 kg × 9.81 m/s² = 647.46 N**. An ideal equal bilateral static split is 323.73 N per foot; the single-support calculation uses 647.46 N. Dynamic multipliers below are sensitivities, not measured gait loads or approved proof factors.

## Conditional stress demands

| Multiplier | Force (N) | Pin double shear at Ø7.6 groove (MPa), if full load | Pin bend at groove root (MPa), if full vertical force at midpoint of 45 mm span | Rail hole bearing (MPa/rail), equal split | Rail top/bottom breakout avg shear (MPa/rail), equal split | One bridge strap net stress (MPa), full axial force |
|---:|---:|---:|---:|---:|---:|---:|
| 0.5× | 323.73 | 3.57 | 84.51 | 1.84 | 2.68 | 7.49 |
| 1× | 647.46 | 7.14 | 169.01 | 3.68 | 5.35 | 14.99 |
| 1.5× | 971.19 | 10.70 | 253.52 | 5.52 | 8.03 | 22.48 |
| 2× | 1294.92 | 14.27 | 338.03 | 7.36 | 10.70 | 29.98 |
| 3× | 1942.38 | 21.41 | 507.04 | 11.04 | 16.05 | 44.96 |

These are **not simultaneous stresses or actual predictions**. Each column uses a separate stylized load-path assumption to reveal which geometry/material data are missing. The pin is intended as a longitudinal adjustment lock, while vertical force should be carried by the captured T-rails/channel/deck; therefore the full-load pin-bending case is a conditional risk screen. If the pin is in fact forced to carry a substantial vertical load, the calculated bending demand is serious: 169 MPa at one body weight and 507 MPa at the illustrative 3× scenario before groove stress concentration. The assembly needs measured/analytically established load sharing to rule that path out.

## Geometry arithmetic checks

| Check | Result | Detail |
|---|---|---|
| body force | **PASS** | 66.0 kg × 9.81 m/s² = 647.46 N |
| rail top/bottom ligament | **PASS** | computed 2.750 mm; no material allowable available |
| rail to bridge web | **PASS** | computed 3.850 mm; deck web strength unverified |
| deck roof above captured rail | **PASS** | computed 4.100 mm; polymer/process strength unverified |
| rail pin diametral clearance | **PASS** | nominal 0.300 mm; proposed dimensional limits imply 0.300–0.370 mm |
| carriage bore not smaller than pin | **PASS** | carriage passage Ø8.80 vs pin Ø8.00 mm; passage clearance is not specified by tolerance |
| ring recess radial clearance | **PASS** | computed 0.250 mm per side; actual catalog ring tolerances not modeled |
| ring boss radial wall | **PASS** | computed 1.400 mm; boss pull-out/impact capacity unverified |
| ring groove axial clearance | **PASS** | computed 0.100 mm total; at assertion boundary, tolerance stack not included |
| outsole residual skin | **PASS** | computed 1.800 mm nominal; this does not validate traction or wear |
| source web comment current | **PASS** | stale 1.85 mm source comment corrected; source geometry unchanged |

Result: **11/11 geometry/arithmetic checks PASS; 0 FAIL**. These checks verify nominal geometry arithmetic only.

## Solver/test availability

No suitable FEA solver or FreeCAD command-line executable is installed in this environment: `ccx`=not found, `CalculiX`=not found, `gmsh`=not found, `FreeCADCmd`=not found, `freecadcmd`=not found, `FreeCAD`=not found. No material-specific FEA was run. No manufactured specimen, fixtures, load cell, fatigue rig, traction rig, or fit test rig is available in this software session, so no physical test was run.

## Required to convert this screen into capacity validation

1. Freeze actual rail, pin, bridge, deck, fastener, outsole and upper materials/processes and supplier specifications.
2. Produce a tolerance-controlled 3D solid/FE model with real fasteners and contacts, documented constraints/load cases, mesh convergence, and stress/strain acceptance criteria.
3. Test manufactured assemblies with guarded proof/eccentric loads, pin/ring retention, cyclic adjustment/fatigue, outsole retention/traction/wear, and fit/upper retention before human trials.

This report does not claim the shoe supports the body mass or is safe to wear.
