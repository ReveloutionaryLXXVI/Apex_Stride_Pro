# Rejected aggregate lower-platform STL export attempt

Three OpenSCAD aggregate assembly STL exports were generated as a qualification check and deliberately **not released**. They failed the watertight-mesh requirement and are too long for a common 220 mm build envelope (EU42 294.0 mm, EU44 307.333 mm, EU46 320.667 mm). Their STL files were removed from the deliverables so they cannot be mistaken for print-ready parts. The JSON contains the measured audit results, and the logs document the export commands/results.

Use the individual valid component STLs in `PRINT_READY_BENCH_FIT_KIT/stl/` for non-wearable fit mockups only. A single printable aggregate STL is not supplied.
