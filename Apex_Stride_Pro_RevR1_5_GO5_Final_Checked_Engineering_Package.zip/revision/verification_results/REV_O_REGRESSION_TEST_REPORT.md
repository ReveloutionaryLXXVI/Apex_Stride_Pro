> **HISTORICAL C1 REPORT — superseded by Rev O C2.** Current source of truth is the root `FINAL_CLOSURE_TEST_REGISTER.md` and `revision/verification_results/fresh_closure_audit/FINAL_CLOSURE_VALIDATION.json` (833 PASS, 0 FAIL for the consolidated digital/analytical register); C2 adds the stop-groove regression and conditional load screen.

# Rev O C1 regression and release report — historical C1 source snapshot

**Supersedes earlier Rev O regression text in this path.** The C1 closure correction restored the rail T-head axial bearing width to the Rev K baseline 11.0 mm after the prior 15.0 mm change was found to use an invalid “side ligament” calculation. Earlier Rev K/L/M/N and pre-C1 Rev O notes remain historical only.

## Current automated validation

At the time of this C1 snapshot, the full register was `fresh_closure_audit/FINAL_CLOSURE_VALIDATION.json` and `.csv`; it is superseded by the root Rev O C2 test register (837 checks).

| Test group | Result | Limits |
|---|---:|---|
| Source consistency | 12/12 PASS | Checks current native and print-prep source values/comments/guards; not structural analysis. |
| Individual fit-kit STL properties | 351/351 PASS | 39 separate meshes; topology, winding, finite coordinates/volume, placement, build envelope and index consistency. Fit mockups only. |
| Upper-concept mesh properties | 63/63 PASS | 21 visual concept meshes; topology only, not cut/sew patterns or fitted wearable components. |
| Optional 3.2 mm outsole study meshes | 72/72 PASS | 9 study meshes; geometry only, not traction, attachment or fatigue qualification. |
| Native OpenSCAD compile variants | 18/18 PASS | EU42/EU44/EU46 × three width presets × heel/toe CSG selectors. |
| Invalid-parameter guards | 2/2 PASS | Unsupported size and width values trigger expected source assertions. |
| Print-prep selector variants | 11/11 PASS | Selector compile tests; no strength inference. |
| Interface intersection screens | 27/27 PASS | Tested pairs under specified CSG conditions; non-overlap does not prove load capacity or full real-world clearance. |
| Mass-output arithmetic checks | 5/5 PASS | Uses fresh native mesh volume and declared assumed density table; not measured mass. |
| Baseline preservation | 1/1 PASS | Original uploaded ZIP hash verified. |
| **Consolidated current register** | **562/562 PASS, 0 FAIL** | Register runtime recorded as 29.06 s in the captured run. |

The original Rev K legacy suite was rerun separately on a scratch copy: its report states `FINAL CAD AUDIT: PASS`, with 65/65 topology outputs passing. The original uploaded ZIP was not modified.

## Current Rev O C1 interface notes

- `rail_head_width = 11.0 mm` restored to the Rev K baseline. The pin bore axis is parallel to Y, so this width is the axial bearing length, **not** a lateral side-ligament measurement.
- Rail index holes are nominal Ø8.3 mm; the toe-carriage passage is Ø8.8 mm; the nominal custom pin shaft is Ø8.0 mm.
- From rail vertical section height 16.1 mm minus 2.3 mm neck and Ø8.3 mm bore, the nominal top/bottom ligament arithmetic is `(16.1 - 2.3 - 8.3) / 2 = 2.75 mm`. This is a geometric dimension only, not a stress allowable or proof of safety.
- The current default outsole is 4.0 mm. The optional 3.2 mm version is a mass study only and is not the default.
- The upper meshes are visual shells, not a finished or fitted shoe upper. The original source package contains no pneumatic chamber, air tubing, valve, coil/leaf spring, piston or damper model.

## Separate aggregate export disposition (not counted in the 562-register total)

**FAIL — rejected and excluded.** An exploratory monolithic lower-platform STL export for EU42/EU44/EU46 was not watertight and had overall lengths 294.0/307.333/320.667 mm, exceeding a common 220 mm build envelope. The files are not shipped. Evidence and logs are under `reports/REJECTED_ASSEMBLY_STL_EXPORT/`. Use only individually checked component STLs for non-wearable fit mockups.

## Not run / unavailable

| Item | Status | Why |
|---|---|---|
| Material-specific FEA, contact, buckling, bearing/tear-out | NOT RUN | Production material grades/allowables, joint/contact definitions and validated solver model are not available. |
| Static/eccentric proof load, impact/landing, fatigue/adjustment cycles | NOT RUN | Requires production-intent manufactured specimens, calibrated fixtures and approved acceptance criteria. |
| Pin and retaining-ring retention/accidental release | NOT RUN | Actual hardware, tolerance stack, ring seating/access and physical retention are unqualified. |
| Fastener joint/clamp/loosening and anchor pull-out | NOT RUN | Grades, threads, lengths, engagement, torque and anti-loosening method are unresolved. |
| Outsole attachment, wet/dry traction, abrasion, tear and flex fatigue | NOT RUN | Compound and attachment system are not selected; physical tests absent. |
| Finished upper, strap anchor, heel retention, fit/pressure/comfort | NOT RUN | No fitted last/pattern, production textile or validated closure system. |
| Pneumatic/spring performance | NOT RUN / not represented in source | Those mechanisms are not modeled in the uploaded package. |
| Independent engineering approval/human trials | NOT RUN | No independent sign-off; human trials must remain gated until safety tests pass. |
| FreeCAD `.FCStd` creation | NOT AVAILABLE | FreeCAD executable/library unavailable in the environment. |
| STEP export | NOT AVAILABLE | OpenSCAD does not export STEP and no verified B-rep conversion path was available. |

## Mass interpretation (mesh volume × assumed density)

C1's default modeled lower platform remains about 3.41–3.45 g heavier than Rev K for EU42/EU44/EU46. The optional 3.2 mm outsole study is about 12.84–14.13 g lighter than Rev K and 16.28–17.54 g lighter than the C1 default, but is not accepted as a wearable solution because grip, attachment, tear, wear and fatigue remain unvalidated. See `REVK_REVO_FRESH_MASS_SUMMARY.csv` and `REVO_OPTIONAL_OUTSOLE_STUDY_MASS.csv` for exact values and density assumptions.

**Disposition:** digital CAD/fit-mockup and documentation work is packaged; the platform is not manufacturing-released or cleared for human wear. Mesh and compile checks do not establish load capacity or safety.
