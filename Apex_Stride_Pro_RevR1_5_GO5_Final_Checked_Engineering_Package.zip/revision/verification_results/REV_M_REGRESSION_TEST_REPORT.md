# Rev M Regression and Release Verification Report

**Scope:** native CAD exports, mesh topology, baseline geometry comparison, pin/retaining-ring fit arithmetic and geometry-derived mass estimates. These are not material strength or wearable release tests.

## Automated checks

- CSV rows: 78; PASS 69; FAIL 0; NOT RUN 9
- Geometry regression rows: 27; PASS 27; FAIL 0; NOT RUN 0
- Native OpenSCAD PNG render: PASS.
- The baseline-comparison rows deliberately classify toe-boss and pin/clip changes as intentional changes; other listed baseline parts are expected to match Rev L exactly.
- The pin/clip test checks geometric envelope and closed mesh topology only; it does not establish clip retention force, groove fatigue strength, pin shear/bending capacity or accidental-release resistance.

## Geometry-based mass estimate

Mass is computed per component from the volume of freshly exported Rev M STL geometry × assumed density. Densities: deck/toe polymer 1.01 g/cm³; rail/bridge aluminium proxy 2.70 g/cm³; pin and clip steel proxy 7.90 g/cm³; outsole 1.15/1.20/1.25 g/cm³ sensitivity, with 1.20 used for central totals; footbed foam proxy 0.20 g/cm³. These are accounting assumptions, not selected material specifications.

The lightweight outsole study remains opt-in only (3.2 mm cover/1.4 mm relief, nominal 1.8 mm remaining skin); the default remains 4.0 mm. No load-bearing decks, rails, bridges, rail-head sections or pin shaft were lightened.

## Explicitly not established by digital checks

- Material-specific FEA/stress, fatigue, impact, wear and buckling calculations.
- Physical proof loading, cyclic size-adjustment testing, pin pull-out/impact testing and secondary-retention validation.
- Outsole attachment, wet/dry traction, flex, abrasion, tear and fatigue performance.
- Upper / strap pull-out, fit to a real last, pressure points, heel retention and wearable comfort.
- Human walking, running, speed or injury-risk results.

**Release disposition:** design files are ready for independent engineering review and controlled specimen manufacture. Wear approval is NOT GRANTED by this report.
