# C3 corrected lock-pin, rail and bridge load screen

**Analytical screening only — not FEA, physical load testing, or wear-release approval.**

66 kg × 9.81 m/s² = **647.46 N** total body weight. An equal bilateral static split is 323.73 N/foot. A single-foot static load can reach 647.46 N before transient effects. Horizontal-load fractions below are transparent sensitivity values, not measured gait data.

## Cross-pin bending sensitivity

Model assumption: total horizontal force H splits equally to two rail holes at ±20.30 mm; simple pin supports are placed at side faces ±45.00 mm. The lever arm is 24.70 mm. Maximum bending is between the rail loads, on the **unnotched Ø8.0 mm shaft**, not at the retaining groove near the side boss. `M=(H/2)×lever`; `σ=M/(πd³/32)`. The groove lies about 0.75 mm from the outside-face support in this simplified model, but it sits inside the 5.5 mm boss; local contact/groove stress cannot be determined from point supports.

| Horizontal H / body weight | H (N) | Max unnotched shaft bending (MPa) | Reference yield ratio* | Rail bearing each (MPa) | Adjacent-hole tear-out shear each (MPa) | One bridge strap net tension (MPa) |
|---:|---:|---:|---:|---:|---:|---:|
| 10% | 64.75 | 15.91 | 73.55 | 0.368 | 0.585 | 1.61 |
| 20% | 129.49 | 31.82 | 36.77 | 0.736 | 1.169 | 3.22 |
| 50% | 323.73 | 79.54 | 14.71 | 1.839 | 2.923 | 8.05 |
| 100% | 647.46 | 159.08 | 7.35 | 3.679 | 5.847 | 16.11 |

*Reference yield ratio uses 1170 MPa typical/reference yield listed for wrought 17-4PH H900 candidate stock, not a design allowable or lot-certified property. It applies only to nominal unnotched pin bending, not ring groove, impact, fatigue, corrosion, support contact, or actual load-sharing.

## Retaining-ring axial extraction sensitivity

The theoretical annular shoulder area at shaft Ø8.0/groove root Ø7.6 is 4.901 mm². The companion CSV calculates nominal shoulder stress for hypothetical 50/100/250/500 N pin-pull loads. These are **not capacity checks**: the purchased DIN 471 ring rating, installation clearances, ring deformation and plastic boss response are unknown.

## What this screen can and cannot establish

It identifies the pin bending, rail bearing/tear-out and bridge strap net-section demand for a simple horizontal lock load. It does not solve the vertical deck/rail contact problem, material anisotropy, stress concentration at the retaining groove, threaded fastening, pin/bridge load sharing, fatigue or impact. The 2.15 mm polymer web, 4.1 mm nominal deck roof and 0.4 mm vertical rail-channel clearance still require a validated FE contact model and physical proof/fatigue testing. Current tooling has no installed FEA solver or FreeCAD B-rep export tool. No physical test was run; the shoe remains not cleared for human wear.
