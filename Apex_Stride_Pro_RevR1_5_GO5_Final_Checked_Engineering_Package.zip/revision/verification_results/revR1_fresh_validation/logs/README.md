# Rev R1.2 validation log provenance

- `fresh_sourcecheck.*`: the full R1.2 source/package regression, 130/130 PASS, exact source/print-prep parity, and all map paths resolving.
- `fresh_cavity.*`: the R1.2 core-cavity geometric probe suite, 9 rows covering EU42/EU44/EU46 and lightening on/off.
- `fresh_kinematic.*`: the R1.2 61-position/250-coordinate nominal adjustment sweep.
- `fresh_railstop.*`: the R1.2 exact rail/stop CSG run, 6/6 PASS.
- `fresh_load_screen.*`: the corrected R1.2 pressure/roof/pin arithmetic screen; passes arithmetic and nominal pressure hierarchy guardrails only.
- `fresh_fitkit.*`: provenance note for 42/42 validated current STL index entries and three fresh R1.2 heel-deck exports; it explicitly does not claim all 42 were freshly exported in R1.2.
- `fresh_mass.*`: provenance note for the 66-row modeled mass basis with 3 fresh revised heel-deck mesh volumes reconciled.
- `prior_R1_1_interface_csg.*`: the last successful 24/24 exact screw/EVA/bridge interface test. It is retained for R1.2 because only the heel-core roof was changed; the R1.2 interface rerun timed out and was not counted as a fresh pass.

All results are software/analytical checks only. No material-specific FEA or physical test was performed. Human wear remains NOT CLEARED.
