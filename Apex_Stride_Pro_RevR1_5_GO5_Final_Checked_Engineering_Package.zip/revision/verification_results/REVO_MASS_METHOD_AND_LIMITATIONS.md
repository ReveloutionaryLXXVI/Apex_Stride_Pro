> **MASS-METHOD NOTE:** This file was authored against the C1 mass geometry. Rev O C2 removes a 0.3 mm stop-slot start offset; it changes the slot location, not its volume. The current-source `recalculate_mass.py` was rerun after C2 and outputs are under `fresh_closure_audit/REVK_REVO_FRESH_*`. Use those CSVs as the current detailed source of mass values.

# Rev K baseline vs Rev O C1 mass estimate — method, assumptions and exclusions

**Current authoritative mass calculations are the fresh C1 outputs under `fresh_closure_audit/`.** This file and the nearby `REVO_*MASS*.csv` files were updated after the C1 rail-width correction; earlier Rev O values are not current.

## Method

Native OpenSCAD component STL volumes were processed as meshes and estimated by `mass_g = volume_mm3 / 1000 × assumed_density_g_cm3`. The C1 correction re-exported 12 affected components (heel deck, toe carriage, left/right rails × EU42/EU44/EU46). Other component volumes were unchanged by C1 and remain from the earlier fresh native component exports. No physical components were weighed.

## Density assumptions

| Component | Assumed density (g/cm³) | Limit |
|---|---:|---|
| Heel deck / toe carriage | 1.01 | Generic polymer scenario; production grade and process not selected |
| Bridges / rails | 2.70 | Aluminum-like scenario; alloy/temper/process not selected |
| Pin / retaining-ring envelope | 7.90 | Steel-like scenario; exact pin and ring not selected or qualified |
| Outsole assembly | 1.20 | Generic elastomer scenario; sensitivity 1.15–1.25 g/cm³ is calculated separately |
| Visual footbed insert | 0.20 | Generic foam scenario; actual cushioning is absent |

## Corrected totals by size

| Size | Rev K baseline (g) | Rev O C1 default (g) | Difference (g) | Optional 3.2 mm outsole study (g) | Study vs Rev K (g) |
|---|---:|---:|---:|---:|---:|
| EU42 | 597.355741 | 600.804323 | +3.448582 | 584.520512 | −12.835229 |
| EU44 | 601.645376 | 605.051280 | +3.405904 | 588.139874 | −13.505502 |
| EU46 | 605.934894 | 609.340798 | +3.405904 | 591.801790 | −14.133104 |

Files: `REVK_MASS_COMPONENT_BREAKDOWN.csv` (baseline), `REVO_MASS_COMPONENT_BREAKDOWN.csv` (C1), `REVO_MASS_BASELINE_COMPARISON.csv`, `REVO_MASS_LIGHTWEIGHT_STUDY_COMPARISON.csv`, `REVO_MASS_OUTSOLE_DENSITY_SENSITIVITY.csv`, and the fresher machine-readable tables in `fresh_closure_audit/`.

## Included / excluded

Included: heel/toe deck, rails, bridge pair, CAD pin, simplified retaining-ring envelope, outsole assembly and visual footbed insert. Excluded: bridge/rail screws and nuts, actual upper/textiles, seams, real foam/pneumatic/spring systems, adhesive, finishing/supports and process variation. Rev K has no modeled retaining ring; Rev O adds a simplified schematic ring envelope, not an actual purchased ring mass. These are assumed-density estimates, not measured part masses.

## Interpretation

The Rev O C1 default is **not lighter** than the Rev K baseline: it is about 3.41–3.45 g heavier. Relative to Rev K, the heel deck is +1.415 g, toe carriage +1.680 g, rail pair +1.049 g, footbed +0.04–0.08 g and modeled retaining-ring envelope +0.620 g; the pin is −1.397 g, with bridges and standard outsole approximately unchanged. The weight target has not been achieved by the default structural revision.

The opt-in 3.2 mm outsole study saves approximately 16.28–17.54 g relative to the C1 default and 12.84–14.13 g relative to Rev K in this model. It retains nominal 1.8 mm skin under 1.4 mm relief, but is not accepted as a wearable solution because grip, attachment, tear, wear, impact and flex fatigue are unvalidated. It remains non-default. The prior 15 mm rail-head width was reverted to 11.0 mm because the earlier side-ligament calculation incorrectly treated width along the pin axis as a lateral ligament.
