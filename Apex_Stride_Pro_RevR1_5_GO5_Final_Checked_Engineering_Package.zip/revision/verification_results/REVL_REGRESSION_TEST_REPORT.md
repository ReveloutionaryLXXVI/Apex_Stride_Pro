# Rev L regression-test report

## Automated checks

| Check | Result | Notes |
|---|---|---|
| RevL default geometry equals RevK for 9 core selectors across EU42/EU44/EU46 | **PASS** | Compared 27 default exports against baseline mesh volume, 3D bounds, exact vertex-coordinate sets and face counts; source default keeps outsole_weight_study=false. |
| OpenSCAD source parse / STL mesh exports for default core parts | **PASS** | Selected core parts exported from Rev L for all three sizes without OpenSCAD errors. |
| Native OpenSCAD GUI PNG export | **NOT RUN** | OpenSCAD native image export needs an OpenGL offscreen context that is unavailable in this runtime; a mesh-derived preview is rendered and checked separately. |
| Opt-in 3.2 mm outsole study: all sizes topology / coverage / mass geometry | **PASS** | Same XY bounding planform; 1.8 mm nominal skin under relief; reduced volume. This is not durability/grip validation. |
| Mesh-derived Rev L preview generation | **PASS** | Rendered from the Rev L default-equivalent STL meshes by the package Matplotlib renderer; not an OpenSCAD native viewport capture. |
| EU42 / EU44 / EU46 size-index registration arithmetic | **PASS** | Arithmetic only; no manufactured-part gauge or physical pin-engagement check. |
| New Rev L STL mesh topology | **PASS** | 3/3 new candidate outsole STLs watertight, winding-consistent and positive-volume. |
| Existing core mechanical/outsole mesh topology checks | **PASS** | 50/50 passed in the rerun of the existing build-and-validate suite. |
| Existing bundled STL integrity audit | **PASS** | 65/65 audited STL assets watertight, winding-consistent and positive-volume. |
| Existing slider travel/collision sweep | **PASS** | 60/60 interior samples clear; 24 contacts at the intended terminal-stop region. |
| Existing connector span and outsole coverage checks | **PASS** | 3/3 connector geometry checks and 3/3 coverage checks passed; geometry arithmetic only. |
| Existing outsole relief ray/cross-section probes | **PASS** | 12/12 relief probes passed; no compression or wear is simulated. |
| Existing lock/bridge registration arithmetic | **PASS** | 3/3 supported size settings pass nominal arithmetic; no actual-part gauge verification. |
| Existing size-coordinate consistency | **PASS** | 4/4 EU42-EU44-EU46 toe-vamp and bridge-front coordinate comparisons passed. |
| Existing upper mockup component inventory | **PASS** | All seven named upper mockup components are present for EU42, EU44 and EU46; this is file presence, not fit validation. |
| Existing URDF mesh references and SI scaling | **PASS** | 8/8 mesh-reference checks passed. |
| Existing worst-case tolerance arithmetic | **PASS** | 8/8 calculated margins positive under assumed tolerances, not supplier guarantees. |
| Mesh-volume mass recalculation | **PASS** | All supported sizes recalculated from actual exported STL volumes using stated density scenarios; no physical masses inferred. |
| Physical weighing of prototype parts | **NOT RUN** | No manufactured prototype parts have been weighed; all mass values are geometry-density estimates. |
| Material-specific structural FEA | **NOT RUN** | No selected material, allowables, contact model, or validated solver input. |
| Physical proof-load / eccentric load | **NOT RUN** | No manufactured specimen, engineer-set acceptance loads, guarded fixture, or load-cell record. |
| Fatigue / adjustment-cycle / pin retention / end-stop impact | **NOT RUN** | No physical test equipment/results. |
| Outsole grip / abrasion / tear / flex durability | **NOT RUN** | Topology is not a material durability or traction test. |
| Upper/strap-anchor pull-out and fit/last validation | **NOT RUN** | Upper remains conceptual; no cut-ready pattern or validated last. |
| Human walking/running/speed test | **NOT RUN** | Not appropriate until independent structural, retention, grip and fit safety gates are passed. |

## Baseline known checks

The package's existing Rev K suite was rerun before the Rev L edit: 50/50 core mesh screens, 65/65 STL topology audit, 60/60 interior slider positions, 24 intended terminal-stop contacts, 12/12 outsole relief probes, 3/3 lock/bridge registrations, 3/3 connector/coverage checks, 8/8 URDF references, and 8 positive tolerance-arithmetic rows passed.

## Interpretive limits

A mesh/topology or clearance arithmetic PASS means only that the checked digital geometry satisfies that check. It is not evidence of strength, load capacity, fatigue life, grip, manufacturability, fit, or human safety. The thinner outsole candidate has less vertical thickness and a 0.8 mm higher ground-facing plane, even though its XY planform bounds are unchanged.
