# Rev M verification status

**Latest Rev M automated register:** 78 rows — 69 PASS, 0 FAIL, 9 NOT RUN. The nine NOT RUN items are physical/material gates and are itemised in `verification_results/REV_M_AUTOMATED_CHECKS.csv` and `verification_results/REV_M_REGRESSION_TEST_REPORT.md`.

**Geometry regression:** 27/27 rows PASS. Unchanged components match Rev L exactly; changed toe bosses and pin/retaining-ring geometry are explicitly recorded as intentional changes.

**Width profiles:** heel and toe profile exports at scales 1.00, 1.04 and 1.08 across EU42/EU44/EU46 pass mesh topology and bounds monotonicity checks. These checks do not establish a physical fit or interference-free assembled shoe.

**Legacy Rev K suite:** 50/50 core exports and 65/65 bundled STL topology audit passed; 60/60 sampled slider positions clear before end stop; 24 expected end-stop contacts; 12/12 outsole relief probes; 8/8 tolerance arithmetic minima; 8/8 URDF mesh references; and recorded connector, outsole coverage, lock/bridge registration and size-coordinate checks passed.

**Mass:** actual exported STL volumes are multiplied by explicitly assumed density proxies. There are no measured physical masses or selected production materials. The 3.2 mm outsole is an opt-in study; the 4.0 mm outsole remains the default.

**Wear status: NOT RELEASED.** Structural FEA, proof load, fatigue, pin/retaining-ring retention, outsole attachment/grip/abrasion/tear, actual upper and strap pull-out, fastener specification, real-last fit, physical mass measurement and human trials have not been performed. Do not interpret a mesh PASS as evidence of material strength or human-use safety.
