# Apex Stride Pro — Historical CAD Handoff (Rev K)

**Historical snapshot only. Superseded by the Rev P C3 source and current package root reports.**

**Status:** Finalized as a CAD concept / engineering-review package. This is the handoff baseline; no further cosmetic CAD revisions are planned. Make new revisions only if a competent engineering review, material-specific analysis or guarded physical testing finds a real failure that needs correction.

**Not a validated wearable shoe.** Software checks establish mesh quality and selected geometric clearances, not the ability to support a person's weight safely. Do not wear or run in the current prototype.

## Start here

- Editable CAD source: `Apex_Stride_Pro_RevK.scad`
- Current concept preview: `REV_K_FINAL_CAD_PREVIEW_EU44.png`
- Engineering review: `REV_K_INTEGRATION_REVIEW.md`
- Verification summary: `VERIFICATION_STATUS_REV_K.md`
- Full STL inventory: `verification_results/FINAL_CAD_MESH_INVENTORY.csv`
- Size-coordinate checks: `verification_results/FINAL_CAD_SIZE_COORDINATE_CHECKS.csv`
- Full audit JSON: `verification_results/FINAL_CAD_AUDIT_SUMMARY.json`

## Contents

- Editable OpenSCAD source with selectors for the adjustable heel/toe chassis, rails, bridge, pin, footbed, outsole, upper shells and visual assembly.
- 65 individually exported STL assets across EU42, EU44 and EU46 mechanical sets, upper concept components and one alternate outsole-thickness study.
- SI-scaled URDF/articulation geometry; verification scripts; CSV reports; mass assumptions; a bilateral foot-measurement worksheet; and staged bench-test gates.
- White/maroon upper concept with vamp shell, heel counter, sidewalls, tongue, Velcro-strap mockups and strap-anchor doublers for all three nominal lengths.

## How to edit/export

1. Open `Apex_Stride_Pro_RevK.scad` in OpenSCAD.
2. Set `eu_size` to `42`, `44` or `46`. `width_scale` values `1.00`, `1.04` and `1.08` are conceptual shell-width presets, not standardized sizing.
3. Set `part` to an individual selector and press **F6 Render**, then **File → Export → Export as STL**. Coordinates are millimetres. Use the included individual part files when possible.
4. `full_mockup`/assembly selectors are visualization assemblies, not single-body print files. A combined export is not an approved printable part; do not print the whole visualization as one STL.

## Re-run the checks

Install OpenSCAD and the packages in `requirements-verification.txt`. From this folder:

```bash
python build_and_validate_revk.py
python export_upper_size_variants_revk.py
python validate_revk_tolerance_integration.py
python audit_final_cad_revk.py
```

Use `./run_final_verification.sh` on Linux/macOS or `run_final_verification.bat` on Windows. All exported meshes are currently cached, so the normal run validates them; use `REVK_FORCE_REBUILD=1` when an explicit fresh core re-export is required.

## Current verification snapshot

- 50/50 core mechanical/outsole mesh screens passed.
- 65/65 STL assets passed the independent topology audit (watertight, winding-consistent, positive-volume).
- 60/60 sampled slider positions before the end stop clear in the collision screen; the terminal samples contact the intended stop region.
- 12/12 outsole-relief probes, 3/3 connector/coverage checks, 3/3 lock registrations and 8/8 URDF references passed.
- 8/8 tolerance calculations have positive margins under the stated assumptions.
- 4/4 size-coordinate comparisons confirmed that toe-vamp and bridge-front parts translate correctly between EU42/EU44/EU46.
- Nominal lock-bore ligament is 2.5 mm and the modeled roof above the rail channel is 4.1 mm. The assumed worst-case ligament is approximately 2.375 mm.

## Open engineering gates — no claims of safety

- Material/process selection and supplier allowables, followed by independent material-specific structural FEA for the rails, pin bore, bridge, stop, deck bosses and outsole joint.
- Guarded bench tests: proof-load/eccentric loading, pin retention, end-stop impact, cyclic adjustment, flex/tear/abrasion and fastener/strap-anchor retention.
- Actual-part gauge checks, bilateral foot measurement and a real graded last; the upper and panel SVG are not cut-ready footwear patterns.
- Only after review and relevant tests: controlled fit validation. No sprint/speed test is justified now.

## Weight and expected speed

The stated density assumptions estimate the EU42 bare chassis at about 495 g and the lower platform with modeled outsole/simple footbed at about 597 g. These omit the true upper, cushioning, fasteners, adhesive and manufacturing allowances. The aggressive 20–25% weight-reduction target is not met.

Apex Stride Pro has **no evidence-based speed-gain figure**. A real runner's speed needs a timed baseline; the prototype could help, do nothing or make performance worse, and is not cleared for use.
