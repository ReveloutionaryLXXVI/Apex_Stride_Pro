# Apex Stride Pro Rev O — closure correction C1 notes

This note supersedes earlier Rev O notes in this folder that described a 3.35 mm “side ligament” derived from rail-head width. That calculation was geometrically invalid because the rail index-hole cylinder axis is along Y, the same axis as rail-head width.

## Current source decisions

- Authoritative source: `revision/Apex_Stride_Pro_RevO.scad`.
- Rail centers remain Y = ±22.5 mm; the adjusted channel/split geometry is retained to maintain web clearance from bridge recesses and the outer deck walls.
- Rail T-head width is restored to **11.0 mm**, matching Rev K baseline width. This dimension is the axial bearing length through which the pin passes; it is not a hole-side ligament.
- Rail index holes remain Ø8.3 mm; carriage passage remains Ø8.8 mm; nominal pin remains Ø8.0 mm.
- Correct nominal vertical top/bottom ligament in the 13.8 mm head height is `(13.8 - 8.3)/2 = 2.75 mm`. This is geometry only, not a strength rating.
- The prior 15.0 mm rail width added estimated mass without being supported by its stated side-ligament rationale. It has been removed from the default source to recover mass while returning to the baseline transverse width, not narrowing below Rev K.
- Rail cavities remain in the modeled production geometry away from the index-hole neighborhoods. The printable polymer rail STLs intentionally remain solid fit gauges and are not structural substitutes.
- Rail bearing/tear-out capacity, pin bending/shear, fatigue, material and manufacturing tolerances remain unverified. Any further reduction below the Rev K 11 mm width requires material-specific analysis and physical testing.

## Weight consequence

The previous 15 mm Rev O source exports overstated the rail envelope mass. `revision/tools/recalculate_mass_closure_c1.py` freshly exported the 12 affected component variants after this correction; unchanged modules retain their previous fresh native volumes because rail-head width does not affect them. Use the fresh `revision/verification_results/fresh_closure_audit/REVK_REVO_FRESH_MASS_SUMMARY.csv` as the current source of estimated mass values. The optional 3.2 mm outsole study remains opt-in only and unvalidated for wear.
