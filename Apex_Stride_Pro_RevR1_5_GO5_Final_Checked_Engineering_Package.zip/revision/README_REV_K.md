# Apex Stride Pro — Rev K Final CAD Concept

This is the final CAD handoff baseline for engineering review and guarded prototype development—not a certified or safe-to-wear shoe.

- `Apex_Stride_Pro_RevK.scad` — editable OpenSCAD source.
- `generated/` — 65 separate STL assets, including EU42/EU44/EU46 mechanical parts, upper mockup components and the alternate outsole-thickness study.
- `REV_K_FINAL_CAD_PREVIEW_EU44.png` — current visual assembly preview.
- `FINAL_CAD_HANDOFF.md` — opening/export instructions, contents, verification and remaining test gates.
- `REV_K_INTEGRATION_REVIEW.md`, `VERIFICATION_STATUS.md` — technical results and limitations.
- `verification_results/` — full STL inventory, size-coordinate audit, tolerance, mass and simulator-reference reports.

All current automated geometry screens pass. Physical strength, fatigue, outsole/strap durability, fit and human-use safety are not validated. Do not wear or run in this concept.
