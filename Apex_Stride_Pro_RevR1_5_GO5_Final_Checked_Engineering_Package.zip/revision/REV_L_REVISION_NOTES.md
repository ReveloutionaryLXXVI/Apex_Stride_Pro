# Rev L coordinated revision notes

## Project intent and release status

Apex Stride Pro remains an adjustable-shoe development project intended for eventual wearable use. Rev L is the engineering-review handoff, not a declaration that a physical prototype is ready to wear. Wear release remains gated on selected materials, independent structural review, guarded physical validation, retention/outsole tests, and fitted-last/closure verification. The original Rev K architecture and baseline files are preserved.

## Revision intent

Rev L is a controlled continuation of the Rev K project. The baseline architecture is retained: heel deck, sliding toe carriage, captured T-rails, rear/front bridge straps, indexed cross-pin, three nominal sizes, outsole pieces, footbed and visual upper. The original `Apex_Stride_Pro_RevK.scad` remains unchanged in the preserved source archive and in the reference copy.

## Changes made

1. **Added an opt-in outsole mass-study mode** in `Apex_Stride_Pro_RevL.scad` through `outsole_weight_study`. Default is `false`, retaining Rev K's 4.0 mm outsole / 2.2 mm relief. Setting it to `true` uses a 3.2 mm outsole / 1.4 mm relief and preserves a nominal 1.8 mm relief skin. The XY coverage bounds are unchanged; the ground-facing plane is 0.8 mm higher. This mode is a study candidate only, not approved for wear.
2. **Exported the candidate outsole for EU42, EU44 and EU46** in `revision_assets/lightweight_study_revL/`. The files were generated from the Rev L source and passed topology, positive-volume and planform-bound checks.
3. **Recomputed mass from actual mesh volumes** for each size and component. The calculations explicitly apply the same candidate density assumptions across the baseline and study geometry. Sensitivity at outsole densities 1.15 / 1.20 / 1.25 g/cm³ is included.
4. **Added engineering deliverables:** 66 kg load assessment; gated speed-test protocol; beginner-friendly BOM and CAD assembly manual; labelled conceptual assembly diagram; mass CSVs; source-regression and mesh reports; rerunnable validation script.
5. **Kept the structural chassis geometry intact.** The toe carriage is the largest single item in the assumed mass decomposition (~211.1 g), followed by the heel deck (~110.3 g), rail pair (~96.7 g), bridge pair (~38.8 g) and solid pin (~38.5 g). Deck/rail/bridge/pin reductions were not made because the package has no selected production material, material allowables, FEA or physical data to justify reducing those load-bearing sections. The hollow pin option was not selected; prior section-property arithmetic indicates about a 6.67% idealized bending-stress increase for the same bending moment.

## Mass result: baseline vs opt-in study mode

Assumptions: deck 1.01 g/cm³; bridge and rails 2.70 g/cm³; solid pin 7.90 g/cm³; outsole 1.15–1.25 g/cm³ with 1.20 g/cm³ midpoint; footbed insert 0.20 g/cm³. These are scenarios, not selected material specifications. Geometry volumes are calculated from the STL meshes; no physical component has been weighed.

| Size | Baseline lower-platform estimate | 3.2 mm study estimate | Estimate saved | Percent of baseline |
|---|---:|---:|---:|---:|
| EU42 | 597.356 g | 581.072 g | 16.284 g | 2.73% |
| EU44 | 601.645 g | 584.734 g | 16.911 g | 2.81% |
| EU46 | 605.935 g | 588.396 g | 17.539 g | 2.89% |

Here “lower platform” means chassis + modeled outsole + simple footbed insert only. It excludes fasteners, actual upper textiles, the actual cushioning stack, adhesive/outsole retention and manufacturing allowances. Totals and reductions are computed before rounding; the displayed values are independently rounded to 0.001 g. Because the current Rev L default is unchanged, the lower default-mode masses remain the Rev K baseline; the savings only apply when the experimental study mode is explicitly selected.

The previous Rev K package already reported mass savings relative to earlier revisions from its existing deck and rail relief geometry. Rev L does not claim an additional safe chassis reduction. A 20–25% reduction target is still not met.

## Load/speed conclusions

For 66 kg, static gravitational force is 647.46 N. This does not establish dynamic shoe load capacity. Walking, running, landing and sprinting introduce variable impact, shear, torsion, local pressure and cyclic loading. Example factors in the load assessment are planning assumptions, not safety proof.

No speed gain can be inferred from mass reduction or the connector shape. The speed protocol is future work and remains NOT RUN; human running/sprinting is gated on independent structural, retention, grip, fit and durability validation.

## Test disposition

- PASS: Rev L default mesh geometry matches Rev K across 9 component selectors for EU42/EU44/EU46 (27 component/size comparisons of vertex-coordinate sets, face counts, volumes and bounds).
- PASS: 3/3 study outsole meshes are watertight, winding-consistent and positive-volume; XY bounding planform equals baseline; volumes are lower.
- PASS: EU42/EU44/EU46 index and bridge registration arithmetic.
- PASS in the existing Rev K regression rerun: 50/50 core mesh screens, 65/65 mesh audit, 60/60 interior slider positions, 24 intended terminal-stop contacts, 12/12 outsole relief probes, 3/3 connector/coverage, 3/3 lock registration, 8/8 URDF references and 8 positive tolerance arithmetic rows.
- PASS: `REV_L_CAD_PREVIEW_EU44.png` was rendered with the package Matplotlib mesh renderer and inspected; the render is derived from the Rev L default-equivalent STL meshes, not from an OpenSCAD native viewport.
- NOT RUN: native OpenSCAD GUI PNG export, because this headless environment lacks an OpenGL offscreen context.
- NOT RUN: material-specific FEA, physical proof loading, fatigue, pin retention/impact, outsole grip/abrasion/tear, strap pull-out, fit/last validation and human running/speed tests.

See `verification_results/REVL_REGRESSION_TEST_REPORT.md` for machine-readable and human-readable test dispositions.
