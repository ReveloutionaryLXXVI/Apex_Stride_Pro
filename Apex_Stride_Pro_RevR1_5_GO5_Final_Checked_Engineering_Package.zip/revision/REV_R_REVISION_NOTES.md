# Rev R revision notes — core-cavity integration

## Preserved

Rev R derives from Rev Q and retains the adjustable captured-rail architecture, corrected rail-head width, separated rail mount pilot lands, corrected stop geometry, 8.3 mm rail index holes, 8.8 mm carriage passage, default 4.0 mm outsole, 5 mm forefoot/7 mm heel removable footbed geometry, and documented candidate material/process assignments.

## Changed

- Replaced the discrete heel-pocket pattern inside the core zone with a single 55×23×10.5 mm continuous subtractive cavity, x −125 to −70 mm, y ±11.5 mm, z −20.6 to −5.5 mm.
- Made the core cavity independent of the optional `lightening_enabled` parameter.
- Added geometry assertions for positive envelope dimensions, location inside the fixed heel region, vertical space and 2.0 mm minimum nominal web to the rail channel.
- Re-exported and re-indexed 42 fit/mockup STLs.
- Added native ray-probe checks for cavity void, roof, adjacent solid and toggled-lightening invariance.
- Fresh mass audit shows the current modeled scope is about 4.5–4.6 g heavier than Rev K, so the default mass-reduction objective is not claimed as achieved.

## Still open by evidence, not documentation

The actual spring geometry/rate/retainers/travel, bladder drawing/effective area/pressure ratings, line/fitting/port routing, check/relief/dump/regulator selection and pressure-loss behavior require supplier specifications and physical testing. Rev R1.2 thickens the local cavity roof to 10.1 mm by reducing the cavity height to 10.5 mm and the custom bladder target height to 9 mm, adding about 5.53 g modeled PA12. The roof and 2.5 mm side web still need material-specific analysis and proof/fatigue validation. No human wear is cleared.
