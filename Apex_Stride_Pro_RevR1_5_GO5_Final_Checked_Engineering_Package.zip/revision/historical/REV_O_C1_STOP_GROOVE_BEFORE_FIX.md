# Historical Rev O C1 source snapshot — stop-groove regression baseline

This file was extracted from the prior Rev O engineering archive before the C2 stop-groove correction. It contains the `+0.3 mm` offset that produced 2.0399957 mm³ positive-volume interference at maximum EU46 extension. It is preserved solely to make the C1→C2 regression reproducible. **Do not use this C1 source to generate current parts.** The authoritative current source is `../Apex_Stride_Pro_RevO.scad` from the `revision/` directory's parent.
