# Apex Stride Pro — Rev M Coordinated Engineering Revision Notes

**Project intent preserved:** adjustable shoe intended for eventual wearable use. This is a continuation of Rev K/Rev L, not a redesign. Rev K and Rev L source files and the original user ZIP are preserved unchanged. Rev M is an engineering-review candidate and is **not cleared for human wear**.

## Changes made in Rev M

### 1. Locking-pin serviceability correction

The prior source modeled an 8 mm shaft with heads at both ends. That geometry cannot be inserted or withdrawn axially through the assembled bore path because both ends are wider than the shaft opening. Rev M replaces the assembled pin with a single-headed nominal Ø8 mm shaft and a separate external retaining-ring interface at the opposite end. The former double-headed solid/hollow pin selectors remain only for traceability and are explicitly marked legacy/not for assembly.

The candidate pin geometry is a nominal Ø8.0 mm shaft spanning 90 mm between side-face planes, one Ø12.0 mm × 3.0 mm head, a nominal Ø7.6 mm × 0.9 mm retaining-ring groove and a 0.30 mm tip projection. The ring groove sits inside a counterbore on the negative-Y face so the simplified ring envelope is 0.35 mm below that side face. The positive-Y head sits in a Ø12.4 mm × 3.0 mm counterbore.

The ring geometry is schematic only and omits genuine retaining-ring lugs and plier holes. Purchase a real DIN 471 external retaining ring for an 8 mm shaft; manufacture the pin groove from the actual ring supplier's controlled drawing and tolerances. DIN 471 reference dimensions for an 8 mm shaft are commonly listed as 0.8 mm ring thickness, Ø7.6 mm groove root, 0.9 mm groove width, 7.4 mm free ID, and 14.7 mm expanded-clearance envelope. Confirm this exact ring’s current drawing before manufacture; do not machine from the schematic STL. Sources checked 15 Oct 2026: [Compel retaining-ring size chart](https://www.compelgroup.co.uk/tools/retaining-ring-size-chart), [Specialty Bolt & Screw DIN 471 listing](https://shop.specialtybolt.com/itemdetail/?itemCode=.8NMRSS-CL), and [Prospect Fastener / Rotor Clip dimensions](https://www.prospectfastener.com/DSH-8ST-PD).

### 2. Local toe boss reinforcement around ring recess

The two local pin-entry bosses on `toe_carriage` were enlarged from 16 × 16 mm to 18 × 18 mm face envelopes to provide nominal 1.4 mm material per side around the Ø15.2 mm × 1.5 mm retaining-ring recess. This is local added volume, not thinning of the deck, rails, bridges, rail head, or shaft. The Ø12.4 mm × 3.0 mm head-side recess remains. This reinforcement is only a geometric allowance: boss root strength, polymer creep, impact and ring access still require analysis and physical validation.

### 3. Preserve the baseline lock-bore architecture

Rev M restores the original 8.8 mm nominal rail-index/carriage pin bore around the nominal 8.0 mm pin (nominal 0.4 mm radial clearance). A tighter 8.1 mm bore was considered while comparing a commercial quick-release pin but was rejected because that commercial part's handle/envelope was unsuitable and the close-fit requirement would need a redesigned tolerance/finish strategy. Rev M therefore retains the baseline nominal bore rather than importing an inapplicable supplier fit. The 8.8 mm clearance still requires physical gauge/registration checks and engineering approval; this digital pass does not establish a satisfactory operational fit.

### 4. CAD/mesh validation and traceability

- Native OpenSCAD exports were generated for ten part selectors for each of EU42, EU44 and EU46: 30 selector-size exports total.
- Three opt-in 3.2 mm outsole-study exports were regenerated and compared with the retained Rev L study geometry.
- All freshly exported component meshes were checked for non-empty geometry, finite positive volume, watertightness and consistent face winding.
- 27 geometry-regression rows passed: 21 exact mesh comparisons across seven unchanged core components (heel deck, both bridge straps, both rails, outsole assembly and footbed) for the three sizes; three intentional toe-boss-volume changes; and three intentional pin/retaining-ring geometry changes.
- The full native OpenSCAD `full_mockup` PNG rendered successfully at 1280 × 960.
- Heel and toe deck width profiles exported at width scales 1.00, 1.04 and 1.08 for EU42/EU44/EU46; mesh topology and width-bounds monotonicity checks passed. These are CAD scale checks only, not fit/clearance validation.
- Invalid EU size and invalid width selectors were confirmed to raise OpenSCAD assertion errors.
- Legacy Rev K regression suite passed: 50/50 core mesh exports, 65/65 STL topology audit, 60/60 slider positions clear before end stop, 24 intended stop contacts, 12/12 outsole relief probes, 8/8 tolerance minima, 8/8 URDF mesh references, and all recorded size/index/bridge/connector coverage checks.
- Rev M validator report: 69 PASS, 0 FAIL, 9 NOT RUN; the 9 NOT RUN entries are explicitly physical/material release gates, not unreported failures.

## Mass change: actual geometry volumes, assumed densities

The Rev M lower-platform estimate is recalculated using freshly exported STL volumes. Densities are accounting assumptions: heel/toe polymer 1.01 g/cm³; bridge/rails aluminium proxy 2.70 g/cm³; pin/clip steel proxy 7.90 g/cm³; outsole 1.15 / 1.20 / 1.25 g/cm³ sensitivity; footbed insert foam proxy 0.20 g/cm³. They are not selected material specifications and mass has not been measured physically.

| Size | Rev L baseline lower-platform estimate | Rev M default 4.0 mm estimate | Rev M delta | Optional 3.2 mm study estimate | Study reduction vs Rev M default |
|---|---:|---:|---:|---:|---:|
| EU42 | 597.356 g | 597.232 g | -0.124 g | 580.948 g | 16.284 g (2.727%) |
| EU44 | 601.645 g | 601.521 g | -0.124 g | 584.610 g | 16.911 g (2.811%) |
| EU46 | 605.935 g | 605.811 g | -0.124 g | 588.272 g | 17.539 g (2.895%) |

Rev M pin serviceability and a slightly larger toe boss essentially cancel mass-wise; Rev M is not represented as a mass-reduction revision beyond Rev L. The only substantial estimated lower-platform reduction remains the optional 3.2 mm outsole geometry study, which stays opt-in and unapproved. Do not interpret these estimates as actual mass, endurance or speed results.

**Scope exclusions:** actual fasteners and nuts, production upper/textile/lining, true cushioning stack, outsole adhesive/retention materials, production tolerances, finish/coatings and manufacturing allowances are excluded. The ring STL is a schematic geometry and its density-derived mass is not the mass of a sourced catalog ring.

## Release disposition

Rev M resolves a clear CAD-level pin assembly/removal problem and adds a defined ring-pocket candidate. It is **not** an assertion that the pin is load-rated. No material-specific FEA, physical weighing, guarded proof/eccentric loading, fatigue, stop impact, retention pull-out, outsole adhesion/traction/wear, strap pull-out, real-last fit or human use/speed tests were run. The remaining gates are listed in `verification_results/REV_M_REGRESSION_TEST_REPORT.md` and `PROJECT_STATUS_AND_RELEASE_GATE.md`.
