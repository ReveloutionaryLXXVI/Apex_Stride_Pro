# Apex Stride Pro — Rev L coordinated engineering revision

**Project intent:** adjustable shoe for eventual wearable use. **Rev L disposition:** design revision and engineering-review handoff. It is not yet cleared for wear because material-specific, structural, retention, outsole, and fit validations remain outstanding. Rev L preserves the Rev K adjustable-shoe architecture and keeps the original 4.0 mm outsole as its default. The optional 3.2 mm outsole is an unvalidated mass-study candidate only.

## Main deliverables

- `Apex_Stride_Pro_RevL.scad` — revised editable OpenSCAD source. The default is intentionally geometry-equivalent to Rev K for the audited core parts; `outsole_weight_study = true` enables the experimental 3.2 mm sole.
- `Apex_Stride_Pro_RevK.scad` — unmodified project baseline source.
- `REV_L_REVISION_NOTES.md` — coordinated changes, mass results and limitations.
- `docs/ASSEMBLY_MANUAL_REV_L.md` — BOM, tools, CAD mockup assembly, prototype gaps, checks and stop conditions.
- `docs/LOAD_ASSESSMENT_66KG.md` — 66 kg force calculation, qualitative load cases, critical regions and required engineering work.
- `docs/SPEED_TEST_PROTOCOL.md` — staged, gated, reproducible speed-comparison protocol; human trials explicitly blocked until independent release.
- `docs/REV_L_ASSEMBLY_DIAGRAM.svg` and `.png`; `REV_L_CAD_PREVIEW_EU44.png` — reference illustrations, not fabrication drawings.
- `revision_assets/lightweight_study_revL/` — three source-exported 3.2 mm outsole meshes, one each for EU42/EU44/EU46.
- `verification_results/REVL_MASS_BASELINE_VS_STUDY.csv` — size summary and sensitivity assumptions.
- `verification_results/REVL_MASS_COMPONENT_BREAKDOWN.csv` — per-size, per-component mesh volumes and density-based mass estimates.
- `verification_results/REVL_REGRESSION_TEST_REPORT.md` plus CSV/JSON artifacts — automated results, explicit NOT RUN gates and details.
- `tools/validate_revl_revision.py` — rerunnable Rev L checks and mass estimate generator.
- `run_final_verification.sh` — existing Rev K validation suite, retained unchanged.

## Key quantitative results

The 66 kg gravitational force is **647.46 N**. This is not a running load rating. Component masses are estimates calculated from STL volumes using assumed density scenarios; they are not measured mass or selected material properties.

| Nominal size | Rev K/default lower-platform estimate | Opt-in 3.2 mm outsole-study estimate | Estimated reduction |
|---|---:|---:|---:|
| EU42 | 597.356 g | 581.072 g | 16.284 g (2.73%) |
| EU44 | 601.645 g | 584.734 g | 16.911 g (2.81%) |
| EU46 | 605.935 g | 588.396 g | 17.539 g (2.89%) |

“Lower platform” includes the modelled chassis, outsole assembly and simple footbed insert. It excludes actual fasteners, wearable upper/textiles, final cushioning, adhesive/sole-retention system and manufacturing allowances. Totals and reductions above are computed from unrounded mesh volumes and density products; displayed three-decimal values are rounded independently. The candidate savings come from outsole volume alone. Load-bearing decks, rails, bridges and solid pin were not thinned in this revision because material-specific evidence is unavailable.

## Regression result snapshot

- **PASS:** 27/27 Rev L default geometry comparisons against Rev K (9 core selectors × 3 sizes); core STL export and mesh topology checks.
- **PASS:** all 3 opt-in study meshes have positive volume and watertight, winding-consistent topology; XY bounding planform is unchanged.
- **PASS:** existing suite: 50/50 core mesh screens; 65/65 mesh inventory audit; 60/60 interior slider samples clear plus 24 intended terminal-stop contacts; 12/12 outsole relief probes; connector/coverage, size/lock registration, URDF reference and tolerance-arithmetic checks.
- **PASS:** Matplotlib mesh-derived preview generated. **NOT RUN:** native OpenSCAD GUI preview export because the environment lacks the required OpenGL offscreen context.
- **NOT RUN:** material-specific FEA, physical weighing, proof/eccentric loading, fatigue/adjustment cycles, pin retention/impact, outsole traction/wear/tear/flex, strap pull-out, fit/last validation and human trials.

The project remains intended for eventual wearable use, but these geometry passes are not strength, durability, manufacturability or safety validation. Do not wear, walk or run in a physical build until the release gates are passed. See the regression report and manual for the full test status.
