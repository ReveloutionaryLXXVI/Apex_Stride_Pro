# Apex Stride Pro — Rev M Engineering-Review Workspace

This folder contains the continued Rev K → Rev L → Rev M adjustable-shoe project. The original Rev K, Rev L and supplied ZIP are retained; Rev M is the current editable CAD candidate.

## Current revision

- `Apex_Stride_Pro_RevM.scad` — editable OpenSCAD source; default uses EU42 and the 4.0 mm outsole.
- `REV_M_NATIVE_PREVIEW_EU44.png` — successful native OpenSCAD full-mockup render.
- `REV_M_REVISION_NOTES.md` — pin serviceability correction, changes, assumptions and mass comparison.
- `docs/ASSEMBLY_MANUAL_REV_M.md` — CAD assembly and eventual prototype assembly reference; conceptual/missing hardware and safety gates are labelled.
- `docs/LOAD_ASSESSMENT_66KG.md` and `docs/SPEED_TEST_PROTOCOL.md` — documented engineering assumptions and staged test plan; no performance claims.
- `verification_results/REV_M_REGRESSION_TEST_REPORT.md` and CSV/JSON files — per-check outcomes, mesh/geometry regression, dimensional audit and mass arithmetic.
- `tools/validate_revm_release.py` — rerunnable export, topology, dimensional and mass validator.

## Latest verification snapshot

- Rev M register: **78 rows = 69 PASS, 0 FAIL, 9 NOT RUN**.
- Exact/intentional geometry regression: **27/27 PASS**.
- Heel and toe deck width profiles at width scales 1.00, 1.04 and 1.08 were exported for EU42/EU44/EU46; all 18 topology checks and six width monotonicity checks pass.
- Legacy Rev K suite rerun: 50 core exports, 65 mesh-topology checks, 60 pre-stop slider-clearance samples, 24 intended stop contacts, 12 outsole-relief probes, eight tolerance calculations, eight URDF mesh references, and the recorded registration/coverage checks pass.
- The native full mockup renders successfully.

These are CAD/software checks only. The nine NOT RUN rows are physical/material validation gates, including FEA, proof loading, fatigue, pin/retaining-ring qualification, outsole performance/retention, physical weighing, fitted upper/fit validation, fastener-joint qualification and human speed testing. **The Rev M prototype is not cleared for human wear.** The project intent remains a wearable adjustable shoe; no physical part has been independently qualified by this digital package.

## Mass estimate — modelled lower platform only

| Size | Rev L default 4.0 mm outsole | Rev M default 4.0 mm outsole | Rev M optional 3.2 mm study | Estimated study reduction |
|---|---:|---:|---:|---:|
| EU42 | 597.356 g | 597.232 g | 580.948 g | 16.284 g (2.727%) |
| EU44 | 601.645 g | 601.521 g | 584.610 g | 16.911 g (2.811%) |
| EU46 | 605.935 g | 605.811 g | 588.272 g | 17.539 g (2.895%) |

Mass equals exported mesh volume × assumed density, not measured weight. Production materials are not selected. Actual fasteners, completed wearable upper/textiles/lining, full cushioning, sole adhesive/retention and manufacturing allowances are excluded. The 3.2 mm outsole is an opt-in geometry/mass study only; the 4.0 mm outsole remains the default.

## Run checks

From this folder, run `python tools/validate_revm_release.py` with OpenSCAD, Python 3, `trimesh`, `numpy`, and `xvfb-run` available. This does not replace physical qualification. See `../PROJECT_STATUS_AND_RELEASE_GATE.md` for the required release gates.
