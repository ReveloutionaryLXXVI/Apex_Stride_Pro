# Apex Stride Pro — Rev N corrective revision notes

## What changed

Rev N is a focused continuation of Rev M. It preserves the adjustable captured-rail architecture, 8 mm single-headed pin with a separate DIN 471 size-8 retaining-ring concept, three nominal EU size settings, standard 4.0 mm outsole, and all previous files as traceable baselines.

### Corrected rail-head ligament geometry

The Rev M rail head was 11.0 mm wide around an 8.8 mm transverse lock bore. This leaves only `(11.0 − 8.8)/2 = 1.1 mm` of nominal material at each side of the hole. That is a material section concern missed by earlier mesh/topology checks; watertight STLs alone cannot detect it.

Rev N changes:

- `rail_head_width`: **11.0 → 15.0 mm**.
- `rail_y`: **±20.0 → ±21.0 mm**.
- Adds assertions for a minimum 3.0 mm side ligament, at least 0.30 mm nominal clearance to the bridge recess, and at least 2.5 mm nominal deck wall at the narrow EU42 split.

This gives a nominal `(15.0 − 8.8)/2 = 3.1 mm` side ligament at the rail hole. The existing rail height/neck/bore dimensions still give `(16.1 − 2.3 − 8.8)/2 = 2.5 mm` nominal top/bottom ligament. With `fit_clearance=0.8 mm`, the bridge-side rail-channel separation is 0.35 mm; the nominal EU42 outer deck wall at the split is 2.7 mm. These are geometric margins only, not approved strength allowables.

The widened channels and moved rails are propagated through the Rev N deck and outsole exports. The polymer rails in the print kit are still dimensional mockups; the production architecture calls for an engineered rail material/process. Material-specific bearing, tear-out, bending, fatigue and load-path analyses remain uncompleted.

## Validation performed

- 60 fresh native OpenSCAD component exports across EU42/EU44/EU46: mesh checks pass.
- 18 width-preset deck exports (EU42/EU44/EU46 × 1.00/1.04/1.08 width × heel/toe): all compile and topology-check PASS.
- 39 individual print-kit parts: 39/39 mesh/orientation/build-plate checks PASS.
- 21 upper-concept meshes: 21/21 topology checks PASS; upper remains visual only.
- 8 Rev N nominal geometry checks PASS, 0 FAIL. Lock-index registration passed for EU42/EU44/EU46.
- One baseline issue was explicitly recorded as `FINDING_FIXED`: Rev M's 1.1 mm side ligament, corrected to 3.1 mm in Rev N.
- Mass estimates were regenerated from native Rev M and Rev N STL volumes using the same assumed density table. The modeled lower platform estimate increases by approximately 3.490 g in Rev N for each size, from the wider rails / propagated channel geometry. These are estimates, not measured masses.

See `verification_results/REV_N_GEOMETRY_FIX_CHECKS.csv`, `REV_N_NATIVE_WIDTH_EXPORT_AUDIT.csv`, `REV_N_VALIDATION_SUMMARY.json`, `REV_N_MASS_COMPONENT_BREAKDOWN.csv`, and `REV_N_MASS_BASELINE_COMPARISON.csv`.

## Items not verified

No material-specific FEA, physical proof load, impact/fatigue test, pin/retaining-ring pull-out or accidental-release test, outsole retention/grip/abrasion test, strap anchorage test, production fastener qualification, real-last fit/pressure test, physical weighing, or human trial was performed. The package is suitable for printing non-wearable bench-fit parts and engineering review. It is **not cleared for human wear**.
