# Apex Stride Pro Rev O — Speed Evaluation Protocol

**Current status: NOT RUN. Speed evaluation is a planned later-stage test for the intended wearable shoe. Human speed testing must not begin until independent engineering validation releases the physical prototype for that purpose.**

## 1. What the CAD can tell us

The Rev O C2 CAD establishes nominal shape and indexed adjustment positions after an end-stop interference correction; it does not establish measured performance. With explicit assumed densities, the modeled lower platform (heel deck, toe carriage, rails, bridge pair, CAD pin/ring, outsole assembly and visual footbed) is estimated at 597.356 g / 601.645 g / 605.935 g for the Rev K baseline (EU42/EU44/EU46) and 600.804 g / 605.051 g / 609.341 g for Rev O C2 default. Thus the corrected default is estimated about 3.41–3.45 g heavier than Rev K under those assumptions. The opt-in 3.2 mm outsole study is estimated at 584.521 g / 588.140 g / 591.802 g, about 12.84–14.13 g below Rev K, but this variant is not wear-qualified and remains opt-in. These are geometry-derived estimates, not measured mass. See `../verification_results/REVO_MASS_METHOD_AND_LIMITATIONS.md` and the component CSV tables. The C2 values supersede earlier Rev O mass numbers retained only in explicitly historical files. The default source remains at 4.0 mm outsole; the lighter mode is experimental and not approved for wear.

Neither lower mass nor the geometric serpentine connector proves energy return or faster running. The files contain no physical prototype data, validated elastomer model, runner timing data, measured running speed or controlled comparison. No speed gain can be predicted from the available files.

## 2. Staged protocol and release gates

### Stage 0 — engineering release (no human use)

Required before proceeding: material/process specifications; independent material-specific FEA and failure-mode review; dimensional gauge checks; confirmed pin registration and retention; static/eccentric load and stop-impact bench results; cyclic adjustment/fatigue results; outsole grip, abrasion, tear and flex results; fastener and strap-anchor retention; a verified last and fit/clearance review. This revision has not completed these gates.

**Stop rule:** if any item is unresolved or failed, do not begin human testing.

### Stage 1 — non-human mass and mechanism characterization

**Equipment:** calibrated scale with 1 g or better resolution; calipers and appropriate go/no-go gauges; displacement indicator; calibrated load cell and guarded rigid fixture; controlled outsole-friction/abrasion/flex fixtures selected by the engineer; data logger and camera for remote observation.

**Procedure:**
1. Record exact specimen identity, size, production lot, materials and configuration. Weigh each fully assembled specimen three times after removing/replacing it on the scale; report all readings and mean/standard deviation.
2. Measure rail/channel, bridge, index-hole/pin, stop and outsole dimensions at defined gauge locations. Record raw values, not pass/fail alone.
3. Have the responsible engineer define load magnitudes, loading rate, dwell, eccentricity, cycle count and acceptance criteria from the intended use, material data and analysis. Do not derive those values from 66 kg static weight alone.
4. Run remote/guarded static, eccentric, pin-retention, stop-impact, cyclic-adjustment, outsole-flex/tear/abrasion and traction tests. Use video and the load-cell trace; measure permanent set and critical dimensions before/after.
5. Do not progress if there is an unexpected crack, audible fracture, pin migration, rail slip, stop damage, fastener loosening, delamination, outsole tear, unstable friction or permanent geometry change outside the engineer-set criteria.

### Stage 2 — controlled human speed comparison (only after written release)

This is a **future protocol**, not a recommendation to test the current concept. Initial work should be limited to consenting, healthy adult runners under footwear/biomechanics supervision; do not begin child trials. A formal study needs ethics/safety review and a prospective sample-size calculation. For a feasibility pilot only, use **12 adult participants** as an explicit planning assumption; this is not guaranteed to provide statistical power for efficacy claims.

**Equipment:** measured 30 m indoor straight track or controlled track; dual-beam electronic timing gates at the defined start and at 10 m, 20 m and 30 m; synchronized high-speed video or validated timing logger; radar/laser system if peak speed is a secondary outcome; calibrated shoe scale; environmental logging; same socks and fit-checked closures; trained supervisor and incident log.

**Controls:** within-participant randomized crossover between the participant's correctly fitted ordinary footwear (control) and the released prototype. Keep track, surface, start method, socks, warm-up, timing system, rest, time of day as far as practical, and environmental conditions consistent. Record footwear size, mass, fit checks, adjustment setting and condition order. The timer/video analyst should be blinded to condition labels when feasible.

**Number of trials:** after a separate familiarization session and only after prototype release, collect **6 valid 30 m trials per condition per participant**, across two sessions separated by at least 48 hours, with three valid trials per condition per session. Randomize condition order within each session. Rest 3-5 minutes between maximal efforts, extending rest if recovery is incomplete. Use a standardized warm-up and a predefined invalid-trial rule (timing-gate fault, slip, obstruction or protocol violation); repeat invalid trials only after recovery and log every exclusion.

**Measurements:** 30 m elapsed time (primary); 10 m and 20 m split times; optional validated peak velocity from radar; optional cadence/stride metrics from synchronized video/IMUs; shoe mass; surface/environment; perceived exertion and any discomfort/instability; all near-misses and adverse events. Do not conflate average 30 m speed with instantaneous peak speed.

**Calculations:** for each participant and condition, calculate the mean of six valid times and the within-person paired difference. Average speed for a 30 m timed segment is:

\[
\bar{v}_{\mathrm{km/h}} = \frac{30\,\mathrm{m}}{t\,\mathrm{s}}\times 3.6
\]

Define percentage time improvement as \(100\times(t_{control}-t_{prototype})/t_{control}\); positive means the prototype time is lower. If using peak speed, compare peak-speed observations separately. Report individual data, mean paired difference, uncertainty/95% confidence interval, trial variability, adverse events and all exclusions. For an efficacy claim, use a pre-specified paired analysis and sample size based on variance/power assumptions; do not cherry-pick each participant's best run.

**Immediate stop conditions:** pin or slider movement, any visible crack/delamination, outsole slip/tear, loosened fastener, loss of closure/retention, instability, pain/discomfort, abnormal noise or a participant/supervisor request. Any safety incident returns the project to engineering review; do not resume until formally cleared.

## 3. Decision criteria and reporting

A result should be reported as “no evidence of improvement” when the paired estimate is near zero or uncertainty is wide. A lower average time alone is not sufficient if the pre-specified uncertainty analysis does not support the claim or if safety events differ. Report mass, surface and test conditions with every result.

No physical running/sprint test was run for this package. The only existing preview and mesh results concern CAD geometry; all speed outcomes remain **unknown**.
