# Rev R upper, footbed, heel-core, and outsole integration specification

## Upper

The seven concept meshes in `PRINT_READY_BENCH_FIT_KIT_REV_R/upper_concept_not_wearable/EUxx/` are envelope-only, not a production pattern or a wearable upper. Build the production upper on the existing model last without changing nominal sole length/width. Required construction candidate: breathable polyester 3D spacer mesh body; high-tenacity woven nylon reinforcement at toe, lateral wear zones, and closure anchors; semi-rigid footwear-grade thermoplastic heel counter (PA12 only if fit, edges, and impacts are validated); breathable textile collar/tongue with PU or EVA foam; abrasion-resistant lining; bonded polyester thread; conventional lacing or engineered straps with reinforced textile anchors.

Supplier actions: procure fabric technical data for areal weight, tear/abrasion, seam behavior, chemical/adhesive compatibility and skin-contact use. Produce a last-matched cut/sew pattern. Model every anchor and stitch seam, ensure 3D clearance to pin, rails, bridge, bladder/tube, spring and full adjustment travel. Conduct anchor pull-out, seam tear, heel retention and fit/pressure-point assessments. No cut pattern or validated upper anchor system exists now.

## Footbed

Rev R adds three separate components per size: `footbed_heel_piece.stl` (nominal 7 mm EVA), `footbed_toe_piece.stl` (nominal 5 mm EVA), and `footbed_toe_lap_tongue.stl` (45×50×5 mm nominal sliding tongue). The heel underside pocket captures the tongue with nominal geometric clearances; for maximum EU46 extension 26.667 mm, the 45 mm tongue leaves about 18.333 mm overlap. The footbed can be removed for inspection without disturbing the mechanism. Supplier compression-deflection curve, density, compression set, thickness tolerance and cover/bond details are not selected, so footbed mass and comfort are not claimed. Bench-cycle at all sizes for binding, wear, thickness build-up and collision with moving components.

## Heel spring / pneumatic core

Rev R has no actual spring, bladder, tubing or valve geometry. `part="heel_core_envelope_study"` displays a 55×23×10.5 mm reserve and schematic zones; unlike Rev Q, the source now subtracts a matching continuous cavity in the fixed heel deck. The cavity proves only geometric reserve—not supplier component fit or compression travel. Engineer positive spring seats/retainers, travel stops, pressure-loss failsafe and protected routing after selecting real supplier components. Do not assign operating pressure or spring rate from the bounding box.

## Outsole

Default outsole geometry remains 4.0 mm. Use a footwear-grade abrasion-resistant rubber compound targeted at 60–70 Shore A and 3–4 mm thickness, subject to supplier tear/abrasion/flex/traction data. The 3.2 mm option is an unvalidated mass study with 1.8 mm nominal residual tread skin; it is not the production default. The existing heel pad, toe pad and serpentine connector are three geometry pieces; no approved bondline, primer, mechanical retention, rubber grade or whole-shoe traction result exists. Obtain a bonding procedure approved for exact rubber and PA12 SLS surface, and test attachment and whole-shoe slip before wear.

Candidate methods: ASTM F2913-24 for whole-shoe dynamic friction; ISO 17707:2005 only for outsoles whose measured longitudinal rigidity is within its scope (maximum 30 N); ISO 17708:2018 for upper-to-sole adhesion where the assembled shoe and bond method fall within scope. A test method reference is not a result or certification.


## Rev R fixed-heel core cavity integration

Rev R1.2 subtracts one continuous underside cavity at x = −125 to −70 mm, y = ±11.5 mm, from z = −20.6 to −10.1 mm: nominal 55 × 23 × 10.5 mm. The cut is independent of the optional `lightening_enabled` setting. The dedicated local roof is now 10.1 mm (previously 5.5 mm), with nominal side web to the rail-channel envelope of 2.5 mm. The outside sole thickness remains 20.6 mm. Source assertions enforce the rear-of-split location, positive dimensions, roof-depth envelope, and at least 2.0 mm nominal rail-channel web.

This corrects the Rev Q pocket-rib collision in CAD, but it is a packaging reserve—not a pressure vessel or selected component drawing. Before closing the underside, a supplier-sized 17-7 PH spring, positive spring seats/retainers, qualified bladder, pressure-rated tube/fittings, port routing, service access, and a pressure-loss fail-safe must be engineered against this actual cavity. The 10.1 mm PA12 roof and 2.5 mm web are not certified; material-specific analysis and guarded physical testing remain release gates. Do not wear or load the printed fit kit.
