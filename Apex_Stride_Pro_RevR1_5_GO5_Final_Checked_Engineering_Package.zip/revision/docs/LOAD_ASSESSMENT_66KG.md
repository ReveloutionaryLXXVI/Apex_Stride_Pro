# Apex Stride Pro Rev P C3 — 66 kg load assessment

**Authoritative current calculation:** `reports/STRUCTURAL_ANALYTICAL_SCREENING_REVP.md`. The earlier Rev O and pre-C3 load tables are historical only; use the current C3 corrected lock-pin screen and its CSVs.

- Body mass: 66 kg.
- Gravitational force: \(66	imes9.81=647.46\;\mathrm{N}\).
- Ideal equal static bilateral split: 323.73 N/foot.
- Single-foot static case: up to 647.46 N before transient effects.

The C3 screen computes a conditional horizontal pin load with two rail load points at ±20.3 mm and side-boss support points approximated at ±45 mm. It uses the unnotched Ø8 mm shaft for maximum midspan bending (159.08 MPa at a hypothetical horizontal load equal to body weight) and separately documents the ring-groove shoulder, rail bearing/tear-out and bridge strap demands. A Kt=2 value is shown only as a sensitivity, not a calculated notch factor. None is an FEA or validated design load.

C3 also preserves 2.5 mm solid lands beyond the Ø3.3 mm rail attachment pilots by segmenting the rail relief cavities. Six native rail exports pass geometry/topology checks. This does not establish rail thread engagement, fastener pull-out, material strength or fatigue.

Solver availability: no material-specific FEA solver / FreeCAD executable was available. No manufactured prototype or test rig was present; no physical tests are reported. Human wear remains not cleared. See the authoritative report for equations, limitations, and exact output paths.
