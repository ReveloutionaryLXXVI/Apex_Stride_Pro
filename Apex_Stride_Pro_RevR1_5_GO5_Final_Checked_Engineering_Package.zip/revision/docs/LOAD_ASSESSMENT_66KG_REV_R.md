# Apex Stride Pro Rev R1.2 — 66 kg load and component operating-envelope assessment

**Status: analytical screening for design decisions only. Material-specific FEA was NOT RUN; no physical test was run; this is not an allowable stress calculation, proof test, or wearable release.** Rev R1.2 includes the corrected M4 screw/foam interface and a thickened heel-core roof; all structural values remain screening only.

## Body-weight datum and load scenarios

`F = m g = 66 kg × 9.81 m/s² = 647.46 N`. An ideal equal bilateral static share is `323.73 N per foot`. A single-support static scenario applies `647.46 N` to one shoe. The factors below are sensitivity cases chosen by the analyst, not measured gait force, medical/biomechanical data, standards acceptance factors, or a proposed safe load.

| One-shoe scenario | Force |
|---|---:|
| Equal bilateral static share | 323.73 N |
| Single-foot static full-body weight | 647.46 N |
| 1.5× sensitivity | 971.19 N |
| 2× sensitivity | 1,294.92 N |
| 3× sensitivity | 1,942.38 N |

## Structural PA12 candidate

Materialise industrial PA12 SLS reference card: density 950 kg/m³, tensile modulus 1650 MPa, tensile strength 48 MPa, flexural strength 41 MPa, flexural modulus 1500 MPa, elongation at break 20%, Shore D75 and HDT 86°C. Supplier card: https://www.materialise.com/en/industrial/3d-printing-materials/pa12-sls. These are process/card reference values; build orientation, lot, part geometry and conditioning affect parts. **48 MPa tensile strength is not yield strength and neither value is a design allowable.** Do not transfer these values to generic FDM or an unspecified MJF grade.

## Current cavity roof strip sensitivity

Rev R1.2 retains the 55×23 mm cavity footprint but uses a 10.5 mm cavity depth (z=−20.6 to −10.1 mm), a 10.1 mm roof (about +5.53 g modeled PA12 mass per heel deck), and the same 2.5 mm nominal side web, with external sole thickness still 20.6 mm. The target bladder body height is 9 mm (1.5 mm nominal vertical clearance). A deliberately simplified one-way roof strip now assumes `L=23 mm`, `h=10.1 mm`, and an effective longitudinal load-spread width `b`. The screening expression used in the accompanying analysis is `σ = 3 F L / (2 b h²)` for a central-load idealization. The actual 3D deck/rail/contact field differs; the width is an unknown assumption.

| Assumed load-spread width | 1× single-foot force | 1.5× | 2× | 3× |
|---:|---:|---:|---:|---:|
| 20 mm | 10.95 MPa | 16.42 MPa | 21.90 MPa | 32.85 MPa |
| 30 mm | 7.30 MPa | 10.95 MPa | 14.60 MPa | 21.90 MPa |
| 40 mm | 5.47 MPa | 8.21 MPa | 10.95 MPa | 16.42 MPa |
| 60 mm | 3.65 MPa | 5.47 MPa | 7.30 MPa | 10.95 MPa |

These are **load-demand sensitivities**, not failure predictions or design factors. The 10.1 mm roof reduces the one-way strip estimate versus the former 5.5 mm roof. Even where the revised estimate is below the 41 MPa flexural-strength reference, that reference is not a design allowable and does not certify the roof; 3D stress/contact, build orientation, fatigue and impact still require analysis. The roof, web, rail channels, contact distribution, build orientation, notches, fatigue and impact need material-specific structural analysis.

## Pin / rail retention sensitivity

Internal pin drawing target is an Ø8 mm 17-4PH H1150D custom pin with a nominal Ø7.6 mm retaining-ring groove root; the finished catalog part is not selected. A conservative simple-beam screen assumes a centre point load over a 90.3 mm span and treats the minimum Ø7.6 mm groove section as if it spanned the whole beam. That deliberately crude model gives:

| Scenario | Screened nominal bending stress |
|---|---:|
| Bilateral static share, 323.73 N | 169.58 MPa |
| Single-foot static, 647.46 N | 339.16 MPa |
| 1.5× | 508.73 MPa |
| 2× | 678.31 MPa |
| 3× | 1,017.47 MPa |

A listed reference minimum proof strength for 17-4PH H1150D is approximately 725 MPa (confirm exact supplier material certification/condition). The 3× sensitivity exceeds that number, and the 2× case has little nominal margin before accounting for groove stress concentration, fatigue, contacts and uncertainty. This is not an approval of the pin; the actual load path may be very different and must be calculated. Printed polymer pins are not acceptable for the critical joint.

## Spring candidate and derived return force

Lee Spring LHP 030B 04S / LHP030B04S is the selected **conditional return-function bench candidate**: Type 17-7 PH stainless; listed OD 4.57 mm, free length 19.05 mm, solid height 10.11 mm, rate 5.126 N/mm, listed load at solid 45.77 N; free-to-solid travel computed from lengths is 8.94 mm. The listed guide-rod dimension is 2.38 mm. For wire Ø0.76 mm, the nominal bore inferred from OD−2×wire is approximately 3.05 mm; this bore is **derived, not a separate supplier-quoted dimension**, and the actual drawing must be obtained before designing a guide.

No spring working stroke is derivable from the bounding cavity. For a stated, analyst-selected return-only scenario of 4–6 mm compression with no preload, `F=kδ` gives about 20.50–30.76 N. At 6 mm, the nominal remaining travel to the calculated solid height is 2.94 mm before tolerances/end effects. This is not a full-body-weight spring. Linkage travel, actual return force, preload, seat retention, guide, load-deflection tolerances and fatigue duty remain selection gates.

## Corrected pneumatic area and low-pressure auxiliary design target

**Correction to the previous screen:** the old arithmetic used the entire 55×23 mm cavity area (1,265 mm²) as though it were the bladder's effective area. That is not the specified bladder. The current RFQ target is a body envelope no larger than 27×22×9 mm inside a 28×23×10.5 mm reserve, so the nominal projected body rectangle is **594 mm²**. The effective pressure area is still supplier-dependent and may be smaller; 594 mm² is only a first-pass geometric proxy.

If the bladder alone carried all of the stated load, the pressure demand would be:

| Scenario | Demand over 594 mm² target body rectangle |
|---|---:|
| Equal bilateral static share, 323.73 N | 0.545 MPa |
| Single-foot static full body weight, 647.46 N | 1.090 MPa |
| 1.5× sensitivity | 1.635 MPa |
| 2× sensitivity | 2.180 MPa |
| 3× sensitivity | 3.270 MPa |

These figures are **not proposed operating pressures**. They show that the specified small bladder cannot be the sole body-load support with the candidate SMC KQ2 1.0 MPa fittings. The design correction is to treat the bladder as a low-pressure auxiliary-return element and require the deck/chassis/ground-contact structure to carry the load, including when the bladder is fully depressurized.

A provisional pressure hierarchy has now been added to the CAD parameters and circuit schedule: **0.40 MPa working target, 0.50 MPa nominal relief-setpoint target**. SMC ARX20 regulation (0.05–0.85 MPa) and AP20-D set range (0.05–0.8 MPa) can cover those targets; KQ2 fittings are rated 1.0 MPa maximum operating and T0425 tubing 1.5 MPa at 20 °C. The 0.50 MPa relief target leaves 0.50 MPa nominal margin to the KQ2 rating, but relief-flow/overshoot must be demonstrated to keep transients below component ratings. AP20-D suitability as the protective relief function, exact variant, and the finished bladder's working/burst/cycle ratings must be confirmed before pressurizing. Sources: https://www.smcworld.com/newproducts/en/pdf/kq2.pdf ; https://static.smc.eu/pdf/AP20-D-A_EU.pdf ; https://static.smc.eu/pdf/Tubing.pdf ; https://www.smc.eu/et-ee/products/arx20-regulator-for-2mpa~15019~cfg?partNumber=ARX20-F01BG.

At the 594 mm² proxy area, the bladder contributes nominally **237.6 N at 0.40 MPa** and **297 N at 0.50 MPa**. At nominal relief pressure, the chassis therefore still needs to carry at least **350.46 N** of the 647.46 N single-foot static case, **997.92 N** of the 2× sensitivity case, and **1,645.38 N** of the 3× case. Since a pressure loss removes that 297 N assist, the chassis must also carry the complete external load in the depressurized fault case. The selected Lee Spring is only about 20.5–30.8 N at an assumed 4–6 mm compression and is a return spring, not a body-load spring.

## Current sourced interfaces and limits

- **Rigid platform:** Materialise industrial PA12 SLS only, with lot/build orientation, critical dimension report and design allowables to be confirmed. Main deck/toe are custom SLS parts, not an off-the-shelf component.
- **Rails/bridges:** custom CNC 6061-T6 parts under internal drawings APX-RAIL-L-R1, APX-RAIL-R-R1, APX-BRG-REAR-R1 and APX-BRG-FRONT-R1; stock supplier is not the finished part manufacturer. Thread engagement, contact/wear, rail straightness and bridge fatigue require shop drawings and testing.
- **Fasteners:** proposed Würth M4 button-head lengths match nominal recess envelopes after Rev R1 edits; their source warns the head style is for limited loads. Check joint loads, thread engagement, anti-loosening, torque and corrosion compatibility.
- **Bushing:** no catalog bushing can yet be confirmed to fit the Ø8.8 mm carriage passage without blocking transverse rail-index engagement. Do not buy a generic sleeve until seat/land geometry is resolved.
- **Spring:** Lee Spring LHP030B04S is a conditional return-only candidate, not a completed fit/function selection.
- **Bladder:** DERFLEX is a custom OEM RFQ path, not a product SKU with working/burst/cycle ratings. Target body envelope ≤27×22×9 mm remains a supplier RFQ target, not a finished-part fit claim.
- **Air circuit:** SMC T0425 Nylon 12 tube is 4.0 mm OD × 2.5 mm ID and has a 13 mm minimum bend radius at its referenced condition. SMC KQ2H04 fittings match 4 mm OD tube, but line/port routing is not modeled. Check-valve direction SKU, AP20-D relief suffix, gauge/tee and 3/2 isolation/dump valve are purchasing holds. Components intended for a bench panel are not shoe-internal parts.
- **Upper/sole:** mesh, formed heel-counter sheet, EVA, rubber sheet, thread and prototype closure candidates have been identified; broad overlay-panel fabric/pattern, actual compound hardness/fatigue rating and production adhesive/primer are not closed.

## Status and next decision gates

Automation verifies source behavior, geometry consistency, adjustment states, mesh integrity and nominal calculations only. It does not measure the physical printed/machined parts. No material-specific FEA, tolerance simulation, cyclic/fatigue test, bladder pressure/leak test, proof load, outsole bond/slip test, sewn-upper retention test, or human-wear trial has been performed. Human wear is not cleared. Outstanding procurement decisions are enumerated in `revision/docs/REV_R1_PROCUREMENT_LIST.csv`; the precise sourced candidates and gates are in `revision/docs/SOURCED_COMPONENT_REGISTER_REV_R1.csv` and `revision/docs/PROCUREMENT_AND_MANUFACTURING_SPEC_REV_R1.md`.


## Current Rev R1.4 GO 1 load-path addendum

The governing strength-design fault case is **zero pneumatic assist**: the mechanical chassis must support the full 66 kg single-support static load of 647.46 N and the engineer-selected sensitivity cases (1.5×=971.19 N, 2×=1,294.92 N, 3×=1,942.38 N). These multipliers are sensitivities, not measured gait forces or standard-mandated loads. The 27×22 mm target bladder area is only 594 mm²; at the provisional 0.50 MPa relief target, ideal force is 297 N, and actual force share/effective area are not verified. Do not credit bladder pressure as a structural safety margin.

Across the split, the intended horizontal/adjustment load path is the overlapping bridge straps and their two indexed lock fasteners, with captured rails constraining vertical pull-out and guide motion; the transverse Ø8 mm cross-pin is the position lock and must not be assumed to be the only vertical support. This load path and its dynamic loads are not yet physically validated. Current strap stack, screw lengths, stagger and tip relief are documented in `REV_R1_4_GO1_GO2_STRUCTURAL_JOINT_REPORT.md`.
