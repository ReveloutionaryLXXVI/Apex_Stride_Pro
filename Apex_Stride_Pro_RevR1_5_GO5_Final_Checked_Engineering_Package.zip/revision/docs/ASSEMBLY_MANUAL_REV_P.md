# Apex Stride Pro — Rev P assembly and engineering handoff manual

**Status:** Rev P is the current digital design candidate; this manual distinguishes a nonwearable dimensional mockup from a future production-intent physical shoe. Do not wear or body-load printed mockup components. No physical load, retention, fatigue, traction or fit test has been completed.

## 1. Authoritative files

- **Editable authoritative CAD:** `revision/Apex_Stride_Pro_RevP.scad`
- **Print export CAD:** `PRINT_READY_BENCH_FIT_KIT_REV_P/source/Apex_Stride_Pro_RevP_PrintPrep.scad`
- **39 individual bench-fit STLs:** `PRINT_READY_BENCH_FIT_KIT_REV_P/stl/EU42/`, `EU44/`, or `EU46/`. Choose one size directory; these are alternatives, not parts to mix.
- **21 upper concept meshes (7 selectors × 3 sizes):** `PRINT_READY_BENCH_FIT_KIT_REV_P/upper_concept_not_wearable/EUxx/`.
- **9 optional 3.2 mm outsole study meshes:** `PRINT_READY_BENCH_FIT_KIT_REV_P/optional_3p2mm_outsole_study/EUxx/`; not approved for wear.
- **Exact 69-file map:** `revision/docs/ASSEMBLY_FILE_MAP_REV_P.csv`.
- **Material/hardware BOM:** `revision/docs/MATERIALS_AND_HARDWARE_INVENTORY_REV_P.csv`.
- **Material candidates and datasheet basis:** `revision/docs/MATERIAL_CANDIDATE_SPECIFICATION_REV_P.md`.
- **Assembly orientation diagram:** `revision/docs/REV_P_ASSEMBLY_ORIENTATION_SCHEMATIC.png` (schematic/not to scale; reference only).
- **Mass estimates:** `revision/verification_results/revP_mass_audit/REVK_REVP_FRESH_MASS_SUMMARY.csv` and `MASS_BY_MATERIAL_CANDIDATE.csv`.
- **Load screen:** `reports/STRUCTURAL_ANALYTICAL_SCREENING_REVP.md`.
- **Tests:** `revision/verification_results/revP_mass_audit/` and `FINAL_CLOSURE_TEST_REGISTER.md`.
- **Original baseline:** `baseline_original/`; do not overwrite it.

The prior Rev O/C2 and Rev K/L/M/N artifacts remain in the package for traceability. **Use only Rev P sources for new exports.** No validated pneumatic chamber/tube/valve or spring/damper/piston is present in the supplied CAD.

## 2. Part/size selection and printing

Select exactly one of EU42, EU44 or EU46. Size labels and width_scale settings (1.00 / 1.04 / 1.08) are nominal CAD presets, not standardized shoe size or foot measurement. Print only the **nonwearable fit/mockup parts**. The fit-kit meshes are exported at 1:1 dimensions, centered in XY, translated so Z-min=0, have positive volume, watertight surfaces and consistent winding, and fit within a 220 × 220 mm XY envelope in the supplied orientation. No G-code is supplied; printer, material, nozzle/layer settings, support, brim and process tolerances must be set by the user. The aggregate lower-platform STL was excluded because it was non-watertight and too long for a 220 mm bed; use the separate component STLs.

For printing/inspection use: calipers, deburring tool, small files, eye protection and a clean bench. Do not use printed rail/pin/ring mockups as structural hardware; printed deck/outsole/upper parts are fit samples only. Reject cracks, delamination, warpage, malformed pin holes or any part that must be forced to mate.

## 3. Main fit/mockup parts and orientation

The full filename/dimension/path list is the authoritative CSV map. Per one shoe, selected size kit contains:

- `heel_deck.stl` (1): fixed rear platform; broad foot-contact side up; underside rail channels face down.
- `rail_left_solid_polymer_fit_only.stl` + `rail_right_solid_polymer_fit_only.stl` (2): rails run front-to-back along X, with the nominal 11 mm T-head held in the deck channel and 6.5 mm neck toward outsole; current source centerlines are Y=±20.3 mm. Rails are mockup gauges; not load-rated rails.
- `toe_carriage.stl` (1): moving toe platform; align both captured channels and cross-pin passage to the rails.
- `bridge_rear.stl` / `bridge_front.stl` (1 each): overlap beneath decks in the formed recesses; each is nominally 23 × 3 mm in section. Do not force them into pockets.
- `pin_through_solid_mockup_only.stl` (1) and `retaining_ring_schematic_mockup_only.stl` (1): only visual/fit gauges, never retention hardware.
- `outsole_heel_pad.stl`, `outsole_toe_pad.stl`, `outsole_flex_connector.stl` (1 each): underside shape samples; attachment is not designed/validated.
- `footbed_heel_piece.stl`, `footbed_toe_piece.stl` (1 each): 3 mm visual inserts; butt seam at the split, no join features and no real cushioning.

The upper concept directory has visual files for toe vamp, sidewall envelope, heel counter, tongue, side overlays, anchor doublers and straps. It is not a stitched upper, fitted footwear pattern or validated anchor layout.

## 4. Beginner-friendly dry-assembly sequence (bench only; zero body load)

1. **Lay out and identify parts.** Choose EU42, EU44 or EU46. Match every name to `ASSEMBLY_FILE_MAP_REV_P.csv`. Do not mix sizes. Check the parts index; the upper meshes and optional 3.2 mm outsole meshes are marked concept/study only.
2. **Orient the heel deck.** Broad top surface upward, captured rail channels and bridge recesses downward. Do not sand away the channel roofs or stop-lug geometry to make parts fit.
3. **Insert the two rail mockups.** Slide them axially into the open captured-channel entry along X. Keep them parallel; do not spread, pry or hammer. The schematic rail head is 11 mm wide, stem 6.5 mm, overall section height 16.1 mm. If there is binding, stop and measure rather than scraping away material.
4. **Attach rails only if it is a deliberate fastener-geometry mockup.** Source shows four nominal rail mounting locations: 4.8 mm deck clearance holes over Ø3.3 mm candidate M4×0.7 tap-drill pilots. C3 splits the rail-relief cavities to retain a solid material land at least 2.5 mm beyond each pilot-hole radius. This is geometry-only; these dimensions do not constitute an approved thread callout or establish pull-out strength. The fit kit contains no screws. Do not tap or install fasteners until rail alloy, thread, engagement, length and head dimensions are approved. For a purely visual dry mockup, leave the rails unfastened and secure the bench assembly by hand only.
5. **Fit the toe carriage.** Align both T channels to rail heads, then slide along X. Never flex the deck to engage it. Nominal extensions are 0 mm (EU42), 13.333 mm (EU44), 26.667 mm (EU46). The stop-groove correction removed the prior positive-volume interference at maximum extension; this is still only nominal CAD geometry, not tolerance qualification.
6. **Check selected-position registration.** At EU42/44/46 positions only, align the Ø8.3 mm rail index bores and Ø8.8 mm toe-boss passage, then insert the polymer pin mockup by hand from the +Y head side. Never hammer, ream, or force it. The pin is an adjustment lock, not the primary intended vertical load path. The physical pin/groove/ring is not finalized by the mockup STL.
7. **Place rear and front bridge straps.** Fit `bridge_rear.stl` into the heel recess and `bridge_front.stl` into the moving toe recess; confirm overlap without scraping. The CAD has 4 nominal anchor screws plus 2 selected-position locking screws and six captive-nut pockets, but no screws/nuts are included. Fastener thread/grade/length/torque/anti-loosening is not finalized. Keep this step a dry fit only.
8. **Add outsole-shape components unbonded.** Place the heel pad and toe pad below decks and the flexible connector between them. Do not guess at adhesive or rely on a printed connector as a spring/damper. Bondline/positive retention, tread compound and grip are not specified. Leave unbonded for mockup.
9. **Place footbed silhouettes.** Align the two flat pieces on top. Their butt seam does not lock together; they are not cushioning.
10. **Overlay upper concepts for visual fit only.** Use the concept meshes only as visual envelopes, not as sewing patterns, actual straps or a means of restraining a foot. Do not place a foot into the assembly.
11. **Document fit.** Photograph and measure rail engagement, clearances, selected pin alignment, bridge overlap, stop contact and outsole/upper interference. Record dimensions, but do not infer strength from a successful dry fit.

## 5. Future production-intent assembly (not an executable wear assembly yet)

The following is the intended conceptual order once hardware drawings and materials are approved: machine/finish rail and pin parts to an approved drawing; gauge rail index bores and pin; capture rails in heel/toe channel arrangement; install rail attachment screws using an approved thread/torque spec; fit rear/front bridge straps, approved M4 screws and captive nuts; set toe to one discrete index; fully insert pin and install the specified DIN 471 external retaining ring with the correct tool; verify positive retention; complete a designed sole attachment system; add specified cushioning/footbed; stitch or bond a fitted upper and attach straps to validated anchors. **This paragraph is a future sequence, not a fabrication release.** The current package does not define a production upper, functional cushioning mechanism, outsole attachment, or load-qualified hardware. Do not pick torque values from generic tables without the actual fastener grade, thread engagement and joint design.

## 6. Critical clearances and stop conditions

C3 rail relief correction evidence: `revision/verification_results/REV_P_C3_SAFETY_CORRECTION/C3_CORRECTIVE_TEST_REGISTER.csv`. The cavities are separated around the two Ø3.3 mm candidate rail attachment pilots to leave a nominal 2.5 mm land beyond each pilot radius. This does not approve the pilot as a final thread or establish screw pull-out, vibration or fatigue capacity.

- Nominal rail index hole Ø8.3 mm with Ø8.0 mm pin gives 0.30 mm diametral clearance (proposed tolerances remain unverified).
- Carriage passage Ø8.8 mm around Ø8.0 mm pin is 0.8 mm nominal diametral clearance.
- Ring envelope Ø14.7 mm in a Ø15.2 mm recess leaves 0.25 mm radial nominal clearance; ring groove is Ø7.6 × 0.9 mm in CAD for an 8 mm DIN471 candidate. Confirm actual catalog drawing before machining.
- Deck roof above captured rail is 4.1 mm nominal; channel/bridge web 2.15 mm; nominal outer wall 5.4 mm at width_scale=1.00; bridge fastener edge distance 4.1 mm. These are geometry measurements, **not strength ratings**.
- Stop immediately if the rail/head binds, bridge recess interferes, hole alignment cannot be reached by hand, pin does not seat, the ring fails to snap fully into groove, boss/deck cracks, or the stop does not touch face-to-face.
- No torque values are approved. No human load, walking or running tests are permitted before material-specific engineering and physical qualification.

## 7. Troubleshooting

- **Rail will not slide:** verify left/right orientation, print scale is 100%, size folder and support/brim artifacts. Do not alter the channel roof/head/web without engineering review.
- **Pin will not align:** return to an indexed station; do not force between settings. Measure bore positions/diameters and inspect stop/rail alignment.
- **Bridge will not sit flush:** confirm correct front/rear bridge and proper width; the nominal source flange is 23.0 mm and stack thickness is 6 mm for the two layers. Do not grind deck webs or bridge flanges to fit.
- **Retaining ring will not seat:** the STL is schematic; stop and gauge the real ring, shaft and groove from supplier drawings. Never use a printed clip.
- **Outsole flex link cracks or feels too stiff:** reject it as a mockup; it is not a specified spring or pneumatic cushion.
- **Upper concept overlaps or floats:** that indicates the visual concept does not represent a fitted pattern; do not compensate by stretching a strap across a foot.

## 8. Regeneration and dependencies

Install a compatible OpenSCAD version and Python 3 with `trimesh` and `numpy`. From the package root, run:

```bash
python revision/tools/export_print_fit_kit_revP.py
python revision/tools/export_upper_concepts_revP.py
python revision/tools/export_optional_outsole_study_revP.py
python revision/tools/recalculate_mass_revP.py
python revision/tools/run_analytical_load_screen_revP.py
python revision/tools/run_revp_kinematic_clearance_sweep.py
python revision/tools/test_revp_locked_stop_intersections.py
python revision/tools/run_revP_source_compile_matrix.py
```

The printed STLs are component fit samples only. FreeCAD and its `.FCStd` writer, a STEP exporter and a suitable FEA solver are not installed in the current execution environment, so no `.FCStd`, STEP or material-specific FEA result is included. No actual fastener torque is assigned. See `FINAL_CLOSURE_TEST_REGISTER.md` for recorded outcomes and limitations.
