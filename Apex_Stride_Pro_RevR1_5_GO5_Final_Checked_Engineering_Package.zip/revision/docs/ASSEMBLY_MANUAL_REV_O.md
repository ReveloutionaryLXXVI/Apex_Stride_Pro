# Apex Stride Pro — Rev O C2 assembly and prototype-preparation manual

**Document scope:** This manual describes the actual Rev O C2 CAD files and **non-wearable dimensional mockup**. It is not permission to wear or load the printed parts. The original architecture is preserved: heel deck, moving toe carriage, captured T-rails, overlapping bridge straps, cross-pin/retaining-ring concept, outsole pads/flex connector, split footbed silhouette and upper concept shells.

## 1. Source of truth and file layout

- **Authoritative editable CAD:** `revision/Apex_Stride_Pro_RevO.scad`.
- **Authoritative print-preparation CAD:** `PRINT_READY_BENCH_FIT_KIT/source/Apex_Stride_Pro_RevO_PrintPrep.scad`.
- **Non-wearable chassis/STL kit:** `PRINT_READY_BENCH_FIT_KIT/stl/EU42/`, `EU44/`, or `EU46/`. Choose one size folder only; these are alternatives, not parts to combine across sizes.
- **Upper visualization only:** `PRINT_READY_BENCH_FIT_KIT/upper_concept_not_wearable/EUxx/`.
- **Optional 3.2 mm outsole study:** `PRINT_READY_BENCH_FIT_KIT/optional_3p2mm_outsole_study/EUxx/`; use only as a separate mass/geometry study, not as the default or for wear.
- **Exact file-by-file map:** `revision/docs/ASSEMBLY_FILE_MAP_REV_O.csv`.
- **Complete material/hardware inventory:** `revision/docs/MATERIALS_AND_HARDWARE_INVENTORY_REV_O.csv`.
- **Mass estimates:** `revision/verification_results/fresh_closure_audit/REVK_REVO_FRESH_MASS_SUMMARY.csv` and `REVO_OPTIONAL_OUTSOLE_STUDY_MASS.csv`.
- **66 kg assessment:** `revision/docs/LOAD_ASSESSMENT_66KG.md`.

The original uploaded package and extracted Rev K source are preserved under `baseline_original/`. Earlier Rev K/L/M/N sources and reports are historical references. Use Rev O C2 files named above for this closure package.

## 2. Choose a size and print purpose

Use exactly one size: EU42, EU44 or EU46. Size increments are nominal CAD presets, not a substitute for measuring both feet against a real last. Width settings 1.00, 1.04 and 1.08 are shell-envelope presets only; they are not standardized widths.

The 39-file main kit is arranged as `01_chassis`, `02_outsole_fit_only`, and `03_hardware_mockup_ONLY`. For one size it contains 13 individual STLs: heel deck, toe carriage, front/rear bridges, two footbed silhouette pieces, three outsole pieces, two rail fit mockups, one pin mockup and one schematic ring mockup. The separate upper directory adds seven concept STL files per size (some files contain pairs/four-patch groups). Do not use the polymer rail, pin, or ring files as load-bearing hardware. The 11 mm rail width matches the original baseline; the prior 15 mm value was removed after identifying incorrect side-ligament arithmetic.

C2 removes a documented 0.3 mm stop-groove start offset that caused a about 2.04 mm³ rail-lug/toe-carriage interference at maximum EU46 extension. Six exact source CSG checks pass for the toe versus both rails at EU42/EU44/EU46; this verifies only absence of positive-volume CAD overlap, not tolerance robustness or strength.

The STL files in the main kit are already centered in XY and placed at Z-min = 0. Their original geometry is only rotated/translated; it is not scaled. Inspect `PRINT_PARTS_INDEX.csv` for per-file extents and mesh status. Printer brim/support placement, nozzle, process orientation and tolerances still depend on your actual printer/slicer. No G-code is included.

## 3. Bill of materials for one bench-fit mockup

Paths below are relative to the package root and substitute `EUxx` with one chosen size.

| Qty. | Component | Exact file | Function/orientation | Important limitation |
|---:|---|---|---|---|
| 1 | `heel_deck` | `PRINT_READY_BENCH_FIT_KIT/stl/EUxx/01_chassis/heel_deck.stl` | Fixed rear deck; broad top side upward, split seam faces toe carriage | Polymer mockup only |
| 1 | `toe_carriage` | `PRINT_READY_BENCH_FIT_KIT/stl/EUxx/01_chassis/toe_carriage.stl` | Moving forefoot deck; align its rail slots and cross-pin tunnel with rails | Polymer mockup only |
| 1 each | `rail_left_solid_polymer_fit_only`, `rail_right_solid_polymer_fit_only` | `.../stl/EUxx/03_hardware_mockup_ONLY/rail_left_solid_polymer_fit_only.stl` and `rail_right_solid_polymer_fit_only.stl` | Rails run front–back along X, centerlines nominally Y = ±22.5 mm; 11 mm T-head fits upward into captured channel; 6.5 mm stem faces the outsole side | Solid polymer fit mockups, not production rails |
| 1 | `bridge_rear` | `.../stl/EUxx/01_chassis/bridge_rear.stl` | Rear strap lies in underside recess on the heel deck | Not a load-rated bridge |
| 1 | `bridge_front` | `.../stl/EUxx/01_chassis/bridge_front.stl` | Front strap lies in underside recess on moving toe deck and overlaps rear strap | Not a load-rated bridge |
| 1 | `pin_through_solid_mockup_only` | `.../stl/EUxx/03_hardware_mockup_ONLY/pin_through_solid_mockup_only.stl` | Mock pin enters from +Y/head side through aligned rail index holes and toe-boss passage | Do not use as a real lock pin |
| 1 | `retaining_ring_schematic_mockup_only` | `.../stl/EUxx/03_hardware_mockup_ONLY/retaining_ring_schematic_mockup_only.stl` | Visual ring at the −Y end of pin | Not a functional snap ring; real DIN 471 size-8 ring is a separate unresolved purchase |
| 1 each | `outsole_heel_pad`, `outsole_toe_pad`, `outsole_flex_connector` | `.../stl/EUxx/02_outsole_fit_only/outsole_heel_pad.stl`, `outsole_toe_pad.stl`, `outsole_flex_connector.stl` | Align to heel, toe and center flexible link, beneath deck | No validated bond or retention system; do not glue on assumptions |
| 1 each | `footbed_heel_piece`, `footbed_toe_piece` | `.../stl/EUxx/01_chassis/footbed_heel_piece.stl`, `footbed_toe_piece.stl` | Visual silhouette on top of decks; butt joint at x = −25 mm | No joining feature; not cushioning |

This is a dimensional fit kit. It does **not** contain the four rail screws, six nominal bridge screws, captive nuts, real pin, real retaining ring, production upper, cushioning material or outsole attachment system. Exact fastener details and torque are not specified; do not substitute arbitrary screws.

## 4. Mockup assembly sequence (no body load)

1. **Inspect prints first.** Compare each print to `PRINT_PARTS_INDEX.csv`. Reject cracked, warped, delaminated or dimensionally suspect parts. Deburr only lightly and do not alter the rail channels, pin bosses, stop lugs or bridge recesses to force a fit.
2. **Place the heel deck.** Put the broad foot-contact face upward and underside channels downward. Keep its split seam at X = −25 mm in source coordinates; the print kit itself is centered for the bed, so use relative mating shapes rather than relying on each STL’s world origin.
3. **Dry-fit the two rails.** Position left/right rail mockups parallel in the captured underside channels with their 11 mm T-heads toward the deck cavity and 6.5 mm stems toward the outsole. The source puts the rail centerlines at ±22.5 mm. Insert axially from the seam/open channel end only if the part moves freely; stop if it jams. The 39-file fit kit rails have mass-relief cavities disabled to make solid polymer gauges, so they do not replicate production rail mass/section.
4. **Fit the moving toe carriage.** Keep the carriage separate at first. Align its paired T-channels with the rail heads and slide it along X without bending the rails. Size extensions from the EU42 reference are nominally 0.000 mm (EU42), 13.333 mm (EU44), and 26.667 mm (EU46). The endpoint lug is a travel stop, not the size lock.
5. **Check pin registration by hand.** At the selected extension, align the Ø8.3 mm nominal rail index holes with the Ø8.8 mm carriage passage. Insert the polymer pin mockup with its single head on +Y and the schematic ring end on −Y. Never hammer it. The real pin/ring geometry and tolerances are not yet an approved manufacturing specification. If it does not slide fully by hand, stop; do not ream/force any hole based on this mockup.
6. **Dry-place bridge straps.** Put `bridge_rear.stl` into the heel underside recess and `bridge_front.stl` into the toe recess; align the overlap and select one indexed pair corresponding to the size. The kit has no bridge screws or nuts. Use this step only to check nominal registration and stack fit; the parts are not positively fastened and must not be pulled, loaded or worn.
7. **Dry-align outsole shapes.** Align the heel pad below the heel deck, toe pad below the moving toe, and serpentine connector between them. Verify the clearance around rail channels/bridge pockets. The CAD contains no finalized adhesive/bondline or validated mechanical retention design. Keep them unbonded during the mockup inspection; do not walk on the parts.
8. **Place footbed silhouette pieces.** Put the heel and toe pieces above the corresponding decks. Their split at X = −25 mm is a plain butt joint with no joining feature. This is a visual insert only, not real foam cushioning.
9. **Overlay upper concepts only if useful.** Files in `upper_concept_not_wearable/EUxx/` show visual shells/straps; they are not fitted footwear patterns or validated straps. Do not attach them to a foot or claim they retain a foot.
10. **Record fit findings.** Test each intended setting by hand without impact. Record measured dimensions, contact/interference, pin insertion/removal force if instrumented, looseness, and photo evidence. Do not infer load capacity from successful dry assembly.

## 5. Viewing and regenerating the CAD

Install OpenSCAD 2021.01 or a compatible current version. Open `revision/Apex_Stride_Pro_RevO.scad` or the print-preparation source above. Parameters are at the top (`eu_size`, `width_scale`, `part`, `outsole_weight_study`). For a native CAD render in a shell, from the package root:

```bash
openscad -o /tmp/apex_full_mockup.csg -D 'eu_size=44' -D 'width_scale=1.00' -D 'part="full_mockup"' revision/Apex_Stride_Pro_RevO.scad
openscad --export-format binstl -o /tmp/apex_heel_deck.stl -D 'eu_size=44' -D 'width_scale=1.00' -D 'part="heel"' revision/Apex_Stride_Pro_RevO.scad
```

For a fit-print component, use the selector in `PRINT_READY_BENCH_FIT_KIT/PRINT_PARTS_INDEX.csv` against `PRINT_READY_BENCH_FIT_KIT/source/Apex_Stride_Pro_RevO_PrintPrep.scad`; the packaged STLs have already been post-normalized for build-plate placement. Use `python revision/tools/recalculate_mass.py` to regenerate the native mesh/density mass study, and `python revision/tools/validate_final_closure.py` to rerun this package’s geometry checks. See `README.md` for dependencies and the limits of each command.

**No FreeCAD executable/library was available in this runtime.** A verified `.FCStd` was therefore not produced. OpenSCAD 2021.01 does not export STEP directly; a faceted mesh converted to a nominal STEP would not be an equivalent editable solid model, so no STEP is supplied. The authoritative editable source is `.scad`, with STL fit meshes as listed. A single aggregate lower-platform STL export was tested and rejected because it was non-watertight and 294–321 mm long; it is not supplied. Use only the individually checked component STLs for non-wearable mockups.

## 6. Production-intent assembly sequence (not a wear authorization)

This is the order to use only after a responsible engineer completes missing drawings/specifications and approves the manufactured parts:

1. Confirm material grades/processes and finish all rail holes, carriage bores, pin groove and ring recess to a released drawing; gauge every mating feature.
2. Assemble real rails into the heel channel, install the specified four rail-fastening screws using the released thread/engagement drawing, and inspect parallelism and sliding.
3. Mate the toe carriage over the rails; verify stop-lug travel and all three settings without binding.
4. Fit rear/front bridge straps into their recesses. Install the specified heel anchor, toe anchor and selected-index fasteners/nuts per the approved bill of materials. Apply only torque values calculated/issued for the exact fasteners, materials, thread engagement and lubrication. **No torque value is available in this package.**
5. Align the selected rail index pair and insert the manufactured metal pin from +Y. Install the correct purchased DIN 471 ring with the correct pliers; verify full ring seating, axial retention and clearance against the recess floor.
6. Apply only the engineered outsole attachment method after substrate/adhesive/fastener approval and cure/inspection criteria. Do not improvise adhesive or rely on friction alone.
7. Install the specified production cushioning/footbed and textile upper only after the actual last/pattern, seam/anchor specification, closure and retention requirements are released. The current CAD does not contain pneumatic chambers, air tubing, valves, coil/leaf springs or a separate piston/damper assembly.
8. Complete material-specific analysis, guarded proof/fatigue/retention/traction/fit validation, independent review and written release before any human wear trial.

## 7. Tolerances, inspection and troubleshooting

Nominal Rev O interfaces: rail centers Y = ±22.5 mm; rail head width 11.0 mm (Rev K baseline); stem width 6.5 mm; neck height 2.3 mm; total rail height 16.1 mm; rail index holes Ø8.3 mm; carriage passage Ø8.8 mm; nominal custom pin shaft Ø8.0 mm; bridge flange width 24 mm and each layer 3 mm; deck thickness 20.6 mm; default outsole 4.0 mm; footbed silhouette 3.0 mm. Values are nominal CAD only, not manufacturing limits.

- **Toe binds:** stop; inspect channel/rail orientation, warping, burrs, parallelism and print scale. Do not sand load surfaces until a drawing gives an allowance.
- **Pin will not pass:** stop; confirm the same size/index position, rails fully seated, hole registration and print dimensions. Do not drill/ream based on STL without an approved tolerance plan.
- **Retaining ring looks flush or sits proud:** the simplified printed ring is not functional; compare only to the released ring drawing. Do not substitute this STL for metal hardware.
- **Bridge sits proud:** check correct rear/front parts and selected-size indexing; do not machine away the underside recess.
- **Outsole overlaps or opens a gap:** note the interference. No approved bond or mechanical attachment exists; do not tape/glue it and treat that as production retention.
- **Any crack, whitened polymer, delamination, unexpected contact, loose fastener, permanent set or pin movement:** stop the bench check and quarantine the part.

## 8. Checks, stop conditions and release status

- The package includes a fresh mass export audit, current part mesh index, Rev O source compile sweeps, parameter assertion checks, upper mesh topology checks, optional outsole study export checks, and the historical Rev O interface/geometry regression reports.
- Automated geometry checks do not prove strength, fatigue, retention, fit, grip or safety. No material-specific FEA, physical proof-load, impact, fatigue, pin/retaining-ring retention, production fastener test, outsole traction/attachment, upper/strap/fit test or human trial has been run for this closure.
- Stop on any geometry failure; do not advance to wear tests from a bench-fit result.

**Final disposition: current CAD/source + mockup print files are digitally checked. The product is not manufacturing-ready or cleared for human wear.** The exact remaining physical and technical release items are in `PROJECT_STATUS_AND_RELEASE_GATE.md` and `revision/docs/MATERIALS_AND_HARDWARE_INVENTORY_REV_O.csv`.
