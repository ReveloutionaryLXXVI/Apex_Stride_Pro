# Apex Stride Pro Rev Q — assembly and integration manual

**Purpose:** identify the actual source and fit/mockup files, show a repeatable non-loaded assembly order, and specify the production integration work. This is not a human-wear or manufacturing release. The new files are Rev Q material-integration CAD candidates.

## 1. Source of truth and file organization

- Editable main CAD: `revision/Apex_Stride_Pro_RevQ.scad`
- Print-prep source, geometry selector-matched: `PRINT_READY_BENCH_FIT_KIT_REV_Q/source/Apex_Stride_Pro_RevQ_PrintPrep.scad`
- Individual fit/mockup STLs and per-size index: `PRINT_READY_BENCH_FIT_KIT_REV_Q/stl/EU42/`, `EU44/`, `EU46/`; index `PRINT_READY_BENCH_FIT_KIT_REV_Q/PRINT_PARTS_INDEX_REV_Q.csv`
- Upper concept meshes (not patterns): `PRINT_READY_BENCH_FIT_KIT_REV_Q/upper_concept_not_wearable/EUxx/`
- Optional thinner outsole study (not for wear): `PRINT_READY_BENCH_FIT_KIT_REV_Q/optional_3p2mm_outsole_study/EUxx/`
- Material/fastener schedule: `COMPONENT_INTERFACE_FASTENER_SCHEDULE_REV_Q.csv`; BOM: `BILL_OF_MATERIALS_REV_Q.csv`; exact component references: `ASSEMBLY_FILE_MAP_REV_Q.csv`.

The original Rev K project archive is preserved under `baseline_original/`. Rev Q does not have a validated pneumatic/spring core. The only source for that subsystem is `part="heel_core_envelope_study"`, a bounding-envelope visualization that overlaps deck pocket ribs; it is not a buildable chamber/cavity.

## 2. Scope and safety

**For dimensional bench/mockup only. Do not wear or load the printed plastic hardware.** Use protective eyewear while depowdering, cutting, deburring or fitting. Keep fingers out of rail channels and moving split. Use gloves appropriate to cutting tools; do not use gloves near rotating drill/spindle tooling. Clamp work on a bench. No power tool modifications to a critical joint without engineering drawings. Stop at any binding, cracked material, pin mismatch, loose/incorrect retaining ring or non-flush outsole.

## 3. Actual fit-kit file list per size

Each of EU42/EU44/EU46 has these 14 files (the exact generated STL paths are in `ASSEMBLY_FILE_MAP_REV_Q.csv`):

| Filename | Qty | Intended role / limit |
|---|---:|---|
| `01_chassis/heel_deck.stl` | 1 | Fixed deck fit mockup; not load-rated PA12 production component |
| `01_chassis/toe_carriage.stl` | 1 | Sliding deck fit mockup |
| `01_chassis/bridge_rear.stl` | 1 | Rear telescoping bridge shape mockup; intended production candidate metal |
| `01_chassis/bridge_front.stl` | 1 | Front moving bridge shape mockup; intended production candidate metal |
| `01_chassis/footbed_heel_piece.stl` | 1 | 7 mm nominal heel foam cut part with underside lap pocket |
| `01_chassis/footbed_toe_piece.stl` | 1 | 5 mm nominal forefoot foam cut part |
| `01_chassis/footbed_toe_lap_tongue.stl` | 1 | 45×50×5 mm nominal sliding tongue for forefoot insert |
| `02_outsole_fit_only/outsole_heel_pad.stl` | 1 | 4 mm outsole geometry gauge; rubber not selected |
| `02_outsole_fit_only/outsole_toe_pad.stl` | 1 | 4 mm outsole geometry gauge |
| `02_outsole_fit_only/outsole_flex_connector.stl` | 1 | Serpentine outsole connector shape gauge, not a validated spring |
| `03_hardware_mockup_ONLY/rail_left_solid_polymer_fit_only.stl` | 1 | Solid polymer rail gauge only; actual rail should be qualified metal candidate |
| `03_hardware_mockup_ONLY/rail_right_solid_polymer_fit_only.stl` | 1 | Solid polymer rail gauge only |
| `03_hardware_mockup_ONLY/pin_through_solid_mockup_only.stl` | 1 | Pin geometry gauge only, never load-bearing hardware |
| `03_hardware_mockup_ONLY/retaining_ring_schematic_mockup_only.stl` | 1 | Ring-envelope gauge only, not a retaining ring |

## 4. Tools and safety equipment

For bench fit: flat bench, rulers/calipers, small flashlight, marker, camera, soft jaw clamp, and preferably pin gauges/small bore gauges. Eye protection and suitable deburring PPE. The physical assembly has no approved torque figures; do not install production fasteners based only on these mockup files. Never hammer the pin or pry captured rails into place.

## 5. Non-loaded mockup assembly order

1. **Select one complete size.** Use the same size prefix for all components; do not mix EU42/EU44/EU46. Verify each path against the index.
2. **Place heel deck** with top/foot surface up; captured rail channels and underside recesses down. Confirm there are no print remnants in the channels. Do not scrape the channel roof or rails to force fit.
3. **Install rail gauges.** Slide left/right solid polymer gauges axially through the open channel entrances. Keep parallel; check even sliding resistance and continuous captured-head engagement. These STLs intentionally omit rail cavities for fit gauging and do not represent production rail mass or strength.
4. **Fit toe carriage.** Align both T-channels over the rails and slide along the adjustment axis. Do not flex deck or rail. At EU42/44/46 settings, confirm the stop does not bind and carriage alignment is repeatable. The CAD stop collision was corrected, but manufacturing tolerance has not been verified.
5. **Check lock-bore alignment.** At the three discrete settings, visually check rail Ø8.3 mm holes against the carriage Ø8.8 mm passage. Insert the polymer pin gauge by hand only. If it does not pass freely, stop and record the misalignment; no reaming or forcing.
6. **Fit bridge gauges.** Set rear and front bridge strips into their recesses and confirm flush seating and overlap. No screws are included. Do not drill/tap or infer torque from the CAD. The design has four candidate anchor fasteners plus a pair of active lock screws at a selected station; exact grade/length/engagement/torque is unresolved.
7. **Trial outsole shapes without glue.** Place heel pad, toe pad and serpentine connector on the underside. Check coverage and ground-facing orientation. Do not bond. The connector is not the mechanical return spring and is not proof of cushioning.
8. **Install footbed geometry.** Place 7 mm heel part and 5 mm toe part on the upper deck. Fit the separate 45 mm tongue to the toe insert at the split, then slide it into the underside heel pocket. Verify it stays overlapped through full size adjustment without edge binding. The EVA supplier/cover bond is unresolved; this is dry dimensional fit.
9. **Overlay upper concepts outside the assembly.** The toe vamp, upper wall, heel counter, tongue, overlays, doublers and strap meshes are silhouettes only. They cannot hold a foot and are not sewing patterns. Do not put a foot into this device.
10. **Record measurements.** Measure rail extension/engagement, stop contact, pin alignment, bridge overlap, footbed lap remaining, outer wall, outsole coverage, and all collisions at EU42, EU44 and EU46. Record tool uncertainty and photos. A successful dry fit does not prove strength.

## 6. Production-intent order — only after missing parts/engineering are completed

1. Select an exact PA12 SLS service and obtain its lot/process card; manufacture rigid heel/toe chassis only from approved production CAD.
2. Select/certify metal rails/bridges, tap drill/thread/engagement and surface finish; gauge the actual bores and channels.
3. Select a metal pin drawing and actual DIN471 size-8 ring from a traceable supplier. Verify shaft, head, groove, protrusion, ring-seat depth and retention. Printed pin/ring files are not parts.
4. Select and test M4 rail/bridge fasteners, captive nuts/inserts, lengths, grades, washers/locking method and torque. Use manufacturer data and joint analysis; there are no approved torque values in Rev Q.
5. Engineer and manufacture a real mechanical spring, spring seats, positive retaining hardware, mechanical stops and a pressure-loss failsafe. Obtain the supplier load curve, free/solid length, preload and fatigue rating.
6. Select a pressure-rated flexible bladder fitting inside a redesigned and verified chamber; route 4 mm OD PU tube only if fitting and pressure requirements match. Add regulator/gauge, check valve, relief valve and controlled dump. Do not set pressure until every component is rated and the whole system has a derived/verified maximum allowable working pressure.
7. Fit and cycle the actual bladder/spring assembly in a guarded fixture and verify no collapse/pinch under pressure loss.
8. Bond or positively attach a selected rubber outsole using its approved PA12-compatible primer/adhesive process, or engineer an appropriate mechanical interface; test flex/peel/grip.
9. Create and sew the last-matched textile upper with nylon reinforcement, heel counter, collar/tongue padding, bonded polyester thread and tested closure anchors. Verify skin clearance from all moving mechanisms.
10. Complete component-specific engineering validation in `PHYSICAL_VALIDATION_CHECKLIST_REV_Q.csv`. Human wear is not permitted until all required gates are passed and an independent engineer approves it.

## 7. Critical nominal interfaces (not tolerances for manufacturing release)

- Rail centerlines ±20.3 mm; rail head 11 mm wide; stem 6.5 mm; total height 16.1 mm.
- Rail index holes Ø8.3 mm; centers separated by nominal 13.333 mm; first to last 26.667 mm. Pin shaft target Ø8.0 mm; carriage passage Ø8.8 mm.
- Candidate rail mounting holes Ø3.3 mm (M4×0.7 tap-drill candidate) under deck Ø4.8 clearance holes at split−60 and split−40 mm, both rails. These are not final thread drawings.
- Bridge strips 23×3 mm each and 6 mm recessed stack; bridge holes Ø4.8 mm, nominal edge distance 4.1 mm.
- Pin head Ø12×3 mm in Ø12.4 counterbore. Candidate ring envelope Ø14.7×0.8 mm, recess Ø15.2×1.5 mm; shaft groove root Ø7.6 mm, width0.9 mm. Actual DIN ring drawing must supersede these model envelopes.
- Footbed heel 7 mm, forefoot 5 mm, tongue 45×50×5 mm, nominal lap at maximum EU46 extension 18.333 mm.
- Outsole 4 mm default; 3.2 mm is a non-wear mass study only.

## 8. Stop conditions / troubleshooting

Stop and do not use if any rail binds, holes do not align without force, pin backs out or cannot be retained, ring does not fully seat, deck/rail/bridge cracks, fastener threads strip, the sole peels or connector tears, bladder/tube pinches or leaks, spring can escape, footbed lap snags, or any upper element enters a moving clearance. Any crack, permanent set, loose bolt, unexpected deflection, pressure spike, audible pop, leakage, ring movement, or loss of adjustment lock during a future guarded test is a test failure. Depressurize remotely and safely before inspection.

## 9. Regeneration

Requires OpenSCAD, Python 3, NumPy and trimesh. From the package root:

```bash
python revision/tools/export_print_fit_kit_revQ.py
python revision/tools/export_upper_concepts_revQ.py
python revision/tools/export_optional_outsole_study_revQ.py
python revision/tools/recalculate_mass_materials_revQ.py
python revision/tools/run_revq_source_compile_checks.py
python revision/tools/build_revq_release_report.py
```

These produce source-derived print/volume and desk-check evidence only. FreeCAD and a verified STEP/FEA workflow are unavailable in the current environment; no `.FCStd`, STEP, FEA result or physical test result is claimed.
