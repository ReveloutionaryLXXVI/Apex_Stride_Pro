# Apex Stride Pro Rev R — staged speed-comparison protocol

**Not authorized for human footwear trials until all physical release gates and independent approval pass.** The current files cannot establish a speed benefit; mass reduction alone does not imply improved running speed or energy return.

## Stage 0 — prerequisite design/test release

Complete material/process selection, production geometry, upper and closure design, qualified metal pin/ring, spring and seat/retainer, rated bladder/circuit and pressure protection, outsole compound/bond, fit envelope, material-specific structural analysis, proof-load/fatigue/pin-retention/pressure/leak/traction/bond/seam/fit checks. Freeze the exact hardware and build. Any failure resets to engineering review; no subject trials until approval.

## Stage 1 — bench characterization (no human)

Equipment: calibrated force/load frame; displacement sensors; high-speed video; pressure transducers at the chamber and regulator output; temperature sensor; cycle actuator/impact apparatus in a guarded enclosure; leak-test tools; slip/traction equipment for whole footwear; mass scale; inspection magnification. Record serial/lot, CAD hash, print job orientation, post-processing, all hardware, calibration and ambient conditions.

At minimum measure: mass by component; static force-displacement curve; left/right rail and pin registration; lock retention and axial pull-out; spring load-deflection and preload; bladder effective area and pressure-force curve; pressure-loss collapse behavior; maximum stops; permanent set; leakage; dynamic force/deflection/rebound; cyclic stiffness and damage; outsole peel/shear, flex, abrasion and slip resistance. Engineer defines load waveform, load multipliers, cycles, acceptable permanent set and failure criteria before tests; do not borrow illustrative 1.5×/2×/3× values from the screening report as acceptance requirements.

## Stage 2 — footwear compliance and controlled fit

Use ASTM F2913-24 whole-shoe slip method and ISO 17708 upper/sole adhesion where applicable; use ISO 17707 outsole flex resistance only if the product falls within the standard's applicable rigidity scope. Define dry/wet/contaminated flooring and pass thresholds before testing. Complete expert fitting/pressure/heel-retention/closure/clearance review for intended sizes. Only proceed if independent engineering and footwear review records signed approval.

## Stage 3 — supervised walking comparison

After approval only. Randomized crossover comparing Rev R against ordinary footwear matched for fit and size. Minimum preliminary design: 12 participants across intended sizes, 2 sessions each, at least 3 valid trials per footwear condition per session; final sample size should be determined by an a priori power analysis. Use same socks, floor, temperature and standardized speed/metronome. Collect body mass, footwear mass, instrumented insole pressure/force, 3D motion capture or validated IMUs, step length/cadence, ground contact time, comfort/pressure survey and any instability/failure. Randomize order and provide rest. Stop immediately for pain, loss of balance, lock migration, noise/crack, pressure loss, sole movement or adverse event.

## Stage 4 — running/sprint comparison (only after walking gate)

Do not initiate running or sprinting based on a successful walk-only test. Obtain separate written approval, repeat the sample-size/power calculation, use instrumented treadmill/track, force plates, timing gates/high-speed video and kinematics. Preregister primary outcomes (e.g., 20 m/30 m time, speed, cadence, contact time and metabolic cost if available), randomization, familiarization, minimum trial count (at least 5 valid trials/condition/session), rest, fatigue controls and stopping criteria. Report individual data, means, confidence intervals and adverse events; no post-hoc selection of fastest trials. Speed or performance improvement requires statistically and practically meaningful between-footwear differences, not just a lighter part.

## Calculations and reporting

For each condition calculate mean and SD over valid trials, paired participant-level difference, percentage change `100×(RevR−control)/control`, 95% confidence intervals and preregistered paired statistical test. Publish all excluded trials and reasons. No speed results exist yet; all human stages are NOT RUN.
