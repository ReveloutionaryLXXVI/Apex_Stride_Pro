# Rev Q material integration — sourced inputs and limits

## Chosen preliminary manufacturing route

Use **industrial SLS PA12 using the specific Materialise PA 12 SLS material card** for the main heel deck, toe carriage and suitable rigid housings. The card reports density 0.95 g/cm³, tensile modulus 1650 MPa, tensile strength 48 MPa, flexural strength 41 MPa, flexural modulus 1500 MPa, elongation at break 20%, Shore D75, HDT 86°C. Actual values may vary with build conditions and geometry/orientation. Source: https://www.materialise.com/en/industrial/3d-printing-materials/pa12-sls

**Do not transfer those numbers to generic FDM or MJF.** If an MJF vendor is used, obtain that exact PA12 grade/process TDS and rerun analysis. Tensile strength is not yield strength and no yield allowable is inferred from this card. Supplier certification and build/process traceability are required.

## Flexible parts

Use TPU 95A only for non-primary protective/compliant parts. UltiMaker-specific FFF data (published 2025-09) reports 67±6 MPa XY-flat and 56±3 MPa Z-up tensile modulus; stress at break 23.7±2.1 MPa XY-flat and 6.4±0.5 MPa Z-up. The orientation split is large; no TPU chamber is considered pressure-rated, airtight or structurally validated by these values. Source: https://um-support-files.ultimaker.com/materials/2.85mm/tds/TPU-95A/TDS-TPU95A-V2.01-250915.pdf

## Spring and rails/pin

17-7 PH UNS S17700 spring wire to ASTM A313/A313M is the spring-material candidate. Elgiloy’s reference lists density 7.81 g/cm³ annealed / 7.67 g/cm³ CH900 and modulus 200 GPa for CH900; wire tensile properties vary by diameter and heat treatment. Supplier spring geometry and force-deflection/fatigue data are mandatory. Source: https://www.elgiloy.com/en/industrial-materials/wire/17-7-ph-stainless-steel and https://store.astm.org/a0313_a0313m-18r25.html

Rails/bridges are provisionally assigned to 6061-T6 metal based on existing tapped rail pilots, but exact alloy/temper, supplier certificate, thread engagement and design allowables remain a supplier/engineer decision. The pin is a candidate commercial/machined 17-4 PH steel component; the STL is not a manufacturing drawing. Ring must be an exact traceable DIN471 size-8 part matched to a manufacturer groove drawing.

## Missing supplier choices

The real spring, bladder, regulator, check valve, relief valve, tubing/fittings, EVA grade/density, rubber compound/density, adhesive/primer, upper fabrics/closures/thread, fastener grades and lengths are not purchased. The BOM reports those as candidates/TBD; no invented costs, working pressure or torque is provided.

No physical test was run and no material-specific FEA was performed as part of this digital integration. The values above are published candidate data only, and supplier grade/process confirmation remains required.
