# Rev P candidate material specification and mass basis

**This is a candidate selection record for engineering evaluation, not an approved production drawing or evidence of load capacity.** Suppliers must provide lot-specific certificates and actual manufactured samples must be tested.

## Proposed low-mass deck material

**EOS PA 2200 Balance, SLS PA12** is a defensible candidate for the heel deck and moving toe carriage because its published density is 0.93 g/cm³, versus the legacy generic estimate of 1.01 g/cm³ used in the original mass table. EOS lists typical tensile strength 48 MPa in X/Y, 42 MPa in Z, tensile modulus 1650 MPa, and strain at break 18% X/Y and 4% Z. That directional difference is important for layer/process orientation, boss pull-out, rail channel and impact behavior. Source: https://www.eos.info/polymer-solutions/data-sheets/all-processes-and-materials?id=pa-2200

The mass scenario substitutes 0.93 g/cm³ only for the combined heel-deck and toe-carriage mesh volumes. It does **not** claim the geometry is lighter or that PA12 has passed the required tests. Using the latest fresh C3 geometry volumes, Rev P is +3.677 to +3.747 g versus Rev K under the legacy density assumptions; under the matched 0.93 g/cm³ deck scenario, Rev P is +3.575 to +3.645 g versus Rev K. The solid rail-screw lands increase rail mass versus the earlier incorrectly relieved rail geometry; do not describe the current default as a geometry-driven weight reduction. This is effectively no geometry-driven mass reduction. The absolute estimate falls about 25.56 g because the assumed deck material density changed, not because this is a measured production part. Current candidate-density totals are EU42 575.471 g, EU44 579.796 g and EU46 584.121 g.

## Proposed metal parts

| Part | Candidate material/spec | Published data used for the calculation | Qualification caveat |
|---|---|---|---|
| Rails and bridge straps | 6061-T6 aluminium in a suitable certified section / machined profile | Density 2.70 g/cm³, modulus 70 GPa; supplier datasheet states 240 MPa minimum proof stress and 260 MPa minimum tensile strength for the specific extrusion scope it quotes | Those limits only apply to the stated product form/dimensions/specification. The exact 11 mm T-head rail profile is not proven to be a standard extrusion. Require a drawing, certificate and tests. Source: https://www.aalco.co.uk/datasheets/Aluminium-Alloy-6061-T6-Extrusions_145.ashx |
| Single-headed locking pin | Machined wrought 17-4PH stainless steel, H900 condition, ASTM A564/UNS S17400 candidate | Reference data sheet lists 1170 MPa yield, 1310 MPa tensile and 190 GPa modulus for wrought ASTM A564 H900; density references around 7.75 g/cm³ | These are typical/reference values, not a design allowable. The groove stress concentration, heat treatment, surface finish, fatigue, shear and actual certificate must be qualified. Source: https://static.markforged.com/downloads/17-4-ph-stainless-steel.pdf and density reference: https://www.dmkalloys.com/alloys/steel-17-4ph.html |
| Pin retaining ring | Lawson item 41580, external 18-8 stainless DIN 471 ring for 8 mm shaft | Supplier listing specifies 14.7 mm ring clearance/envelope, 0.80 mm thickness, Ø7.6 mm groove, 0.90 mm groove width; listing says pack of 5 and price requires login | Product drawing/stock/availability and tolerances must be confirmed against the ring actually purchased. Groove and recess must be gauged; retention must be physically tested. Source: https://www.lawsonproducts.com/products/retaining-ring-external-18-8-stainless-steel-8mm-41580 |

## Mass outputs from fresh native CAD meshes

The authoritative values are in `revision/verification_results/revP_mass_audit/REVK_REVP_FRESH_COMPONENT_MASS.csv`, `REVK_REVP_FRESH_MASS_SUMMARY.csv`, and `MASS_BY_MATERIAL_CANDIDATE.csv`. STL volumes were freshly exported from OpenSCAD and checked for watertightness/winding/positive finite volume before calculating mass. All densities remain assumptions except the proposed values transcribed from the above datasheets. The model excludes unmodeled production fasteners, outsole bondline, real upper, foam/functional cushioning, any pneumatic/spring hardware absent from the source, manufacturing waste/finishing, and process variability.

No cost is given: exact component drawings are not released, no applicable local supplier quotes were obtained, and the ring listing does not show pricing without account access. Do not treat a datasheet candidate as purchased or available stock.
