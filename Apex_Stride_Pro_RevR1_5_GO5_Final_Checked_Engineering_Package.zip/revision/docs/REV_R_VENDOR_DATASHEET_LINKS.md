# Rev R1 vendor links and source evidence

Date checked: 2026-10-16. URLs are primary/vendor pages unless identified as a reseller. Prices are page observations, not purchase orders, and can change. Links below are the traceable source register used by the BOM.

| Component | Exact candidate / model | Source link | Published price/data observed |
|---|---|---|---|
| Structural PA12 | Materialise PA 12 (SLS) | https://www.materialise.com/en/industrial/3d-printing-materials/pa12-sls | Density 0.95 g/cm³; tensile modulus 1650 MPa; tensile strength 48 MPa; flexural strength 41 MPa; flexural modulus 1500 MPa; elongation20%; Shore D75; HDT86°C; values vary with build orientation/geometry; price quote. |
| Spring | Lee Spring LHP 030B 04S / LHP030B04S | https://www.leespring.com/product/compression-spring-lhp030b04s-stainless-steel-type-17-7-ph | 17-7PH stainless; OD4.57, derived bore≈3.05 (OD−2×wire Ø0.76; not independently supplier-quoted), free19.05, solid10.11, wire0.76, rate5.126N/mm, load at solid45.77N, travel8.94mm. No single-unit price verified. Assumed 4–6mm stroke gives20.5–30.8N; conditional return-only candidate. |
| Custom bladder fabric/OEM | DERFLEX airtight TPU-coated fabric / custom bladder program | https://www.derflex.com/airtight-tpu-fabric-inflatable-air-bladders.html | OEM fabric and custom welded chamber program; no finished chamber pressure/burst/cycle rating/product SKU. Quote only. |
| Tube | SMC T0425 | https://static.smc.eu/pdf/Tubing.pdf | 4×2.5mm Nylon12; bend radius13mm; max operating1.5MPa at20°C; burst pressure curve is separate. |
| Check valve | SMC AKH04A-M5 documented variant | https://www.smc.eu/en-gb/products/akh-check-valve-with-one-touch-fitting-male-connector~31267~cfg?partNumber=AKH04A-M5 | 4mm tube, M5×0.8, cracking0.005MPa. **A direction is male-thread to tube; opposite direction must be ordered for bladder charging.** |
| Regulator | SMC ARX20-F01BG | https://www.smc.eu/et-ee/products/arx20-regulator-for-2mpa~15019~cfg?partNumber=ARX20-F01BG | G1/8, outlet0.05–0.85MPa, inlet2MPa max, proof3MPa, bracket+gauge, 35×80mm, 110g. External bench only. |
| Relief | SMC AP20-D series 1/8 | https://www.smc.com.cn/webcatalog/en-ae/modular-frl-units-pressure-control-equipment/regulators/AP20-D-E/ | Set range0.05–0.8MPa (standard range), max operating0.85MPa; thread/option suffix must be fixed. |
| Fitting | SMC KQ2H04-M5A / KQ2H04-G01A | https://www.smcworld.com/newproducts/en/pdf/kq2.pdf | 4mm tube; M5 / G1/8 ports; KQ2 family max operating1MPa, proof3MPa. KQ2H04-M5A reseller listing USD1.61. |
| Rail screws | Würth 009801412 M4×12 | https://eshop.wuerth.de/Screw-with-flattened-half-round-head-and-hexagon-socket-ISO-7380-1-A2-070-stainless-steel-plain-SCR-BUT-ISO7380-1-A2-070-HS25-M4X12/009801412.sku/en/US/EUR/ | A2-070, Ø7.6×2.2 head, ISO7380-1; 2Nm listed torque is not approved project torque; Würth warns button heads are limited-load. |
| Fixed anchors | M4×22 under-head, exact supplier/SKU TBD | No exact 22 mm supplier SKU verified; the prior M4×18 vendor page is not a valid source for the R1.4 length. | Do not substitute 18 mm; verify actual thread length, head rating and engagement from the selected manufacturer drawing. |
| Moving anchors | Würth 009801416 M4×16 | https://eshop.wuerth.de/Product-categories/ISO-7380-1-stainless-steel-A2-plain/31573511180202.cyid/3157.cgid/en/US/INR/ | Würth family variant listing lists M4×16, head7.6×2.2; request current local price. |
| Bridge locks | M4×14 under-head, exact supplier/SKU TBD | No exact 14 mm supplier SKU verified; the prior M4×8 vendor page is not a valid source for the R1.4 length. | Do not substitute 8 mm; verify actual thread length, head rating, nut engagement and locking method from manufacturer drawing. |
| M4 nuts | Keller & Kalmbach 5240324 ISO4032 M4 A2-70 | https://www.keller-kalmbach.com/products/fasteners/nuts/iso-4032-hexagon-nut/p/5240324 | Exact article; customer-specific price/login. |
| Retaining ring | Lawson 41580 | https://www.lawsonproducts.com/products/retaining-ring-external-18-8-stainless-steel-8mm-41580 | DIN471 8mm, ring clearance14.7, thickness0.8, groove7.6×0.9; pack of5, price/login. |
| Rail/bridge metal | 6061-T6 custom CNC parts | Custom part no stock SKU | No single purchased finished part fits this CAD; RFQ custom rails and straps, require cert. |
| Pin material | 17-4PH UNS S17400 H1150D custom turned pin | https://www.langleyalloys.com/materials/stainless/17-4-ph/ | Supplier product page gives H1150D minimum proof stress725MPa and tensile860MPa; purchase size/stock availability for Ø8 bar must be confirmed. |
| Upper spacer mesh | Spacermesh 2BC2-8A | https://spacermesh.com/product/mesh-2bc2-8a/ | 100% polyester, 3mm, 340gsm, 150cm width, 50m roll; quote; page text/table disagree on middle yarn 33D vs30D. |
| Nylon webbing | Strapworks WSR-NYL-M37-034-BLK | https://www.strapworks.com/34-inch-milspec-17337-nylon-black | USD0.89/ft or 30ft roll USD24.56; ¾ in, approx1.02mm thick; no certified break force published. Strap/edge reinforcement only. |
| Heel counter | Avetco Poliflex P2080 SKU PO.016.2080.8MM | https://www.avetcoinc.com/product/poliflex-p2080-0-8-mm/ | USD27 per 1×1.38m sheet; 0.8mm thermoplastic, activation guidance110–130°C, 4–6kg/cm², 4–10s. |
| EVA footbed | GISMA EVA-50 | https://www.giismex.com/en/Footwear-Material/171.html | 50kg/m³, 52±3 Shore C, resilience≥60%, flex≥1.2M cycles; 5mm standard, heel7mm custom. Quote. |
| Collar/tongue foam | GISMA EVA-38 | https://www.giismex.com/en/Footwear-Material/171.html | 38kg/m³, 38±3 Shore C, resilience≥65%, flex≥0.8M cycles; 3mm standard. Quote. |
| Outsole | Vibram Cherry sheet SKU 7175CHERRYSHT4MMBLK | https://www.montanaleather.com/product/7175-vibram-cherry-sheet/ | USD45 listed per sheet, 36×11in, 4mm; no Shore A/flex/abrasion properties published on listing. |
| Closure strap | VELCRO Brand VEL-OW64511 via MISAR UAE | https://shop.misar.ae/product/VELCRO-ORG-One-Wrap-Strap-Part-No-VEL-OW64511-9MWyi | AED70 each listed; 20×200mm polypropylene, peel1.8N/cm², shear32N/cm², medium cycle life; prototype only. |
| Sewing thread | Coats Dabond Tex90 candidate | https://www.coats.com/en/Products/Threads/Dabond/Dabond/ and https://www.trivantage.com/itemfiles/pdfs/tds/Coats_Dabond_Specifications.pdf | Manufacturer thread family and product sheet; Tex90 table row strength data; exact spool color/lot/price from distributor. |
| Adhesive | LOCTITE 406 IDH135436 | https://next.henkel-adhesives.com/us/en/products/industrial-adhesives/central-pdp.html/loctite-406/BP000000153530.html | 20g product; trial coupon candidate only. TDS does not certify PA12-SLS-to-Vibram7175 shoe-flex bond, so no production adhesive selected. |


See `REV_R1_PROCUREMENT_LIST.csv` for prioritized bench-buy, RFQ, and hold status. All prices are observed listing snapshots, not quotes or purchase orders.


See `REV_R1_PROCUREMENT_LIST.csv` for prioritized bench-buy, RFQ, and hold status. All prices are observed listing snapshots, not quotes or purchase orders.

| Custom metal stock | McMaster-Carr 6061 aluminum bar stock category (stock material only; not a finished shoe part) | https://www.mcmaster.com/products/aluminum-bars/material~aluminum-2/material~6061-aluminum/ | CNC rail/bridge geometries remain custom RFQ parts APX-RAIL-L/R-R1 and APX-BRG-REAR/FRONT-R1; supplier certification and machining quote required. |


See `REV_R1_PROCUREMENT_LIST.csv` for prioritized bench-buy, RFQ, and hold status. All prices are observed listing snapshots, not quotes or purchase orders.
