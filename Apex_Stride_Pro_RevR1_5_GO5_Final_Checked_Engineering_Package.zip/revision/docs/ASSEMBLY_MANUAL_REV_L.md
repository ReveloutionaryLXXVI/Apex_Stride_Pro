# Apex Stride Pro — Rev L Assembly Manual

**Document status:** CAD mockup assembly and engineering planning for a design intended to become an adjustable wearable shoe. This is not a release-to-wear manual: do not wear, walk, or run in a physical build until the independent engineering and physical-validation gates in Sections 5 and 9 are complete. The optional thinner-outsole mode is an unvalidated mass-study variant.

Reference files: [`REV_L_CAD_PREVIEW_EU44.png`](../REV_L_CAD_PREVIEW_EU44.png), [`REV_L_ASSEMBLY_DIAGRAM.svg`](REV_L_ASSEMBLY_DIAGRAM.svg), [`Apex_Stride_Pro_RevL.scad`](../Apex_Stride_Pro_RevL.scad), and the per-size STL files under `generated/EU42`, `generated/EU44`, and `generated/EU46`.

![Rev L conceptual assembly stack and adjustment register](REV_L_ASSEMBLY_DIAGRAM.png)

## 1. Read before assembly

This package contains **two different things**:

- **CAD visualization assembly:** a digital arrangement of concept geometry used to check nominal relationships. This can be inspected in OpenSCAD or a mesh viewer.
- **Eventual physical prototype:** would require actual, specified materials, machined/finished rails and pin holes, engineered fasteners and threads, outsole retention, finished cushioning, a real upper, a fitted last, and independent engineering release. The current BOM is not sufficient to construct a safe wearable shoe.

The source does not specify production tolerances for all features, final materials, manufacturing process, fastener lengths/grades/thread engagement, torque values, outsole attachment or sewing/cutting patterns. Those fields are marked **TBD / engineering review** below instead of being guessed.

## 2. Bill of materials (CAD inventory)

Mass/material figures are design assumptions, not supplier selection. Density assumptions used by the mass estimate: deck parts 1.01 g/cm³ (PA12-like candidate), bridge and rails 2.70 g/cm³ (aluminum-like candidate), locking pin 7.90 g/cm³ (stainless-like candidate), outsole 1.15–1.25 g/cm³ (TPU-like scenario), and footbed insert 0.20 g/cm³ (foam scenario). **No material grade is selected.** All dimensions below are CAD nominal values in millimetres unless noted.

| Item / CAD name | Qty. | Known CAD geometry | Material / status |
|---|---:|---|---|
| `heel_deck` (`heel_deck.stl`) | 1 | 20.6 mm deck thickness; nominal heel profile extends from x = -147 mm to joint at x = -25 mm; captured-rail channels and bridge/nut pockets | PA12-like density scenario only; structural deck, bosses and channel roof need analysis |
| `toe_carriage` (`toe_carriage.stl`) | 1 | 20.6 mm deck thickness; local nominal profile from x = -25 mm to x = 147 mm; pin-entry bosses and index tunnel | PA12-like density scenario only; structural deck and bosses need analysis |
| `rail_left` | 1 | 155 mm nominal rail length; 11 mm T-head width; 6.5 mm stem width; 2.3 mm neck; 16.1 mm total height; three nominal 8.8 mm index bores per rail; two 3.3 mm rail-fastener pilot holes per rail | Aluminum-like density scenario; grade, threading, finish and allowable loads TBD |
| `rail_right` | 1 | Mirror-side mate of `rail_left`; rail centre lines are nominally ±20 mm from centreline | Same as left rail; verify actual pair with gauges |
| `bridge_rear` (`bridge_rear.stl`) | 1 | 24 mm wide, 3 mm thick; about 130 mm length in local design coordinates; heel anchor pair plus three indexed hole pairs | Aluminum-like density scenario; edge distance, fatigue and bearing TBD |
| `bridge_front` (`bridge_front.stl`) | 1 | 24 mm wide, 3 mm thick; about 85 mm length; toe anchor pair and one lock-screw pair; moves with carriage | Aluminum-like density scenario; overlap and screw bearing not validated |
| `locking_pin_solid` (`locking_pin_solid.stl`) | 1 | 8.0 mm shaft diameter; 12.0 mm head diameter; 3.0 mm head depth; 90 mm shaft span between end planes, approximately 96 mm overall with both heads | Stainless-like density scenario; material, retention against accidental withdrawal and strength TBD |
| `locking_pin_hollow` (`pin_through_hollow`) | 0 for assembly; study only | 8 mm OD with a 4 mm axial bore | Not the default. Existing arithmetic indicates higher nominal bending stress at the same moment; do not substitute without engineering approval |
| `outsole_heel_pad` | 1 | 4.0 mm default thickness; relief depth 2.2 mm in baseline | TPU-like density scenario; tread compound, attachment, grip, abrasion and tear performance TBD |
| `outsole_flex_connector` | 1 | 4.0 mm default thickness; 74 mm target developed path in the model; width varies along the connector | TPU-like density scenario; geometric path length is not validated strain/fatigue performance |
| `outsole_toe_pad` | 1 | 4.0 mm default thickness; relief depth 2.2 mm in baseline | Same as heel pad |
| **Optional Rev L outsole study** | alternate set | 3.2 mm thickness and 1.4 mm relief, leaving 1.8 mm nominal skin; same XY planform but ground-facing plane is 0.8 mm higher | Geometry/mass study only; not for wear and not a validated material design |
| `footbed_insert` | 1 | 3.0 mm visualization insert | Foam density scenario only; not real cushioning or pressure-management component |
| `upper_wall_shell` | 1 visual shell | 22 mm wall height and 3 mm wall thickness | Concept envelope only; not a textile pattern or fitted upper |
| `toe_vamp_shell` | 1 visual shell | Curved shell with illustrative ventilation holes (2.4 mm diameter) | Not a cut/sew pattern; hole spacing and tear resistance unvalidated |
| `heel_counter_shell` | 1 visual shell | Curved heel cup envelope; no fitted last dimensions supplied | Concept only; not heel-retention hardware |
| `upper_lateral_overlays` | 2 visual side overlays | Pair generated by the CAD module | Concept only; material and attachment not selected |
| `upper_tongue` | 1 visual tongue | Curved instep envelope | Concept only; no lining/padding specification |
| `upper_velcro_straps` | 2 visual strap shapes | Two across-instep bands in the model | Not actual hook-and-loop webbing; no tested closure or anchor |
| `upper_strap_anchor_doublers` | 4 visual patches | Two patches per side in the model | Not actual sewn reinforcement; pull-out/tear testing not run |
| Bridge screws and captive nuts | 6 sets intended by CAD envelope | Six 4.8 mm screw passages: two heel anchors, two toe anchors, two selected-index locks; captive nut pockets are modelled | M4-envelope only. Exact screw length, grade, head style, nut standard, engagement and torque are TBD; not included as solid STL parts |
| Rail attachment screws | 4 intended positions | Two stations per rail; 4.8 mm deck passages and 3.3 mm rail pilot holes | Thread and fastener details are not modeled. Do not buy/install until the rail thread engagement and fastener are specified |
| Outsole retention / adhesive / liner / pin keeper | Not present | No validated physical retention design included | **Missing; engineering review required** |
| Textile, lining, foam stack, seams, production hook-and-loop | Not present | Mockup shapes only | **Missing; sourcing, footwear patterning and validation required** |

`toe_carriage_local.stl` is a local-coordinate export for articulation, not an additional physical part. `upper_sidewall_legacy.stl` is a legacy aggregate visualization export and should not be stacked on top of the separate Rev L upper mockup parts. The complete `full_mockup` selector is a visualization, not a print-ready one-piece component.

## 3. Required tools and protective equipment

### For CAD-only mockup work

- Computer with OpenSCAD and a mesh viewer.
- Mouse/trackpad and keyboard.
- Optional digital calipers for inspecting exported dimensions; do not treat rendered dimensions as manufacturing gauges.

### For a future engineer-supervised bench prototype

Only after a qualified reviewer freezes materials/processes and supplies detailed drawings: calipers, calibrated plug/pin gauges for the pin and holes, a surface/height gauge as needed, compatible driver/hex tools for the specified fasteners, a calibrated low-range torque tool **only after a torque specification exists**, rigid clamping/fixture, calibrated load cell/force frame, remote camera/data logger and a protective enclosure or equivalent guarding. Wear appropriate eye protection and face protection for guarded mechanical testing; keep all body parts out of the load path. Use the actual part drawing and fastener maker's instructions.

No generic torque value is safe to assume. Determine torque from the actual fastener grade, thread, engagement, substrate, lubrication and joint design; document it before assembly. Do not substitute a “typical M4 torque”.

## 4. CAD mockup assembly — step by step

These steps describe how to inspect and position the existing geometry in OpenSCAD. They are **not instructions for a wearable build**.

1. **Keep a clean copy.** Retain `Apex_Stride_Pro_RevK.scad` and the original ZIP untouched. Open `Apex_Stride_Pro_RevL.scad` for the new source. In the parameter section choose `eu_size = 42`, `44` or `46` and `width_scale = 1.00`, `1.04` or `1.08`. Width settings are concept envelopes, not standardized footwear widths.
2. **Start with the full visual assembly.** Keep `part = "full_mockup"` and press F5 (Preview). The view includes the deck/rail/bridge/pin assembly, outsole arrangement, footbed and separate conceptual upper shapes. The packaged Rev K preview depicts the Rev L default geometry because the Rev L default keeps the original 4.0 mm outsole.
3. **Inspect the fixed heel deck.** Use the `heel` selector for the `heel_deck`. Its underside includes two captured-rail channels and bridge/nut recesses. Do not remove deck material or enlarge recesses by hand.
4. **Position the rails.** Use `rail_left` and `rail_right`. Each is a T-section intended to slide longitudinally into the undercut channel from an open end. In the CAD view, ensure each head lies in the wide captured cavity and each stem aligns with the narrow throat. The two rail centre lines are at y = ±20 mm. Do not force an actual fabricated rail into a channel that binds; physical dimensions and surface finish are not validated.
5. **Place the toe carriage.** Use `toe` (assembled coordinates) or `toe_local` (local simulation coordinates) as appropriate. Its nominal extension relative to EU42 is 0 mm for EU42, 13.3334 mm for EU44, and 26.6668 mm for EU46. For a selected size, set the carriage at that position and check that the cross-pin tunnel aligns with both corresponding rail index bores.
6. **Stack the bridge straps.** Position `bridge_rear` in the rear/heel recess first. Position `bridge_front` above it toward the deck, within the nominal 6 mm stack recess. Their individual layers are each 3 mm thick; the nominal design overlap is 85 mm in the three indexed settings. The rear strap is anchored at the heel; the front strap moves with the toe carriage. Check the two selected index holes and toe-anchor holes against their matching recesses.
7. **Place the locking pin.** Use `pin_through` / `locking_pin_solid`. The solid pin spans the carriage tunnel and the selected holes in both rails; its heads fit into the modelled side counterbores. Do not substitute `pin_through_hollow` in the baseline assembly. The design has no separate tether or secondary pin keeper, so pin retention is a high-priority unresolved safety item.
8. **Show the size-lock fasteners as envelopes only.** The bridge CAD provides six screw locations and captive-nut pockets: two at the heel strap anchor, two at the toe strap anchor and two at the chosen bridge index. The CAD also provides four rail attachment positions. Actual hardware is not provided as solids; exact types, threads, lengths, engagement and torque remain unapproved.
9. **Add the outsole pieces for visualization.** Position `outsole_heel_pad`, `outsole_flex_connector` and `outsole_toe_pad` on the underside. `outsole_assembly` combines them. The planform overlaps the ground-facing coverage and the flex connector bridges the moving joint, with grooves around rails/bridge. The package does not model how the outsole is attached or retained to a physical shoe.
10. **Add the footbed insert.** `footbed_insert` is a single 3 mm concept sheet at the top of the decks. It is not cushioning stack material and is not a fit/pressure validated surface.
11. **Add the upper mockup.** The full visualization uses `toe_vamp_shell`, `heel_counter_shell`, `upper_wall_shell`, `upper_lateral_overlays`, `upper_tongue`, `upper_velcro_straps` and `upper_strap_anchor_doublers`. These shapes illustrate an envelope only. They do not define seams, seam allowance, real fabric pieces, lining, attachment method, strap webbing, hook-and-loop material, toe allowance or a verified last.
12. **Review individual parts before export.** Set `part` to one of the individual selectors and press F6 (Render), then export that part as STL. Never export the whole `full_mockup` or combined `assembly` preview as a single printable/load-bearing part. Use the already exported individual STL assets where available.

### Switching the optional mass-study outsole in CAD

Rev L has `outsole_weight_study = false` by default. Set it to `true` to choose the 3.2 mm / 1.4 mm geometry study. This preserves the XY planform bounds but changes the outsole bottom by 0.8 mm and leaves a nominal 1.8 mm skin under relief channels. Use the pre-exported study meshes in `revision_assets/lightweight_study_revL/`. **Do not interpret this option as approved for a physical wearable shoe.** Grip, compression, abrasion, tear, fatigue, outsole retention and ground clearance must be reviewed and tested.

## 5. Eventual wearable prototype — missing steps and engineering gate

There is no complete physical assembly recipe yet because key parts/specifications do not exist. Before building a wearable specimen, an independent footwear/mechanical team must:

1. Select the actual grades/processes for the deck, rails, bridge straps, pin, outsole, footbed and fasteners, including supplier allowables and manufacturing tolerances.
2. Finish all critical pin bores, rail profiles, threads and contact surfaces; provide drawings and acceptance gauges. Reconcile the 4.8 mm deck passages with the 3.3 mm rail pilot holes and specify engagement/threads.
3. Specify the pin's positive retention against accidental withdrawal. The modeled end heads alone are not a validated pin-retention system.
4. Engineer the outsole's bond/attachment and confirm that the outsole cannot peel, snag or interfere with adjustment. Select the actual grip compound and validate dry/wet traction, abrasion and tear.
5. Create a real last and cut/sew pattern from bilateral foot measurements. The included `REV_K_UPPER_PANEL_PLANNING_NOT_CUT_READY.svg` is a planning sheet only; it is not cut-ready. Specify actual upper textile/lining, seams, strap hardware and tested reinforcements.
6. Define all fasteners, nut/thread interfaces, torque and locking methods from the selected hardware and joint materials. Torque values must be obtained from those real specifications; none is approved by this package.
7. Complete independent structural analysis and guarded bench tests before even controlled fit validation. No human running or sprinting before written release.

## 6. Fit, clearance and inspection checklist

Use the list below for CAD review and later calibrated bench measurements. A visual check is not a manufacturing acceptance check.

- [ ] Correct size selector and matching toe extension (EU42: 0 mm; EU44: 13.3334 mm; EU46: 26.6668 mm).
- [ ] Both rails are oriented correctly and enter the channels without forced interference.
- [ ] Both rail index bores and the carriage tunnel are aligned at the same nominal size setting; pin passes through both sides without hammering or bending.
- [ ] Pin heads seat in their side counterbores; accidental withdrawal retention remains **unvalidated**.
- [ ] Bridge strap rear/front orientation is correct; both 3 mm layers occupy the intended 6 mm recess and chosen indexed pair aligns.
- [ ] Six bridge fastener-envelope positions and four rail attachment positions are reviewed against finalized fastener drawings before physical assembly.
- [ ] Outsole relief aligns with rail and bridge underside; pads do not rock or pinch the moving interface. Actual outsole retention is **not modeled**.
- [ ] All deck, rail, pin, bridge, stop, nut-pocket and outsole parts are free of cracks, burrs, delamination or unexpected deformation.
- [ ] Upper/footbed remains labelled as concept until a real last, pattern, closure and pressure/retention checks exist.
- [ ] Actual gauge readings, part IDs, fastener IDs and inspection photos are recorded for any engineered bench specimen.

Nominal geometry in Rev K/L reports includes a 2.5 mm rail-head ligament, approximately 2.375 mm worst-case ligament under stated tolerances, a 4.1 mm roof above the rail channel, an 8.8 mm pin bore around an 8.0 mm pin, rail-head clearances calculated under assumed process tolerances, and 4.8 mm bridge holes. These are not validated stress, fit or strength allowances. Actual fabricated parts must be measured.

## 7. Troubleshooting (CAD/bench fixture only)

| Symptom | Possible cause | Safe response |
|---|---|---|
| Toe carriage will not slide in CAD or binds on a bench coupon | Wrong rail orientation, incorrect size transform, burrs, actual dimensions outside assumed tolerance | Stop; verify part selector/orientation and gauge actual parts. Do not force or sand load-bearing sections without engineering approval. |
| Pin will not enter | Size index mismatch, rail holes not registered, bore/pin dimension or alignment outside assumptions | Withdraw/reposition the carriage and recheck registration/gauges. Never hammer the pin or enlarge holes by hand. |
| Bridge screw holes appear misaligned | Wrong size setting, front strap not translated with carriage, incorrect strap layer order | Verify 0 / 13.3334 / 26.6668 mm setting and rear/front strap position. Do not drill new holes. |
| End stop contacts before the expected terminal setting | Rail/lug orientation or geometry mismatch, fabrication error | Stop; compare to source and inspect on a guarded fixture. Do not use the lock pin as a substitute for a damaged stop. |
| Outsole rocks, peels or interferes with rails | Ground plane/relief mismatch, material deformation, missing retention design | Stop. Outsole retention and durability are unresolved; do not wear the specimen. |
| Upper shell gaps or straps do not fit a foot | Expected from conceptual surfaces; no verified last/pattern | Do not trim these CAD shells into a wearable upper. Generate a real pattern from a verified last and footwear review. |
| Fastener loosens or no torque can be identified | Fastener/joint specification incomplete | Do not guess torque. Stop, identify actual part/thread/grade/material and obtain engineer-approved joint instructions. |

## 8. Safe, guarded bench testing and stop conditions

Bench testing is allowed only after an engineer specifies material, geometry, fixture and pass/fail thresholds. Use a sacrificial specimen, remote loading, a calibrated load cell and protective guarding; no person or foot may be in the fixture. Apply loads only in the engineer-approved directions, rates and magnitudes. Log force/time, displacement, adjustment position and critical dimensions before/after. The current package does not prescribe a numerical proof load because the correct proof load is not established.

**Stop immediately** for any crack, sudden noise consistent with fracture, rail/pin migration, unintended release, stop damage, permanent set beyond the engineer-set threshold, fastener movement, delamination, outsole tearing, unstable slip, fixture movement or sensor/guard failure. Quarantine the specimen, photograph and record the event, and return to engineering review. Do not test an altered specimen until its revision and affected analyses/tests are approved.

## 9. Current release disposition

The project intent remains a wearable adjustable shoe, and the Rev K architecture is retained. The 4.0 mm outsole remains the default; the 3.2 mm variant is an opt-in study only. Neither geometry mode has material-specific FEA, proof-load, fatigue, traction, abrasion, retention, fit or human-use validation. **Rev L is not yet cleared for wear or running.** Complete and document the independent release gates before any human trial.
