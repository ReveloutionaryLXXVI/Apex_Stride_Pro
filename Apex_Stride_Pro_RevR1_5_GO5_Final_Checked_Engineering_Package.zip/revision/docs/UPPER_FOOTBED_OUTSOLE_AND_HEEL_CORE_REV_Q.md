# Rev Q upper, footbed, heel-core, and outsole integration specification

## Upper

The seven concept meshes in `PRINT_READY_BENCH_FIT_KIT_REV_Q/upper_concept_not_wearable/EUxx/` are envelope-only, not a production pattern or a wearable upper. Build the production upper on the existing model last without changing nominal sole length/width. Required construction candidate: breathable polyester 3D spacer mesh body; high-tenacity woven nylon reinforcement at toe, lateral wear zones, and closure anchors; semi-rigid footwear-grade thermoplastic heel counter (PA12 only if fit, edges, and impacts are validated); breathable textile collar/tongue with PU or EVA foam; abrasion-resistant lining; bonded polyester thread; conventional lacing or engineered straps with reinforced textile anchors.

Supplier actions: procure fabric technical data for areal weight, tear/abrasion, seam behavior, chemical/adhesive compatibility and skin-contact use. Produce a last-matched cut/sew pattern. Model every anchor and stitch seam, ensure 3D clearance to pin, rails, bridge, bladder/tube, spring and full adjustment travel. Conduct anchor pull-out, seam tear, heel retention and fit/pressure-point assessments. No cut pattern or validated upper anchor system exists now.

## Footbed

Rev Q adds three separate components per size: `footbed_heel_piece.stl` (nominal 7 mm EVA), `footbed_toe_piece.stl` (nominal 5 mm EVA), and `footbed_toe_lap_tongue.stl` (45×50×5 mm nominal sliding tongue). The heel underside pocket captures the tongue with nominal geometric clearances; for maximum EU46 extension 26.667 mm, the 45 mm tongue leaves about 18.333 mm overlap. The footbed can be removed for inspection without disturbing the mechanism. Supplier compression-deflection curve, density, compression set, thickness tolerance and cover/bond details are not selected, so footbed mass and comfort are not claimed. Bench-cycle at all sizes for binding, wear, thickness build-up and collision with moving components.

## Heel spring / pneumatic core

The current CAD has no actual spring, bladder, air tubing or valve geometry. `part="heel_core_envelope_study"` displays only a maximum 55×23×15.1 mm bounding region and schematic spring/bladder zones. It deliberately overlays the existing deck lightening ribs, so this envelope is not a free cavity and proves neither fit nor compression travel. The platform must be locally re-engineered after selecting a real spring and bladder envelope; retain mechanical spring support independently of pressure loss, add positive spring seats/retainers, compression stops and protected tubing routing. Do not assign operating pressure or spring rate from the bounding box.

## Outsole

Default outsole geometry remains 4.0 mm. Use a footwear-grade abrasion-resistant rubber compound targeted at 60–70 Shore A and 3–4 mm thickness, subject to supplier tear/abrasion/flex/traction data. The 3.2 mm option is an unvalidated mass study with 1.8 mm nominal residual tread skin; it is not the production default. The existing heel pad, toe pad and serpentine connector are three geometry pieces; no approved bondline, primer, mechanical retention, rubber grade or whole-shoe traction result exists. Obtain a bonding procedure approved for exact rubber and PA12 SLS surface, and test attachment and whole-shoe slip before wear.

Candidate methods: ASTM F2913-24 for whole-shoe dynamic friction; ISO 17707:2005 only for outsoles whose measured longitudinal rigidity is within its scope (maximum 30 N); ISO 17708:2018 for upper-to-sole adhesion where the assembled shoe and bond method fall within scope. A test method reference is not a result or certification.
