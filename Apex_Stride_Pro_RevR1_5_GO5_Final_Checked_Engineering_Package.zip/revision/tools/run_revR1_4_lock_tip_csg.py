#!/usr/bin/env python3
"""Exact CSG check that M4x14 lock shanks/tips pass through the toe-deck lock path."""
from pathlib import Path
import csv,subprocess,tempfile,json,time
ROOT=Path(__file__).resolve().parents[2]; SRC=ROOT/'revision/Apex_Stride_Pro_RevR.scad'; OUT=ROOT/'revision/verification_results/revR1_4_go1_go2'
source=SRC.read_text(); prefix=source.split('// ---------- EXPORT SELECTOR ----------',1)[0]; rows=[]; t0=time.time()
for size in (42,44,46):
  ext=(size-42)*6.6667
  sides=(-5.0,5.0) if size==42 else (-5.0,)
  for yy in sides:
    body=f'''intersection() {{
      translate([{ext:.4f},0,0]) toe_deck_local();
      translate([{ext:.4f}+heel_split_x+bridge_lock_x+( {yy} < 0 ? -bridge_pair_stagger_mm : bridge_pair_stagger_mm), {yy}, sole_bottom_z+bridge_screw_head_depth])
        cylinder(h=bridge_lock_screw_length_mm-bridge_screw_head_depth,d=4.0,$fn=48);
    }}'''
    with tempfile.TemporaryDirectory(prefix='apex_r14_lock_csg_') as td:
      td=Path(td); scad=td/'test.scad'; out=td/'intersection.stl'; scad.write_text(prefix+'\n'+body+'\n')
      cp=subprocess.run(['openscad','-o',str(out),'-D',f'eu_size={size}',str(scad)],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=70)
      empty='Current top level object is empty.' in cp.stdout and not out.exists() and 'ERROR:' not in cp.stdout
      rows.append({'size':f'EU{size}','y_mm':yy,'interface':'M4x14 shank through deck nut-pocket and tip-relief','result':'PASS' if empty else 'FAIL','expected_empty_intersection':empty,'details':cp.stdout[-300:].replace('\n',' | ')})
      print(f"{'PASS' if empty else 'FAIL'} EU{size} y={yy:+.1f} lock shank/deck relief",flush=True)
with (OUT/'REV_R1_4_LOCK_TIP_CSG.csv').open('w',newline='') as f: w=csv.DictWriter(f,fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
summary={'checks':len(rows),'pass':sum(r['result']=='PASS' for r in rows),'fail':sum(r['result']=='FAIL' for r in rows),'elapsed_seconds':round(time.time()-t0,2),'scope':'Nominal cylindrical shank versus actual deck CAD; no real nut/threads/tolerances.'}
(OUT/'REV_R1_4_LOCK_TIP_CSG.json').write_text(json.dumps(summary,indent=2)+'\n'); print(json.dumps(summary,indent=2)); raise SystemExit(1 if summary['fail'] else 0)
