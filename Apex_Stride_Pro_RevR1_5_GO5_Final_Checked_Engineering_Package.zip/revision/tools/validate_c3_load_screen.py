#!/usr/bin/env python3
"""Validate arithmetic consistency of the Rev P C3 analytical load-screen CSVs.
These are equation/data consistency checks only, not strength or safety approval.
"""
from pathlib import Path
import csv, math, json
ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'revision/verification_results/REV_P_C3_SAFETY_CORRECTION'
HFILE=OUT/'C3_HORIZONTAL_LOCK_PIN_LOAD_SCREEN.csv'
PFILE=OUT/'C3_AXIAL_PIN_RETENTION_SENSITIVITY.csv'
checks=[]
def add(name, ok, detail): checks.append({'check':name,'result':'PASS' if ok else 'FAIL','detail':detail})
def close(a,b,tol=1e-8): return abs(float(a)-float(b)) <= tol*max(1.0,abs(float(b)))
H=list(csv.DictReader(HFILE.open(newline='',encoding='utf-8')))
P=list(csv.DictReader(PFILE.open(newline='',encoding='utf-8')))
F=66*9.81; d=8.0; droot=7.6; lever=24.7; Z=math.pi*d**3/32
add('body_weight_66kg', close(F,647.46), f'F={F:.2f} N')
add('four_horizontal_cases_present', [float(r['horizontal_load_fraction_of_body_weight']) for r in H]==[0.1,0.2,0.5,1.0], f'rows={len(H)} fractions={[float(r["horizontal_load_fraction_of_body_weight"]) for r in H]}')
add('all_horizontal_forces_reconcile', all(close(r['horizontal_load_N'],float(r['horizontal_load_fraction_of_body_weight'])*F) for r in H), 'H=fraction×647.46 N')
add('rail_loads_split_evenly', all(close(r['assumed_rail_load_each_N'],float(r['horizontal_load_N'])/2) for r in H), 'each rail is assigned H/2 by stated simplified model')
add('beam_lever_reconciles', all(close(r['assumed_support_to_rail_load_lever_mm'],lever) for r in H), f'lever={lever:.2f} mm')
add('unnotched_section_modulus', all(close(r['pin_max_unnotched_shaft_bending_stress_MPa'], (float(r['pin_max_bending_moment_Nmm'])/Z)) for r in H), f'Z=π×8³/32={Z:.6f} mm³; uses unnotched shaft at max nominal moment')
add('bending_moment_equation', all(close(r['pin_max_bending_moment_Nmm'],float(r['assumed_rail_load_each_N'])*lever) for r in H), 'M=(H/2)×24.7 mm')
add('yield_ratio_is_reference_only', all(close(r['reference_yield_ratio_unnotched_midspan_only'],1170/float(r['pin_max_unnotched_shaft_bending_stress_MPa'])) for r in H), '1170 MPa wrought candidate reference divided by nominal shaft stress; not an allowable')
add('rail_bearing_area', all(close(r['rail_pin_bearing_stress_MPa_per_rail'],float(r['assumed_rail_load_each_N'])/(8.0*11.0)) for r in H), 'projected area=8 mm pin×11 mm rail head')
add('bridge_net_area', all(close(r['bridge_net_tension_stress_MPa_one_strap_all_H'],float(r['horizontal_load_N'])/40.2) for r in H), 'net area=(23−2×4.8)×3=40.2 mm²')
add('groove_point_support_labeled_not_validated', all('NOT_VALIDATED' in r['groove_point_support_bending_stress_MPa_NOT_VALIDATED'].__class__.__name__ or 'NOT_VALIDATED' in HFILE.read_text() for r in H), 'groove local-contact stress is explicitly marked not validated')
add('four_retention_pull_cases_present', [float(r['hypothetical_axial_pin_pull_N']) for r in P]==[50.0,100.0,250.0,500.0], f'rows={len(P)} pull levels')
area=math.pi*(d*d-droot*droot)/4
add('ring_shoulder_area_reconciles', all(close(r['groove_shoulder_annular_area_mm2'],area) for r in P), f'annular shoulder area={area:.6f} mm²')
add('retention_stress_reconciles', all(close(r['nominal_shoulder_bearing_stress_MPa'],float(r['hypothetical_axial_pin_pull_N'])/area) for r in P), 'nominal stress=pull/annular area')
add('no_physical_or_fea_claims', 'physical_tests_run": false' in (OUT/'C3_LOAD_SCREEN_SUMMARY.json').read_text() and 'material_specific_fea_run": false' in (OUT/'C3_LOAD_SCREEN_SUMMARY.json').read_text(), 'output records no material-specific FEA and no physical tests')
with (OUT/'C3_LOAD_SCREEN_VALIDATION.csv').open('w',newline='',encoding='utf-8') as f:
 w=csv.DictWriter(f,fieldnames=['check','result','detail']);w.writeheader();w.writerows(checks)
summary={'checks':len(checks),'pass':sum(x['result']=='PASS' for x in checks),'fail':sum(x['result']=='FAIL' for x in checks),'scope':'CSV/analytical arithmetic consistency only; no strength or safety validation'}
(OUT/'C3_LOAD_SCREEN_VALIDATION.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
for x in checks:
 print(x['result'],x['check'],x['detail'])
raise SystemExit(1 if summary['fail'] else 0)
