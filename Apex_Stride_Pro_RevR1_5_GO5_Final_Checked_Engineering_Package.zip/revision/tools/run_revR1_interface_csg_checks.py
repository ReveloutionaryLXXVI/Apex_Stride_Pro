#!/usr/bin/env python3
"""Exact CSG checks for Rev R1 M4 toe-anchor screw/bridge/EVA clearances.

These are geometric clearance checks only. Nominal hardware envelopes are simplified
cylinders; thread form, head shape, tolerances, foam compression, and actual hardware are
not represented. An empty intersection is the expected pass result.
"""
from pathlib import Path
import csv, json, subprocess, tempfile, time
ROOT=Path(__file__).resolve().parents[2]
SRC=ROOT/'revision/Apex_Stride_Pro_RevR.scad'
OUT=ROOT/'revision/verification_results/revR_component_closure'
OUT.mkdir(parents=True,exist_ok=True)
source=SRC.read_text(encoding='utf-8')
marker='// ---------- EXPORT SELECTOR ----------'
if marker not in source:
    raise SystemExit('FAIL: selector marker not found')
module_source=source.split(marker,1)[0]
rows=[]; started=time.time()
def run_case(size,side,case,body):
    sign = -1 if side=='minusY' else 1
    yy = sign*5.0
    harness_body = module_source + '\n' + body.replace('__YY__',f'{yy:.1f}') + '\n'
    with tempfile.TemporaryDirectory(prefix='apex_revr1_interface_') as td:
        td=Path(td); harness=td/'intersection.scad'; out=td/'intersection.stl'
        harness.write_text(harness_body,encoding='utf-8')
        cmd=['openscad','-o',str(out),'-D',f'eu_size={size}',str(harness)]
        cp=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=90)
        empty=('Current top level object is empty.' in cp.stdout) and not out.exists() and 'ERROR:' not in cp.stdout
        passed=bool(empty)
        rows.append({'size':f'EU{size}','anchor_side':side,'interface':case,'exit_code':cp.returncode,'intersection_mesh_exists':out.exists(),'expected_empty_message':empty,'result':'PASS' if passed else 'FAIL','details':cp.stdout[-500:].replace('\n',' | ')})
        print(f"{'PASS' if passed else 'FAIL'} EU{size} {side} {case}",flush=True)
def run_rear_case(size,side,interface,x_expr):
    sign = -1 if side=='minusY' else 1
    yy=sign*5.0
    body=f'''intersection() {{
      bridge_rear_strap();
      union() {{
        translate([{x_expr}, {yy:.1f}, sole_bottom_z]) cylinder(h=bridge_screw_head_depth,d=7.6,$fn=64);
        translate([{x_expr}, {yy:.1f}, sole_bottom_z+bridge_screw_head_depth]) cylinder(h=18.0,d=4.0,$fn=64);
      }}
    }}'''
    harness_body=module_source+'\n'+body+'\n'
    with tempfile.TemporaryDirectory(prefix='apex_revr1_rear_interface_') as td:
        td=Path(td);harness=td/'intersection.scad';out=td/'intersection.stl'
        harness.write_text(harness_body,encoding='utf-8')
        cmd=['openscad','-o',str(out),'-D',f'eu_size={size}',str(harness)]
        cp=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=90)
        empty=('Current top level object is empty.' in cp.stdout) and not out.exists() and 'ERROR:' not in cp.stdout
        rows.append({'size':f'EU{size}','anchor_side':side,'interface':interface,'exit_code':cp.returncode,'intersection_mesh_exists':out.exists(),'expected_empty_message':empty,'result':'PASS' if empty else 'FAIL','details':cp.stdout[-500:].replace('\n',' | ')})
        print(f"{'PASS' if empty else 'FAIL'} EU{size} {side} {interface}",flush=True)
for size in (42,44,46):
  for side in ('minusY','plusY'):
    # A nominal M4 threaded-shank envelope reaches z=+0.60 mm; 5.5 mm diameter,
    # 0.72 mm-deep EVA underside relief has top z=+0.86 mm.
    run_case(size,side,'M4x16_shank_vs_EVA', '''intersection() {
      footbed_toe_piece();
      translate([extension+heel_split_x+10, __YY__, -15.4]) cylinder(h=16.0,d=4.0,$fn=64);
    }''')
    # Check both moving toe-anchor recesses.
    run_case(size,side,'M4x16_head_and_shank_vs_front_strap', '''intersection() {
      translate([extension,0,0]) bridge_front_strap();
      union() {
        translate([extension+heel_split_x+10, __YY__, -17.6]) cylinder(h=2.2,d=7.6,$fn=64);
        translate([extension+heel_split_x+10, __YY__, -15.4]) cylinder(h=16.0,d=4.0,$fn=64);
      }
    }''')
    # Check the fixed heel-anchor head pocket and the indexed rear-strap lock pocket
    # selected for each size (EU42/EU44/EU46 exercise all three hole stations).
    run_rear_case(size,side,'M4x18_head_and_shank_vs_rear_heel_anchor','heel_split_x-10')
    offset=(size-42)*6.6667
    run_rear_case(size,side,'M4_lock_head_and_shank_vs_rear_index_hole',f'heel_split_x+bridge_lock_x+{offset:.4f}')
fields=list(rows[0])
with (OUT/'REV_R1_TOE_ANCHOR_INTERFACE_CSG.csv').open('w',newline='',encoding='utf-8') as f:
    w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rows)
summary={'revision':'Rev R1 interface clearance check','checks':len(rows),'pass':sum(r['result']=='PASS' for r in rows),'fail':sum(r['result']=='FAIL' for r in rows),'result':'PASS' if all(r['result']=='PASS' for r in rows) else 'FAIL','elapsed_seconds':round(time.time()-started,2),'methods':['Actual footbed_toe_piece geometry intersected with nominal Ø4 x 16 mm M4 shank envelope.','Actual moving bridge_front_strap geometry intersected with the M4x16 button-head and shank envelope.','Actual fixed bridge_rear_strap geometry intersected with M4x18 heel-anchor envelopes and indexed locking-screw envelopes at EU42/EU44/EU46 stations.'],'limitations':['Nominal cylindrical hardware envelopes only; not manufacturer CAD.','No tolerance stack, foam compression, manufacturing variation or physical gauging.','This does not validate joint strength or the overall load path.']}
(OUT/'REV_R1_TOE_ANCHOR_INTERFACE_CSG.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
print(json.dumps(summary,indent=2))
raise SystemExit(1 if summary['fail'] else 0)
