#!/usr/bin/env python3
"""Reproduce C1->C2 stop-groove regression using the preserved C1 source snapshot.

Tests toe-carriage/rail intersections at maximum EU46 extension (4*mm_per_eu_size).
C1 should exhibit a positive-volume overlap; C2 should not. Uses actual OpenSCAD
module geometry (source is truncated immediately before its normal export selector).
"""
from pathlib import Path
import csv, json, shutil, subprocess, tempfile, time
ROOT=Path(__file__).resolve().parents[2]
SOURCES={
 'BEFORE_C1':ROOT/'revision/historical/REV_O_C1_STOP_GROOVE_BEFORE_FIX.scad',
 'AFTER_C2':ROOT/'revision/Apex_Stride_Pro_RevO.scad',
}
OUT=ROOT/'revision/verification_results/fresh_closure_audit'; OUT.mkdir(parents=True,exist_ok=True)
exe=shutil.which('openscad')
if not exe: raise SystemExit('FAIL: openscad not found')
rows=[]; start=time.time()
with tempfile.TemporaryDirectory(prefix='apex_stop_regression_') as td:
 td=Path(td)
 for state,src in SOURCES.items():
  text=src.read_text(encoding='utf-8')
  marker='// ---------- EXPORT SELECTOR ----------'
  if marker not in text: raise SystemExit(f'FAIL: selector marker missing in {src}')
  mod=text.split(marker,1)[0]
  for side in ('left','right'):
   y='-rail_y' if side=='left' else 'rail_y'
   harness=td/f'{state}_{side}.scad'
   # Set size explicitly using CLI so extension = (46-42)*mm_per_eu_size.
   harness.write_text(mod+f'\nintersection() {{ translate([extension,0,0]) toe_deck_local(); side_rail_local({y}); }}\n',encoding='utf-8')
   dst=td/f'{state}_{side}.stl'
   cp=subprocess.run([exe,'-o',str(dst),'-D','eu_size=46',str(harness)],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=70)
   empty=('Current top level object is empty.' in cp.stdout) and not dst.exists()
   volume=0.0; faces=0
   if dst.exists() and dst.stat().st_size>84:
    import trimesh
    m=trimesh.load_mesh(dst,force='mesh',process=True)
    faces=len(m.faces); volume=abs(float(m.volume)) if m.is_watertight else float('nan')
   if state=='BEFORE_C1': ok=(volume>1e-4 and faces>0)
   else: ok=empty
   rows.append({'state':state,'source':src.relative_to(ROOT).as_posix(),'size':'EU46','extension_mm':round(4*6.6667,4),'rail_side':side,'return_code':cp.returncode,'mesh_exists':dst.exists(),'faces':faces,'intersection_volume_mm3':volume,'empty_intersection_message':empty,'result':'PASS' if ok else 'FAIL','log_tail':cp.stdout[-500:].replace('\n','\\n')})
path=OUT/'REV_O_C1_TO_C2_STOP_FIX_REPRODUCIBLE.csv'
with path.open('w',newline='',encoding='utf-8') as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
pre=[r for r in rows if r['state']=='BEFORE_C1']; post=[r for r in rows if r['state']=='AFTER_C2']
summary={'title':'Rev O C1 to C2 stop-groove regression','checks':len(rows),'pass':sum(r['result']=='PASS' for r in rows),'fail':sum(r['result']=='FAIL' for r in rows),'before_total_intersection_volume_mm3':sum(r['intersection_volume_mm3'] for r in pre),'after_total_intersection_volume_mm3':sum(r['intersection_volume_mm3'] for r in post),'result':'PASS' if all(r['result']=='PASS' for r in rows) else 'FAIL','limitations':['CGAL solid-intersection test at maximum EU46 extension only; other sizes/positions are checked in separate tests.','Shows positive-volume interference or its absence; not tolerance, deformation, strength, fatigue or wear validation.'],'rows':rows}
(OUT/'REV_O_C1_TO_C2_STOP_FIX_REPRODUCIBLE.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in summary.items() if k!='rows'},indent=2))
raise SystemExit(1 if summary['fail'] else 0)
