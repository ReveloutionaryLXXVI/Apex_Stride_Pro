#!/usr/bin/env python3
"""Regenerate the Rev P dimensional fit-kit STLs from the current print-prep SCAD.

Requires OpenSCAD, trimesh, numpy. Outputs are normalized by rigid rotation/translation only;
no dimensional scaling occurs. These are non-wearable mockup parts, not load-bearing hardware.
"""
from pathlib import Path
import csv, subprocess, tempfile, sys
import numpy as np
import trimesh
ROOT=Path(__file__).resolve().parents[2]
KIT=ROOT/'PRINT_READY_BENCH_FIT_KIT_REV_P'
SRC=KIT/'source/Apex_Stride_Pro_RevP_PrintPrep.scad'
INDEX=KIT/'PRINT_PARTS_INDEX.csv'
rows=list(csv.DictReader(INDEX.open(newline='',encoding='utf-8')))
for i,r in enumerate(rows,1):
    size=int(r['size'].replace('EU',''))
    part=r['cad_selector']
    out=KIT/'stl'/r['file']
    out.parent.mkdir(parents=True,exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='apex_fitkit_export_') as td:
        native=Path(td)/'native.stl'
        cmd=['openscad','--export-format','binstl','-o',str(native),'-D',f'eu_size={size}','-D','width_scale=1.00','-D',f'part="{part}"']
        if part in ('rail_left','rail_right'):
            cmd += ['-D','rail_weight_relief=false']
        cmd += [str(SRC)]
        cp=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=90)
        if cp.returncode or not native.exists() or native.stat().st_size<500 or 'ERROR:' in cp.stdout:
            raise RuntimeError(f'OpenSCAD export failed {r["size"]}/{part}:\n{cp.stdout[-2000:]}')
        mesh=trimesh.load_mesh(native,force='mesh',process=True)
        if not mesh.is_watertight or not mesh.is_winding_consistent or not np.isfinite(mesh.vertices).all() or not np.isfinite(mesh.volume) or mesh.volume<=0:
            raise RuntimeError(f'Native component mesh failed topology: {r["size"]}/{part}')
        native_volume=float(mesh.volume)
        orient=r['orientation']
        if orient=='rail_side':
            mesh.apply_transform(trimesh.transformations.rotation_matrix(np.deg2rad(90),[1,0,0]))
        elif orient=='pin_vertical_head_down':
            mesh.apply_transform(trimesh.transformations.rotation_matrix(np.deg2rad(-90),[1,0,0]))
        elif orient in ('z_bottom','ring_flat'):
            pass
        else:
            raise ValueError(f'Unknown print orientation {orient!r} for {r["file"]}')
        bounds=mesh.bounds
        mesh.apply_translation([-float((bounds[0,0]+bounds[1,0])/2),-float((bounds[0,1]+bounds[1,1])/2),-float(bounds[0,2])])
        mesh.export(out,file_type='stl')
        verify=trimesh.load_mesh(out,force='mesh',process=True)
        b=verify.bounds; e=verify.extents; v=np.asarray(verify.vertices); vol=float(verify.volume)
        tests={
            'watertight':bool(verify.is_watertight),
            'winding_consistent':bool(verify.is_winding_consistent),
            'positive_volume':bool(np.isfinite(vol) and vol>0),
            'finite_vertices':bool(np.isfinite(v).all()),
            'xy_centered':bool(max(abs((b[0,0]+b[1,0])/2),abs((b[0,1]+b[1,1])/2))<1e-3),
            'z_min_zero':bool(abs(float(b[0,2]))<1e-3),
            'bed_220':bool(max(float(e[0]),float(e[1]))<=220.001),
            'volume_matches':bool(abs(vol-native_volume)<=max(.02,abs(native_volume)*1e-6)),
        }
        r['x_mm']=f'{e[0]:.3f}'; r['y_mm']=f'{e[1]:.3f}'; r['z_mm']=f'{e[2]:.3f}'
        r['native_volume_mm3']=f'{native_volume:.4f}'; r['normalized_volume_mm3']=f'{vol:.4f}'
        r['watertight']=str(tests['watertight']); r['winding_consistent']=str(tests['winding_consistent'])
        r['positive_volume']=str(tests['positive_volume']); r['finite_vertices']=str(tests['finite_vertices'])
        r['xy_centered']=str(tests['xy_centered']); r['z_min_zero']=str(tests['z_min_zero'])
        r['bed_xy_fits_220x220']=str(tests['bed_220']); r['serialization_volume_match']=str(tests['volume_matches'])
        r['result']='PASS' if all(tests.values()) else 'FAIL'
        if not all(tests.values()):
            raise RuntimeError(f'Normalized fit STL failed {r["file"]}: {tests}, extents={e}')
    print(f'[{i}/{len(rows)}] PASS {r["file"]} {r["x_mm"]}x{r["y_mm"]}x{r["z_mm"]} mm',flush=True)
with INDEX.open('w',newline='',encoding='utf-8') as f:
    w=csv.DictWriter(f,fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
print(f'PASS: regenerated {len(rows)} component STL meshes and updated {INDEX}')
