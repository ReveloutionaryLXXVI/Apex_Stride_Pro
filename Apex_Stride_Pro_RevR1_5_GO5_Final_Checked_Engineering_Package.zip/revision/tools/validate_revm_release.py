#!/usr/bin/env python3
"""Reproducible Rev M CAD export, topology, regression, dimensional and mass checks.

Requires: OpenSCAD CLI, Python 3, trimesh, numpy.
These are digital geometry checks only. They are not FEA or physical qualification.
"""
from __future__ import annotations
import csv, json, math, shutil, subprocess, sys, tempfile
from pathlib import Path
import numpy as np
import trimesh

ROOT = Path(__file__).resolve().parents[1]
REV_M = ROOT / 'Apex_Stride_Pro_RevM.scad'
REV_L = ROOT / 'Apex_Stride_Pro_RevL.scad'
GEN_L = ROOT / 'generated'
GEN_M = ROOT / 'generated_revm'
STUDY_L = ROOT / 'revision_assets' / 'lightweight_study_revL'
STUDY_M = GEN_M / 'lightweight_study_3p2mm'
RES = ROOT / 'verification_results'
SIZES = (42, 44, 46)

# assumed density, g/cm^3 — placeholders for scenario math, not selected production materials
DENSITIES = {
    'heel_deck': 1.01, 'toe_carriage': 1.01,
    'bridge_rear': 2.70, 'bridge_front': 2.70,
    'rail_left': 2.70, 'rail_right': 2.70,
    'pin_through_solid': 7.90, 'pin_retaining_clip': 7.90,
    'outsole_assembly': 1.20, 'footbed_insert': 0.20,
}
OUTSOLE_SENSITIVITY = {'low': 1.15, 'mid': 1.20, 'high': 1.25}
SELECTORS = {
    'heel_deck': 'heel', 'toe_carriage': 'toe',
    'bridge_rear': 'bridge_rear', 'bridge_front': 'bridge_front',
    'rail_left': 'rail_left', 'rail_right': 'rail_right',
    'pin_through_solid': 'pin_through_solid',
    'pin_retaining_clip': 'pin_retaining_clip',
    'outsole_assembly': 'outsole_assembly', 'footbed_insert': 'footbed_insert',
}
BASELINE_NAMES = {
    'heel_deck':'heel_deck', 'toe_carriage':'toe_carriage',
    'bridge_rear':'bridge_rear', 'bridge_front':'bridge_front',
    'rail_left':'rail_left', 'rail_right':'rail_right',
    'pin_through_solid':'locking_pin_solid', 'outsole_assembly':'outsole_assembly',
    'footbed_insert':'footbed_insert',
}
UNCHANGED_COMPONENTS = ('heel_deck','bridge_rear','bridge_front','rail_left','rail_right','outsole_assembly','footbed_insert')

def write_csv(path: Path, rows: list[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        raise ValueError(f'no rows for {path}')
    with path.open('w', newline='', encoding='utf-8') as f:
        w=csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader(); w.writerows(rows)

def export_stl(src: Path, dst: Path, selector: str, size: int, study: bool=False, width: float=1.00) -> None:
    dst.parent.mkdir(parents=True, exist_ok=True)
    # Reuse a cached export only when it is demonstrably newer than the source and non-empty.
    # This makes repeated audits reproducible without re-rendering every unchanged solid.
    if dst.exists() and dst.stat().st_size >= 500 and dst.stat().st_mtime >= src.stat().st_mtime:
        return
    cmd=['openscad','--export-format','binstl','-o',str(dst),'-D',f'eu_size={size}',
         '-D',f'width_scale={width:.2f}','-D',f'part="{selector}"',
         '-D',f'outsole_weight_study={"true" if study else "false"}',str(src)]
    run=subprocess.run(cmd, capture_output=True, text=True, timeout=120)
    if run.returncode != 0 or not dst.exists() or dst.stat().st_size < 500:
        raise RuntimeError(f'OpenSCAD export failed: size={size}, selector={selector}, study={study}\n{run.stdout}\n{run.stderr}')

def load_mesh(path: Path) -> trimesh.Trimesh:
    m=trimesh.load_mesh(path,force='mesh',process=True)
    if not isinstance(m,trimesh.Trimesh) or len(m.faces)==0:
        raise RuntimeError(f'Empty/non-mesh STL: {path}')
    return m

def topo_ok(m: trimesh.Trimesh) -> bool:
    return bool(m.is_watertight and m.is_winding_consistent and m.volume > 0 and np.isfinite(m.volume) and np.all(np.isfinite(m.bounds)))

def max_bounds_delta(a: trimesh.Trimesh, b: trimesh.Trimesh) -> float:
    return float(np.max(np.abs(a.bounds-b.bounds)))

def exact_mesh_equivalent(a: trimesh.Trimesh,b: trimesh.Trimesh) -> bool:
    # Stable comparison of exact vertex-coordinate sets and face counts; exported STL vertex ordering can vary.
    if a.vertices.shape != b.vertices.shape or a.faces.shape != b.faces.shape:
        return False
    aa=np.array(a.vertices)
    bb=np.array(b.vertices)
    key=lambda v: v[np.lexsort((v[:,2],v[:,1],v[:,0]))]
    return np.array_equal(key(aa),key(bb))

def g(volume_mm3: float, density: float) -> float:
    return volume_mm3/1000.0*density

def main() -> int:
    RES.mkdir(parents=True,exist_ok=True)
    if not shutil.which('openscad'):
        raise RuntimeError('OpenSCAD is not installed or not on PATH')
    if not REV_M.exists() or not REV_L.exists():
        raise RuntimeError('Rev M/Rev L source missing')

    test_rows=[]; geom_rows=[]; mass_rows=[]; summary_rows=[]; dim_rows=[]
    meshes={}
    # Fresh exports for supported sizes. Includes all current lower-platform components and the new ring.
    for size in SIZES:
        meshes[size]={}
        for component,selector in SELECTORS.items():
            path=GEN_M/f'EU{size}'/f'{component}.stl'
            export_stl(REV_M,path,selector,size)
            m=load_mesh(path)
            meshes[size][component]=m
            ok=topo_ok(m)
            test_rows.append({'check_id':f'EXPORT_{size}_{component}','group':'native OpenSCAD export + topology',
                              'status':'PASS' if ok else 'FAIL', 'detail':f'{selector}; watertight={m.is_watertight}; winding={m.is_winding_consistent}; volume_mm3={m.volume:.6f}; faces={len(m.faces)}'})
        # also export source-selected 3.2mm study and verify retained RevL study mesh compatibility
        study_path=STUDY_M/f'EU{size}'/'outsole_assembly_3p2mm.stl'
        export_stl(REV_M,study_path,'outsole_assembly',size,study=True)
        study=load_mesh(study_path)
        packaged=load_mesh(STUDY_L/f'EU{size}'/'outsole_assembly_3p2mm.stl')
        study_same=abs(study.volume-packaged.volume)<0.1 and max_bounds_delta(study,packaged)<0.02
        base_out=load_mesh(GEN_M/f'EU{size}'/'outsole_assembly.stl')
        xy_same=bool(np.max(np.abs(base_out.bounds[:2,:2]-study.bounds[:2,:2])) < 0.02)
        top_same=abs(float(base_out.bounds[1,2]-study.bounds[1,2])) < 0.02
        bottom_delta=float(study.bounds[0,2]-base_out.bounds[0,2])
        residual_skin=3.2-1.4
        study_ok=topo_ok(study) and xy_same and top_same and abs(bottom_delta-0.8)<0.05 and abs(residual_skin-1.8)<1e-8
        test_rows.append({'check_id':f'STUDY_{size}_OUTSOLE','group':'3.2 mm opt-in mass study','status':'PASS' if (study_same and study_ok) else 'FAIL',
                          'detail':f'fresh vs archived volume/bounds match={study_same}; topology={topo_ok(study)}; XY bounds same={xy_same}; top bounds same={top_same}; lower plane shift={bottom_delta:.3f} mm; residual skin={residual_skin:.2f} mm; volume_cm3={study.volume/1000:.6f}'})

    # All three labelled width presets are exercised for every size on both deck profiles.
    width_records={}
    for size in SIZES:
        for width in (1.00,1.04,1.08):
            width_records[(size,width)]={}
            for part_name, selector in [('heel_deck','heel'),('toe_carriage','toe')]:
                out=GEN_M/'width_variants'/f'EU{size}_W{int(round(width*100)):03d}_{part_name}.stl'
                export_stl(REV_M,out,selector,size,width=width)
                m=load_mesh(out)
                ok=topo_ok(m)
                width_records[(size,width)][part_name]=m
                test_rows.append({'check_id':f'WIDTH_{size}_{int(round(width*100))}_{part_name.upper()}','group':'width preset native export + topology',
                                  'status':'PASS' if ok else 'FAIL','detail':f'width_scale={width:.2f}; volume_mm3={m.volume:.3f}; y_extent_mm={m.bounds[1,1]-m.bounds[0,1]:.3f}; watertight={m.is_watertight}; winding={m.is_winding_consistent}'})
        for part_name in ('heel_deck','toe_carriage'):
            m0=width_records[(size,1.00)][part_name]
            m4=width_records[(size,1.04)][part_name]
            m8=width_records[(size,1.08)][part_name]
            y0=m0.bounds[1,1]-m0.bounds[0,1]; y4=m4.bounds[1,1]-m4.bounds[0,1]; y8=m8.bounds[1,1]-m8.bounds[0,1]
            monotonic=(y4>y0 and y8>y4 and abs(m4.bounds[0,0]-m0.bounds[0,0])<0.02 and abs(m8.bounds[1,0]-m0.bounds[1,0])<0.02)
            test_rows.append({'check_id':f'WIDTH_SCALE_MONOTONIC_{size}_{part_name.upper()}','group':'width preset bounds consistency',
                              'status':'PASS' if monotonic else 'FAIL','detail':f'Y extent scale values={y0:.3f}/{y4:.3f}/{y8:.3f} mm for width 1.00/1.04/1.08; longitudinal X bounds unchanged={abs(m8.bounds[0,0]-m0.bounds[0,0])<0.02 and abs(m8.bounds[1,0]-m0.bounds[1,0])<0.02}'})

    # Baseline geometry regression: exact expected unchanged parts, intentional changes explicitly checked.
    for size in SIZES:
        for component in UNCHANGED_COMPONENTS:
            old=load_mesh(GEN_L/f'EU{size}'/f'{BASELINE_NAMES[component]}.stl')
            new=meshes[size][component]
            exact=exact_mesh_equivalent(old,new)
            bdelta=max_bounds_delta(old,new)
            vdelta=abs(old.volume-new.volume)
            passed=exact and bdelta < 1e-4 and vdelta < 1e-4 and topo_ok(new)
            geom_rows.append({'size':f'EU{size}','component':component,'change_class':'expected unchanged','baseline_volume_mm3':f'{old.volume:.6f}',
                              'revm_volume_mm3':f'{new.volume:.6f}','volume_delta_mm3':f'{new.volume-old.volume:.6f}',
                              'max_bounds_delta_mm':f'{bdelta:.6f}','exact_mesh_match':exact,'status':'PASS' if passed else 'FAIL'})
        # Toe boss increase is intentional to create wall around the 15.2 mm retaining-ring recess.
        old=load_mesh(GEN_L/f'EU{size}'/'toe_carriage.stl'); new=meshes[size]['toe_carriage']
        dv=new.volume-old.volume
        planned=(dv > 500 and dv < 800 and topo_ok(new) and max_bounds_delta(old,new) < 1e-3)
        geom_rows.append({'size':f'EU{size}','component':'toe_carriage','change_class':'intentional Rev M retaining-ring boss enlargement',
                          'baseline_volume_mm3':f'{old.volume:.6f}','revm_volume_mm3':f'{new.volume:.6f}','volume_delta_mm3':f'{dv:.6f}',
                          'max_bounds_delta_mm':f'{max_bounds_delta(old,new):.6f}','exact_mesh_match':False,'status':'PASS' if planned else 'FAIL'})
        # Pin was changed from a non-removable double-head to a one-head pin; clip is a separate schematic mesh.
        oldpin=load_mesh(GEN_L/f'EU{size}'/'locking_pin_solid.stl')
        pin=meshes[size]['pin_through_solid']; clip=meshes[size]['pin_retaining_clip']
        pb=pin.bounds; cb=clip.bounds
        one_body=(len(pin.split(only_watertight=False))==1 and len(clip.split(only_watertight=False))==1)
        pin_dims=(abs((pb[1,1]-pb[0,1])-90.30)<0.05 and abs((pb[1,0]-pb[0,0])-12.0)<0.05 and abs((pb[1,2]-pb[0,2])-12.0)<0.05)
        groove_center=-45.0-0.30+0.6+0.9/2
        groove_bounds=(groove_center-0.45, groove_center+0.45)
        ring_inside=(cb[0,1] >= groove_bounds[0]-0.001 and cb[1,1] <= groove_bounds[1]+0.001)
        tip_margin=groove_bounds[0]-pb[0,1]
        face_recess=cb[0,1]+45.0
        ring_seated=(abs(cb[0,1]+44.65)<0.05 and abs(cb[1,1]+43.85)<0.05 and abs((cb[1,0]-cb[0,0])-14.7)<1.2 and ring_inside and abs(tip_margin-0.6)<0.02 and abs(face_recess-0.35)<0.05)
        pin_ok=topo_ok(pin) and topo_ok(clip) and one_body and pin_dims and ring_seated
        geom_rows.append({'size':f'EU{size}','component':'pin_and_retaining_clip','change_class':'intentional Rev M removable pin retention concept',
                          'baseline_volume_mm3':f'{oldpin.volume:.6f}','revm_volume_mm3':f'{pin.volume+clip.volume:.6f}',
                          'volume_delta_mm3':f'{pin.volume+clip.volume-oldpin.volume:.6f}', 'max_bounds_delta_mm':'N/A (two parts)',
                          'exact_mesh_match':False,'status':'PASS' if pin_ok else 'FAIL'})
        test_rows.append({'check_id':f'PIN_RING_ASSEMBLY_{size}','group':'pin/ring geometry and topology','status':'PASS' if pin_ok else 'FAIL',
                          'detail':f'pin single body={len(pin.split(only_watertight=False))==1}; ring single body={len(clip.split(only_watertight=False))==1}; pin span={pb[1,1]-pb[0,1]:.3f} mm; ring face envelope y=[{cb[0,1]:.3f},{cb[1,1]:.3f}] mm; groove bounds={groove_bounds}; ring inside groove={ring_inside}; end margin={tip_margin:.3f} mm; face recess={face_recess:.3f} mm; geometry only, not retention proof'})

    # Geometric/parameter checks: registration and source-defined design clearances.
    mm_per_eu=6.6667; heel_split=-25.0; pin_offset=30.0
    for size in SIZES:
        ext=(size-42)*mm_per_eu
        pinx=heel_split+pin_offset+ext
        # this model locates both rail-side pin bores on the shared pin x-position
        nominal_bore=8.8; shaft=8.0; radial=(nominal_bore-shaft)/2
        ligament=(16.1-2.3-nominal_bore)/2
        # clip groove center from CAD: -pin_entry - tail + endMargin + width/2
        groove_center=-45.0-0.30+0.6+0.9/2
        ring_face_side=-45.0
        ring_outer=14.7; pocket=15.2; boss=18.0
        ring_wall=(boss-pocket)/2
        ok=(abs(ext-{42:0,44:13.3334,46:26.6668}[size])<1e-3 and abs(radial-0.4)<1e-8 and abs(ligament-2.5)<1e-8 and
            abs(groove_center+44.25)<1e-8 and (pocket-ring_outer)/2>=0.24 and ring_wall>=1.3)
        dim_rows.append({'size':f'EU{size}','extension_mm':f'{ext:.4f}','lock_pin_x_mm':f'{pinx:.4f}','pin_shaft_d_mm':shaft,
                         'nominal_bore_d_mm':nominal_bore,'nominal_radial_clearance_mm':f'{radial:.3f}','nominal_rail_head_ligament_mm':f'{ligament:.3f}',
                         'pin_groove_center_from_shoe_midplane_mm':f'{groove_center:.3f}','clip_envelope_d_mm':ring_outer,'clip_recess_d_mm':pocket,
                         'nominal_clip_radial_clearance_mm':f'{(pocket-ring_outer)/2:.3f}','boss_face_width_mm':boss,'minimum_nominal_recess_wall_mm':f'{ring_wall:.3f}',
                         'status':'PASS' if ok else 'FAIL'})
    for r in dim_rows:
        test_rows.append({'check_id':f'DIMENSIONAL_CLEARANCE_{r["size"]}','group':'parameter arithmetic / nominal clearance screen',
                          'status':r['status'],'detail':f"extension={r['extension_mm']} mm; bore={r['nominal_bore_d_mm']} mm; shaft={r['pin_shaft_d_mm']} mm; radial clearance={r['nominal_radial_clearance_mm']} mm; rail ligament={r['nominal_rail_head_ligament_mm']} mm; ring recess wall={r['minimum_nominal_recess_wall_mm']} mm; arithmetic only"})

    # invalid size/width guards must fail with an explicit OpenSCAD assertion, not silently export.
    for name, define in [('INVALID_SIZE_GUARD','eu_size=40'),('INVALID_WIDTH_GUARD','width_scale=1.07')]:
        with tempfile.TemporaryDirectory(prefix='apex_revm_guard_') as td:
            out=Path(td)/'invalid.stl'
            cmd=['openscad','--export-format','binstl','-o',str(out),'-D',define,'-D','part="heel"',str(REV_M)]
            cp=subprocess.run(cmd,capture_output=True,text=True,timeout=60)
            log=cp.stdout+'\n'+cp.stderr
            explicit=(cp.returncode != 0 and 'ERROR: Assertion' in log and 'Current top level object is empty' in log)
            test_rows.append({'check_id':name,'group':'invalid-input assertion guard','status':'PASS' if explicit else 'FAIL',
                              'detail':f'define={define}; returncode={cp.returncode}; assertion_seen={"ERROR: Assertion" in log}; output_file_exists={out.exists()}'})

    # mass component breakdown against Rev L source-exported baseline meshes.
    for size in SIZES:
        base_masses={}; revm_masses={}
        for component,density in DENSITIES.items():
            new=meshes[size][component]
            mnew=g(new.volume,density)
            revm_masses[component]=mnew
            old_name=BASELINE_NAMES.get(component)
            if old_name:
                old=load_mesh(GEN_L/f'EU{size}'/f'{old_name}.stl')
                old_density=7.9 if old_name=='locking_pin_solid' else density
                mold=g(old.volume,old_density)
                base_masses[component]=mold
                delta=mnew-mold
                base_vol=old.volume
            else:
                mold=0.0; delta=mnew; base_vol=0.0
            mass_rows.append({'size':f'EU{size}','component':component,'revm_mesh_volume_mm3':f'{new.volume:.5f}',
                              'assumed_density_g_cm3':f'{density:.3f}','revm_estimated_mass_g':f'{mnew:.5f}',
                              'revk_l_baseline_component':old_name or 'no matching component (new retaining ring)',
                              'baseline_mesh_volume_mm3':f'{base_vol:.5f}' if old_name else 'N/A',
                              'baseline_estimated_mass_g':f'{mold:.5f}' if old_name else 'N/A',
                              'mass_delta_g_vs_revL_component':f'{delta:.5f}' if old_name else 'N/A',
                              'mass_scope':'geometry volume × assumed density; not measured; ring CAD is schematic'})
        baseline_row = next(r for r in csv.DictReader((RES/'REVL_MASS_BASELINE_VS_STUDY.csv').open()) if r['size']==f'EU{size}')
        baseline_total=float(baseline_row['baseline_lower_platform_g_mid_density'])
        revm_base_total=sum(revm_masses.values())
        old_total_expected=sum(base_masses.get(k,0) for k in ('heel_deck','toe_carriage','bridge_rear','bridge_front','rail_left','rail_right','pin_through_solid','outsole_assembly','footbed_insert'))
        # ensure computed old totals match the prior summary within rounding.
        old_component_total=sum(base_masses[k] for k in ('heel_deck','toe_carriage','bridge_rear','bridge_front','rail_left','rail_right','pin_through_solid','outsole_assembly','footbed_insert'))
        study_mesh=load_mesh(STUDY_M/f'EU{size}'/'outsole_assembly_3p2mm.stl')
        study_total=revm_base_total-revm_masses['outsole_assembly']+g(study_mesh.volume,OUTSOLE_SENSITIVITY['mid'])
        # low/mid/high outsole density scenarios, default and study
        def outsole_scenario(m: trimesh.Trimesh, rho: float) -> float: return g(m.volume,rho)
        revm_other=revm_base_total-revm_masses['outsole_assembly']
        base_out=load_mesh(GEN_M/f'EU{size}'/'outsole_assembly.stl')
        summary_rows.append({'size':f'EU{size}','baseline_revL_default_lower_platform_g':f'{baseline_total:.3f}',
             'revm_default_lower_platform_g_mid_density':f'{revm_base_total:.3f}',
             'revm_delta_vs_revL_default_g':f'{revm_base_total-baseline_total:.3f}',
             'revm_default_outsole_g_low_1p15':f'{outsole_scenario(base_out,1.15):.3f}',
             'revm_default_outsole_g_mid_1p20':f'{outsole_scenario(base_out,1.20):.3f}',
             'revm_default_outsole_g_high_1p25':f'{outsole_scenario(base_out,1.25):.3f}',
             'revm_lightweight_study_lower_platform_g_mid_density':f'{study_total:.3f}',
             'revm_lightweight_saving_g':f'{revm_base_total-study_total:.3f}',
             'revm_lightweight_saving_pct':f'{100*(revm_base_total-study_total)/revm_base_total:.3f}',
             'mass_scope':'modeled lower-platform only; excludes actual fasteners, wearable upper, full cushioning, sole adhesive/retention and manufacturing allowances'})
        # Cross-check source-derived baseline accounting.
        ok=abs(old_component_total-baseline_total)<0.03
        test_rows.append({'check_id':f'MASS_RECONCILIATION_{size}','group':'mass accounting','status':'PASS' if ok else 'FAIL',
                          'detail':f'RevL baseline from source meshes + density assumptions={old_component_total:.5f} g; prior summary={baseline_total:.5f} g; delta={old_component_total-baseline_total:.5f} g'})

    # Assert the three size presets are accepted/rejected consistently and a native render succeeds.
    png=ROOT/'REV_M_NATIVE_PREVIEW_EU44.png'
    xvfb=shutil.which('xvfb-run')
    render_cmd=([xvfb,'-a','openscad','-o',str(png),'--imgsize=1280,960','--viewall','--autocenter','-D','eu_size=44','-D','width_scale=1.00','-D','part="full_mockup"',str(REV_M)] if xvfb else [])
    render_ok=False; render_detail='xvfb-run unavailable'
    if render_cmd:
        cp=subprocess.run(render_cmd,capture_output=True,text=True,timeout=180)
        render_ok=(cp.returncode==0 and png.exists() and png.stat().st_size>10000)
        render_detail=f'returncode={cp.returncode}; png_exists={png.exists()}; bytes={png.stat().st_size if png.exists() else 0}; stdout={cp.stdout[-200:]}; stderr={cp.stderr[-500:]}'
    test_rows.append({'check_id':'NATIVE_FULL_MOCKUP_RENDER','group':'OpenSCAD native GUI image export','status':'PASS' if render_ok else 'FAIL','detail':render_detail})

    # Physical/material checks are explicit NOT RUN entries rather than falsely counted as passing.
    physical_gates = [
      ('MATERIAL_SPECIFIC_FEA','Material-specific structural FEA and failure-mode analysis','No production material/process/allowable data or validated contact model in the package.'),
      ('PHYSICAL_PROOF_LOAD','Guarded static/eccentric proof-load testing','Requires manufactured specimens, engineered load/acceptance criteria, calibrated load cell and guarding.'),
      ('FATIGUE_CYCLE','Fatigue, adjustment cycling and stop-impact validation','No physical cycle or impact tests were performed.'),
      ('PIN_RING_RETENTION','Pin/ring pull-out, accidental-release and groove-fatigue testing','CAD geometry does not establish retention capacity or pin/clip wear resistance.'),
      ('OUTSOLE_VALIDATION','Outsole attachment, traction, abrasion, flex and tear testing','No selected outsole compound/bond or physical test data.'),
      ('PHYSICAL_MASS','Physical weighing of completed assemblies','No physical assembly exists in this runtime; all figures are geometry × assumed density.'),
      ('UPPER_FIT','Last, fit, heel retention and strap-anchor pull-out validation','Upper and closures are conceptual, and no foot-fit trial was run.'),
      ('FASTENER_JOINT','Fastener thread engagement, torque and loosening validation','Actual fastener grades/threads/materials are not specified, so no torque value is supported.'),
      ('HUMAN_SPEED_TRIAL','Human walking/running/speed trial','Blocked until all independent structural, retention, grip, fit and durability release gates pass; no test run.'),
    ]
    for check_id, label, detail in physical_gates:
        test_rows.append({'check_id':check_id,'group':label,'status':'NOT RUN','detail':detail})

    # Write reports, and a single result JSON.
    write_csv(RES/'REV_M_GEOMETRY_REGRESSION.csv',geom_rows)
    write_csv(RES/'REV_M_DIMENSIONAL_AND_CLEARANCE_CHECKS.csv',dim_rows)
    write_csv(RES/'REV_M_MASS_COMPONENT_BREAKDOWN.csv',mass_rows)
    write_csv(RES/'REV_M_MASS_BASELINE_COMPARISON.csv',summary_rows)
    write_csv(RES/'REV_M_AUTOMATED_CHECKS.csv',test_rows)
    counts={s:sum(1 for r in test_rows if r['status']==s) for s in ('PASS','FAIL','NOT RUN')}
    # Geometry rows are also part of the automated status totals.
    geom_counts={s:sum(1 for r in geom_rows if r['status']==s) for s in ('PASS','FAIL','NOT RUN')}
    overall_fail=counts['FAIL']+geom_counts['FAIL']
    summary={'revision':'Rev M','sizes':list(SIZES),'automated_check_rows':len(test_rows),'automated_status_counts':counts,
             'geometry_regression_rows':len(geom_rows),'geometry_regression_status_counts':geom_counts,
             'all_automated_geometry_checks_pass':overall_fail==0,'wear_release_ready':False,'physical_validation_status':'NOT RUN / REQUIRED',
             'note':'This validator does not simulate material strength, fatigue, retention capacity, traction, fit or human safety.'}
    (RES/'REV_M_VALIDATION_SUMMARY.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')

    md=['# Rev M Regression and Release Verification Report','',
        '**Scope:** native CAD exports, mesh topology, baseline geometry comparison, pin/retaining-ring fit arithmetic and geometry-derived mass estimates. These are not material strength or wearable release tests.','',
        '## Automated checks','',
        f"- CSV rows: {len(test_rows)}; PASS {counts['PASS']}; FAIL {counts['FAIL']}; NOT RUN {counts['NOT RUN']}",
        f"- Geometry regression rows: {len(geom_rows)}; PASS {geom_counts['PASS']}; FAIL {geom_counts['FAIL']}; NOT RUN {geom_counts['NOT RUN']}",
        f"- Native OpenSCAD PNG render: {'PASS' if render_ok else 'FAIL'}.",
        '- The baseline-comparison rows deliberately classify toe-boss and pin/clip changes as intentional changes; other listed baseline parts are expected to match Rev L exactly.',
        '- The pin/clip test checks geometric envelope and closed mesh topology only; it does not establish clip retention force, groove fatigue strength, pin shear/bending capacity or accidental-release resistance.',
        '', '## Geometry-based mass estimate', '',
        'Mass is computed per component from the volume of freshly exported Rev M STL geometry × assumed density. Densities: deck/toe polymer 1.01 g/cm³; rail/bridge aluminium proxy 2.70 g/cm³; pin and clip steel proxy 7.90 g/cm³; outsole 1.15/1.20/1.25 g/cm³ sensitivity, with 1.20 used for central totals; footbed foam proxy 0.20 g/cm³. These are accounting assumptions, not selected material specifications.',
        '', 'The lightweight outsole study remains opt-in only (3.2 mm cover/1.4 mm relief, nominal 1.8 mm remaining skin); the default remains 4.0 mm. No load-bearing decks, rails, bridges, rail-head sections or pin shaft were lightened.',
        '', '## Explicitly not established by digital checks', '',
        '- Material-specific FEA/stress, fatigue, impact, wear and buckling calculations.',
        '- Physical proof loading, cyclic size-adjustment testing, pin pull-out/impact testing and secondary-retention validation.',
        '- Outsole attachment, wet/dry traction, flex, abrasion, tear and fatigue performance.',
        '- Upper / strap pull-out, fit to a real last, pressure points, heel retention and wearable comfort.',
        '- Human walking, running, speed or injury-risk results.',
        '', '**Release disposition:** design files are ready for independent engineering review and controlled specimen manufacture. Wear approval is NOT GRANTED by this report.', '']
    (RES/'REV_M_REGRESSION_TEST_REPORT.md').write_text('\n'.join(md),encoding='utf-8')
    print(json.dumps(summary,indent=2))
    return 1 if overall_fail else 0

if __name__=='__main__':
    sys.exit(main())
