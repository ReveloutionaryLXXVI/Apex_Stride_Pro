#!/usr/bin/env python3
"""Build the current Rev R1 digital validation report and QA summary after rerunning checks."""
from pathlib import Path
import csv, json, hashlib
ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'revision/verification_results/revR1_fresh_validation'
OUT.mkdir(parents=True,exist_ok=True)
def readj(path): return json.loads(path.read_text(encoding='utf-8'))
def readcsv(path):
    with path.open(newline='',encoding='utf-8') as f: return list(csv.DictReader(f))
source=readj(ROOT/'revision/verification_results/revR_core_integration/REVR_SOURCE_COMPILE_AND_PACKAGE_CHECKS.json')
cavity=readj(ROOT/'revision/verification_results/revR_core_integration/REVR_CORE_CAVITY_GEOMETRY_CHECKS.json')
sweep=readj(ROOT/'revision/verification_results/revR_material_integration/kinematic_sweep/REV_R_61_POSITION_KINEMATIC_CLEARANCE_SWEEP.json')
csg=readj(ROOT/'revision/verification_results/revR_material_integration/exact_csg/REV_R_EXACT_TOE_RAIL_INTERSECTION_TEST.json')
mass=readj(ROOT/'revision/verification_results/revR_core_integration/REVR_MASS_AUDIT_SUMMARY.json')
mass_rows=readcsv(ROOT/'revision/verification_results/revR_core_integration/REVK_VS_REVR_MATERIAL_CARD_MASS_SUMMARY.csv')
interface=readj(ROOT/'revision/verification_results/revR_component_closure/REV_R1_TOE_ANCHOR_INTERFACE_CSG.json')
load=readj(OUT/'REV_R1_INDEPENDENT_LOAD_SCREEN.json')
part_index=readcsv(ROOT/'PRINT_READY_BENCH_FIT_KIT_REV_R/PRINT_PARTS_INDEX_REV_R.csv')
required_names=['cavity','kinematic','csg','fitkit','mass','sourcecheck','load_screen']
exit_codes={}
for n in required_names:
    p=Path('/mnt/data/apex_work/rerun_r1_2')/f'fresh_{n}.exit'
    if p.exists(): exit_codes[n]=int(p.read_text().strip())
all_exit_ok=len(exit_codes)==len(required_names) and all(v==0 for v in exit_codes.values())
source_path=ROOT/'revision/Apex_Stride_Pro_RevR.scad'
source_sha=hashlib.sha256(source_path.read_bytes()).hexdigest()
summary={
 'revision':'Rev R1.2 fresh validation / M4, pressure-area and local roof corrections',
 'date':'2026-10-16',
 'authoritative_cad':'revision/Apex_Stride_Pro_RevR.scad',
 'authoritative_cad_sha256':source_sha,
 'fresh_run_exit_codes':exit_codes,
 'all_fresh_checks_exit_zero':all_exit_ok,
 'source_package_checks':{'checks':source.get('check_count'), 'pass':source.get('pass'), 'fail':source.get('fail'), 'result':source.get('result')},
 'cavity_checks':{'row_count':len(cavity),'result':'PASS' if all((r.get('pass') is True) or (r.get('independent_of_lightening_toggle') is True) for r in cavity) else 'CHECK'},
 'kinematic_sweep':{'positions':sweep.get('positions'),'checks':sweep.get('checks'),'position_rows_pass':sweep.get('position_rows_pass'),'position_rows_fail':sweep.get('position_rows_fail'),'result':sweep.get('result')},
 'rail_stop_csg':{'checks':csg.get('checks'),'pass':csg.get('pass'),'fail':csg.get('fail'),'result':csg.get('result')},
 'toe_anchor_interface_csg':{'checks':interface.get('checks'),'pass':interface.get('pass'),'fail':interface.get('fail'),'result':interface.get('result'),'R1_2_status':'not rerun in R1.2; the roof-only change does not alter tested toe/strap/footbed interfaces; prior exact CSG suite passed 24/24'},
 'fitkit_mesh_exports':{'rows':len(part_index),'pass':sum(r.get('result')=='PASS' for r in part_index),'fail':sum(r.get('result')!='PASS' for r in part_index)},
 'modeled_mass_basis_entries':mass.get('revised_total_mesh_basis_entries', mass.get('fresh_native_mesh_exports')),
 'fresh_roof_heel_deck_mesh_exports':mass.get('fresh_native_mesh_exports'),
 'assembly_map_rows':source.get('assembly_map_rows'),'missing_assembly_map_paths':source.get('missing_map_paths'),
 'mass_by_size':mass_rows,
 'independent_load_screen':load,
 'structural_fea':'NOT RUN; no compatible FEA solver/workflow found or run in this environment',
 'physical_tests':'NOT RUN',
 'wear_release':'NOT CLEARED',
 'disposition':'digital geometry/interface checks pass only; not structurally qualified or wearable'
}
(OUT/'REV_R1_FRESH_VALIDATION_QA.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
# Readable standalone validation report.
report=f'''# Apex Stride Pro — Rev R1.2 corrected validation and design-input fixes

**Date:** 2026-10-16  
**Baseline:** Rev R geometry with corrected M4 counterbores, corrected bladder area/pressure inputs, and a 10.1 mm heel-core roof  
**Disposition:** Digital geometry checks pass after the screw-interface and local heel-core roof corrections. **This remains a non-wearable fit/mockup and engineering-review package; structural capacity, pressure safety, and human wear are not cleared.**

## Defect 1 — M4 screw-head interference corrected

An exact OpenSCAD CSG intersection test was added for the nominal M4 screw envelopes against the actual strap and footbed geometry. The first run passed the six toe-screw-to-EVA checks but failed all six toe button-head/strap checks: the recess cutter started 0.01 mm below the strap face but was only 2.20 mm high, ending 0.01 mm short of the 2.20 mm head envelope. That left a tiny positive-volume overlap in the nominal CAD.

**Fix 1:** all three M4 button-head recess cutters in `revision/Apex_Stride_Pro_RevR.scad` now use `bridge_screw_head_depth + 0.01` cutter height. Since each cutter starts 0.01 mm below the external face, the recess into the actual strap stays 2.20 mm deep; the cutter simply reaches the intended head top plane. The authoritative and print-prep CAD were synchronized; a standalone copy of the corrected source is also provided with the deliverables. The toe screw / EVA clearances were not changed.

The exact-interface suite checks the 16 mm moving toe anchors, 18 mm heel anchors, and indexed rear-strap locking screw envelopes at EU42/EU44/EU46. The last complete run passed **{interface.get('pass')}/{interface.get('checks')}**, and it is retained for R1.2 because the roof-only change does not alter any of those tested interface surfaces; the suite was not rerun in this R1.2 pass. Nominal cylinder models prove geometric non-interference only; they are not manufacturer CAD or physical fit tests.

## Defect 2 — heel-core roof geometry reinforced

The prior 5.5 mm local roof over the spring/bladder cavity produced 36.92 MPa at 1× and 73.84 MPa at 2× in the 20 mm-width one-way strip sensitivity. Rather than only repeating that concern, Rev R1.2 changes the actual subtraction geometry: the roof is now **10.1 mm**, cavity height **10.5 mm**, and outside sole remains **20.6 mm**. The custom bladder RFQ height target is reduced from 14 to **9 mm**, leaving 1.5 mm nominal vertical clearance; length/width/port/fold clearances still require an OEM drawing. This local reinforcement adds 5,819 mm³ (about 5.53 g) of assumed-density PA12 in the heel deck. The corresponding simple strip sensitivity falls to **10.95 MPa at 1×, 21.90 MPa at 2× and 32.85 MPa at 3×** for a 20 mm load-spread width. This materially improves the screening result but does not replace material-specific FEA or proof/fatigue testing.

## Fresh software verification results

| Check | Fresh result | What it establishes |
|---|---:|---|
| Source/package/mesh suite | {source.get('pass')}/{source.get('check_count')} PASS | Selectors/configurations, source parity, component mesh integrity, documentation/map checks and arithmetic gates |
| Continuous heel-core cavity | {len(cavity)}/9 rows | Cavity ray probes, watertightness, and invariance to the optional lightening switch across EU42/44/46 |
| Adjustment sweep | {sweep.get('position_rows_pass')}/{sweep.get('positions')} positions; {sweep.get('checks')} checks | Nominal slider/stop/bridge arithmetic only |
| Rail/stop exact CSG | {csg.get('pass')}/{csg.get('checks')} PASS | No positive-volume intersection at indexed positions for both rails across EU42/44/46 |
| M4/EVA/bridge interface CSG | {interface.get('pass')}/{interface.get('checks')} PASS (previous run; unchanged interfaces) | Empty exact CSG overlap for nominated screw/head envelopes with actual strap/footbed geometry; not rerun because R1.2 only changes the heel-core roof |
| Non-wearable fit-kit mesh validation | {sum(r.get('result')=='PASS' for r in part_index)}/{len(part_index)} PASS | Current 42 indexed STLs are validated; three affected heel-deck STLs were freshly re-exported for R1.2; other selector geometry is unchanged |
| Modeled mass basis | {mass.get('revised_total_mesh_basis_entries',mass.get('fresh_native_mesh_exports'))} component-size rows; {mass.get('fresh_native_mesh_exports')} heel-deck meshes freshly re-exported and volume-validated for R1.2 | PA12 roof-volume delta measured on current heel-deck meshes; other selector geometry unchanged |
| Assembly-file map | {source.get('assembly_map_rows')} entries, {len(source.get('missing_map_paths') or [])} missing | All mapped file paths resolve |

The adjustment sweep reports no nominal arithmetic failures. These checks do **not** model manufacturing tolerances, part deformation, fatigue, physical contact pressure, or load-rated performance.

## Recomputed modeled platform mass

| Size | Rev K modeled platform | Rev R modeled platform | Delta |
|---|---:|---:|---:|
'''
for r in mass_rows:
    report+=f"| {r['size']} | {float(r['RevK_full_modeled_platform_g_outsole_1p20']):.3f} g | {float(r['RevR_full_modeled_platform_g_outsole_1p20']):.3f} g | {float(r['RevR_delta_platform_g']):+.3f} g |\n"
report+='''
These figures are partial model estimates—not measured finished-shoe mass. They exclude EVA/footbed mass, actual retaining ring, production fasteners, upper, return spring, bladder, tubing/fittings/regulator, adhesive and other unmodeled parts. Outsole mass assumes an illustrative 1.20 g/cm³ density. The modeled mass-reduction target remains unmet.

## 66 kg structural / pneumatic screen

The full 66 kg gravitational load is **647.46 N** (`66 × 9.81`). The load-screen multipliers intentionally assign that entire load to **one shoe** as a conservative single-support sensitivity case; they do not use the average two-foot stance. The ideal equal bilateral static share is **323.73 N per foot** (which would mean half the listed force/stress/pressure values before any multiplier if that were the chosen load case). The 1.5×/2×/3× cases are analyst sensitivities, not measured gait loads or safety factors.

- **Pneumatics — corrected calculation:** the previous screen wrongly used the 1,265 mm² *whole cavity* area as bladder area. The specified RFQ bladder body target is ≤27×22×9 mm, so its maximum target projected rectangle is only **594 mm²** before the effective pressure area is confirmed. If the bladder alone carried the full 647.46 N single-shoe load, pressure demand is 1.090 MPa at 1×, 1.635 MPa at 1.5×, 2.180 MPa at 2× and 3.270 MPa at 3× (the bilateral static share is 0.545 MPa). This cannot be handled by the candidate KQ2 fittings rated 1.0 MPa. **Corrective design input:** treat the bladder as an auxiliary-force element with a 0.40 MPa provisional working target and 0.50 MPa nominal relief-setpoint target. The nominal force is 237.6 N at working target and 297 N at relief target; the chassis must carry the remainder and withstand the complete external load with the bladder depressurized. Setpoints remain provisional until the bladder's working/burst/cycle rating and actual effective area are known and relief-flow/overshoot tests show chamber transients remain below every component rating.
- **Cavity roof, corrected geometry:** Rev R1.2 thickens the local PA12 roof from 5.5 to 10.1 mm by reducing the custom bladder body height target to 9.0 mm; the outside sole thickness remains 20.6 mm, cavity depth is 10.5 mm, and target vertical clearance is 1.5 mm. The same one-way strip sensitivity at 20 mm load-spread width falls from 36.92 to about 10.94 MPa at 1×, 21.88 MPa at 2× and 32.82 MPa at 3×, versus a 41 MPa published flexural-strength reference. This is only an analytical geometry sensitivity—not 3D FEA, a design allowable or fatigue proof. Supplier must confirm a finished 9 mm-high bladder and effective area.
- **Pin:** the simple point-load beam screen depends strongly on assumed effective span: 40.6 mm rail-center spacing gives 152.49 MPa at 1× and 457.47 MPa at 3×; using a 90.3 mm whole-pin span gives 339.16 MPa at 1× and 1,017.47 MPa at 3×. The true support/load distribution is unresolved; neither is a validated pin stress. A 725 MPa candidate H1150D proof reference is just a material comparison, not a design allowable or fatigue limit.

No compatible FEA solver/workflow was found or run in this environment. No material-specific 3D FEA, mesh convergence/contact analysis, tolerance/strain simulation, pressure/leak/burst test, static proof load, impact/fatigue cycle, pin/ring retention test, outsole bond/slip test, sewn upper fit test, or human-wear test was performed. The CSV/JSON load screen records all scenarios and limitations at `revision/verification_results/revR1_fresh_validation/`.

## Release decision

**Digital source/mesh checks: PASS. The prior 24/24 exact interface CSG result remains applicable to unchanged mating interfaces. Structural qualification and human wear: NOT CLEARED.** Keep the shoe non-wearable until the production material/process and exact hardware are fixed, the load/contact path is independently analyzed with approved allowables, the bladder/circuit has rated hardware and fail-safe dump behavior, and appropriate guarded physical proof/fatigue/fit/traction tests pass.

Reproduce the validation with the source scripts under `revision/tools/`; the current report and machine-readable QA summary are `REV_R1_FRESH_VALIDATION_REPORT.md` and `revision/verification_results/revR1_fresh_validation/REV_R1_FRESH_VALIDATION_QA.json`.
'''
(ROOT/'REV_R1_FRESH_VALIDATION_REPORT.md').write_text(report,encoding='utf-8')
# Put a compact fresh-status notice at the top of the existing project status file.
status_path=ROOT/'PROJECT_STATUS_AND_RELEASE_GATE.md'
status=status_path.read_text(encoding='utf-8')
start='<!-- FRESH REV R1 VALIDATION UPDATE BEGIN -->'
end='<!-- FRESH REV R1 VALIDATION UPDATE END -->'
notice=f'''{start}
## Fresh validation/correction pass — 2026-10-16

- Found a **0.01 mm nominal CSG clash** between the M4 button-head envelope and all six moving front-strap recesses. Corrected the three button-head cutter heights by +0.01 mm (without changing the 2.20 mm depth into the plate); synchronized source and print-prep CAD.
- Exact interface CSG suite: **{interface.get('pass')}/{interface.get('checks')} PASS** across EU42/EU44/EU46, checking toe EVA reliefs, moving-front-strap screw heads, fixed rear-anchor heads, and indexed rear locking-screw heads.
- Fresh core suite: **{source.get('pass')}/{source.get('check_count')} PASS**; cavity checks **{len(cavity)}/9**; adjustment sweep **{sweep.get('position_rows_pass')}/{sweep.get('positions')}**; rail/stop CSG **{csg.get('pass')}/{csg.get('checks')}**; fit-kit meshes **{sum(r.get('result')=='PASS' for r in part_index)}/{len(part_index)}**; native mesh mass recomputation **{mass.get('fresh_native_mesh_exports')}** exports.
- This is still **not FEA or physical qualification**. No material-specific FEA, physical proof/fatigue/pressure/traction/fit tests, or human-wear test has run. Human wear remains **NOT CLEARED**. See `REV_R1_FRESH_VALIDATION_REPORT.md` for the load sensitivities and release gates.
{end}

'''
if start in status and end in status:
    a=status.index(start); b=status.index(end)+len(end)
    status=status[:a]+notice.rstrip()+status[b:]
else:
    status=notice+status
status_path.write_text(status,encoding='utf-8')
print(json.dumps({'qa_path':str(OUT/'REV_R1_FRESH_VALIDATION_QA.json'),'report_path':str(ROOT/'REV_R1_FRESH_VALIDATION_REPORT.md'),'source_suite':source.get('result'),'interface_csg':interface.get('result'),'all_exit_zero':all_exit_ok},indent=2))
