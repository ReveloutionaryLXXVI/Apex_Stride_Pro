#!/usr/bin/env python3
"""Fast source-driven 61-position slider / stop / registration screen for Rev O C2.

This complements (does not replace) exact OpenSCAD CSG interface intersections. It verifies
nominal coordinate arithmetic from the current SCAD dimensions at 61 extension positions.
A positive-volume end-stop overlap was independently confirmed on the pre-fix source and
removed by the source correction; the terminal CSG test is stored separately.
"""
from pathlib import Path
import re,csv,json,math
ROOT=Path(__file__).resolve().parents[2]
SRC=ROOT/'revision/Apex_Stride_Pro_RevO.scad'
OUT=ROOT/'revision/verification_results/fresh_closure_audit'; OUT.mkdir(parents=True,exist_ok=True)
txt=SRC.read_text(encoding='utf-8')
def val(name):
 m=re.search(rf'(?m)^\s*{re.escape(name)}\s*=\s*([-+]?(?:\d+\.?\d*|\.\d+))\s*;',txt)
 if not m: raise KeyError(name)
 return float(m.group(1))
mm=val('mm_per_eu_size'); split=val('heel_split_x'); rail_start=split-65.0; rail_end=split+90.0; rail_y=val('rail_y')
slot=val('slot_length'); head=val('rail_head_width'); stem=val('rail_stem_width'); neck=val('rail_neck_height'); height=val('rail_height')
clear=val('fit_clearance'); clear_z=val('fit_clearance_vertical'); bridge_width=val('bridge_flange_width'); bridge_clear=val('bridge_fit_clearance'); bridge_rear_start=val('bridge_rear_start'); bridge_rear_end=val('bridge_rear_end'); bridge_front_start=val('bridge_front_start'); bridge_front_end=val('bridge_front_end')
max_ext=4*mm
count=61
rows=[]
for i in range(count):
 ext=max_ext*i/(count-1)
 # Geometry from the moving TOE deck and stationary rail, as encoded in Rev O source.
 channel_start=split-0.5+ext
 channel_end=split+slot+1.0+ext
 engagement=max(0.0,min(rail_end,channel_end)-max(rail_start,channel_start))
 lug_start=rail_end-3.0
 groove_start_ref=rail_end-3.0-4*mm  # corrected source now has no +0.3 here
 groove_start_world=groove_start_ref+ext
 stop_clearance=lug_start-groove_start_world # >=0 means no positive-volume interference; 0 means end contact
 groove_end_ref=groove_start_ref+3.0+4*mm+0.3
 groove_end_world=groove_end_ref+ext
 lug_end=rail_end
 slot_overhang=groove_end_world-lug_end
 # Bridge strap overlap as moving front strap slides across fixed rear strap.
 rear0=split-bridge_rear_start; rear1=split+bridge_rear_end
 front0=split-bridge_front_start+ext; front1=split+bridge_front_end+ext
 bridge_overlap=min(rear1,front1)-max(rear0,front0)
 ok=(engagement>0 and stop_clearance>=-1e-6 and slot_overhang>=-1e-6 and bridge_overlap>0)
 rows.append({'position_index':i,'extension_mm':round(ext,6),'rail_channel_engagement_mm':round(engagement,6),'stop_clearance_to_contact_mm':round(stop_clearance,6),'stop_groove_overrun_past_lug_end_mm':round(slot_overhang,6),'bridge_strap_overlap_mm':round(bridge_overlap,6),'result':'PASS' if ok else 'FAIL','detail':'nominal coordinate arithmetic only; adjustment is unlocked between indexed lock stations'})
path=OUT/'REV_O_61_POSITION_KINEMATIC_CLEARANCE_SWEEP.csv'
with path.open('w',newline='',encoding='utf-8') as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
# Exact lock station registration from current CAD equations.
regs=[]
for size in (42,44,46):
 ext=(size-42)*mm
 rail_pin_x=split+30+ext
 toe_bore_x=split+30+ext
 rear_bridge_hole=split+val('bridge_lock_x')+ext
 front_bridge_hole=split+val('bridge_lock_x')+ext
 regs.append({'size':f'EU{size}','extension_mm':ext,'rail_pin_index_error_mm':abs(rail_pin_x-toe_bore_x),'bridge_lock_pair_error_mm':abs(rear_bridge_hole-front_bridge_hole),'result':'PASS' if abs(rail_pin_x-toe_bore_x)<1e-8 and abs(rear_bridge_hole-front_bridge_hole)<1e-8 else 'FAIL'})
with (OUT/'REV_O_DISCRETE_LOCK_REGISTRATION_RECHECK.csv').open('w',newline='',encoding='utf-8') as f:
 w=csv.DictWriter(f,fieldnames=list(regs[0]));w.writeheader();w.writerows(regs)
summary={'positions':count,'checks':count*4+len(regs)*2,'position_rows_pass':sum(r['result']=='PASS' for r in rows),'position_rows_fail':sum(r['result']=='FAIL' for r in rows),'registration_rows_pass':sum(r['result']=='PASS' for r in regs),'registration_rows_fail':sum(r['result']=='FAIL' for r in regs),'extension_range_mm':[0.0,max_ext],'min_rail_channel_engagement_mm':min(r['rail_channel_engagement_mm'] for r in rows),'max_stop_clearance_before_contact_mm':max(r['stop_clearance_to_contact_mm'] for r in rows),'terminal_stop_clearance_mm':rows[-1]['stop_clearance_to_contact_mm'],'min_bridge_overlap_mm':min(r['bridge_strap_overlap_mm'] for r in rows),'result':'PASS' if all(r['result']=='PASS' for r in rows+regs) else 'FAIL','limitations':['Nominal source-coordinate arithmetic only.','No tolerance, deformability, material, wear, or dynamic simulation.','The pin must be withdrawn during continuous adjustment; lock-hole alignment is checked only at EU42/EU44/EU46 indexed settings.']}
(OUT/'REV_O_61_POSITION_KINEMATIC_CLEARANCE_SWEEP.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
print(json.dumps(summary,indent=2))
raise SystemExit(1 if summary['result']!='PASS' else 0)
