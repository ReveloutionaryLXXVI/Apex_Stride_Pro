#!/usr/bin/env python3
"""Representative Rev R1.4 exact CSG checks plus all-variant coordinate guardrails."""
from pathlib import Path
import subprocess,tempfile,csv,json,math,time
ROOT=Path(__file__).resolve().parents[2]
SRC=ROOT/'revision/Apex_Stride_Pro_RevR.scad'
OUT=ROOT/'revision/verification_results/revR1_4_go1_go2'; OUT.mkdir(parents=True,exist_ok=True)
src=SRC.read_text(encoding='utf-8'); modsrc=src.split('// ---------- EXPORT SELECTOR ----------',1)[0]
rows=[]; t0=time.time()
def run(size,side,interface,body):
    yy=-5.0 if side=='minusY' else 5.0
    body=body.replace('__YY__',f'{yy:.1f}')
    with tempfile.TemporaryDirectory(prefix='apex_r14_csg_') as td:
        td=Path(td); scad=td/'check.scad'; stl=td/'intersection.stl'
        scad.write_text(modsrc+'\n'+body+'\n',encoding='utf-8')
        cp=subprocess.run(['openscad','-o',str(stl),'-D',f'eu_size={size}',str(scad)],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=60)
        empty=('Current top level object is empty.' in cp.stdout) and not stl.exists() and 'ERROR:' not in cp.stdout
        ok=empty
        rows.append({'size':f'EU{size}','side':side,'interface':interface,'result':'PASS' if ok else 'FAIL','exit_code':cp.returncode,'expected_empty_intersection':empty,'details':cp.stdout[-250:].replace('\n',' | ')})
        print(f"{'PASS' if ok else 'FAIL'} EU{size} {side} {interface}",flush=True)
for size in (42,44,46):
    ext=(size-42)*6.6667
    sides=('minusY','plusY') if size==42 else ('minusY',)
    for side in sides:
        off='(yy<0 ? -bridge_pair_stagger_mm : bridge_pair_stagger_mm)'
        # Fixed rear anchor screw, head and actual under-head length vs real rear strap.
        run(size,side,'M4x22_rear_anchor_vs_rear_strap',f'''intersection() {{
          bridge_rear_strap(); union() {{
            translate([heel_split_x-10+{off.replace('yy','__YY__')}, __YY__, sole_bottom_z]) cylinder(h=bridge_screw_head_depth,d=7.6,$fn=48);
            translate([heel_split_x-10+{off.replace('yy','__YY__')}, __YY__, sole_bottom_z+bridge_screw_head_depth]) cylinder(h=bridge_rear_anchor_screw_length_mm-bridge_screw_head_depth,d=4.0,$fn=48);
          }} }}''')
        # Toe anchor screw vs actual moving front strap.
        run(size,side,'M4x16_toe_anchor_vs_front_strap',f'''intersection() {{
          translate([{ext:.4f},0,0]) bridge_front_strap(); union() {{
            translate([{ext:.4f}+heel_split_x+10+{off.replace('yy','__YY__')}, __YY__, sole_bottom_z+bridge_flange_thickness]) cylinder(h=bridge_screw_head_depth,d=7.6,$fn=48);
            translate([{ext:.4f}+heel_split_x+10+{off.replace('yy','__YY__')}, __YY__, sole_bottom_z+bridge_flange_thickness+bridge_screw_head_depth]) cylinder(h=bridge_toe_anchor_screw_length_mm-bridge_screw_head_depth,d=4.0,$fn=48);
          }} }}''')
        # Selected indexed lock screw vs real rear strap at this size station.
        run(size,side,'M4x14_lock_vs_rear_strap',f'''intersection() {{
          bridge_rear_strap(); union() {{
            translate([heel_split_x+bridge_lock_x+{ext:.4f}+{off.replace('yy','__YY__')}, __YY__, sole_bottom_z]) cylinder(h=bridge_screw_head_depth,d=7.6,$fn=48);
            translate([heel_split_x+bridge_lock_x+{ext:.4f}+{off.replace('yy','__YY__')}, __YY__, sole_bottom_z+bridge_screw_head_depth]) cylinder(h=bridge_lock_screw_length_mm-bridge_screw_head_depth,d=4.0,$fn=48);
          }} }}''')
# Deterministic coordinate checks for every design size; these complement CSG, not physical tolerancing.
head_center_sep=math.hypot(2*2.0,2*5.0); cap=4.5-2.2
checks={
 'strap_cap_mm':(cap,cap>=2.3,'>=2.3 mm cap'),
 'two_layer_stack_mm':(9.0,abs(9.0-2*4.5)<1e-9,'stack = two 4.5 mm layers'),
 'pair_head_edge_gap_mm':(head_center_sep-7.9,head_center_sep-7.9>=1.0,'>=1.0 mm edge gap'),
 'toe_anchor_tip_z_mm':(-20.6+4.5+16.0,-20.6+4.5+16.0<0.15-0.20,'tip at least 0.20 mm below footbed'),
 'lock_tip_relief_margin_mm':(1.65-(14-9-3.45),1.65-(14-9-3.45)>=0.10,'>=0.10 mm axial relief margin'),
 'rear_anchor_tip_z_mm':(-20.6+22.0,(-20.6+22.0)<=5.4,'rear anchor tip remains within existing heel-footbed lap void'),
}
for n,(val,ok,note) in checks.items():
    rows.append({'size':'ALL','side':'COORDINATE','interface':n,'result':'PASS' if ok else 'FAIL','exit_code':0,'expected_empty_intersection':ok,'details':f'value={val:.4f}; acceptance={note}'})
with (OUT/'REV_R1_4_JOINT_INTERFACE_CSG.csv').open('w',newline='',encoding='utf-8') as f:
    w=csv.DictWriter(f,fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
summary={'revision':'Rev R1.4 GO1+GO2','checks':len(rows),'csg_checks':sum(r['side'] not in ('COORDINATE','PAIR') for r in rows),'coordinate_guardrails':len(checks),'pass':sum(r['result']=='PASS' for r in rows),'fail':sum(r['result']=='FAIL' for r in rows),'elapsed_seconds':round(time.time()-t0,2),'scope':'Nominal CAD/screw-envelope intersections and coordinate guardrails; not strength or physical qualification.'}
(OUT/'REV_R1_4_JOINT_INTERFACE_CSG.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2)); raise SystemExit(1 if summary['fail'] else 0)
