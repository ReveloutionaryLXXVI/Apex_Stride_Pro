#!/usr/bin/env python3
"""Fast native-OpenSCAD mass audit for Rev R1.3 active geometry; estimates only."""
from pathlib import Path
import subprocess,tempfile,csv,json
import numpy as np, trimesh
root=Path(__file__).resolve().parents[2]; src=root/'revision/Apex_Stride_Pro_RevR.scad'
out=root/'revision/verification_results/revR1_3_full_audit';out.mkdir(parents=True,exist_ok=True)
parts=[('heel_deck','heel',0.95,'PA12 SLS candidate density from Materialise card'),('toe_carriage','toe',0.95,'PA12 SLS candidate density from Materialise card'),('bridge_rear','bridge_rear',2.70,'6061-T6 density assumption; material not procured'),('bridge_front','bridge_front',2.70,'6061-T6 density assumption; material not procured'),('rail_left','rail_left',2.70,'6061-T6 density assumption; material not procured'),('rail_right','rail_right',2.70,'6061-T6 density assumption; material not procured'),('locking_pin','pin_through_solid',7.75,'17-4PH candidate density; exact part/condition not procured'),('outsole_assembly','outsole_assembly',1.20,'placeholder rubber density; compound not selected')]
def export(size,sel):
 with tempfile.TemporaryDirectory(prefix='apex_r13_mass_') as td:
  f=Path(td)/'p.stl';cmd=['openscad','--export-format','binstl','-o',str(f),'-D',f'eu_size={size}','-D','width_scale=1.00','-D',f'part="{sel}"',str(src)]
  cp=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=75)
  if cp.returncode or not f.exists() or f.stat().st_size<500 or 'ERROR:' in cp.stdout: raise RuntimeError(f'{sel}/{size}: {cp.stdout[-1000:]}')
  m=trimesh.load(f,force='mesh',process=True)
  if not(m.is_watertight and m.is_winding_consistent and np.isfinite(m.vertices).all() and m.volume>0): raise RuntimeError(f'Mesh failure {sel}/{size}')
  return float(m.volume),[float(x) for x in m.extents]
rows=[]; summary=[]
for size in (42,44,46):
 total=0; outsole=0
 for name,sel,density,basis in parts:
  vol,ext=export(size,sel); mass=vol/1000*density
  rows.append({'size':f'EU{size}','component':name,'selector':sel,'volume_mm3':round(vol,4),'extents_mm':'x'.join(f'{x:.3f}' for x in ext),'density_g_cm3':density,'estimated_mass_g':round(mass,4),'basis':basis,'mesh_result':'PASS'})
  if name=='outsole_assembly': outsole=mass
  else: total+=mass
 # Current footbed volume measurement is geometry only; no density is assigned.
 summary.append({'size':f'EU{size}','chassis_plus_pin_g':round(total,4),'outsole_mass_placeholder_g':round(outsole,4),'modeled_lower_platform_excluding_footbed_fasteners_ring_upper_pneumatics_adhesive_g':round(total+outsole,4)})
with (out/'REV_R1_3_MASS_BY_COMPONENT.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
(out/'REV_R1_3_MASS_SUMMARY.json').write_text(json.dumps({'revision':'Rev R1.3','native_openSCAD_exports':len(rows),'components_per_size':len(parts),'all_mesh_exports_valid':all(r['mesh_result']=='PASS' for r in rows),'mass_summary':summary,'omissions':['EVA footbed mass (density/grade unknown)','actual retaining-ring mass','fasteners','upper','spring','bladder','tubing/valves/regulator','adhesives'], 'caveat':'Mass values are estimates from modeled geometry times candidate density assumptions, not measured finished mass.'},indent=2)+'\n')
print(json.dumps({'native_exports':len(rows),'all_meshes_pass':all(r['mesh_result']=='PASS' for r in rows),'summary':summary},indent=2))
