#!/usr/bin/env python3
"""Fresh OpenSCAD mesh-volume mass estimate for Rev K vs Rev O.

Requires OpenSCAD, Python 3, numpy and trimesh. Outputs are assumed-density estimates,
not measured mass or strength evidence. Run from any working directory.
"""
from pathlib import Path
import subprocess, tempfile, csv
import numpy as np
import trimesh
ROOT=Path(__file__).resolve().parents[2]
K_SRC=ROOT/'baseline_original/extracted/Apex_Stride_Pro_RevK.scad'
O_SRC=ROOT/'revision/Apex_Stride_Pro_RevO.scad'
OUT=ROOT/'revision/verification_results/fresh_closure_audit'; OUT.mkdir(parents=True,exist_ok=True)
PARTS={'heel_deck':'heel','toe_carriage':'toe','bridge_rear':'bridge_rear','bridge_front':'bridge_front','rail_left':'rail_left','rail_right':'rail_right','locking_pin':'pin_through_solid','outsole_assembly':'outsole_assembly','footbed_insert':'footbed_insert'}
DENSITY={'heel_deck':1.01,'toe_carriage':1.01,'bridge_rear':2.70,'bridge_front':2.70,'rail_left':2.70,'rail_right':2.70,'locking_pin':7.90,'retaining_ring':7.90,'outsole_assembly':1.20,'footbed_insert':0.20}
def export(src,size,selector,study=False):
  with tempfile.TemporaryDirectory(prefix='apex_mass_') as td:
    dst=Path(td)/'part.stl'
    cmd=['openscad','--export-format','binstl','-o',str(dst),'-D',f'eu_size={size}','-D','width_scale=1.00','-D',f'part="{selector}"']
    if study: cmd += ['-D','outsole_weight_study=true']
    cmd += [str(src)]
    cp=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=60)
    if cp.returncode or not dst.exists() or dst.stat().st_size<500: raise RuntimeError(f'Export failure EU{size} {selector} {src}: {cp.stdout[-1200:]}')
    m=trimesh.load_mesh(dst,force='mesh',process=True)
    if not(m.is_watertight and m.is_winding_consistent and np.isfinite(m.vertices).all() and np.isfinite(m.volume) and m.volume>0): raise RuntimeError(f'Mesh check failed EU{size} {selector} {src}')
    return float(m.volume), [float(x) for x in m.extents]
rows=[]; totals={}; exports=0
for rev,label,src in [('RevK','RevK',K_SRC),('RevO','RevO',O_SRC)]:
 for size in (42,44,46):
  total=0.0
  for comp,sel in PARTS.items():
   vol,ext=export(src,size,sel); exports += 1
   mass=vol/1000*DENSITY[comp]
   rows.append({'revision':label,'size':f'EU{size}','component':comp,'selector':sel,'volume_mm3':f'{vol:.6f}','assumed_density_g_cm3':DENSITY[comp],'estimated_mass_g':f'{mass:.6f}','extents_mm':'x=%.3f;y=%.3f;z=%.3f'%tuple(ext),'mesh_result':'PASS','method':'Fresh OpenSCAD STL export, trimesh volume × assumed density; not measured'})
   total+=mass
  if label=='RevO':
   vol,ext=export(src,size,'pin_retaining_clip'); exports += 1
   mass=vol/1000*DENSITY['retaining_ring']
   rows.append({'revision':label,'size':f'EU{size}','component':'retaining_ring','selector':'pin_retaining_clip','volume_mm3':f'{vol:.6f}','assumed_density_g_cm3':DENSITY['retaining_ring'],'estimated_mass_g':f'{mass:.6f}','extents_mm':'x=%.3f;y=%.3f;z=%.3f'%tuple(ext),'mesh_result':'PASS','method':'Simplified ring envelope mass only; not purchased ring mass'})
   total+=mass
  totals[(label,size)]=total
  print(label, f'EU{size}',f'total={total:.6f} g',flush=True)
study_rows=[]
for size in (42,44,46):
 vol,ext=export(O_SRC,size,'outsole_assembly',True); exports+=1
 study_out=vol/1000*DENSITY['outsole_assembly']
 default_out=float(next(r['estimated_mass_g'] for r in rows if r['revision']=='RevO' and r['size']==f'EU{size}' and r['component']=='outsole_assembly'))
 st=totals[('RevO',size)]-default_out+study_out
 study_rows.append({'size':f'EU{size}','RevK_baseline_g':f'{totals[("RevK",size)]:.6f}','RevO_default_g':f'{totals[("RevO",size)]:.6f}','default_delta_g':f'{totals[("RevO",size)]-totals[("RevK",size)]:+.6f}','default_delta_percent':f'{(totals[("RevO",size)]/totals[("RevK",size)]-1)*100:+.3f}%','study_outsole_volume_mm3':f'{vol:.6f}','study_outsole_estimated_mass_g':f'{study_out:.6f}','RevO_study_platform_g':f'{st:.6f}','study_vs_default_g':f'{st-totals[("RevO",size)]:+.6f}','study_vs_RevK_g':f'{st-totals[("RevK",size)]:+.6f}','density_assumptions':'deck=1.01; rails/bridges=2.70; pin/ring=7.90; outsole=1.20; footbed=0.20 g/cm3','status':'UNVALIDATED STUDY ONLY','excludes':'unmodelled fasteners, production upper, actual foam/pneumatic/spring components, adhesive, process allowances'})
with (OUT/'REVK_REVO_FRESH_COMPONENT_MASS.csv').open('w',newline='',encoding='utf-8') as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
with (OUT/'REVK_REVO_FRESH_MASS_SUMMARY.csv').open('w',newline='',encoding='utf-8') as f:
 w=csv.DictWriter(f,fieldnames=list(study_rows[0]));w.writeheader();w.writerows(study_rows)
with (OUT/'REVO_OPTIONAL_OUTSOLE_STUDY_MASS.csv').open('w',newline='',encoding='utf-8') as f:
 fields=['size','RevO_default_g','study_outsole_volume_mm3','study_outsole_estimated_mass_g','RevO_study_platform_g','study_vs_default_g','study_vs_RevK_g','density_assumptions','status','excludes']
 w=csv.DictWriter(f,fieldnames=fields);w.writeheader()
 for r in study_rows:
  w.writerow({'size':r['size'],'RevO_default_g':r['RevO_default_g'],'study_outsole_volume_mm3':r['study_outsole_volume_mm3'],'study_outsole_estimated_mass_g':r['study_outsole_estimated_mass_g'],'RevO_study_platform_g':r['RevO_study_platform_g'],'study_vs_default_g':r['study_vs_default_g'],'study_vs_RevK_g':r['study_vs_RevK_g'],'density_assumptions':r['density_assumptions'],'status':r['status'],'excludes':r['excludes']})
print(f'PASS: fresh native mesh exports={exports}; component rows={len(rows)}; output={OUT}')
