#!/usr/bin/env python3
"""Current Rev P C3 document/file/mass reconciliation audit.
This does not perform or imply structural or physical wear validation.
"""
from pathlib import Path
import csv, hashlib, json
from collections import defaultdict
ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'revision/verification_results/fresh_closure_audit'
OUT.mkdir(parents=True,exist_ok=True)
checks=[]
def add(group,item,ok,detail): checks.append({'group':group,'item':item,'status':'PASS' if ok else 'FAIL','detail':detail})

# Exact component file map.
mp=ROOT/'revision/docs/ASSEMBLY_FILE_MAP_REV_P.csv'
map_rows=list(csv.DictReader(mp.open(newline='',encoding='utf-8')))
missing=[r['relative_filename'] for r in map_rows if not (ROOT/r['relative_filename']).is_file()]
expected={"39 main fit/mockup parts, 21 upper concept meshes, 9 optional outsole-study meshes"}
add('assembly_file_map','69 mapped part paths',len(map_rows)==69 and not missing,
    f'rows={len(map_rows)}; missing={len(missing)}; missing_examples={missing[:5]}')

# Fresh mass component totals must agree with the native exported summary.
cp=ROOT/'revision/verification_results/revP_mass_audit/REVK_REVP_FRESH_COMPONENT_MASS.csv'
sp=ROOT/'revision/verification_results/revP_mass_audit/REVK_REVP_FRESH_MASS_SUMMARY.csv'
comp=list(csv.DictReader(cp.open(newline='',encoding='utf-8')))
summ=list(csv.DictReader(sp.open(newline='',encoding='utf-8')))
add('mass_audit','fresh component data rows',len(comp)==57,f'rows={len(comp)}')
for r in summ:
    size=r['size']; total=sum(float(x['estimated_mass_g']) for x in comp if x['revision']=='RevP' and x['size']==size)
    target=float(r['RevP_default_g']); delta=total-target
    add('mass_reconciliation',size,abs(delta)<1e-5,f'component sum={total:.6f}g; summary={target:.6f}g; delta={delta:.9f}g')
    expected_delta=target-float(r['RevK_baseline_g'])
    add('mass_delta_reconciliation',size,abs(expected_delta-float(r['default_delta_g']))<1e-5,
        f'derived delta={expected_delta:+.6f}g; CSV delta={float(r["default_delta_g"]):+.6f}g')

# Current sources agree on the C3 solid land parameters.
for rel in ['revision/Apex_Stride_Pro_RevP.scad','PRINT_READY_BENCH_FIT_KIT_REV_P/source/Apex_Stride_Pro_RevP_PrintPrep.scad']:
    text=(ROOT/rel).read_text(encoding='utf-8')
    toks=['rail_mount_pilot_d = 3.3;','rail_relief_sidewall_mm = 2.5;','cavity_a0 = max(cavity_x0, x_mount_1 + mount_keepout)','cavity_b0 = max(cavity_x0, x_mount_2 + mount_keepout)']
    ok=all(t in text for t in toks)
    add('source_sync',rel,ok,'C3 pilot diameter, 2.5 mm solid-land parameter and split cavity expressions present')

# C3 correction and load arithmetic registers.
c3=ROOT/'revision/verification_results/REV_P_C3_SAFETY_CORRECTION/C3_CORRECTIVE_TEST_REGISTER.csv'
c3_rows=list(csv.DictReader(c3.open(newline='',encoding='utf-8')))
add('C3_geometry_land_register','17 C3 correction checks',len(c3_rows)==17 and all(r['result']=='PASS' for r in c3_rows),
    f'rows={len(c3_rows)}; passes={sum(r["result"]=="PASS" for r in c3_rows)}; fails={sum(r["result"]=="FAIL" for r in c3_rows)}')
loadv=ROOT/'revision/verification_results/REV_P_C3_SAFETY_CORRECTION/C3_LOAD_SCREEN_VALIDATION.csv'
lv=list(csv.DictReader(loadv.open(newline='',encoding='utf-8')))
add('C3_load_screen','15 analytical data consistency checks',len(lv)==15 and all(r['result']=='PASS' for r in lv),
    f'rows={len(lv)}; passes={sum(r["result"]=="PASS" for r in lv)}; fails={sum(r["result"]=="FAIL" for r in lv)}')

# Current preview is visual-only; check file existence rather than treating render as solid export.
preview=ROOT/'reports/REV_P_FULL_MOCKUP_EU44.png'
add('preview','current Rev P preview exists',preview.is_file(),f'exists={preview.is_file()}; visualization only, not printable assembly')

# The preserved original package is verified against the recorded checksum in the root preservation manifest.
orig=ROOT/'baseline_original/Apex_Stride_Pro_FINAL_CAD_Package_uploaded_original.zip'
add('baseline_preservation','original upload present',orig.is_file() and orig.stat().st_size>0,
    f'exists={orig.is_file()}; bytes={orig.stat().st_size if orig.exists() else 0}')

outcsv=OUT/'FINAL_DOCUMENT_REFERENCE_AUDIT_REV_P_C3.csv'
with outcsv.open('w',newline='',encoding='utf-8') as f:
    w=csv.DictWriter(f,fieldnames=['group','item','status','detail']);w.writeheader();w.writerows(checks)
failed=[r for r in checks if r['status']=='FAIL']
summary={'checks':len(checks),'pass':len(checks)-len(failed),'fail':len(failed),'physical_validation':False,'scope':'file map, source parity, mass reconciliation and current C3 evidence links only'}
(OUT/'FINAL_DOCUMENT_REFERENCE_AUDIT_REV_P_C3.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
for r in checks: print(r['status'],r['group'],r['item'],r['detail'])
raise SystemExit(1 if failed else 0)
