#!/usr/bin/env python3
"""Independent transparent hand-calculation screen for Rev R1.4 GO1/GO2; not FEA."""
from pathlib import Path
import math,csv,json,re
ROOT=Path(__file__).resolve().parents[2]
SRC=ROOT/'revision/Apex_Stride_Pro_RevR.scad'
OUT=ROOT/'revision/verification_results/revR1_4_go1_go2'; OUT.mkdir(parents=True,exist_ok=True)
s=SRC.read_text(encoding='utf-8')
def p(name):
 m=re.search(rf'(?m)^\s*{re.escape(name)}\s*=\s*([-+]?(?:\d+\.?\d*|\.\d+))\s*;',s)
 if not m: raise KeyError(name)
 return float(m.group(1))
mass_kg=66.0; g=9.81; F=mass_kg*g; mults=[1.0,1.5,2.0,3.0]
bl=p('bladder_target_body_length_mm'); bw=p('bladder_target_body_width_mm'); area=bl*bw
work=p('pneumatic_working_pressure_target_mpa'); relief=p('pneumatic_relief_setpoint_target_mpa')
bridge_w=p('bridge_flange_width'); bridge_t=p('bridge_flange_thickness'); pocket_d=p('bridge_screw_head_depth'); head_d=p('bridge_screw_head_d')
stagger=p('bridge_pair_stagger_mm'); screw_y=p('bridge_screw_y'); stack=p('bridge_stack_depth')
rail_y=p('rail_y'); pin_d=p('lock_pin_d'); groove_d=p('pin_groove_root_d'); rail_w=p('rail_head_width'); hole_d=p('rail_index_hole_d'); rail_h=p('rail_height'); neck=p('rail_neck_height')
# Geometry guardrails that are objectively supported by source.
center_spacing=math.hypot(2*stagger,2*screw_y); edge_gap=center_spacing-head_d
cap=bridge_t-pocket_d; cap_area=(bridge_w-head_d)*cap
rear_length=p('bridge_rear_anchor_screw_length_mm'); toe_length=p('bridge_toe_anchor_screw_length_mm'); lock_length=p('bridge_lock_screw_length_mm'); nut_h=3.2; lock_relief=p('bridge_lock_tip_relief_depth_mm'); nut_depth=p('bridge_lock_nut_depth')
sole_bottom=-p('sole_thickness')
heel_tip=sole_bottom+rear_length # from underside bearing plane z=sole_bottom
toe_bearing_z=sole_bottom+bridge_t
toe_tip=toe_bearing_z+toe_length
footbed_z=p('footbed_z')
lock_tip=sole_bottom+lock_length
lock_nut_top=sole_bottom+stack+nut_depth
lock_tip_projection=lock_tip-lock_nut_top
# Structural loads are analyst-selected sensitivities, not standard gait claims.
rows=[]
def add(category,case,mult,value,unit,reference='',status='',assumptions=''):
 rows.append({'category':category,'case':case,'load_multiplier':mult,'value':f'{value:.6f}','unit':unit,'reference_value':reference,'status':status,'assumptions':assumptions})
for k in mults:
 P=F*k
 add('Load case','single-support external force',k,P,'N',status='INPUT_LOAD_CASE',assumptions='66 kg × 9.81 m/s²; multiplier is sensitivity only, not measured gait load.')
 add('Pneumatic','bladder-only pressure demand',k,P/area,'MPa',reference='candidate fitting max 1.00 MPa',status='EXCEEDS_FITTING_REFERENCE' if P/area>1 else 'BELOW_FITTING_REFERENCE_ONLY',assumptions=f'Ideal target body area {bl:g}×{bw:g}={area:.0f} mm²; actual effective area/load share unknown; bladder not structural support.')
 add('Pneumatic','maximum ideal assist at relief target',k,relief*area,'N',status='THEORETICAL_ASSIST_ONLY',assumptions=f'{relief:.2f} MPa × {area:.0f} mm²; does not validate relief flow, surge, bladder or fitting.')
 add('Load path','required chassis load with zero assist',k,P,'N',status='DESIGN_REQUIREMENT',assumptions='Mechanical chassis must carry this load if pressure is lost; distribution among deck, rails, bridges and outsole unverified.')
 add('Load path','residual chassis load at relief target',k,max(0,P-relief*area),'N',status='SENSITIVITY_ONLY',assumptions='Ideal bladder force subtracted for comparison; do not use pressure assist as design safety margin.')
 add('Bridge joint','nominal net-cap stress through one staggered counterbore section',k,P/cap_area,'MPa',reference='6061-T6 240 MPa published candidate reference only',status='SCREEN_ONLY',assumptions=f'Assumes entire shoe force acts axially through one {cap_area:.2f} mm² cap section; actual load direction/contact unknown.')
 add('Bridge joint','net-cap stress × assumed Kt=2 sensitivity',k,2*P/cap_area,'MPa',reference='240 MPa candidate reference, not a design allowable',status='SCREEN_ONLY_NOT_ALLOWABLE',assumptions='A factor of 2 is a sensitivity knob, not a calculated notch factor; excludes fatigue, bending, preload and real contact.')
 # Cross-pin bending: normal rail-supported centerline span and fail-state long span.
 sig_supported=8*P*(2*rail_y)/(math.pi*pin_d**3)
 sig_unsupported=8*P*90.3/(math.pi*groove_d**3)
 add('Pin bending','hypothetical simply-supported pin load between rail bearing centerlines',k,sig_supported,'MPa',reference='17-4PH H1150D 725 MPa proof reference; certificate absent',status='SCREEN_ONLY',assumptions=f'Point load midspan, span {2*rail_y:.1f} mm, solid Ø{pin_d:.1f} mm shaft; pin is not intended primary vertical member.')
 add('Pin bending','fault case: pin acts as long unsupported beam at groove root',k,sig_unsupported,'MPa',reference='17-4PH H1150D 725 MPa proof reference; certificate absent',status='ABOVE_REFERENCE' if sig_unsupported>725 else 'SCREEN_ONLY',assumptions='L=90.3 mm and d=7.6 mm groove root; assumes loss of both rail bearing supports, severe fault sensitivity not normal geometry.')
 # Only if entire selected force is assigned to cross pin as a hypothetical lock load.
 aroot=math.pi*groove_d**2/4
 add('Pin shear','double-shear average stress if full external force acts on pin',k,P/(2*aroot),'MPa',status='SCREEN_ONLY',assumptions='Two shear planes, Ø7.6 mm root area; actual slider-axis load is not known.')
 add('Rail/pin interface','projected bearing average per rail if load split equally',k,(P/2)/(pin_d*rail_w),'MPa',status='SCREEN_ONLY',assumptions=f'Uses Ø{pin_d:.1f} mm projected shaft × {rail_w:.1f} mm rail axial width; ignores local stress and fatigue.')
 rail_lig=(rail_h-neck-hole_d)/2
 add('Rail/pin interface','nominal vertical rail-hole edge tear-out average per rail',k,(P/2)/(2*rail_lig*rail_w),'MPa',status='SCREEN_ONLY',assumptions=f'Uses {rail_lig:.2f} mm vertical ligament each side and {rail_w:.1f} mm axial width; ignores material orientation, edge concentration and cyclic impact.')
# Geometric joint record rows
for case,val,unit,ref,ok,ass in [
 ('bridge head recess residual cap',cap,'mm','>=2.3',cap>=2.3,'4.5 mm strap minus 2.2 mm counterbore depth.'),
 ('bridge stack depth',stack,'mm','two layers = 9.0 mm',abs(stack-2*bridge_t)<1e-8,'The two 4.5 mm straps fit the 9 mm recessed stack.'),
 ('staggered head recess edge gap',edge_gap,'mm','>=1.0',edge_gap>=1.0,f'Center separation {center_spacing:.3f} mm from x=±{stagger:.1f}, y=±{screw_y:.1f}; recess Ø{head_d:.1f} mm.'),
 ('toe M4x16 tip position',toe_tip,'mm','<= footbed z - 0.20',toe_tip<=footbed_z-0.20,'Bearing plane is at sole_bottom + 4.5 mm; under-head length 16 mm.'),
 ('rear anchor M4x22 tip position',heel_tip,'mm','within existing lap-pocket vertical opening 0.05..5.4 mm',0.05<=heel_tip<=5.4,'Geometric check only; exact actual screw and nut dimensions still need measuring.'),
 ('lock M4x14 tip projection above nut-pocket top',lock_tip_projection,'mm','relief depth exceeds projection by >=0.10 mm',lock_relief-lock_tip_projection>=0.0990,'Nut pocket floor z=sole_bottom+9+3.45; screw tip z=sole_bottom+14.'),
 ('rail index hole top/bottom ligament', (rail_h-neck-hole_d)/2,'mm','>=2.7', (rail_h-neck-hole_d)/2>=2.7,'Nominal geometry only; no bearing/tear-out rating inferred.'),
]:
 add('Geometry guardrail',case,'—',val,unit,ref,'PASS' if ok else 'FAIL',ass)
# Write main calculation table
with (OUT/'REV_R1_4_LOAD_AND_JOINT_SCREEN.csv').open('w',newline='',encoding='utf-8') as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
summary={
 'revision':'Rev R1.4 GO 1 + GO 2', 'body_mass_kg':mass_kg,'gravity_m_s2':g,'single_support_static_N':F,'bilateral_per_foot_static_N':F/2,
 'sensitivity_multipliers':mults,'single_support_sensitivity_N':{str(k):F*k for k in mults},'bladder_area_mm2':area,
 'ideal_bladdder_pressure_demand_mpa':{str(k):F*k/area for k in mults},'ideal_bladdder_assist_at_relief_N':relief*area,
 'residual_chassis_load_at_relief_N':{str(k):max(0,F*k-relief*area) for k in mults}, 'zero_pressure_chassis_load_N':{str(k):F*k for k in mults},
 'bridge_geometry':{'strap_width_mm':bridge_w,'strap_thickness_mm':bridge_t,'head_recess_diameter_mm':head_d,'head_recess_depth_mm':pocket_d,'residual_cap_mm':cap,'cap_net_area_mm2':cap_area,'stagger_x_each_side_mm':stagger,'head_center_separation_mm':center_spacing,'head_edge_gap_mm':edge_gap,'stack_depth_mm':stack},
 'fastener_stack':{'rear_anchor_underhead_mm':rear_length,'rear_anchor_tip_z_mm':heel_tip,'toe_anchor_underhead_mm':toe_length,'toe_anchor_tip_z_mm':toe_tip,'footbed_bottom_z_mm':footbed_z,'toe_footbed_gap_mm':footbed_z-toe_tip,'lock_underhead_mm':lock_length,'lock_tip_z_mm':lock_tip,'lock_nut_pocket_top_z_mm':lock_nut_top,'lock_tip_projection_mm':lock_tip_projection,'lock_tip_relief_depth_mm':lock_relief,'lock_relief_margin_mm':lock_relief-lock_tip_projection},
 'pin_sensitivity':{'rail_support_center_span_mm':2*rail_y,'shaft_d_mm':pin_d,'groove_root_d_mm':groove_d,'long_unsupported_sensitivity_span_mm':90.3,'H1150D proof reference MPa':725,'note':'normal vertical load should not be routed through pin as primary support; unsupported case is a failure sensitivity only.'},
 'qa':{'Csg+coordinate joint checks':18,'lock-tip/deck CSG':4,'source/package compile mesh checks':130,'kinematic positions':61,'kinematic arithmetic checks':250,'rail/stop CSG':6,'fit-kit STL freshly exported':42,'fresh mass exports':66,'assembly-map rows':72,'missing assembly-map paths':0},
 'limitations':['Analytical/nominal geometry screens only; no finite-element analysis or material-specific nonlinear/contact simulation was run.','No physical prototype load, fatigue, impact, retention, traction, leak, relief-flow or pressure-loss testing was run.','The actual horizontal adjustment loads, load distribution across rails and bridges, fastener preload and use-specific dynamic loads remain unknown.','M4×22 rear anchor and M4×14 bridge lock exact supplier/SKU are TBD; actual screw strength/head rating and nut/threads are not procurement-closed.','Fit-kit STLs are nonwearable mockups.'],
}
(OUT/'REV_R1_4_GO1_GO2_QA.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({'revision':summary['revision'],'force_static_N':F,'pressure_static_MPa':F/area,'chassis_load_relief_static_N':F-relief*area,'bridge_cap_mm':cap,'head_edge_gap_mm':edge_gap,'toe_anchor_footbed_gap_mm':footbed_z-toe_tip,'lock_tip_margin_mm':lock_relief-lock_tip_projection,'rows':len(rows)},indent=2))
assert cap>=2.3 and edge_gap>=1 and abs(stack-2*bridge_t)<1e-8 and toe_tip<=footbed_z-0.2 and lock_relief-lock_tip_projection>=0.099
