from pathlib import Path
import re, shutil
ROOT=Path(__file__).resolve().parents[2]
revp=ROOT/'revision/Apex_Stride_Pro_RevP.scad'
revq=ROOT/'revision/Apex_Stride_Pro_RevQ.scad'
s=revp.read_text()
s=s.replace('APEX STRIDE PRO — GROWTHFIT CAPTURED-RAIL ADJUSTABLE SHOE CONCEPT — REV P PATCH C3', 'APEX STRIDE PRO — GROWTHFIT CAPTURED-RAIL ADJUSTABLE SHOE CONCEPT — REV Q MATERIAL INTEGRATION')
s=s.replace('Rev P retains the tested Rev P stop-groove correction', 'Rev Q preserves the tested Rev P/C3 rail and stop corrections')
s=s.replace('This is an engineering candidate, not a released wearable product.', 'Material card and specified upper/footbed/cushioning inputs are integrated in Rev Q. The lower-core bladder/spring remains a bounded packaging study because no rated bladder, spring curve, vertical stop travel, or pressure system has been selected. This is not a released wearable product.')
s=s.replace('// REV P candidate: reduced split outline and adjusted rail/bridge spacing; still requires physical qualification.', '// REV Q material integration candidate, derived from Rev P C3; unchanged chassis/rail/bridge load geometry pending material-specific FEA.')
s=s.replace('footbed_insert_thickness = 3.0; // visualization only; real cushioning requires material selection', '''// Rev Q removable EVA footbed target: 7 mm heel / 5 mm forefoot. Supplier compression data remains required.
footbed_heel_thickness = 7.0;
footbed_forefoot_thickness = 5.0;
footbed_edge_inset = 4.5;
footbed_lap_length = 45.0; // derived from 26.667 mm max extension + 18.333 mm minimum residual overlap
footbed_lap_halfwidth = 27.5; // at split, from 64 mm nominal sole width minus 4.5 mm inset per side
footbed_lap_clearance = 0.35; // geometric mockup clearance, verify after EVA die-cut/process
footbed_z = 0.15;

// Candidate material-card inputs (not used as strength allowables or production certification).
pa12_density_kg_m3 = 950;
pa12_tensile_modulus_mpa = 1650;
pa12_tensile_strength_mpa = 48; // tensile strength, NOT yield strength
pa12_flexural_strength_mpa = 41;
pa12_flexural_modulus_mpa = 1500;
pa12_elongation_percent = 20;
pa12_shore_d = 75;
pa12_hdt_c = 86;
tpu95a_modulus_xy_mpa = 67;
tpu95a_modulus_z_mpa = 56;
tpu95a_break_xy_mpa = 23.7;
tpu95a_break_z_mpa = 6.4;
pneumatic_tube_od_mm = 4.0; // only if selected fitting matches OD and rated pressure
heel_core_envelope_length = 55.0; // available longitudinal bounding envelope in rear under-deck pocket zone
heel_core_envelope_width = 23.0; // bounded by central region between the rail-channel edges; NOT a continuous free cavity
heel_core_envelope_height = 15.1; // current lightening-pocket depth: sole thickness 20.6 - roof z-depth 5.5
heel_core_envelope_x0 = -125.0;
heel_core_envelope_z0 = sole_bottom_z;''')
# add additional param assertions after width and source values are defined
anchor='assert(outsole_pad_thickness >= 3.0, "Outsole layer must be at least 3.0 mm in this concept model.");'
s=s.replace(anchor, anchor+'''\nassert(footbed_heel_thickness >= 6.0 && footbed_heel_thickness <= 8.0, "Heel EVA footbed target must remain in the 6-8 mm supplier-confirmed range.");
assert(footbed_forefoot_thickness >= 4.0 && footbed_forefoot_thickness <= 6.0, "Forefoot EVA footbed target must remain in the 4-6 mm supplier-confirmed range.");
assert(footbed_lap_length >= (4*mm_per_eu_size)+18.0, "Footbed sliding lap is too short to preserve overlap at EU46 extension.");''')
# replace footbed module block
old='''module footbed_insert() {
    translate([0,0,0.15])
        linear_extrude(height=footbed_insert_thickness)
            offset(delta=-4.5) upper_footprint_2d();
}'''
new='''// Rev Q removable EVA inserts: heel is 7 mm, forefoot 5 mm. A rear tongue on the moving
// forefoot insert slides in a bottom pocket in the heel insert. The 45 mm tongue exceeds the
// maximum 26.667 mm size extension by 18.333 mm, preserving coverage at EU46. Foam properties,
// friction, seam wear and compression-set still need supplier confirmation and bench cycling.
module footbed_heel_piece() {
  difference() {
    translate([0,0,footbed_z])
      linear_extrude(height=footbed_heel_thickness)
        offset(delta=-footbed_edge_inset) heel_profile_2d();
    // Underside sliding pocket: leave a nominal 1.75 mm top skin above the 5.25 mm pocket.
    // The moving EVA tongue is 5.0 mm thick and leaves 0.25 mm nominal vertical clearance.
    translate([heel_split_x-footbed_lap_length-footbed_lap_clearance,
               -footbed_lap_halfwidth-footbed_lap_clearance, footbed_z-0.10])
      cube([footbed_lap_length+2*footbed_lap_clearance,
            2*(footbed_lap_halfwidth+footbed_lap_clearance), footbed_forefoot_thickness+0.25+0.10]);
  }
}
module footbed_toe_piece() {
  translate([extension,0,footbed_z])
    linear_extrude(height=footbed_forefoot_thickness)
      offset(delta=-footbed_edge_inset) toe_profile_2d();
}
module footbed_toe_lap_tongue() {
  translate([extension,0,footbed_z])
    linear_extrude(height=footbed_forefoot_thickness)
      polygon(points=[
        [heel_split_x-footbed_lap_length, -footbed_lap_halfwidth],
        [heel_split_x, -footbed_lap_halfwidth],
        [heel_split_x, footbed_lap_halfwidth],
        [heel_split_x-footbed_lap_length, footbed_lap_halfwidth]
      ]);
}
module footbed_insert() {
  union() {
    footbed_heel_piece();
    footbed_toe_piece();
    footbed_toe_lap_tongue();
  }
}

// A non-manufacturing visualization of the maximum under-deck envelope reserved for the
// heel spring + bladder concept. It deliberately overlays the current deck's discrete pocket
// ribs; it is NOT evidence that components fit into the existing separated lightening pockets.
// The overlay makes the integration gap visible. Do not export this selector as a physical part.
module heel_core_envelope_study() {
  color([0.10,0.50,0.95,0.32])
    translate([heel_core_envelope_x0,-heel_core_envelope_width/2,heel_core_envelope_z0])
      cube([heel_core_envelope_length,heel_core_envelope_width,heel_core_envelope_height]);
  // Schematic split only: left 24 mm mechanical spring reserve, right 28 mm bladder reserve,
  // separated by 3 mm. These are bounding zones, not spring/bladder dimensions or selected parts.
  color([0.15,0.72,0.38,0.42])
    translate([heel_core_envelope_x0,-heel_core_envelope_width/2,heel_core_envelope_z0])
      cube([24,heel_core_envelope_width,heel_core_envelope_height]);
  color([0.95,0.58,0.12,0.42])
    translate([heel_core_envelope_x0+27,-heel_core_envelope_width/2,heel_core_envelope_z0])
      cube([28,heel_core_envelope_width,heel_core_envelope_height]);
}'''
if old not in s:
    raise SystemExit('footbed module block not found')
s=s.replace(old,new)
# add selectors before else unknown at the end
s=s.replace('''} else if (part == "footbed_insert") {
  footbed_insert();
} else if (part == "toe_vamp_shell") {''','''} else if (part == "footbed_insert") {
  footbed_insert();
} else if (part == "footbed_heel_piece") {
  footbed_heel_piece();
} else if (part == "footbed_toe_piece") {
  footbed_toe_piece();
} else if (part == "footbed_toe_lap_tongue") {
  footbed_toe_lap_tongue();
} else if (part == "heel_core_envelope_study") {
  heel_core_envelope_study();
} else if (part == "toe_vamp_shell") {''')
s=s.replace('footbed_insert, toe_vamp_shell', 'footbed_insert, footbed_heel_piece, footbed_toe_piece, footbed_toe_lap_tongue, heel_core_envelope_study, toe_vamp_shell')
# source history phrase only exact revision comments
revq.write_text(s)
# Build print-prep as same authoritative geometry + same selectors, differing header only. Keep all CAD logic identical.
printdir=ROOT/'PRINT_READY_BENCH_FIT_KIT_REV_Q/source'
printdir.mkdir(parents=True,exist_ok=True)
pp='''/*\n APEX STRIDE PRO — REV Q PRINT PREP SOURCE\n Derived from revision/Apex_Stride_Pro_RevQ.scad with identical geometry and selector set.\n Printable components are for dimensional fit/mockup only, not load-bearing human wear.\n*/\n'''+s
(ppath:=printdir/'Apex_Stride_Pro_RevQ_PrintPrep.scad').write_text(pp)
print('wrote',revq,ppath, 'bytes',len(s))
