#!/usr/bin/env python3
"""Independent pressure/load arithmetic; pressure demand uses the actual target bladder envelope.
This is an analytical screen, not FEA, and does not approve a working pressure or wearable release. Rev R1.2 changes core roof thickness to 10.1 mm and bladder target height to 9 mm.
"""
from pathlib import Path
import csv, json, math, re, shutil, importlib.util
ROOT=Path(__file__).resolve().parents[2]
SRC=ROOT/'revision/Apex_Stride_Pro_RevR.scad'
OUT=ROOT/'revision/verification_results/revR1_fresh_validation'
OUT.mkdir(parents=True,exist_ok=True)
txt=SRC.read_text(encoding='utf-8')
def value(name):
    m=re.search(rf'(?m)^\s*{re.escape(name)}\s*=\s*([-+]?(?:\d+\.?\d*|\.\d+))\s*;',txt)
    if not m: raise KeyError(f'missing CAD parameter: {name}')
    return float(m.group(1))

mass_kg=66.0; g=9.81; F0=mass_kg*g
load_case=('Conservative single-support sensitivity: entire 66 kg gravitational load assigned to one shoe; multipliers are analyst-selected sensitivities, not measured gait loads.')
cavity_area=value('heel_core_envelope_length')*value('heel_core_envelope_width')
bladder_length=value('bladder_target_body_length_mm')
bladder_width=value('bladder_target_body_width_mm')
bladder_area=bladder_length*bladder_width
roof_h=value('heel_core_roof_thickness_mm')
roof_span=value('heel_core_envelope_width')
rail_spacing=2*value('rail_y')
pin_d=value('pin_groove_root_d')
working_p=value('pneumatic_working_pressure_target_mpa')
relief_p=value('pneumatic_relief_setpoint_target_mpa')
fitting_rating=value('pneumatic_candidate_fitting_max_working_mpa')
tube_rating=value('pneumatic_candidate_tube_max_working_mpa')
relief_range=value('pneumatic_candidate_relief_family_max_set_mpa')
regulator_max=value('pneumatic_candidate_regulator_max_output_mpa')
pa12_flexural_reference_mpa=value('pa12_flexural_strength_mpa')
h1150d_proof_reference_mpa=725.0
multipliers=[1.0,1.5,2.0,3.0]
working_force=working_p*bladder_area # MPa=N/mm^2
relief_force=relief_p*bladder_area
rows=[]
def add(check,mult,span,force,result_value,unit,ref,comparison,result):
    rows.append({'check':check,'load_case':load_case,'multiplier':mult,'assumed_span_or_width_mm':span,'force_N':force,'result_value':result_value,'unit':unit,'reference_value':ref,'comparison':comparison,'result':result})
for mult in multipliers:
    force=F0*mult
    p_bladd_only=force/bladder_area
    add('bladder pressure demand if bladder alone carries load',mult,bladder_area,force,p_bladd_only,'MPa',fitting_rating,
        f'target bladder body footprint {bladder_length:g} x {bladder_width:g} mm = {bladder_area:g} mm2; compare to SMC KQ2 nominal max working pressure; actual effective area may be smaller',
        'EXCEEDS_FITTING_IF_BLADDER_ALONE' if p_bladd_only>fitting_rating else 'below fitting rating only under ideal area assumption')
    residual_work=max(0.0,force-working_force)
    residual_relief=max(0.0,force-relief_force)
    add('required structural support at provisional working target',mult,bladder_area,force,residual_work,'N',None,
        f'F_total minus nominal bladder force at {working_p:.2f} MPa ({working_force:.2f} N); structural path must support this',
        'STRUCTURAL_LOAD_PATH_REQUIRED' if residual_work>0 else 'no residual under idealized calculation')
    add('required structural support at provisional relief target',mult,bladder_area,force,residual_relief,'N',None,
        f'F_total minus nominal bladder force at {relief_p:.2f} MPa ({relief_force:.2f} N); assumes full target projected area and relief response',
        'STRUCTURAL_LOAD_PATH_REQUIRED' if residual_relief>0 else 'no residual under idealized calculation')
    for width in [20.0,30.0,40.0,60.0]:
        sigma=3*force*roof_span/(2*width*roof_h**2)
        add('cavity roof one-way strip sensitivity (bladder depressurized fail-safe case)',mult,width,force,sigma,'MPa',pa12_flexural_reference_mpa,
            'gross external load; simplified central-load strip versus published PA12 flexural-strength reference, not an allowable',
            'above reference' if sigma>pa12_flexural_reference_mpa else 'not above reference; still not qualified')
    for span in [rail_spacing,90.3]:
        moment=force*span/4
        sigma=32*moment/(math.pi*pin_d**3)
        add('pin centre-load beam span sensitivity',mult,span,force,sigma,'MPa',h1150d_proof_reference_mpa,
            'simple centre point load, round 7.6 mm groove-root section; compare to candidate H1150D proof reference only',
            'above reference' if sigma>h1150d_proof_reference_mpa else 'not above reference; not a design allowable')

with (OUT/'REV_R1_INDEPENDENT_LOAD_SCREEN.csv').open('w',newline='',encoding='utf-8') as f:
    w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
# Corrective arithmetic gates: these deliberately fail if the full cavity is reused as bladder area.
assert abs(F0-647.46)<1e-8
assert abs(F0/2-323.73)<1e-8
assert abs(cavity_area-1265.0)<1e-8
assert abs(bladder_area-594.0)<1e-8
assert abs(F0/bladder_area-1.09)<1e-8
assert abs(F0*2/bladder_area-2.18)<1e-8
assert abs(F0*3/bladder_area-3.27)<1e-8
assert abs(working_force-237.6)<1e-8 and abs(relief_force-297.0)<1e-8
assert 0 < working_p < relief_p <= relief_range < fitting_rating < tube_rating
assert relief_p < regulator_max and fitting_rating-relief_p >= 0.40
pp=ROOT/'PRINT_READY_BENCH_FIT_KIT_REV_R/source/Apex_Stride_Pro_RevR_PrintPrep.scad'
source_lines=SRC.read_text(encoding='utf-8').splitlines();pp_lines=pp.read_text(encoding='utf-8').splitlines()
parity=pp_lines==source_lines
assert parity, 'print-prep source differs from authoritative CAD source'
solver_checks={name:shutil.which(name) for name in ['ccx','calculix','gmsh','FreeCAD','freecad','abaqus','code_aster']}
solver_modules={name:bool(importlib.util.find_spec(name)) for name in ['sfepy','fenics','dolfinx','calfem','pyNastran']}
summary={
 'revision':'Rev R1.2 corrected pressure screen and reinforced heel-core roof',
 'body_mass_kg':mass_kg,'gravity_m_s2':g,'body_force_N':F0,'equal_bilateral_static_force_per_foot_N':F0/2,'load_case':load_case,
 'projected_cavity_area_mm2':cavity_area,
 'target_bladder_body_dimensions_mm':{'length':bladder_length,'width':bladder_width,'height':value('bladder_target_body_height_mm')},
 'target_bladder_projected_area_mm2':bladder_area,
 'pressure_demand_if_bladder_alone_1x_MPa':F0/bladder_area,
 'pressure_demand_if_bladder_alone_1p5x_MPa':1.5*F0/bladder_area,
 'pressure_demand_if_bladder_alone_2x_MPa':2*F0/bladder_area,
 'pressure_demand_if_bladder_alone_3x_MPa':3*F0/bladder_area,
 'provisional_working_pressure_target_MPa':working_p,
 'provisional_relief_setpoint_target_MPa':relief_p,
 'nominal_bladder_force_at_working_target_N':working_force,
 'nominal_bladder_force_at_relief_setpoint_N':relief_force,
 'required_structural_support_at_relief_setpoint_N':{f'{m:g}x':max(0.0,F0*m-relief_force) for m in multipliers},
 'required_structural_share_at_relief_setpoint_percent':{f'{m:g}x':100*max(0.0,F0*m-relief_force)/(F0*m) for m in multipliers},
 'nominal_relief_to_fitting_pressure_margin_MPa':fitting_rating-relief_p,
 'candidate_ratings_MPa':{'working_target':working_p,'relief_setpoint_target':relief_p,'AP20_D_max_setpoint':relief_range,'ARX20_max_output':regulator_max,'KQ2_max_working':fitting_rating,'T0425_max_working_at_20C':tube_rating},
 'nominal_roof_thickness_mm':roof_h,'pin_groove_root_diameter_mm':pin_d,'rail_centerline_spacing_mm':rail_spacing,'whole_pin_span_sensitivity_mm':90.3,
 'roof_strip_formula':f'sigma = 3*F*L/(2*b*h^2), L=23 mm, h={roof_h:.1f} mm revised heel-core roof, b=20/30/40/60 mm assumed',
 'pin_formula':'sigma = 32*(F*span/4)/(pi*d^3), d=7.6 mm, span=40.6 and 90.3 mm sensitivity only',
 'pa12_flexural_reference_MPa':pa12_flexural_reference_mpa,'candidate_pin_proof_reference_MPa':h1150d_proof_reference_mpa,
 'printprep_source_parity':parity,'fea_solver_executables_found':{k:v for k,v in solver_checks.items() if v},'fea_solver_executables_checked':list(solver_checks.keys()),'python_fea_modules_found':[k for k,v in solver_modules.items() if v],
 'result':'PASS_CORRECTED_ARITHMETIC_AND_NOMINAL_PRESSURE_HIERARCHY_ONLY',
 'limitations':[
  'The old pressure screen incorrectly used the full 55 x 23 mm cavity area as bladder area; this correction uses the specified 27 x 22 mm target bladder body footprint (594 mm2). Actual pressure-effective area may be smaller.',
  'The 0.40 MPa working / 0.50 MPa nominal relief settings are provisional design targets only. They are not approved until the finished bladder has an OEM-declared working/burst/cycle rating, the AP20-D flow/overshoot is checked, and measured chamber pressure transients stay below all component ratings.',
  'At the provisional 0.50 MPa relief target, nominal bladder support is only 297 N at the assumed full projected area. The chassis/structural load path must safely carry the residual and must withstand the full load with the bladder depressurized; this is not demonstrated by the current strip screen.',
  'The Lee Spring candidate is a 20.5–30.8 N return spring at an assumed 4–6 mm compression and is not a body-load spring.',
  'No finite-element solver/workflow was available or run. Roof-strip and pin-beam analyses are analyst-defined sensitivity models, not validated stress/load-path analyses or design allowables.',
  'Candidate material reference values do not account for manufacturing direction, notches, contact, fatigue or impact. No physical tests or human wear tests were performed.'
 ]
}
(OUT/'REV_R1_INDEPENDENT_LOAD_SCREEN.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
print(json.dumps(summary,indent=2))
