#!/usr/bin/env python3
"""Independent analytical load-screen for Apex Stride Pro Rev P.

This is NOT finite-element analysis and NOT a material-specific capacity check. It parses
nominal geometry values from the current OpenSCAD source, checks internal arithmetic, and
calculates transparent scenario stresses for explicitly hypothetical load paths.
Requires Python stdlib only. Run from any directory.
"""
from pathlib import Path
import re, csv, json, math, shutil, time

ROOT = Path(__file__).resolve().parents[2]
SRC = ROOT / "revision/Apex_Stride_Pro_RevP.scad"
OUT = ROOT / "revision/verification_results/revP_mass_audit/analytical_screen"
REPORT = ROOT / "reports/STRUCTURAL_ANALYTICAL_SCREENING_REVP.md"
OUT.mkdir(parents=True, exist_ok=True)
REPORT.parent.mkdir(parents=True, exist_ok=True)
text = SRC.read_text(encoding="utf-8")

def val(name):
    m = re.search(rf"(?m)^\s*{re.escape(name)}\s*=\s*([-+]?(?:\d+\.?\d*|\.\d+))\s*;", text)
    if not m:
        raise KeyError(f"could not parse scalar {name} from {SRC}")
    return float(m.group(1))

# Extract source-controlled dimensions.
P = {
    "sole_thickness_mm": val("sole_thickness"),
    "rail_y_mm": val("rail_y"),
    "width_scale": val("width_scale"),
    "bridge_screw_y_mm": val("bridge_screw_y"),
    "rail_head_width_mm": val("rail_head_width"),
    "rail_neck_height_mm": val("rail_neck_height"),
    "rail_height_mm": val("rail_height"),
    "fit_clearance_mm": val("fit_clearance"),
    "fit_clearance_vertical_mm": val("fit_clearance_vertical"),
    "bridge_flange_width_mm": val("bridge_flange_width"),
    "bridge_fit_clearance_mm": val("bridge_fit_clearance"),
    "lock_pin_d_mm": val("lock_pin_d"),
    "pin_groove_root_d_mm": val("pin_groove_root_d"),
    "rail_index_hole_d_mm": val("rail_index_hole_d"),
    "lock_hole_d_mm": val("lock_hole_d"),
    "pin_keeper_counterbore_d_mm": val("pin_keeper_counterbore_d"),
    "pin_keeper_clip_od_mm": val("pin_keeper_clip_od"),
    "pin_keeper_recess_depth_mm": val("pin_keeper_recess_depth"),
    "pin_keeper_clip_thickness_mm": val("pin_keeper_clip_thickness"),
    "pin_groove_width_mm": val("pin_groove_width"),
    "pin_tail_extension_mm": val("pin_tail_extension"),
    "pin_entry_y_mm": val("pin_entry_y"),
    "pin_head_d_mm": val("pin_head_d"),
    "pin_counterbore_d_mm": val("pin_counterbore_d"),
    "bridge_lock_hole_d_mm": val("bridge_lock_hole_d"),
    "bridge_flange_thickness_mm": val("bridge_flange_thickness"),
    "bolt_hole_d_mm": val("bolt_hole_d"),
    "lightening_roof_z_mm": val("lightening_roof_z"),
    # Current source default has outsole_weight_study=false, so use the final branch of each ternary.
    "outsole_pad_thickness_mm": 4.0,
    "outsole_relief_depth_mm": 2.2,
}
# Derived source geometry.
P["rail_head_vertical_height_mm"] = P["rail_height_mm"] - P["rail_neck_height_mm"]
P["rail_vertical_ligament_mm"] = (P["rail_head_vertical_height_mm"] - P["rail_index_hole_d_mm"]) / 2
P["deck_roof_above_rail_channel_mm"] = P["sole_thickness_mm"] - P["rail_height_mm"] - P["fit_clearance_vertical_mm"]
P["channel_to_bridge_web_mm"] = P["rail_y_mm"] - (P["rail_head_width_mm"] / 2 + P["fit_clearance_mm"]) - (P["bridge_flange_width_mm"] / 2 + P["bridge_fit_clearance_mm"])
P["rail_hole_nominal_diametral_clearance_mm"] = P["rail_index_hole_d_mm"] - P["lock_pin_d_mm"]
P["rail_hole_max_diametral_clearance_from_proposed_limits_mm"] = (P["rail_index_hole_d_mm"] + 0.05) - (P["lock_pin_d_mm"] - 0.02)
P["ring_recess_radial_clearance_mm"] = (P["pin_keeper_counterbore_d_mm"] - P["pin_keeper_clip_od_mm"]) / 2
P["ring_boss_radial_wall_mm"] = (18.0 - P["pin_keeper_counterbore_d_mm"]) / 2
P["ring_axial_groove_clearance_mm"] = P["pin_groove_width_mm"] - P["pin_keeper_clip_thickness_mm"]
P["outsole_nominal_residual_skin_mm"] = P["outsole_pad_thickness_mm"] - P["outsole_relief_depth_mm"]
P["pin_support_span_assumed_mm"] = 2 * P["rail_y_mm"]  # centers at ±rail_y
P["pin_groove_root_section_area_mm2"] = math.pi * P["pin_groove_root_d_mm"]**2 / 4
P["pin_nominal_section_area_mm2"] = math.pi * P["lock_pin_d_mm"]**2 / 4
P["rail_bearing_projected_area_per_rail_mm2"] = P["lock_pin_d_mm"] * P["rail_head_width_mm"]
P["rail_top_bottom_breakout_area_per_rail_mm2"] = 2 * P["rail_vertical_ligament_mm"] * P["rail_head_width_mm"]
P["bridge_net_section_area_one_strap_mm2"] = (P["bridge_flange_width_mm"] - 2 * P["bolt_hole_d_mm"]) * P["bridge_flange_thickness_mm"]

# Explicit analytical screening force scenarios. Multipliers are sensitivity cases, NOT
# measured dynamic loads or selected regulatory proof factors.
body_mass_kg = 66.0
gravity_m_s2 = 9.81
F = body_mass_kg * gravity_m_s2
multipliers = [0.5, 1.0, 1.5, 2.0, 3.0]
scenarios = []
for mult in multipliers:
    force = F * mult
    # Hypothetical pin loading: all load on a central point between two rails 2*rail_y apart.
    L = P["pin_support_span_assumed_mm"]
    droot = P["pin_groove_root_d_mm"]
    area_root = math.pi * droot**2 / 4
    I_root = math.pi * droot**4 / 64
    section_mod_root = math.pi * droot**3 / 32
    M = force * L / 4
    sigma_bend = M / section_mod_root
    # Idealized double-shear stress if the pin takes the full scenario force across two shear planes.
    tau_double = force / (2 * area_root)
    # If the same total load is split equally between the two rails, projected pin/rail bearing and
    # top/bottom breakout demands follow. This assumes a load orientation that loads the top/bottom
    # ligament; it is not a prediction of actual contact distribution.
    rail_bearing = (force / 2) / P["rail_bearing_projected_area_per_rail_mm2"]
    rail_breakout = (force / 2) / P["rail_top_bottom_breakout_area_per_rail_mm2"]
    # Axial bridge sensitivity: one bridge strap of current flange width x 3 mm thickness carries force across a section containing the two 4.8 mm holes at each pair station.
    bridge_stress_single = force / P["bridge_net_section_area_one_strap_mm2"]
    bridge_stress_equal_pair = force / (2 * P["bridge_net_section_area_one_strap_mm2"])
    scenarios.append({
        "load_multiplier_sensitivity_only": mult,
        "total_force_N": force,
        "pin_groove_double_shear_MPa_if_full_load": tau_double,
        "pin_groove_bending_MPa_if_full_load_centered_over_rail_center_span": sigma_bend,
        "rail_bearing_MPa_per_rail_if_equal_load_split": rail_bearing,
        "rail_top_bottom_ligament_average_shear_MPa_per_rail_if_equal_split": rail_breakout,
        "single_bridge_strap_net_tension_MPa_if_full_axial_load": bridge_stress_single,
        "two_bridge_straps_equal_share_net_tension_MPa_each": bridge_stress_equal_pair,
        "pin_bending_deflection_mm_at_E_190GPa_candidate": force * L**3 / (48 * 190000.0 * I_root),
    })

# Geometry/arithmetic checks have determinate outcomes. Strength screens do not: no allowables/materials.
checks = []
def add(name, ok, detail):
    checks.append({"check": name, "result": "PASS" if ok else "FAIL", "detail": detail})
add("body force", abs(F - 647.46) < 1e-9, f"66.0 kg × 9.81 m/s² = {F:.2f} N")
add("rail top/bottom ligament", P["rail_vertical_ligament_mm"] >= 2.7, f"computed {P['rail_vertical_ligament_mm']:.3f} mm; no material allowable available")
add("rail to bridge web", P["channel_to_bridge_web_mm"] >= 2.0, f"computed {P['channel_to_bridge_web_mm']:.3f} mm; deck web strength unverified")
add("deck roof above captured rail", P["deck_roof_above_rail_channel_mm"] >= 4.0, f"computed {P['deck_roof_above_rail_channel_mm']:.3f} mm; polymer/process strength unverified")
add("rail pin diametral clearance", 0.25 <= P["rail_hole_nominal_diametral_clearance_mm"] <= 0.40, f"nominal {P['rail_hole_nominal_diametral_clearance_mm']:.3f} mm; proposed dimensional limits imply {P['rail_hole_nominal_diametral_clearance_mm']:.3f}–{P['rail_hole_max_diametral_clearance_from_proposed_limits_mm']:.3f} mm")
add("carriage bore not smaller than pin", P["lock_hole_d_mm"] >= P["lock_pin_d_mm"], f"carriage passage Ø{P['lock_hole_d_mm']:.2f} vs pin Ø{P['lock_pin_d_mm']:.2f} mm; passage clearance is not specified by tolerance")
add("ring recess radial clearance", P["ring_recess_radial_clearance_mm"] >= 0.25, f"computed {P['ring_recess_radial_clearance_mm']:.3f} mm per side; actual catalog ring tolerances not modeled")
add("ring boss radial wall", P["ring_boss_radial_wall_mm"] >= 1.3, f"computed {P['ring_boss_radial_wall_mm']:.3f} mm; boss pull-out/impact capacity unverified")
add("ring groove axial clearance", P["ring_axial_groove_clearance_mm"] >= 0.1 - 1e-9, f"computed {P['ring_axial_groove_clearance_mm']:.3f} mm total; at assertion boundary, tolerance stack not included")
add("outsole residual skin", P["outsole_nominal_residual_skin_mm"] >= 1.79, f"computed {P['outsole_nominal_residual_skin_mm']:.3f} mm nominal; this does not validate traction or wear")
add("deck outer wall", 32.0*P["width_scale"]-(P["rail_y_mm"]+P["rail_head_width_mm"]/2+P["fit_clearance_mm"]) >= 5.2, f"computed {32.0*P['width_scale']-(P['rail_y_mm']+P['rail_head_width_mm']/2+P['fit_clearance_mm']):.3f} mm nominal at width_scale={P['width_scale']:.2f}; CAD wall limit is geometric only")
add("bridge screw edge distance", P["bridge_flange_width_mm"]/2-P["bridge_screw_y_mm"]-P["bolt_hole_d_mm"]/2 >= 4.0, f"computed {P['bridge_flange_width_mm']/2-P['bridge_screw_y_mm']-P['bolt_hole_d_mm']/2:.3f} mm nominal; bolt grade/torque not specified")
add("source Rev P dimensions current", "2.15 mm nominal deck web" in text and "3.85 mm nominal deck web" not in text and "Rev O C2" not in text.splitlines()[0], "Rev P title and current calculated web documented; historical comments are not accepted")

# Machine-check file/hash presence and solver availability for actual FEA declaration.
solver_candidates = {name: shutil.which(name) for name in ["ccx", "CalculiX", "gmsh", "FreeCADCmd", "freecadcmd", "FreeCAD"]}
solver_available = any(solver_candidates.values())

# Persist data.
with (OUT / "STRUCTURAL_ANALYTICAL_SCREENING_GEOMETRY_CHECKS.csv").open("w", newline="", encoding="utf-8") as f:
    w = csv.DictWriter(f, fieldnames=["check", "result", "detail"]); w.writeheader(); w.writerows(checks)
with (OUT / "STRUCTURAL_ANALYTICAL_SCREENING_SCENARIOS.csv").open("w", newline="", encoding="utf-8") as f:
    w = csv.DictWriter(f, fieldnames=list(scenarios[0])); w.writeheader(); w.writerows(scenarios)
res = {
    "title": "Apex Stride Pro Rev P analytical load screen",
    "method": "closed-form beam, shear, projected-bearing, breakout, and net-section calculations from parsed CAD dimensions",
    "body_mass_kg": body_mass_kg,
    "gravity_m_s2": gravity_m_s2,
    "body_weight_N": F,
    "geometry_arithmetic_check_count": len(checks),
    "geometry_arithmetic_pass": sum(c["result"] == "PASS" for c in checks),
    "geometry_arithmetic_fail": sum(c["result"] == "FAIL" for c in checks),
    "scenarios": scenarios,
    "geometry_parameters": P,
    "solver_commands_found": solver_candidates,
    "material_specific_fea_run": False,
    "physical_test_run": False,
    "limitations": [
        "The shoe design does not specify production material grades, allowables, fastener grades, contact/friction data, tolerances, or a validated structural load-sharing model.",
        "1.5x, 2x, and 3x forces are sensitivity multipliers only, not measured gait forces or approved proof loads.",
        "Pin bending scenario assumes the entire selected load acts vertically at midspan between rail centers; the intended nominal load path is through captured rails/channels, so this is a conditional risk bound, not a prediction of actual pin loading.",
        "Pin shear/bearing, rail breakout, and bridge net-section values are demands under explicitly hypothetical load paths; no material allowables are available for pass/fail strength judgments.",
        "190 GPa modulus in the deflection column is a published wrought 17-4PH H900 candidate value, not a confirmed purchased/processed pin property; this column is sensitivity only.",
        "These calculations are not finite-element analysis and do not establish safe mass, strength, fatigue life, running capability, or wear authorization."
    ]
}
(OUT / "STRUCTURAL_ANALYTICAL_SCREENING.json").write_text(json.dumps(res, indent=2)+"\n", encoding="utf-8")

lines = [
    "# Rev P — 66 kg analytical structural screen",
    "",
    "**Type:** closed-form analytical screening from dimensions parsed from the current OpenSCAD source. **Not FEA. Not a physical test. Not safety approval.**",
    "",
    f"Body weight: **66 kg × 9.81 m/s² = {F:.2f} N**. An ideal equal bilateral static split is {F/2:.2f} N per foot; the single-support calculation uses {F:.2f} N. Dynamic multipliers below are sensitivities, not measured gait loads or approved proof factors.",
    "",
    "## Conditional stress demands",
    "",
    "| Multiplier | Force (N) | Pin double shear at Ø7.6 groove (MPa), if full load | Pin bend at groove root (MPa), if full vertical force at midpoint of span between rail centers | Rail hole bearing (MPa/rail), equal split | Rail top/bottom breakout avg shear (MPa/rail), equal split | One bridge strap net stress (MPa), full axial force |",
    "|---:|---:|---:|---:|---:|---:|---:|",
]
for s in scenarios:
    lines.append(f"| {s['load_multiplier_sensitivity_only']:g}× | {s['total_force_N']:.2f} | {s['pin_groove_double_shear_MPa_if_full_load']:.2f} | {s['pin_groove_bending_MPa_if_full_load_centered_over_rail_center_span']:.2f} | {s['rail_bearing_MPa_per_rail_if_equal_load_split']:.2f} | {s['rail_top_bottom_ligament_average_shear_MPa_per_rail_if_equal_split']:.2f} | {s['single_bridge_strap_net_tension_MPa_if_full_axial_load']:.2f} |")
lines += [
    "",
    f"These are **not simultaneous stresses or actual predictions**. Each column uses a separate stylized load-path assumption to reveal which geometry/material data are missing. The pin is intended as a longitudinal adjustment lock, while vertical force should be carried by the captured T-rails/channel/deck; therefore the full-load pin-bending case is a conditional risk screen. At this revision the rail-center span is {P['pin_support_span_assumed_mm']:.1f} mm, so the calculated demands are {scenarios[1]['pin_groove_bending_MPa_if_full_load_centered_over_rail_center_span']:.1f} MPa at 1× body weight and {scenarios[-1]['pin_groove_bending_MPa_if_full_load_centered_over_rail_center_span']:.1f} MPa at the illustrative 3× scenario before groove stress concentration. This is not a predicted pin stress unless the assumed load path occurs; the assembly needs load-sharing analysis and physical testing.",
    "",
    "## Geometry arithmetic checks",
    "",
    "| Check | Result | Detail |",
    "|---|---|---|",
]
for c in checks:
    lines.append(f"| {c['check']} | **{c['result']}** | {c['detail']} |")
lines += [
    "",
    f"Result: **{sum(c['result']=='PASS' for c in checks)}/{len(checks)} geometry/arithmetic checks PASS; {sum(c['result']=='FAIL' for c in checks)} FAIL**. These checks verify nominal geometry arithmetic only.",
    "",
    "## Solver/test availability",
    "",
    "No suitable FEA solver or FreeCAD command-line executable is installed in this environment: " + ", ".join(f"`{k}`={'found' if v else 'not found'}" for k,v in solver_candidates.items()) + ". No material-specific FEA was run. No manufactured specimen, fixtures, load cell, fatigue rig, traction rig, or fit test rig is available in this software session, so no physical test was run.",
    "",
    "## Required to convert this screen into capacity validation",
    "",
    "1. Freeze actual rail, pin, bridge, deck, fastener, outsole and upper materials/processes and supplier specifications.",
    "2. Produce a tolerance-controlled 3D solid/FE model with real fasteners and contacts, documented constraints/load cases, mesh convergence, and stress/strain acceptance criteria.",
    "3. Test manufactured assemblies with guarded proof/eccentric loads, pin/ring retention, cyclic adjustment/fatigue, outsole retention/traction/wear, and fit/upper retention before human trials.",
    "",
    "The 17-4PH H900 candidate datasheet lists 1170 MPa typical/reference yield for wrought ASTM A564 H900, but the part is custom, grooved, tolerance-affected and not yet sourced; no design allowable or fatigue margin is established. The PA2200 SLS candidate has EOS reported 42 MPa Z tensile strength and 4% Z strain-at-break; print/process orientation and geometry-specific allowables are unresolved. These candidate properties do not validate the assembly.",
    "",
    "This report does not claim the shoe supports the body mass or is safe to wear."
]
REPORT.write_text("\n".join(lines)+"\n", encoding="utf-8")
print(json.dumps({"body_weight_N": F, "geometry_checks": len(checks), "pass": sum(c['result']=='PASS' for c in checks), "fail": sum(c['result']=='FAIL' for c in checks), "solver_commands_found": solver_candidates, "structural_scenarios": len(scenarios), "report": str(REPORT)}, indent=2))
if any(c['result']=='FAIL' for c in checks):
    raise SystemExit(1)
