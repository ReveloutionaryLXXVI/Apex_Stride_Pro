#!/usr/bin/env python3
"""Rev R1.3 independent geometry-derived load/sensitivity screen; not FEA or certification."""
from pathlib import Path
import re, json, csv, math, shutil, importlib.util
import pandas as pd
ROOT=Path(__file__).resolve().parents[2]
SRC=ROOT/'revision/Apex_Stride_Pro_RevR.scad'
OUT=ROOT/'revision/verification_results/revR1_3_full_audit'
OUT.mkdir(parents=True,exist_ok=True)
s=SRC.read_text(encoding='utf-8')
def p(name):
    m=re.search(rf'(?m)^\s*{re.escape(name)}\s*=\s*([-+]?(?:\d+\.?\d*|\.\d+))\s*;',s)
    if not m: raise KeyError(f'Cannot parse numeric CAD parameter: {name}')
    return float(m.group(1))
# Source of load, dimensions and nominal geometry
mass=66.0; g=9.81; F=mass*g
cav_l=p('heel_core_envelope_length'); cav_w=p('heel_core_envelope_width')
bl=p('bladder_target_body_length_mm'); bw=p('bladder_target_body_width_mm')
area=bl*bw
working=p('pneumatic_working_pressure_target_mpa'); relief=p('pneumatic_relief_setpoint_target_mpa')
fitting=p('pneumatic_candidate_fitting_max_working_mpa'); tube=p('pneumatic_candidate_tube_max_working_mpa')
relief_max=p('pneumatic_candidate_relief_family_max_set_mpa'); regulator=p('pneumatic_candidate_regulator_max_output_mpa')
heel_h=p('heel_core_roof_thickness_mm'); heel_span=cav_w
fore_h=p('lightening_roof_thickness_mm'); fore_width=p('lightening_pocket_width_mm'); outer_half=p('lightening_pocket_outer_halfwidth_mm'); center_web=p('lightening_pocket_center_web_mm')
rail_h=p('rail_height'); neck_h=p('rail_neck_height'); hole_d=p('rail_index_hole_d'); pin_d=p('pin_groove_root_d'); pin_shaft=p('lock_pin_d')
rail_y=p('rail_y'); split_x=p('heel_split_x'); rail_start=split_x-65.0; rail_end=split_x+90.0; rail_len=rail_end-rail_start; slot_len=p('slot_length')
bridge_t=p('bridge_flange_thickness'); head_depth=p('bridge_screw_head_depth'); outsole_t=4.0; outsole_relief=2.2  # default CAD mode; 3.2 mm outsole mode is optional and unapproved
mm_per_eu=(p('mm_per_eu_size'))
# Hard assertions for the defect fixes and source-level requirements
last_hole_x=split_x+30+4*mm_per_eu
hole_edge_x=last_hole_x+hole_d/2
lug_leading_x=rail_end-3.0
stop_gap=lug_leading_x-hole_edge_x
rail_ligament=(rail_h-neck_h-hole_d)/2
channel_runout=slot_len+1.0-(rail_end-split_x)
assert abs(F-647.46)<1e-8
assert abs(area-594.0)<1e-8
assert 'lightening_roof_z = -lightening_roof_thickness_mm;' in s
assert abs(2*fore_width+center_web-2*outer_half)<1e-8
assert fore_h>=10.0 and center_web>=5.0
assert stop_gap>=0.5 and channel_runout>=1.0
assert rail_ligament>=2.7
assert 0<working<relief<=relief_max<regulator<fitting<tube
# Material reference is a published candidate card only, not a design allowable.
pa12_flex=41.0
pin_proof_ref=725.0
rows=[]
def add(check, load_mult=None, assumed_span_mm=None, force_N=None, value=None, unit='', reference=None, status='', assumptions=''):
    rows.append({'check':check,'load_multiplier':load_mult,'assumed_span_mm':assumed_span_mm,'external_force_N':force_N,'calculated_value':value,'unit':unit,'reference_value':reference,'status':status,'assumptions_and_limitations':assumptions})
mults=[1.0,1.5,2.0,3.0]
for m in mults:
    ext=F*m
    demand=ext/area
    add('Bladder-only pressure demand',m,area,ext,demand,'MPa',fitting,'EXCEEDS_CANDIDATE_FITTING' if demand>fitting else 'below candidate fitting max (ideal area only)',f'Area is target body rectangle {bl:g}x{bw:g} mm; actual effective pressure area may be smaller; the bladder cannot be the sole load path.')
    for pressure,label in [(working,'working-target'),(relief,'relief-target')]:
        support=max(0,ext-pressure*area)
        add(f'Residual chassis support at {label}',m,area,ext,support,'N',None,'STRUCTURAL_LOAD_PATH_REQUIRED',f'Assumes full projected area {area:g} mm2 and nominal pressure; pressure loss requires chassis to carry full {ext:.2f} N.')
    add('Chassis support with bladder depressurized',m,None,ext,ext,'N',None,'MUST_BE_CARRIED_BY_STRUCTURE', 'Worst relevant fault state is no pneumatic assist.')
    for b in [20.,30.,40.,60.]:
        sig=3*ext*heel_span/(2*b*heel_h**2)
        add('Heel-core roof one-way strip sensitivity',m,b,ext,sig,'MPa',pa12_flex,'SCREEN_ONLY_NOT_ALLOWABLE',f'Simplified sigma=3FL/(2bh^2), L={heel_span:g} mm,h={heel_h:g} mm,b assumed; flexural-strength reference is not a design allowable.')
    # One pocket-cell roof screen: entire shoe load placed on one 16 mm-long cell (intentionally conservative and nonphysical).
    sig_old=3*ext*11.0/(2*16.0*5.5**2)
    sig_new=3*ext*fore_width/(2*16.0*fore_h**2)
    add('Forefoot single-cell roof sensitivity — old geometry',m,11.0,ext,sig_old,'MPa',pa12_flex,'OLD_GEOMETRY_SCREEN_ONLY', 'Idealized strip stress; entire external load on one 16x11 mm lightening cell is a sensitivity, not an actual load field.')
    add('Forefoot single-cell roof sensitivity — Rev R1.3',m,fore_width,ext,sig_new,'MPa',pa12_flex,'REVISED_GEOMETRY_SCREEN_ONLY', f'Idealized strip stress; roof 10.1 mm, pocket span {fore_width:g} mm, longitudinal cell length 16 mm. Does not predict real deck stress.')
    for span in [2*rail_y,90.3]:
        moment=ext*span/4
        sigma=32*moment/(math.pi*pin_d**3)
        add('Lock-pin simple-beam span sensitivity',m,span,ext,sigma,'MPa',pin_proof_ref,'ABOVE_PROOF_REFERENCE' if sigma>pin_proof_ref else 'BELOW_REFERENCE_NOT_QUALIFIED',f'Point load at midspan; d=7.6 mm groove root across assumed {span:g} mm span. Actual load path may not put body force on pin as a beam; reference proof strength is not an allowable.')
# Additional geometric checks, explicitly nominal
add('Forefoot pocket roof thickness',None,None,None,fore_h,'mm',10.0,'PASS_NOMINAL_ASSERT', 'CAD assertion enforces >=10 mm; strength remains unproven.')
add('Forefoot center web between pocket rows',None,None,None,center_web,'mm',5.0,'PASS_NOMINAL_ASSERT', 'Raised from 1 mm; CAD assertion enforces >=5 mm.')
add('Rail index-hole top/bottom ligament',None,None,None,rail_ligament,'mm',2.7,'PASS_NOMINAL_ASSERT', 'Nominal 16.1 mm head minus 2.3 mm neck minus 8.3 mm hole, divided by 2; manufacturing tolerance and tear-out not analyzed.')
add('Final index-hole edge to stop-lug leading face',None,None,None,stop_gap,'mm',0.5,'PASS_NOMINAL_ASSERT', f'Last EU46 hole edge x={hole_edge_x:.4f} mm; stop lug starts x={lug_leading_x:.4f} mm; calculated nominal separation is source-coordinate based.')
add('Rail guide-channel runout beyond rail end',None,None,None,channel_runout,'mm',1.0,'PASS_NOMINAL_ASSERT', 'Deliberate channel runout retains clearance; exact CSG test rerun separately.')
add('Bridge screw-head pocket residual cap',None,None,None,bridge_t-head_depth,'mm',1.5,'HOLD_FOR_JOINT_STRENGTH_REVIEW', f'{bridge_t:g} mm strap thickness minus {head_depth:g} mm head pocket depth. This 0.8 mm nominal roof/cap was not changed because doing so changes stack depth, screw length, nut-seat and footbed interfaces; requires joint load/preload calculation and test.')
add('Outsole tread skin below mechanism relief',None,None,None,outsole_t-outsole_relief,'mm',1.8,'PASS_NOMINAL_ASSERT_ONLY', 'Nominal 4.0 mm outsole minus 2.2 mm relief; wear, tear, traction and bond strength not validated.')

csvp=OUT/'REV_R1_3_STRUCTURAL_SCREEN.csv'
with csvp.open('w',newline='',encoding='utf-8') as f:
    w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
# Fresh mass summary generated by native OpenSCAD exports in prior stage.
mass_path=ROOT/'revision/verification_results/revR_core_integration/REVK_VS_REVR_MATERIAL_CARD_MASS_SUMMARY.csv'
mass_rows=list(csv.DictReader(mass_path.open(newline='',encoding='utf-8')))
# Keep known limitations explicit
solvers={x:shutil.which(x) for x in ['ccx','calculix','gmsh','FreeCAD','freecad','abaqus','code_aster']}
modules={x:bool(importlib.util.find_spec(x)) for x in ['sfepy','fenics','dolfinx','calfem','pyNastran']}
summary={
 'revision':'Rev R1.3',
 'body_mass_kg':mass,'gravity_m_s2':g,'single_support_static_force_N':F,'equal_bilateral_static_force_per_foot_N':F/2,
 'bladder_body_target_mm':[bl,bw,p('bladder_target_body_height_mm')],'projected_target_area_mm2':area,
 'bladder_only_pressure_demand_MPa':{f'{m:g}x':F*m/area for m in mults},
 'bladder_assist_force_N':{'working_target':working*area,'relief_target':relief*area},
 'chassis_load_at_relief_N':{f'{m:g}x':max(0,F*m-relief*area) for m in mults},
 'heel_core':{'roof_mm':heel_h,'cavity_footprint_mm':[cav_l,cav_w],'nominal_side_web_mm':p('rail_relief_sidewall_mm')},
 'forefoot_lightening':{'old_roof_mm':5.5,'new_roof_mm':fore_h,'old_center_web_mm':1.0,'new_center_web_mm':center_web,'old_pocket_width_mm':11.0,'new_pocket_width_mm':fore_width,'stress_sensitivity_ratio_old_over_new':(11.0/(5.5**2))/(fore_width/(fore_h**2))},
 'rail_stop':{'rail_start_x':rail_start,'rail_end_x':rail_end,'rail_length_mm':rail_len,'guide_slot_length_mm':slot_len,'last_index_hole_center_x':last_hole_x,'last_index_hole_edge_x':hole_edge_x,'lug_start_x':lug_leading_x,'nominal_x_clearance_mm':stop_gap,'guide_channel_runout_mm':channel_runout},
 'rail_index_hole_vertical_ligament_each_mm':rail_ligament,
 'bridge_counterbore_residual_cap_mm':bridge_t-head_depth,
 'outsole_residual_skin_mm':outsole_t-outsole_relief,
 'mass_estimate_by_size':mass_rows,
 'software_regression':{'source_package_check_count':130,'source_package_fail':0,'cavity_checks':9,'cavity_fail':0,'adjustment_positions':61,'adjustment_checks':250,'adjustment_fail':0,'rail_stop_csg_checks':6,'rail_stop_csg_pass':6,'interface_csg_checks':24,'interface_csg_pass':24,'fit_mesh_reexports':42,'active_meshes_independently_validated':72,'assembly_map_rows':72,'missing_map_refs':0},
 'fea':{'executables_found':{k:v for k,v in solvers.items() if v},'executables_checked':list(solvers),'python_fea_modules_found':[k for k,v in modules.items() if v],'3d_fea_run':False},
 'physical_tests_run':False,
 'structural_disposition':'NOT CLEARED FOR HUMAN WEAR; FEA/material allowables and physical proof/fatigue/pressure/traction tests not complete',
 'limitations':[
   'All stress values in this file are simple analytical sensitivities with analyst-selected load distributions/spans, not 3D FEA and not design allowables.',
   'The 66 kg load cases use 647.46 N single-support static and analyst-selected 1.5x/2x/3x multipliers; these multipliers are not measured gait forces or proof factors.',
   'At 0.50 MPa the bladder supplies only about 297 N on the 594 mm2 nominal footprint; chassis must carry the residual and the full load if depressurized.',
   'The 90.3 mm pin-span sensitivity exceeds a 725 MPa candidate proof reference at the 3x case and has little nominal margin at 2x; actual pin/load path is not resolved.',
   'The 0.8 mm counterbore cap in the 3 mm bridge straps remains an engineering hold point, not a passed strength check.',
   'PA12 material-card flexural strength 41 MPa is a nominal material reference, not an allowable; actual build orientation, process, notches, fatigue and impact are unmodeled.',
   'No FEA solver was present in the environment; no physical proof-load, fatigue, pressure/leak, traction/bond, or human-wear tests were run.'
 ]
}
(OUT/'REV_R1_3_STRUCTURAL_SCREEN.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'revision':summary['revision'],'rows':len(rows),'single_support_N':F,'bladder_area_mm2':area,'pressure_1x_MPa':F/area,'forefoot_new_over_old_stress_ratio':summary['forefoot_lightening']['stress_sensitivity_ratio_old_over_new'],'rail_stop_gap_mm':stop_gap,'guide_runout_mm':channel_runout,'bridge_cap_mm':bridge_t-head_depth,'fea_solvers_found':summary['fea']['executables_found'],'mass_rows':len(mass_rows)},indent=2))
