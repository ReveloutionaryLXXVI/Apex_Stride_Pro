#!/usr/bin/env python3
"""Recalculate Rev O mass after correction C1 (rail head restored to 11 mm).

Only rail_head_width changed between the prior fresh export set and C1. The selectors affected
are heel, toe, rail_left and rail_right for each of three sizes (12 exports). All other component
modules (bridges, pin, ring, footbed and outsole) are parameter-independent of rail_head_width;
their prior fresh native export volumes are retained. Rev K baseline volumes are untouched.
This targeted correction script runs much faster than re-exporting every unchanged component.
Requires OpenSCAD, trimesh and numpy.
"""
from pathlib import Path
import csv, subprocess, tempfile, hashlib, json, time
import numpy as np, trimesh
ROOT=Path(__file__).resolve().parents[2]
SRC=ROOT/'revision/Apex_Stride_Pro_RevO.scad'
OUT=ROOT/'revision/verification_results/fresh_closure_audit'
MASS=OUT/'REVK_REVO_FRESH_COMPONENT_MASS.csv'
SUMMARY=OUT/'REVK_REVO_FRESH_MASS_SUMMARY.csv'
STUDY=OUT/'REVO_OPTIONAL_OUTSOLE_STUDY_MASS.csv'
DENSITY={'heel_deck':1.01,'toe_carriage':1.01,'bridge_rear':2.7,'bridge_front':2.7,'rail_left':2.7,'rail_right':2.7,'locking_pin':7.9,'outsole_assembly':1.2,'footbed_insert':0.2,'retaining_ring':7.9}
PARTS={'heel_deck':'heel','toe_carriage':'toe','rail_left':'rail_left','rail_right':'rail_right'}
t0=time.time()
with MASS.open(newline='',encoding='utf-8') as f: rows=list(csv.DictReader(f))
# Re-export every parameter-dependent Rev O component for each supported size.
updates=[]
for size in (42,44,46):
 for comp,selector in PARTS.items():
  with tempfile.TemporaryDirectory(prefix='apex_c1_mass_') as td:
   dst=Path(td)/'part.stl'
   cmd=['openscad','--export-format','binstl','-o',str(dst),'-D',f'eu_size={size}','-D','width_scale=1.00','-D',f'part="{selector}"',str(SRC)]
   cp=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=90)
   if cp.returncode or not dst.exists() or dst.stat().st_size<500 or 'ERROR:' in cp.stdout:
    raise RuntimeError(f'Export failed EU{size}/{selector}: {cp.stdout[-1600:]}')
   m=trimesh.load_mesh(dst,force='mesh',process=True); v=np.asarray(m.vertices); vol=float(m.volume)
   if not(m.is_watertight and m.is_winding_consistent and np.isfinite(v).all() and np.isfinite(vol) and vol>0):
    raise RuntimeError(f'Mesh failed EU{size}/{selector}')
   mass=vol/1000*DENSITY[comp]
   updated={'revision':'RevO','size':f'EU{size}','component':comp,'selector':selector,'volume_mm3':f'{vol:.6f}','assumed_density_g_cm3':DENSITY[comp],'estimated_mass_g':f'{mass:.6f}','extents_mm':'x=%.3f;y=%.3f;z=%.3f'%tuple(m.extents),'mesh_result':'PASS','method':'Fresh native OpenSCAD STL export after Rev O closure correction C1; volume × assumed density; not measured'}
   for i,r in enumerate(rows):
    if r['revision']=='RevO' and r['size']==f'EU{size}' and r['component']==comp:
     rows[i].update(updated); break
   else: raise RuntimeError(f'No prior mass row to update for {comp} EU{size}')
   updates.append({'size':f'EU{size}','component':comp,'selector':selector,'volume_mm3':vol,'estimated_mass_g':mass,'result':'PASS'})
   print(f'PASS EU{size} {comp}: {vol:.4f} mm3, {mass:.6f} g',flush=True)
# Compute exact totals from the component rows. The 3.2 mm outsole study geometry did not depend on rail width.
with STUDY.open(newline='',encoding='utf-8') as f: old_study=list(csv.DictReader(f))
by_size={}
for size in ('EU42','EU44','EU46'):
  k=sum(float(r['estimated_mass_g']) for r in rows if r['revision']=='RevK' and r['size']==size)
  o=sum(float(r['estimated_mass_g']) for r in rows if r['revision']=='RevO' and r['size']==size)
  old=next(r for r in old_study if r['size']==size)
  study_out=float(old['study_outsole_estimated_mass_g'])
  out_default=float(next(r['estimated_mass_g'] for r in rows if r['revision']=='RevO' and r['size']==size and r['component']=='outsole_assembly'))
  st=o-out_default+study_out
  by_size[size]={'RevK_baseline_g':k,'RevO_default_g':o,'default_delta_g':o-k,'default_delta_percent':(o/k-1)*100,'study_outsole_volume_mm3':float(old['study_outsole_volume_mm3']),'study_outsole_estimated_mass_g':study_out,'RevO_study_platform_g':st,'study_vs_default_g':st-o,'study_vs_RevK_g':st-k,'density_assumptions':'deck=1.01; rails/bridges=2.70; pin/ring=7.90; outsole=1.20; footbed=0.20 g/cm3','status':'UNVALIDATED STUDY ONLY','excludes':'unmodelled fasteners, production upper, actual foam/pneumatic/spring components, adhesive, process allowances'}
with MASS.open('w',newline='',encoding='utf-8') as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
with SUMMARY.open('w',newline='',encoding='utf-8') as f:
 w=csv.DictWriter(f,fieldnames=['size']+list(next(iter(by_size.values())).keys()));w.writeheader()
 for size,r in by_size.items(): w.writerow({'size':size,**r})
with STUDY.open('w',newline='',encoding='utf-8') as f:
 fields=['size','RevO_default_g','study_outsole_volume_mm3','study_outsole_estimated_mass_g','RevO_study_platform_g','study_vs_default_g','study_vs_RevK_g','density_assumptions','status','excludes']
 w=csv.DictWriter(f,fieldnames=fields);w.writeheader()
 for size,r in by_size.items(): w.writerow({'size':size,'RevO_default_g':f'{r["RevO_default_g"]:.6f}','study_outsole_volume_mm3':f'{r["study_outsole_volume_mm3"]:.6f}','study_outsole_estimated_mass_g':f'{r["study_outsole_estimated_mass_g"]:.6f}','RevO_study_platform_g':f'{r["RevO_study_platform_g"]:.6f}','study_vs_default_g':f'{r["study_vs_default_g"]:+.6f}','study_vs_RevK_g':f'{r["study_vs_RevK_g"]:+.6f}','density_assumptions':r['density_assumptions'],'status':r['status'],'excludes':r['excludes']})
log={'script':'recalculate_mass_closure_c1.py','revision':'Rev O C1','source_sha256':hashlib.sha256(SRC.read_bytes()).hexdigest(),'exports':len(updates),'elapsed_s':round(time.time()-t0,2),'updated_components':updates,'summary':by_size,'method':'Fresh native export for 12 affected heel/toe/rail components; retained prior fresh native volumes only for geometry-independent components and outsole study; Rev K baseline unchanged.'}
(OUT/'REV_O_C1_MASS_RECALCULATION.json').write_text(json.dumps(log,indent=2)+'\n')
print(json.dumps({'exports':len(updates),'elapsed_s':log['elapsed_s'],'summary':by_size},indent=2))
