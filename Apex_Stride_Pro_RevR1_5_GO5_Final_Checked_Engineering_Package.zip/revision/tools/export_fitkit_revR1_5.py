#!/usr/bin/env python3
"""Regenerate every standard R1.5 fit-kit STL from the synchronized native CAD.
Non-wearable dimensional fit kit only. No dimensional scaling is performed.
"""
from pathlib import Path
import csv, subprocess, tempfile, sys, time
import numpy as np
import trimesh
ROOT=Path(__file__).resolve().parents[2]
KIT=ROOT/'PRINT_READY_BENCH_FIT_KIT_REV_R'
SRC=ROOT/'revision/Apex_Stride_Pro_RevR.scad'
INDEX=KIT/'PRINT_PARTS_INDEX_REV_R.csv'
rows=list(csv.DictReader(INDEX.open(newline='',encoding='utf-8')))
started=time.time()
for i,r in enumerate(rows,1):
    size=int(r['size'].replace('EU',''))
    part=r['cad_selector']
    out=KIT/'stl'/r['file']
    out.parent.mkdir(parents=True,exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='apex_r15_fitkit_') as td:
        native=Path(td)/'native.stl'
        cmd=['openscad','--export-format','binstl','-o',str(native),'-D',f'eu_size={size}','-D','width_scale=1.00','-D',f'part="{part}"']
        if part in ('rail_left','rail_right'):
            cmd += ['-D','rail_weight_relief=false']
        cmd += [str(SRC)]
        cp=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=120)
        if cp.returncode or not native.exists() or native.stat().st_size<500 or 'ERROR:' in cp.stdout:
            raise RuntimeError(f'OpenSCAD export failed {r["size"]}/{part}:\n{cp.stdout[-2000:]}')
        mesh=trimesh.load_mesh(native,force='mesh',process=True)
        if not mesh.is_watertight or not mesh.is_winding_consistent or not np.isfinite(mesh.vertices).all() or not np.isfinite(mesh.volume) or mesh.volume<=0:
            raise RuntimeError(f'Native mesh failed topology: {r["size"]}/{part}: watertight={mesh.is_watertight} winding={mesh.is_winding_consistent} vol={mesh.volume}')
        native_volume=float(mesh.volume)
        orient=r['orientation']
        if orient=='rail_side': mesh.apply_transform(trimesh.transformations.rotation_matrix(np.deg2rad(90),[1,0,0]))
        elif orient=='pin_vertical_head_down': mesh.apply_transform(trimesh.transformations.rotation_matrix(np.deg2rad(-90),[1,0,0]))
        elif orient in ('z_bottom','ring_flat'): pass
        else: raise ValueError(f'Unknown orientation {orient!r} for {r["file"]}')
        bounds=mesh.bounds
        mesh.apply_translation([-float((bounds[0,0]+bounds[1,0])/2),-float((bounds[0,1]+bounds[1,1])/2),-float(bounds[0,2])])
        mesh.export(out,file_type='stl')
        verify=trimesh.load_mesh(out,force='mesh',process=True)
        b=verify.bounds; e=verify.extents; vol=float(verify.volume); v=np.asarray(verify.vertices)
        checks={
          'watertight':bool(verify.is_watertight), 'winding_consistent':bool(verify.is_winding_consistent),
          'positive_volume':bool(np.isfinite(vol) and vol>0), 'finite_vertices':bool(np.isfinite(v).all()),
          'xy_centered':bool(max(abs((b[0,0]+b[1,0])/2),abs((b[0,1]+b[1,1])/2))<1e-3),
          'z_min_zero':bool(abs(float(b[0,2]))<1e-3), 'bed_xy_fits_220':bool(max(float(e[0]),float(e[1]))<=220.001),
          'volume_matches':bool(abs(vol-native_volume)<=max(.02,abs(native_volume)*1e-6)),
          'no_degenerate_faces':bool(int((verify.area_faces<=1e-10).sum())==0)
        }
        r['x_mm']=f'{e[0]:.3f}'; r['y_mm']=f'{e[1]:.3f}'; r['z_mm']=f'{e[2]:.3f}'
        r['native_volume_mm3']=f'{native_volume:.4f}'; r['normalized_volume_mm3']=f'{vol:.4f}'
        r['watertight']=str(checks['watertight']); r['winding_consistent']=str(checks['winding_consistent'])
        r['positive_volume']=str(checks['positive_volume']); r['finite_vertices']=str(checks['finite_vertices'])
        r['xy_centered']=str(checks['xy_centered']); r['z_min_zero']=str(checks['z_min_zero'])
        r['bed_220x220']=str(checks['bed_xy_fits_220']); r['serialization_volume_match']=str(checks['volume_matches'])
        r['result']='PASS' if all(checks.values()) else 'FAIL'
        if not all(checks.values()): raise RuntimeError(f'Export QA failed {r["file"]}: {checks}, extents={e}')
    print(f'[{i}/{len(rows)}] PASS {r["file"]} {r["x_mm"]}x{r["y_mm"]}x{r["z_mm"]} mm',flush=True)
with INDEX.open('w',newline='',encoding='utf-8') as f:
    w=csv.DictWriter(f,fieldnames=list(rows[0]),lineterminator='\n'); w.writeheader(); w.writerows(rows)
summary={
 'revision':'Rev R1.5 GO3+GO4', 'source':str(SRC.relative_to(ROOT)), 'fit_kit_export_count':len(rows),
 'passed':sum(r['result']=='PASS' for r in rows),'failed':sum(r['result']!='PASS' for r in rows),
 'seconds':round(time.time()-started,2), 'source_sha256':__import__('hashlib').sha256(SRC.read_bytes()).hexdigest(),
 'changed_design':'standard outsole relief 2.2 -> 1.5 mm; standard 4.0 mm nominal tread skin 1.8 -> 2.5 mm; optional 3.2 mm study remains 1.8 mm skin',
 'notes':['All fit-kit STLs are non-wearable dimensional samples.','Each mesh is freshly exported, oriented and translated only; no scaling.','CAD exports normalized to Z-min=0 and XY-centered; 220x220mm envelope checked.']}
qa=ROOT/'revision/verification_results/revR1_5_go3_go4'; qa.mkdir(parents=True,exist_ok=True)
(qa/'REV_R1_5_FITKIT_EXPORT_QA.json').write_text(__import__('json').dumps(summary,indent=2)+'\n')
print(__import__('json').dumps(summary,indent=2),flush=True)
if summary['failed']: raise SystemExit(1)
