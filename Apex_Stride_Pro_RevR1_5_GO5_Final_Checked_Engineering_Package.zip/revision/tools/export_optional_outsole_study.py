#!/usr/bin/env python3
"""Regenerate the Rev O optional 3.2 mm outsole mass-study meshes.

These are bench-fit geometry study parts only. This script does not produce G-code
or certify material, traction, outsole bonding, flex fatigue, or human-use safety.
Requires OpenSCAD and trimesh. Geometry is rigidly translated to a centered build
plate coordinate system; no scaling or dimensional change is applied.
"""
from pathlib import Path
import subprocess, tempfile, csv
import numpy as np
import trimesh

ROOT = Path(__file__).resolve().parents[2]
SRC = ROOT / 'PRINT_READY_BENCH_FIT_KIT/source/Apex_Stride_Pro_RevO_PrintPrep.scad'
OUT = ROOT / 'PRINT_READY_BENCH_FIT_KIT/optional_3p2mm_outsole_study'
PARTS = ('outsole_heel_pad', 'outsole_toe_pad', 'outsole_flex_connector')
rows=[]
for size in (42, 44, 46):
    for part in PARTS:
        dst = OUT / f'EU{size}' / f'{part}_3p2mm_study_only.stl'
        dst.parent.mkdir(parents=True, exist_ok=True)
        with tempfile.TemporaryDirectory(prefix='apex_outsole_study_') as td:
            raw=Path(td)/'raw.stl'
            cmd=['openscad','--export-format','binstl','-o',str(raw),
                 '-D',f'eu_size={size}','-D','width_scale=1.00',
                 '-D',f'part="{part}"','-D','outsole_weight_study=true',str(SRC)]
            cp=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=60)
            if cp.returncode or not raw.exists() or raw.stat().st_size < 500:
                raise RuntimeError(f'OpenSCAD export failed: EU{size} {part}\n{cp.stdout[-1500:]}')
            mesh=trimesh.load_mesh(raw,force='mesh',process=True)
            if not (mesh.is_watertight and mesh.is_winding_consistent and np.isfinite(mesh.vertices).all() and np.isfinite(mesh.volume) and mesh.volume>0):
                raise RuntimeError(f'Raw geometry check failed: EU{size} {part}')
            # Center XY and put minimum Z on the plate; translate only, never scale.
            b=mesh.bounds
            mesh.apply_translation((-(b[0,0]+b[1,0])/2, -(b[0,1]+b[1,1])/2, -b[0,2]))
            b2=mesh.bounds; ext=mesh.extents
            if abs((b2[0,0]+b2[1,0])/2)>1e-3 or abs((b2[0,1]+b2[1,1])/2)>1e-3 or abs(b2[0,2])>1e-3:
                raise RuntimeError(f'Placement normalization failed: EU{size} {part} bounds={b2}')
            if max(float(ext[0]),float(ext[1])) > 220.001:
                raise RuntimeError(f'220x220 XY envelope exceeded: EU{size} {part} extents={ext}')
            mesh.export(dst,file_type='stl')
            check=trimesh.load_mesh(dst,force='mesh',process=True)
            if not (check.is_watertight and check.is_winding_consistent and check.volume>0 and np.isfinite(check.vertices).all()):
                raise RuntimeError(f'Serialized STL check failed: {dst}')
            rows.append({
              'size':f'EU{size}','file':str(dst.relative_to(ROOT)),'component':part,
              'selector':part,'qty_per_shoe':1,'study_thickness_mm':3.2,'study_relief_mm':1.4,
              'nominal_residual_skin_mm':1.8,'native_volume_mm3':f'{mesh.volume:.6f}',
              'x_mm':f'{ext[0]:.3f}','y_mm':f'{ext[1]:.3f}','z_mm':f'{ext[2]:.3f}',
              'watertight':check.is_watertight,'winding_consistent':check.is_winding_consistent,
              'xy_centered':True,'z_min_zero':abs(float(check.bounds[0,2]))<1e-3,
              'fits_220mm_xy':max(float(ext[0]),float(ext[1]))<=220.001,
              'result':'PASS','use_status':'UNVALIDATED MASS STUDY ONLY; NOT FOR WEAR'
            })
            print('PASS',size,part,tuple(round(float(x),3) for x in ext),f'vol={mesh.volume:.1f}mm3',flush=True)
index=OUT/'OPTIONAL_OUTSOLE_STUDY_INDEX.csv'
with index.open('w',newline='',encoding='utf-8') as f:
    w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
print('WROTE',index,'rows=',len(rows))
