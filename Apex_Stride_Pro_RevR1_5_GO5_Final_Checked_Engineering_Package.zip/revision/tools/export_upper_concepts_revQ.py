#!/usr/bin/env python3
"""Export Rev Q upper visual concept components; these are not footwear patterns or wearable parts."""
from pathlib import Path
import subprocess, tempfile, csv
import numpy as np
import trimesh
ROOT=Path(__file__).resolve().parents[2]
SRC=ROOT/'PRINT_READY_BENCH_FIT_KIT_REV_Q/source/Apex_Stride_Pro_RevQ_PrintPrep.scad'
OUT=ROOT/'PRINT_READY_BENCH_FIT_KIT_REV_Q/upper_concept_not_wearable'
selectors=[
 ('toe_vamp_shell','toe_vamp_shell_concept_only.stl'),
 ('upper_wall_shell','upper_wall_shell_concept_only.stl'),
 ('heel_counter_shell','heel_counter_shell_concept_only.stl'),
 ('upper_strap_anchor_doublers','upper_strap_anchor_doublers_concept_only.stl'),
 ('upper_tongue','upper_tongue_concept_only.stl'),
 ('upper_lateral_overlays','upper_lateral_overlays_concept_only.stl'),
 ('upper_velcro_straps','upper_velcro_straps_concept_only.stl'),
]
rows=[]
for size in (42,44,46):
 for selector,filename in selectors:
  out=OUT/f'EU{size}'/filename; out.parent.mkdir(parents=True,exist_ok=True)
  with tempfile.TemporaryDirectory(prefix='apex_revp_upper_') as td:
   native=Path(td)/'native.stl'
   cmd=['openscad','--export-format','binstl','-o',str(native),'-D',f'eu_size={size}','-D','width_scale=1.00','-D',f'part="{selector}"',str(SRC)]
   proc=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=45)
   if proc.returncode or not native.exists() or native.stat().st_size<300 or 'ERROR:' in proc.stdout:
    rows.append({'size':f'EU{size}','selector':selector,'file':str(out.relative_to(ROOT)),'export_result':'FAIL','reason':proc.stdout[-500:]})
    continue
   mesh=trimesh.load_mesh(native,force='mesh',process=True)
   v=mesh.vertices
   if not len(v) or not np.isfinite(v).all():
    rows.append({'size':f'EU{size}','selector':selector,'file':str(out.relative_to(ROOT)),'export_result':'FAIL','reason':'empty or non-finite mesh'})
    continue
   native_volume=float(mesh.volume) if mesh.is_watertight else float('nan')
   # Keep source geometry and orientation intact for assembly/reference; do not scale/translate.
   mesh.export(out,file_type='stl')
   check=trimesh.load_mesh(out,force='mesh',process=True)
   e=check.extents; bounds=check.bounds
   rows.append({'size':f'EU{size}','selector':selector,'file':str(out.relative_to(ROOT)),'export_result':'PASS','bytes':out.stat().st_size,'watertight':bool(check.is_watertight),'winding_consistent':bool(check.is_winding_consistent),'positive_volume':bool(check.is_watertight and np.isfinite(check.volume) and check.volume>0),'finite_vertices':bool(np.isfinite(check.vertices).all()),'bounds_mm':f'{bounds[0].round(3).tolist()}..{bounds[1].round(3).tolist()}','extents_mm':','.join(f'{x:.3f}' for x in e),'topology_class':'closed-solid' if check.is_watertight else 'open/surface concept','volume_mm3':round(float(check.volume),3) if check.is_watertight else '', 'notes':'visual concept mesh only; not a footwear pattern or wearable component'})
with (OUT/'../UPPER_CONCEPT_EXPORT_AUDIT_REV_Q.csv').open('w',newline='',encoding='utf-8') as f:
 fields=sorted(set().union(*(r.keys() for r in rows)))
 w=csv.DictWriter(f,fieldnames=fields); w.writeheader();w.writerows(rows)
fail=[r for r in rows if r.get('export_result')!='PASS']
print(f'exports={len(rows)}; export failures={len(fail)}; closed solids={sum(r.get("topology_class")=="closed-solid" for r in rows)}; open/surface concepts={sum(r.get("topology_class")=="open/surface concept" for r in rows)}')
if fail: print(fail)
raise SystemExit(bool(fail))
