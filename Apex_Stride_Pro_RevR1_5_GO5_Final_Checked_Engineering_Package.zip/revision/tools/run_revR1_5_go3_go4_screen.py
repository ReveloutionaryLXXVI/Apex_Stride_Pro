#!/usr/bin/env python3
"""Transparent Rev R1.5 GO3/GO4 analytical screening; not FEA or qualification."""
from pathlib import Path
import math, csv, json, re
ROOT=Path(__file__).resolve().parents[2]
SRC=ROOT/'revision/Apex_Stride_Pro_RevR.scad'
OUT=ROOT/'revision/verification_results/revR1_5_go3_go4'; OUT.mkdir(parents=True,exist_ok=True)
s=SRC.read_text(encoding='utf-8')
def n(name):
    m=re.search(rf'(?m)^\s*{re.escape(name)}\s*=\s*([-+]?(?:\d+\.?\d*|\.\d+))\s*;',s)
    if not m: raise KeyError(name)
    return float(m.group(1))
def row(cat,case,load,value,unit,reference='',status='SCREEN_ONLY',assumptions=''):
    rows.append({'category':cat,'case':case,'load_multiplier':load,'value':f'{value:.6f}','unit':unit,'reference_value':reference,'status':status,'assumptions':assumptions})
def ternary(name):
    m=re.search(rf'(?m)^\s*{re.escape(name)}\s*=\s*outsole_weight_study\s*\?\s*([0-9]+(?:\.[0-9]+)?)\s*:\s*([0-9]+(?:\.[0-9]+)?)\s*;',s)
    if not m: raise KeyError(f'Unable to parse source ternary for {name}')
    return float(m.group(1)),float(m.group(2))
# Extract current live CAD inputs
mass=66.0; g=9.81; F=mass*g; mults=[1.0,1.5,2.0,3.0]
bl=n('bladder_target_body_length_mm'); bw=n('bladder_target_body_width_mm'); area=bl*bw
work=n('pneumatic_working_pressure_target_mpa'); relief=n('pneumatic_relief_setpoint_target_mpa')
fitmax=n('pneumatic_candidate_fitting_max_working_mpa'); tube_max=n('pneumatic_candidate_tube_max_working_mpa')
relief_min=n('pneumatic_candidate_relief_min_set_mpa'); relief_family=n('pneumatic_candidate_relief_family_max_set_mpa'); regulator_min=n('pneumatic_candidate_regulator_min_output_mpa'); regulator_max=n('pneumatic_candidate_regulator_max_output_mpa')
bridge_w=n('bridge_flange_width'); bridge_t=n('bridge_flange_thickness'); pocket_d=n('bridge_screw_head_depth'); head_d=n('bridge_screw_head_d')
stagger=n('bridge_pair_stagger_mm'); screw_y=n('bridge_screw_y'); stack=n('bridge_stack_depth')
rail_y=n('rail_y'); pin_d=n('lock_pin_d'); groove_d=n('pin_groove_root_d'); rail_w=n('rail_head_width'); hole_d=n('rail_index_hole_d'); rail_h=n('rail_height'); neck=n('rail_neck_height')
sole_thick=n('sole_thickness'); study_pad,pad=ternary('outsole_pad_thickness'); study_relief,standard_relief=ternary('outsole_relief_depth'); fore_roof=n('lightening_roof_thickness_mm'); fore_web=n('lightening_pocket_center_web_mm'); fore_pocket_w=n('lightening_pocket_width_mm'); fore_outer_half=n('lightening_pocket_outer_halfwidth_mm')
rear_len=n('bridge_rear_anchor_screw_length_mm'); toe_len=n('bridge_toe_anchor_screw_length_mm'); lock_len=n('bridge_lock_screw_length_mm')
lock_relief=n('bridge_lock_tip_relief_depth_mm'); nut_depth=n('bridge_lock_nut_depth'); footbed_z=n('footbed_z')
sole_bottom=-sole_thick; toe_bearing=sole_bottom+bridge_t; toe_tip=toe_bearing+toe_len
heel_tip=sole_bottom+rear_len; lock_tip=sole_bottom+lock_len; lock_pocket_top=sole_bottom+stack+nut_depth
cap=bridge_t-pocket_d; cap_area=(bridge_w-head_d)*cap
center_sep=math.hypot(2*stagger,2*screw_y); edge_gap=center_sep-head_d
rail_lig=(rail_h-neck-hole_d)/2
rows=[]
for k in mults:
    P=F*k
    row('External load','one-shoe vertical load',k,P,'N',status='DESIGN_LOAD_SENSITIVITY',assumptions='66 kg × 9.81 m/s². Multipliers 1, 1.5, 2, 3 are analyst-selected sensitivities, not measured gait loads or a standard.')
    row('Pneumatic','bladder-only pressure demand',k,P/area,'MPa',f'candidate fitting family max {fitmax:.2f} MPa','ABOVE_CANDIDATE_LIMIT' if P/area>fitmax else 'BELOW_LIMIT_ONLY',f'Area={bl:g}×{bw:g}={area:.0f} mm²; actual effective area/load sharing unknown. Bladder is auxiliary, never relied on for required structure.')
    row('Pneumatic','ideal assist at working-pressure target',k,work*area,'N',status='IDEAL_STATIC_FORCE_ONLY',assumptions=f'{work:.2f} MPa × {area:.0f} mm²; no friction, area-loss, surge or deflection model.')
    row('Pneumatic','ideal assist at relief target',k,relief*area,'N',status='IDEAL_STATIC_FORCE_ONLY',assumptions=f'{relief:.2f} MPa × {area:.0f} mm²; relief capacity, response, transient overshoot and exact component configuration unverified.')
    row('Load path','chassis required with zero pressure',k,P,'N',status='MANDATORY_STRUCTURAL_CASE',assumptions='The mechanically supported structure must carry the complete case following pressure loss; no pressure credit allowed for design strength.')
    row('Load path','residual chassis force after ideal relief assist',k,max(0,P-relief*area),'N',status='SENSITIVITY_NOT_DESIGN_ALLOWANCE',assumptions='Subtracts ideal static bladder force only to understand load sharing; design must still pass zero-pressure case.')
    # Bridge residual-cap nominal and assumed concentration sensitivities
    row('Bridge section','net-cap nominal axial stress',k,P/cap_area,'MPa','6061-T6 proof reference 240 MPa; not allowable','SCREEN_ONLY',f'{cap_area:.3f} mm² net section, assumes entire vertical load passes through one cap, although actual load path is unknown.')
    row('Bridge section','net-cap stress with assumed Kt=2',k,2*P/cap_area,'MPa','6061-T6 proof reference 240 MPa; not allowable','SCREEN_ONLY', 'Kt=2 is a sensitivity parameter, not an FEA/calculated stress concentration; excludes bending, screw preload, fatigue and bearing.')
    # Pin bending sensitivities: not assumed to be primary vertical load path
    sig_supported=8*P*(2*rail_y)/(math.pi*pin_d**3)
    sig_unsupported=8*P*90.3/(math.pi*groove_d**3)
    row('Pin bending','hypothetical rail-supported center-span point load',k,sig_supported,'MPa','17-4PH H1150D proof reference 725 MPa; actual certificate unavailable','FAULT_SENSITIVITY_ONLY',f'{2*rail_y:.1f} mm support-center span, solid Ø{pin_d:g}; pin is intended as axial adjustment lock, not vertical chassis member.')
    row('Pin bending','unsupported-span/groove-root fault sensitivity',k,sig_unsupported,'MPa','17-4PH H1150D proof reference 725 MPa; actual certificate unavailable','EXCEEDS_REFERENCE' if sig_unsupported>725 else 'FAULT_SENSITIVITY_ONLY', '90.3 mm unsupported span and groove-root diameter; severe hypothetical loss of rail support, not normal load configuration.')
    root_area=math.pi*groove_d**2/4
    row('Pin shear','average double-shear at groove-root area',k,P/(2*root_area),'MPa',status='LOCK_LOAD_UNKNOWN',assumptions='Assigns total one-shoe force to pin in double shear solely as upper-bound sensitivity; not intended body-load path.')
    row('Rail/pin interface','projected bearing average per rail',k,(P/2)/(pin_d*rail_w),'MPa',status='SCREEN_ONLY',assumptions='Equal split across two rails; local contact, fit, alloy/process, impact and fatigue not represented.')
    row('Rail/pin interface','nominal rail-hole vertical ligament average tear-out stress',k,(P/2)/(2*rail_lig*rail_w),'MPa',status='SCREEN_ONLY',assumptions=f'Uses {rail_lig:.2f} mm nominal vertical ligament each side, axial width {rail_w:g} mm, equal split; notch/load direction/fatigue omitted.')
    # Simple two-edge-supported beam strip as an intentionally crude roof stiffness screening
    E= n('pa12_flexural_modulus_mpa'); L=23.0; b=20.0; h=n('heel_core_roof_thickness_mm')
    sigma_heel=3*P*L/(2*b*h*h)
    I=b*h**3/12
    defl=P*L**3/(48*E*I)
    row('Heel roof','simple strip bending stress (20 mm width)',k,sigma_heel,'MPa','PA12 SLS flexural strength candidate 41 MPa','SCREEN_ONLY',f'Simply-supported strip, 23 mm span, 20 mm width, {h:.1f} mm roof and flexural modulus {E:g} MPa. Assumes load distributed through a beam idealization; not a structural model/FEA.')
    row('Heel roof','simple strip midspan deflection',k,defl,'mm',status='SCREEN_ONLY',assumptions='Same crude strip model; omits ribs, shell/plate action, contacts, anisotropy, large deformation, void interactions and actual load footprint.')
    # Forefoot top skin analogous conservative short strip sensitivity
    fore_sigma=3*P*9/(2*16*fore_roof**2)
    row('Forefoot roof','simple strip bending stress',k,fore_sigma,'MPa','PA12 SLS flexural strength candidate 41 MPa','SCREEN_ONLY', 'Assumed 9 mm pocket span and 16 mm loaded strip width; actual forefoot footprint and load share unknown; no FEA.')
# R1.5 live geometric and pneumatic configuration guardrails
skin_default=pad-standard_relief; skin_study=study_pad-study_relief
lock_proj=lock_tip-lock_pocket_top; toe_gap=footbed_z-toe_tip
geo=[
 ('standard outsole remaining skin',skin_default,'mm','>=2.49',skin_default>=2.49,'4.0 mm outside pad minus 1.5 mm mechanism relief; geometry-only change, tread compound/adhesion/tear/fatigue unqualified.'),
 ('optional outsole-study remaining skin',skin_study,'mm','>=1.79; not approved for wear',skin_study>=1.79,'3.2 mm outside pad minus 1.4 mm relief; experimental mass study preserved unchanged.'),
 ('heel core roof',n('heel_core_roof_thickness_mm'),'mm','>=10.0',n('heel_core_roof_thickness_mm')>=10.0,'Geometry only, not strength qualification.'),
 ('forefoot pocket roof',fore_roof,'mm','>=10.0',fore_roof>=10.0,'Parsed from the live lightening_roof_thickness_mm CAD parameter; geometry only.'),
 ('forefoot center web',fore_web,'mm','>=5.0',fore_web>=5.0,'Parsed from the live lightening_pocket_center_web_mm CAD parameter; geometry only.'),
 ('bridge residual cap',cap,'mm','>=2.3',cap>=2.3,'Strap thickness minus head-counterbore depth.'),
 ('bridge layer stack',stack,'mm','9.0',abs(stack-2*bridge_t)<1e-8,'Two layers of current 4.5 mm strap thickness.'),
 ('staggered head-recess edge gap',edge_gap,'mm','>=1.0',edge_gap>=1,'Nominal center separation from ±2 mm X / ±5 mm Y and Ø7.9 mm recess; no fatigue result.'),
 ('toe screw-to-footbed gap',toe_gap,'mm','>=0.20',toe_gap>=0.2,'Nominal CAD coordinates only; confirm actual hardware under-head length, tolerances and footbed compression.'),
 ('lock-tip relief margin',lock_relief-lock_proj,'mm','>=0.10',lock_relief-lock_proj>=0.099,'Nominal 1.65 mm tip relief and M4x14 screw; exact SKU remains TBD.'),
 ('rail index hole top/bottom ligament',rail_lig,'mm','>=2.7',rail_lig>=2.7,'Geometry only; bearing/tear-out rating not established.'),
 ('candidate fitting margin vs provisional relief',fitmax-relief,'MPa','>0 before transient allowance',fitmax>relief,'Candidate fitting-family 1.0 MPa rating vs 0.50 MPa target. Pressure overshoot and relief performance not tested.'),
 ('candidate tube margin vs provisional relief',tube_max-relief,'MPa','>0 after exact manufacturer document/variant and temperature derating are confirmed',None,'Conservative 1.50 MPa placeholder is based on an older SMC Tubing.pdf; newer SMC EU PPE-Gg catalog lists T0425 at 3.3 MPa at <=20 C. Resolve document/revision/variant applicability and temperature derating with SMC before treating tube rating as verified. Even if the tube meets 1.50 MPa, the candidate fitting is nominally limited to 1.0 MPa.'),
 ('relief-family setpoint capability',relief_family-relief,'MPa','standard range 0.05–0.80 MPa must include the 0.50 MPa target',relief_min <= relief <= relief_family,'SMC AP20-D official catalog/datasheet publishes standard 0.05–0.8 MPa range and separate 0.02–0.2 MPa low range. Family capability passes only for standard-range configuration; exact order code/thread still open. https://static.smc.eu/pdf/AP20-D-A_EU.pdf'),
 ('regulator output-range capability',regulator_max-work,'MPa','ARX20-F01BG range 0.05–0.85 MPa must include working target 0.40 MPa',regulator_min <= work <= regulator_max and regulator_max >= relief,'SMC configured ARX20-F01BG page publishes 0.05–0.85 MPa range, G 1/8 thread, and BG bracket+gauge. Exact purchase/config and output behavior under actual flow still require confirmation. https://www.smc.eu/et-ee/products/arx20-regulator-for-2mpa~15019~cfg?partNumber=ARX20-F01BG'),
 ('AP20-D exact order code/thread/option',0.0,'status','complete supplier-configured SKU and port/thread match circuit',None,'Family set-pressure range is verified, but exact order code, thread, options and installed arrangement are not frozen.'),
 ('relief flow and overshoot for actual chamber volume',0.0,'status','demonstrate transient pressure stays below every component working limit',None,'Manufacturer relief-flow curves do not yet establish response for the actual bladder volume, tube, check valve and source flow. Must be guarded bench-tested with chamber-side transducer.'),
 ('bladder rating and pressure-loss safe state',0.0,'status','OEM working/burst/cycle ratings and zero-pressure mechanical safety verified',None,'No finished bladder SKU/drawing/rating or complete pressure-loss dump/failsafe qualification exists; pressure assistance receives no structural credit.')]
for case,val,unit,ref,ok,ass in geo: row('R1.5 geometry/pneumatic guardrail',case,'—',val,unit,ref,('UNVERIFIED_SELECTION' if ok is None else ('PASS' if ok else 'FAIL')),ass)
# export rows, numeric QA assertion independent of descriptive labels
csvp=OUT/'REV_R1_5_STRUCTURAL_SCREEN.csv'
with csvp.open('w',newline='',encoding='utf-8') as f:
    w=csv.DictWriter(f,fieldnames=list(rows[0]),lineterminator='\n');w.writeheader();w.writerows(rows)
summary={
 'revision':'Rev R1.5 GO 3 + GO 4', 'source_sha256':__import__('hashlib').sha256(SRC.read_bytes()).hexdigest(),
 'body_mass_kg':mass,'g_m_s2':g,'single_support_static_N':F,'bilateral_static_N_per_foot':F/2,'multipliers':mults,
 'single_support_loads_N':{str(k):F*k for k in mults}, 'bladder_area_mm2':area,
 'bladder_pressure_demand_MPa':{str(k):F*k/area for k in mults}, 'ideal_assist_at_working_target_N':work*area, 'ideal_assist_at_relief_target_N':relief*area,
 'zero_pressure_chassis_load_N':{str(k):F*k for k in mults}, 'residual_chassis_load_at_relief_N':{str(k):max(0,F*k-relief*area) for k in mults},
 'pneumatic_candidate_limits_MPa':{'fitting_max_working':fitmax,'tube_max_working_at_reference_temperature':tube_max,'relief_min_standard_set':relief_min,'relief_max_standard_set':relief_family,'regulator_min_output':regulator_min,'regulator_max_output':regulator_max},
 'bridge_geometry_mm':{'strap_width':bridge_w,'strap_thickness':bridge_t,'head_recess_diameter':head_d,'head_recess_depth':pocket_d,'cap':cap,'net_cap_area_mm2':cap_area,'stagger_x':stagger,'hole_y':screw_y,'head_edge_gap':edge_gap,'stack':stack},
 'pin_sensitivity':{'support_center_span_mm':2*rail_y,'shaft_d_mm':pin_d,'groove_root_d_mm':groove_d,'fault_span_mm':90.3,'stress_supported_at_3x_MPa':8*(F*3)*(2*rail_y)/(math.pi*pin_d**3),'stress_unsupported_at_3x_MPa':8*(F*3)*90.3/(math.pi*groove_d**3),'reference_proof_MPa':725,'status':'Not qualified; normal axial lock force and fault load path are unknown. Severe unsupported span exceeds the candidate proof-strength reference.'},
 'outsole':{'standard_external_thickness_mm':pad,'standard_relief_depth_mm':standard_relief,'standard_skin_mm':skin_default,'optional_study_external_thickness_mm':study_pad,'optional_study_relief_depth_mm':study_relief,'optional_study_skin_mm':skin_study},
 'geometry_guardrails_pass':sum(1 for x in geo if x[4] is True),'geometry_guardrails_count':len(geo),'unverified_guardrails':[x[0] for x in geo if x[4] is None],'failed_guardrails':[x[0] for x in geo if x[4] is False],
 'rows':len(rows),'limitations':['Analytical screens only: no finite-element analysis, nonlinear contact solution or structural certification was run.','Materialise PA12 values are published nominal values; exact material/process/build orientation and conditioned properties not certified.','Pressure area/load share, relief-flow capacity, pressure overshoot and pressure-loss transient remain unknown.','Pin axial load, rail load sharing, impact/fatigue, bearing distribution, fastener grade and preload remain unknown.','No physical load/fatigue/retention/traction/abrasion/adhesion tests.']}
(OUT/'REV_R1_5_STRUCTURAL_SCREEN_QA.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'revision':summary['revision'],'source_sha256':summary['source_sha256'],'rows':len(rows),'guardrails_pass':summary['geometry_guardrails_pass'],'guardrails_total':summary['geometry_guardrails_count'],'failed':summary['failed_guardrails'],'unverified':summary['unverified_guardrails'],'static_N':F,'bladder_demand_MPa':F/area,'relief_assist_N':relief*area,'standard_skin_mm':skin_default,'study_skin_mm':skin_study},indent=2))
assert not summary['failed_guardrails'], summary['failed_guardrails']
