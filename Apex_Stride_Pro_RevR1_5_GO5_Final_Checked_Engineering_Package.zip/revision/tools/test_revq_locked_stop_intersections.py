#!/usr/bin/env python3
"""Exact OpenSCAD CSG tests for toe-carriage/rail intersections at indexed sizes.

Builds a temporary harness from the authoritative source's module definitions (the
source's export-selector tail is omitted), then intersects the moving toe deck and
both fixed rails. For an expected-empty CSG, OpenSCAD normally returns exit code 1
and prints 'Current top level object is empty.'; this is treated as a pass only when
that exact message is present and no mesh is written. This is a geometry-only test,
not a strength or tolerance validation.
"""
from pathlib import Path
import csv, json, shutil, subprocess, tempfile, re, time

ROOT = Path(__file__).resolve().parents[2]
SRC = ROOT / 'revision/Apex_Stride_Pro_RevQ.scad'
OUT = ROOT / 'revision/verification_results/revQ_material_integration/exact_csg'
OUT.mkdir(parents=True, exist_ok=True)
OPENSCAD = shutil.which('openscad')
if not OPENSCAD:
    raise SystemExit('FAIL: openscad executable not found')
source = SRC.read_text(encoding='utf-8')
marker = '// ---------- EXPORT SELECTOR ----------'
if marker not in source:
    raise SystemExit('FAIL: export selector marker missing')
module_source = source.split(marker, 1)[0]
rows=[]
t0=time.time()
with tempfile.TemporaryDirectory(prefix='apex_revp_csg_stop_') as td:
    td=Path(td)
    harness=td/'csg_intersection.scad'
    for size in (42,44,46):
        for side in ('left','right'):
            rail_y_expr = '-rail_y' if side=='left' else 'rail_y'
            test_source = module_source + f'''\n// Auto-generated intersection harness for EU{size}, {side} rail.\nintersection() {{\n  translate([extension,0,0]) toe_deck_local();\n  side_rail_local({rail_y_expr});\n}}\n'''
            harness.write_text(test_source, encoding='utf-8')
            out=td/f'eu{size}_{side}_intersection.stl'
            cmd=[OPENSCAD,'-o',str(out),'-D',f'eu_size={size}',str(harness)]
            proc=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=70)
            log=proc.stdout
            empty=('Current top level object is empty.' in log) and not out.exists()
            # This is an expected-empty test. A generated, non-empty mesh is a defect.
            passed=empty
            rows.append({
                'size':f'EU{size}','side':side,'exit_code':proc.returncode,
                'intersection_mesh_exists':out.exists(),'empty_intersection_message':empty,
                'result':'PASS' if passed else 'FAIL',
                'detail':log[-800:].replace('\n','\\n')
            })
            if out.exists(): out.unlink()

csvp=OUT/'REV_Q_EXACT_TOE_RAIL_INTERSECTION_TEST.csv'
with csvp.open('w',newline='',encoding='utf-8') as f:
    w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
summary={
  'revision':'Rev Q','method':'OpenSCAD CGAL CSG intersection of actual toe_deck_local translated by extension against side_rail_local at each supported size',
  'checks':len(rows),'pass':sum(r['result']=='PASS' for r in rows),'fail':sum(r['result']=='FAIL' for r in rows),
  'result':'PASS' if all(r['result']=='PASS' for r in rows) else 'FAIL',
  'seconds':round(time.time()-t0,2),
  'rows':rows,
  'limitations':['Checks positive-volume solid intersection only. Does not establish manufactured clearance, structural capacity, wear, fatigue, or safety.','At end-of-travel the lug/slot surfaces are intended to contact face-to-face; the empty-solid-intersection test rules out positive-volume interference, not tolerance robustness.']
}
(OUT/'REV_Q_EXACT_TOE_RAIL_INTERSECTION_TEST.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in summary.items() if k!='rows'},indent=2))
raise SystemExit(1 if summary['fail'] else 0)
