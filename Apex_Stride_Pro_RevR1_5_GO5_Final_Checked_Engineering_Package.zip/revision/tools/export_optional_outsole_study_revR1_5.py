#!/usr/bin/env python3
from pathlib import Path
import subprocess,tempfile,csv,json,time
import numpy as np, trimesh
ROOT=Path(__file__).resolve().parents[2]
SRC=ROOT/'revision/Apex_Stride_Pro_RevR.scad'
KIT=ROOT/'PRINT_READY_BENCH_FIT_KIT_REV_R'
OUT=ROOT/'revision/verification_results/revR1_5_go3_go4';OUT.mkdir(parents=True,exist_ok=True)
selectors={'outsole_heel_pad':'outsole_heel_pad_3p2mm_study_only.stl','outsole_toe_pad':'outsole_toe_pad_3p2mm_study_only.stl','outsole_flex_connector':'outsole_flex_connector_3p2mm_study_only.stl'}
rows=[]; t0=time.time()
for size in (42,44,46):
 for part,filename in selectors.items():
  out=KIT/'optional_3p2mm_outsole_study'/f'EU{size}'/filename
  out.parent.mkdir(parents=True,exist_ok=True)
  with tempfile.TemporaryDirectory(prefix='apex_r15_optional_') as td:
   native=Path(td)/'part.stl'
   cmd=['openscad','--export-format','binstl','-o',str(native),'-D',f'eu_size={size}','-D','width_scale=1.00','-D','outsole_weight_study=true','-D',f'part="{part}"',str(SRC)]
   cp=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=120)
   if cp.returncode or not native.exists() or native.stat().st_size<500 or 'ERROR:' in cp.stdout: raise RuntimeError(f'{size}/{part} export failed:\n{cp.stdout[-1600:]}')
   mesh=trimesh.load_mesh(native,force='mesh',process=True)
   if not mesh.is_watertight or not mesh.is_winding_consistent or mesh.volume<=0 or not np.isfinite(mesh.vertices).all(): raise RuntimeError(f'{size}/{part} native mesh invalid')
   volume_native=float(mesh.volume)
   b=mesh.bounds;mesh.apply_translation([-float((b[0,0]+b[1,0])/2),-float((b[0,1]+b[1,1])/2),-float(b[0,2])]);mesh.export(out,file_type='stl')
   verify=trimesh.load_mesh(out,force='mesh',process=True);ext=verify.extents
   ok=verify.is_watertight and verify.is_winding_consistent and abs(verify.volume-volume_native)<=max(.02,volume_native*1e-6) and max(ext[0],ext[1])<=220.001
   rows.append({'size':f'EU{size}','selector':part,'file':str(out.relative_to(KIT)),'volume_mm3':f'{verify.volume:.4f}','x_mm':f'{ext[0]:.3f}','y_mm':f'{ext[1]:.3f}','z_mm':f'{ext[2]:.3f}','watertight':verify.is_watertight,'winding_consistent':verify.is_winding_consistent,'positive_volume':verify.volume>0,'result':'PASS' if ok else 'FAIL','note':'Optional 3.2 mm sole with 1.8 mm nominal tread skin; experimental and not cleared for wear.'})
   print(f'[{len(rows)}/9] {"PASS" if ok else "FAIL"} EU{size} {part}',flush=True)
with (OUT/'REV_R1_5_OPTIONAL_OUTSOLE_STUDY_AUDIT.csv').open('w',newline='',encoding='utf-8') as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0]),lineterminator='\n');w.writeheader();w.writerows(rows)
s={'revision':'Rev R1.5 GO3+GO4','count':len(rows),'passed':sum(r['result']=='PASS' for r in rows),'failed':sum(r['result']!='PASS' for r in rows),'skin_mm':1.8,'status':'EXPERIMENTAL; NOT APPROVED FOR WEAR','seconds':round(time.time()-t0,2)}
(OUT/'REV_R1_5_OPTIONAL_OUTSOLE_STUDY_AUDIT.json').write_text(json.dumps(s,indent=2)+'\n')
print(json.dumps(s,indent=2));raise SystemExit(1 if s['failed'] else 0)
