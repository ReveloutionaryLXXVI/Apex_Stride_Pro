#!/usr/bin/env python3
"""Fresh native OpenSCAD mesh-volume mass estimate Rev K vs Rev R.
Only geometries exported and mesh-validated here are counted. Footbed EVA density,
actual ring mass, fasteners, upper, bladder, spring, hoses and adhesive remain TBD.
"""
from pathlib import Path
import subprocess,tempfile,csv,json,math
import numpy as np
import trimesh
ROOT=Path(__file__).resolve().parents[2]
SOURCES={'RevK':ROOT/'baseline_original/extracted/Apex_Stride_Pro_RevK.scad',
         'RevR':ROOT/'revision/Apex_Stride_Pro_RevR.scad'}
OUT=ROOT/'revision/verification_results/revR_core_integration'
OUT.mkdir(parents=True,exist_ok=True)
# Density in g/cm^3; explicitly documented estimates/candidate values only.
DENSITY={
 'heel_deck':(0.95,'Materialise PA12 SLS card: density 0.95 g/cm3'),
 'toe_carriage':(0.95,'Materialise PA12 SLS card: density 0.95 g/cm3'),
 'bridge_rear':(2.70,'6061-T6 aluminium candidate density assumption; exact rail/bridge grade not procured'),
 'bridge_front':(2.70,'6061-T6 aluminium candidate density assumption; exact rail/bridge grade not procured'),
 'rail_left':(2.70,'6061-T6 aluminium candidate density assumption; exact rail/bridge grade not procured'),
 'rail_right':(2.70,'6061-T6 aluminium candidate density assumption; exact rail/bridge grade not procured'),
 'locking_pin':(7.75,'17-4PH metal pin candidate density estimate; lot/product not selected'),
 'outsole_assembly':(1.20,'illustrative rubber-density placeholder only; compound/supplier density not selected'),
}
PARTS=[('heel_deck','heel'),('toe_carriage','toe'),('bridge_rear','bridge_rear'),('bridge_front','bridge_front'),('rail_left','rail_left'),('rail_right','rail_right'),('locking_pin','pin_through_solid')]
def export(src,size,selector,study=False):
 with tempfile.TemporaryDirectory(prefix='apex_revr_mass_') as td:
  dst=Path(td)/'mesh.stl'
  cmd=['openscad','--export-format','binstl','-o',str(dst),'-D',f'eu_size={size}','-D','width_scale=1.00','-D',f'part="{selector}"']
  if study: cmd += ['-D','outsole_weight_study=true']
  cmd += [str(src)]
  cp=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=75)
  if cp.returncode or not dst.exists() or dst.stat().st_size<400 or 'ERROR:' in cp.stdout:
   raise RuntimeError(f'OpenSCAD export failed size={size}, selector={selector}, file={src}: {cp.stdout[-1200:]}')
  m=trimesh.load_mesh(dst,force='mesh',process=True)
  ok=(m.is_watertight and m.is_winding_consistent and np.isfinite(m.vertices).all() and np.isfinite(m.volume) and m.volume>0)
  if not ok: raise RuntimeError(f'Mesh validation failed {size}/{selector}: water={m.is_watertight},wind={m.is_winding_consistent},vol={m.volume}')
  return float(m.volume),[float(v) for v in m.extents]
rows=[]; summary=[]; count=0; footbed_rows=[]; core_totals={}
for rev,src in SOURCES.items():
 for size in (42,44,46):
  total=0.0
  for comp,sel in PARTS:
   vol,ext=export(src,size,sel); count+=1
   d,reason=DENSITY[comp];mass=vol/1000*d;total+=mass
   rows.append({'revision':rev,'size':f'EU{size}','component':comp,'selector':sel,'volume_mm3':f'{vol:.6f}','density_g_cm3':d,'estimated_mass_g':f'{mass:.6f}','dimensions_mm':','.join(f'{x:.3f}' for x in ext),'mass_basis':reason,'mesh_result':'PASS','mass_scope':'included in modeled rigid chassis subtotal; excludes unmodeled fasteners'})
  out_vol,_=export(src,size,'outsole_assembly');count+=1
  out_d,out_reason=DENSITY['outsole_assembly'];out_mass=out_vol/1000*out_d
  total_with_out=total+out_mass
  rows.append({'revision':rev,'size':f'EU{size}','component':'outsole_assembly','selector':'outsole_assembly','volume_mm3':f'{out_vol:.6f}','density_g_cm3':out_d,'estimated_mass_g':f'{out_mass:.6f}','dimensions_mm':'assembled aggregate only; component STLs exported individually','mass_basis':out_reason,'mesh_result':'PASS','mass_scope':'included in full modeled lower platform total, illustrative density only'})
  # Footbed volume is measured but no EVA density assigned.
  sels=[('footbed_insert','footbed_insert')] if rev=='RevK' else [('footbed_heel_piece','footbed_heel_piece'),('footbed_toe_piece','footbed_toe_piece'),('footbed_toe_lap_tongue','footbed_toe_lap_tongue')]
  footvol=0
  for comp,sel in sels:
   vol,ext=export(src,size,sel);count+=1;footvol+=vol
   footbed_rows.append({'revision':rev,'size':f'EU{size}','component':comp,'selector':sel,'volume_mm3':f'{vol:.6f}','estimated_mass_g':'TBD','material_candidate':'EVA foam with textile cover','why_mass_TBD':'EVA grade/density not selected; measured compression-density datasheet required','mesh_result':'PASS'})
  # RevR ring displayed as schematic, do not turn display mesh volume into actual ring mass.
  if rev=='RevR':
   ring_vol,ring_ext=export(src,size,'pin_retaining_clip');count+=1
   rows.append({'revision':rev,'size':f'EU{size}','component':'retaining_ring_schematic_only','selector':'pin_retaining_clip','volume_mm3':f'{ring_vol:.6f}','density_g_cm3':'TBD','estimated_mass_g':'TBD','dimensions_mm':','.join(f'{x:.3f}' for x in ring_ext),'mass_basis':'schematic clip is not an exact catalog ring shape; use purchased DIN 471 size-8 ring mass','mesh_result':'PASS','mass_scope':'not included in subtotal'})
  core_totals[(rev,size)]=(total,total_with_out,footvol)
  print(rev,f'EU{size}',f'chassis+pin={total:.3f}g',f'+outsole@1.20={total_with_out:.3f}g',f'footbed_volume={footvol:.1f} mm3',flush=True)
# default versus optional 3.2 outsole variant for RevR
study=[]
for size in (42,44,46):
 vol,_=export(SOURCES['RevR'],size,'outsole_assembly',True);count+=1
 m=vol/1000*1.20
 chassis, default_total, footvol=core_totals[('RevR',size)]
 study.append({'size':f'EU{size}','RevR_default_outsole_volume_mm3':f'{(default_total-chassis)/1.2*1000:.6f}','study_outsole_volume_mm3':f'{vol:.6f}','study_outsole_mass_g_at_1p20':f'{m:.6f}','RevR_default_platform_g_excluding_footbed_fasteners_core':f'{default_total:.6f}','RevR_optional_3p2_platform_g_same_scope':f'{(chassis+m):.6f}','mass_delta_study_minus_default_g':f'{m-(default_total-chassis):+.6f}','estimated_saved_g':f'{(default_total-chassis)-m:.6f}','rubber_density_assumption_g_cm3':1.20,'status':'UNVALIDATED STUDY ONLY; not for wear; rubber density is placeholder'})
for name, data in [('REVR_COMPONENT_MASS_MATERIAL_CARD.csv',rows),('REVR_FOOTBED_GEOMETRY_VOLUME.csv',footbed_rows),('REVR_OPTIONAL_OUTSOLE_STUDY_MASS.csv',study)]:
 with (OUT/name).open('w',newline='',encoding='utf-8') as f:
  w=csv.DictWriter(f,fieldnames=list(data[0]));w.writeheader();w.writerows(data)
# summary with apples-to-apples current material assignments across both geometry variants
srows=[]
for size in (42,44,46):
 k0,k1,_=core_totals[('RevK',size)];q0,q1,_=core_totals[('RevR',size)]
 srows.append({'size':f'EU{size}','RevK_chassis_pin_mass_g':f'{k0:.6f}','RevR_chassis_pin_mass_g':f'{q0:.6f}','RevR_delta_chassis_pin_g':f'{q0-k0:+.6f}','RevK_full_modeled_platform_g_outsole_1p20':f'{k1:.6f}','RevR_full_modeled_platform_g_outsole_1p20':f'{q1:.6f}','RevR_delta_platform_g':f'{q1-k1:+.6f}','excludes':'footbed mass (EVA density TBD), retaining ring actual mass, production fasteners, upper, spring, pneumatic bladder/tubing/fittings/regulator, adhesive; outsole mass uses placeholder density 1.20 g/cm3'})
with (OUT/'REVK_VS_REVR_MATERIAL_CARD_MASS_SUMMARY.csv').open('w',newline='',encoding='utf-8') as f:
 w=csv.DictWriter(f,fieldnames=list(srows[0]));w.writeheader();w.writerows(srows)
report={'fresh_native_mesh_exports':count,'size_cases':[42,44,46],'mesh_checks':'all exports watertight, winding-consistent, finite vertices, positive finite volume','material_assignments':{k:{'density_g_cm3':v[0],'basis':v[1]} for k,v in DENSITY.items()},'EVA_density':'not selected; footbed mass excluded','retaining_ring_mass':'not calculated from schematic mesh; catalog part required','outsole_density':'1.20 g/cm3 sensitivity placeholder only','outputs':['REVR_COMPONENT_MASS_MATERIAL_CARD.csv','REVR_FOOTBED_GEOMETRY_VOLUME.csv','REVR_OPTIONAL_OUTSOLE_STUDY_MASS.csv','REVK_VS_REVR_MATERIAL_CARD_MASS_SUMMARY.csv']}
(OUT/'REVR_MASS_AUDIT_SUMMARY.json').write_text(json.dumps(report,indent=2)+'\n')
print('PASS fresh native geometry mass exports',count)
