#!/usr/bin/env python3
"""Rev P C3 correction: preserve solid lands around rail attachment pilot holes and run a horizontal lock-pin screening analysis.

Requires OpenSCAD, Python 3, numpy, trimesh. All stresses are simplified screening calculations, not FEA or safety approval.
"""
from pathlib import Path
import csv, json, math, re, subprocess, tempfile, hashlib, time
import numpy as np
import trimesh
ROOT=Path(__file__).resolve().parents[2]
SRC=ROOT/'revision/Apex_Stride_Pro_RevP.scad'
PSRC=ROOT/'PRINT_READY_BENCH_FIT_KIT_REV_P/source/Apex_Stride_Pro_RevP_PrintPrep.scad'
OUT=ROOT/'revision/verification_results/REV_P_C3_SAFETY_CORRECTION'
OUT.mkdir(parents=True, exist_ok=True)
t0=time.time(); checks=[]
def add(group,name,ok,detail): checks.append({'group':group,'check':name,'result':'PASS' if ok else 'FAIL','detail':detail})
def num(key, default=None):
    txt=SRC.read_text()
    m=re.search(r'^\s*'+re.escape(key)+r'\s*=\s*([-+0-9.]+)\s*;',txt,re.M)
    if not m:
        if default is not None:return default
        raise ValueError(f'Parameter {key} not found')
    return float(m.group(1))
# Source-driven dimensions and relief keepout arithmetic.
heel_split=num('heel_split_x'); rail_start=num('rail_start_x') if re.search(r'^\s*rail_start_x\s*=\s*[-+0-9.]+\s*;',SRC.read_text(),re.M) else heel_split-65
rail_end=heel_split+90; attach_x=[heel_split-60,heel_split-40]
bolt_d=num('bolt_hole_d'); pilot_d=num('rail_mount_pilot_d'); sidewall=num('rail_relief_sidewall_mm'); index_d=num('rail_index_hole_d'); pin_d=num('lock_pin_d'); rail_y=num('rail_y'); head_w=num('rail_head_width'); neck_h=num('rail_neck_height'); rail_h=num('rail_height'); mm_size=num('mm_per_eu_size')
keepout=pilot_d/2+sidewall
idx_first=heel_split+30
idx_last=heel_split+30+4*mm_size
c0=rail_start+num('rail_relief_end_margin_mm')
c1=idx_first-index_d/2-sidewall
c2=idx_last+index_d/2+sidewall
c3=rail_end-num('rail_relief_end_margin_mm')
cavities=[(max(c0,attach_x[0]+keepout),min(c1,attach_x[1]-keepout)),
          (max(c0,attach_x[1]+keepout),c1),(c2,c3)]
for i,x in enumerate(attach_x,1):
    nearest=min(abs(x-a) for interval in cavities for a in interval if math.isfinite(a))
    # exact minimum distance to an interval along x
    dmin=min((lo-x if x<lo else x-hi if x>hi else 0.0) for lo,hi in cavities if hi>lo)
    clearance=dmin-pilot_d/2
    add('rail_attachment_lands',f'attachment_pilot_{i}_solid_land',clearance+1e-9>=sidewall,
        f'pilot x={x:.3f} mm; nearest relief edge distance={dmin:.3f} mm from center; material land beyond Ø{pilot_d:.2f} pilot radius={clearance:.3f} mm; requirement {sidewall:.3f} mm')
for i,(lo,hi) in enumerate(cavities,1):
    ok=hi>lo
    add('rail_relief_segments',f'cavity_segment_{i}_positive_length',ok,f'x=[{lo:.3f},{hi:.3f}] mm length={hi-lo:.3f} mm')
# Compile/export actual metal rail geometry with relief enabled; check watertightness, winding, finite positive volume.
rail_meshes=[]
for size in (42,44,46):
  for part in ('rail_left','rail_right'):
    with tempfile.TemporaryDirectory(prefix='apex_c3_rail_') as td:
      dst=Path(td)/'rail.stl'
      cmd=['openscad','--export-format','binstl','-o',str(dst),'-D',f'eu_size={size}','-D','width_scale=1.00','-D','rail_weight_relief=true','-D',f'part="{part}"',str(SRC)]
      cp=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=90)
      if cp.returncode or not dst.exists() or dst.stat().st_size<500:
        add('rail_native_export',f'EU{size}_{part}',False,cp.stdout[-1000:]); continue
      mesh=trimesh.load_mesh(dst,force='mesh',process=True)
      ok=mesh.is_watertight and mesh.is_winding_consistent and np.isfinite(mesh.vertices).all() and np.isfinite(mesh.volume) and mesh.volume>0
      add('rail_native_export',f'EU{size}_{part}',ok,f'faces={len(mesh.faces)} volume={mesh.volume:.3f} mm3 extents={mesh.extents.round(3).tolist()}')
      rail_meshes.append({'size':size,'part':part,'volume_mm3':float(mesh.volume),'sha256':hashlib.sha256(dst.read_bytes()).hexdigest()})
# Check source equivalence: required keepout block in both authoritative and print prep sources.
for p in (SRC,PSRC):
  s=p.read_text(); ok=('cavity_a0 = max(cavity_x0, x_mount_1 + mount_keepout)' in s and
      'cavity_b0 = max(cavity_x0, x_mount_2 + mount_keepout)' in s and
      'cavity_a1 = min(cavity_x1, x_mount_2 - mount_keepout)' in s)
  add('source_sync',p.name,ok,'both source trees must preserve local solid lands around both Ø3.3 mm tapped attachment pilots')
# Horizontal load screening with a two-rail symmetric lock-pin beam model.
F=66.0*9.81; pin_root=num('pin_groove_root_d'); span_support=2*num('pin_entry_y'); span_rail=2*rail_y
lever=(span_support-span_rail)/2
Z=math.pi*pin_d**3/32.0  # Max-moment section is the unnotched Ø8 mm shaft between rail loads
A=math.pi*pin_root**2/4.0  # Conservative root area for shear sensitivity
rail_proj=pin_d*head_w
hole_pitch=2*mm_size; ligament_between=hole_pitch-index_d; half_lig=ligament_between/2
breakout_area=2*head_w*half_lig
bridge_width=num('bridge_flange_width'); bridge_thick=num('bridge_flange_thickness'); bridge_net=(bridge_width-2*bolt_d)*bridge_thick
rows=[]
for frac in (0.10,0.20,0.50,1.00):
  H=F*frac
  M=(H/2)*lever  # total horizontal load is split equally between the two rail bearing points
  sig=M/Z
  v=H/2
  tau_max=4*v/(3*A)
  bearing=(H/2)/rail_proj
  tear=(H/2)/breakout_area if breakout_area>0 else float('inf')
  bridge=H/bridge_net
  for kt in (1.5,2.0):
    row={'horizontal_load_fraction_of_body_weight':frac,'horizontal_force_N':H,'pin_support_span_mm':span_support,'rail_center_span_mm':span_rail,'pin_bending_lever_arm_mm':lever,'pin_groove_root_d_mm':pin_root,'pin_groove_root_section_modulus_mm3':Z,'pin_nominal_bending_stress_MPa':sig,'notch_factor_sensitivity_only':kt,'pin_notch_sensitivity_stress_MPa':sig*kt,'17_4PH_H900_reference_yield_MPa':1170.0,'yield_ratio_reference_only':1170.0/(sig*kt),'max_circular_section_shear_MPa':tau_max,'rail_bearing_MPa_per_rail':bearing,'rail_between_index_holes_ligament_mm':ligament_between,'rail_adjacent_hole_tearout_avg_shear_MPa_per_rail':tear,'one_6061_bridge_strap_net_tension_MPa':bridge,'two_straps_equal_share_MPa_each':bridge/2,'method_note':'Stylized quasi-static horizontal load; all force assumed to enter pin; two rail bearing points at ±rail_y, end supports at ±pin_entry_y. Kt values are sensitivities, not determined notch factors.'}
    rows.append(row)
# Per-load duplicate Kt rows are intentional so the assumption is explicit.
with (OUT/'C3_HORIZONTAL_LOCK_PIN_LOAD_SCREEN.csv').open('w',newline='',encoding='utf-8') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
# independent equations cross-check
add('analytical_screen','body_weight_calculation',abs(F-647.46)<1e-9,f'66 × 9.81 = {F:.2f} N')
add('analytical_screen','pin_beam_geometry',span_support>span_rail>0 and lever>0,f'support span {span_support:.2f} mm; rail centers {span_rail:.2f} mm; each rail load lever {lever:.2f} mm')
add('analytical_screen','pin_bending_equation',abs(rows[0]['pin_nominal_bending_stress_MPa'] - ((F*.1/2)*lever/Z))<1e-9,f'unnotched Ø{pin_d:.1f} mm shaft section modulus {Z:.4f} mm3; H=0.1 body-weight scenario stress {rows[0]["pin_nominal_bending_stress_MPa"]:.3f} MPa')
add('analytical_screen','bridge_net_section_positive',bridge_net>0,f'bridge net area=(23-2×4.8)×3={bridge_net:.2f} mm2')
# Persist report records
with (OUT/'C3_CORRECTIVE_TEST_REGISTER.csv').open('w',newline='',encoding='utf-8') as f:
  w=csv.DictWriter(f,fieldnames=['group','check','result','detail']);w.writeheader();w.writerows(checks)
summary={'revision':'Rev P corrective patch C3','checks':len(checks),'pass':sum(c['result']=='PASS' for c in checks),'fail':sum(c['result']=='FAIL' for c in checks),'fresh_rail_mesh_exports':len(rail_meshes),'rail_meshes':rail_meshes,'cavity_intervals_x_mm':cavities,'rail_attachment_x_mm':attach_x,'rail_attachment_keepout_radius_mm':keepout,'body_mass_kg':66,'body_weight_N':F,'horizontal_lock_pin_scenarios_rows':len(rows),'material_specific_fea_run':False,'physical_tests_run':False,'elapsed_s':round(time.time()-t0,2)}
(OUT/'C3_CORRECTIVE_TEST_SUMMARY.json').write_text(json.dumps(summary,indent=2)+'\n')
lines=['# C3 corrective test results — rail attachment lands + horizontal lock-pin screen','',
       '**Scope:** one source-level structural-interface correction plus analytical load sensitivity. This is not FEA, a physical test, or wear certification.','',
       '## Rail attachment pilot-land correction','',
       f'The rail screw pilot centers are at x={attach_x[0]:.2f} and {attach_x[1]:.2f} mm relative to the model frame. With a Ø{pilot_d:.2f} mm candidate M4 tap-drill pilot and {sidewall:.2f} mm requested solid margin beyond its radius, the relief cavity must remain at least {keepout:.2f} mm away from each pilot center. The C3 source breaks the existing rail cavity into segments so both pilot lands remain solid.','',
       '| Relief segment | X interval (mm) | Length (mm) |','|---|---:|---:|']
for i,(lo,hi) in enumerate(cavities,1): lines.append(f'| {i} | {lo:.3f} to {hi:.3f} | {hi-lo:.3f} |')
lines += ['',f'**Automated C3 checks: {summary["pass"]} PASS, {summary["fail"]} FAIL.** Each metal-rail selector exported as a watertight, consistently wound, positive-volume STL in all six size/side runs. The separate fit-kit rail STLs remain solid polymer gauge parts.','',
          '## Horizontal load screen for the adjustment lock pin','',
          f'Body weight is {F:.2f} N. The pin-beam model assumes side-boss supports at ±{num("pin_entry_y"):.1f} mm and rail bearing loads at ±{rail_y:.1f} mm, so each rail load is offset {lever:.2f} mm from its nearest support; each rail carries H/2. This is a simplified bounding load path; it assumes **all** horizontal shoe force is carried by the pin and ignores load-sharing with the bridge screws.','',
          '| Horizontal load | Force (N) | Nominal unnotched shaft bending stress (MPa) | Kt=2 sensitivity (MPa) | Reference yield ratio* | Rail hole bearing per rail (MPa) | Bridge net tension, one strap (MPa) |','|---:|---:|---:|---:|---:|---:|---:|']
for frac in (0.1,0.2,0.5,1.0):
    r=next(x for x in rows if x['horizontal_load_fraction_of_body_weight']==frac and x['notch_factor_sensitivity_only']==2.0)
    lines.append(f'| {frac:.0%} BW | {r["horizontal_force_N"]:.2f} | {r["pin_nominal_bending_stress_MPa"]:.2f} | {r["pin_notch_sensitivity_stress_MPa"]:.2f} | {r["yield_ratio_reference_only"]:.2f} | {r["rail_bearing_MPa_per_rail"]:.2f} | {r["one_6061_bridge_strap_net_tension_MPa"]:.2f} |')
lines += ['', '*Reference yield ratio compares notch-factor sensitivity stress with 1170 MPa reference yield for wrought 17-4PH H900 candidate data only. This is not a design allowable or verified component yield strength; actual material cert, groove radius, surface finish, fatigue, corrosion and impact are unknown. Kt=2 is a sensitivity assumption only.','',
          'Rail bearing stress uses projected area pin diameter × 11 mm head width per rail. Adjacent-hole tear-out uses half the gap between neighboring Ø8.3 mm holes as the shear ligament; results are in the CSV. Bridge strap tension uses (23−2×4.8)×3=40.2 mm² net area. These simplified elastic stress demands ignore local contact nonlinearity, prying, screw preload, fatigue and actual gait loads.','',
          '## Result / limitations','',
          'The C3 rail relief no longer crosses the tapped attachment pilots; a minimum 2.5 mm material margin is preserved in X between the hole edge and each relief region. This addresses an identifiable geometry/interface defect. The current 20.6 mm PA12 deck, 2.15 mm web, 4.1 mm roof and 0.4 mm nominal rail/channel vertical clearance still need material-specific structural analysis and tolerance qualification. No FEA solver is installed; no physical load, fatigue, retention, outsole, traction or fit tests were performed. Human wear remains prohibited pending those release tests.']
(OUT/'C3_CORRECTIVE_STRUCTURAL_SCREEN.md').write_text('\n'.join(lines)+'\n')
print(json.dumps(summary,indent=2))
if summary['fail']: raise SystemExit(1)
