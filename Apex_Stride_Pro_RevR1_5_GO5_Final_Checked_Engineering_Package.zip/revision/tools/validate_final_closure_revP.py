#!/usr/bin/env python3
"""Run current digital checks for Apex Stride Pro Rev P closure package.

Requires OpenSCAD, numpy, trimesh. Intersection checks are CSG positive-volume screens;
they do not prove clearance under tolerance or structural safety.
"""
from pathlib import Path
import csv, json, hashlib, subprocess, tempfile, time, sys
import numpy as np
import trimesh
ROOT=Path(__file__).resolve().parents[2]
KIT=ROOT/'PRINT_READY_BENCH_FIT_KIT_REV_P'
SRC=ROOT/'revision/Apex_Stride_Pro_RevP.scad'
PSRC=KIT/'source/Apex_Stride_Pro_RevP_PrintPrep.scad'
OUT=ROOT/'revision/verification_results/revP_mass_audit/consolidated_validation'; OUT.mkdir(parents=True,exist_ok=True)
records=[]; t0=time.time()
def add(group,item,ok,detail): records.append({'group':group,'item':item,'result':'PASS' if ok else 'FAIL','detail':str(detail)})
def run(cmd, timeout=60):
    return subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=timeout)
# Explicit source/density/feature consistency checks.
s=SRC.read_text(); ps=PSRC.read_text()
for label,text in [('native',s),('printprep',ps)]:
    for token,name in [('Rev P','Rev P revision label'),('rail_y = 20.3;','rail center Y ±20.3 mm'),('rail_head_width = 11.0;','11 mm baseline rail head width'),('rail_index_hole_d = 8.3;','Ø8.3 rail index hole'),('rail_head_width >= 11.0','no narrowing below baseline bearing length'),('lock_hole_d = 8.8;','Ø8.8 carriage passage'),('outsole_pad_thickness = outsole_weight_study ? 3.2 : 4.0;','4.0 mm default / 3.2 mm study'),('rail_end_x-3.0-4*mm_per_eu_size,','stop-groove correction without prior 0.3 mm overlap'),('bridge_flange_width = 23.0;','current bridge flange width')]:
        add('source_consistency',f'{label}:{name}',token in text, f'token present={token in text}')
# Main print kit checks.
with (KIT/'PRINT_PARTS_INDEX.csv').open(newline='',encoding='utf-8') as f: index=list(csv.DictReader(f))
for r in index:
    p=KIT/'stl'/r['file']; item=f"{r['size']}:{r['file']}"
    if not p.exists():
        add('print_mesh',item,False,'missing file'); continue
    try:
        m=trimesh.load_mesh(p,force='mesh',process=True); b=m.bounds; e=m.extents; v=np.asarray(m.vertices)
        checks={
          'watertight':m.is_watertight,'winding_consistent':m.is_winding_consistent,
          'finite_vertices':np.isfinite(v).all(),'positive_finite_volume':np.isfinite(m.volume) and m.volume>0,
          'XY_centered':max(abs((b[0,0]+b[1,0])/2),abs((b[0,1]+b[1,1])/2))<1e-3,
          'Zmin_zero':abs(float(b[0,2]))<1e-3,
          '220mm_xy_envelope':max(float(e[0]),float(e[1]))<=220.001,
          'index_volume_match':abs(float(m.volume)-float(r['normalized_volume_mm3']))<=max(.02,abs(float(m.volume))*1e-6),
          'index_result_PASS':r['result']=='PASS'
        }
        for k,ok in checks.items(): add('print_mesh',f'{item}:{k}',ok,f'extents={tuple(round(float(x),4) for x in e)} volume={m.volume:.4f} mm³')
    except Exception as ex: add('print_mesh',item,False,f'load/parse exception: {ex}')
# Upper concept meshes: topology only, not functional validation.
upper=list(sorted((KIT/'upper_concept_not_wearable').glob('EU*/*.stl')))
for p in upper:
    try:
        m=trimesh.load_mesh(p,force='mesh',process=True)
        for k,ok in [('watertight',m.is_watertight),('winding',m.is_winding_consistent),('positive_finite_volume',np.isfinite(m.volume) and m.volume>0 and np.isfinite(m.vertices).all())]:
            add('upper_mesh',p.relative_to(ROOT).as_posix()+':'+k,ok,f'volume={m.volume:.4f} mm³')
    except Exception as ex: add('upper_mesh',p.relative_to(ROOT).as_posix(),False,str(ex))
# Optional 3.2 mm outsole study pieces.
with (KIT/'optional_3p2mm_outsole_study/OUTSOLE_STUDY_EXPORT_AUDIT_REV_P.csv').open(newline='',encoding='utf-8') as f: study=list(csv.DictReader(f))
for r in study:
    p=ROOT/r['file']
    try:
        m=trimesh.load_mesh(p,force='mesh',process=True); b=m.bounds; e=m.extents
        vals=np.asarray(m.vertices)
        checks={
          'exists':p.exists(),'watertight':m.is_watertight,'winding':m.is_winding_consistent,
          'positive_finite_volume':np.isfinite(m.volume) and m.volume>0 and np.isfinite(vals).all(),
          'XY_centered':max(abs((b[0,0]+b[1,0])/2),abs((b[0,1]+b[1,1])/2))<1e-3,
          'Zmin_zero':abs(float(b[0,2]))<1e-3,
          '220mm_xy_envelope':max(float(e[0]),float(e[1]))<=220.001,
          'study_index_PASS':r['result']=='PASS'
        }
        for k,ok in checks.items(): add('optional_outsole_study',r['size']+':'+r['selector']+':'+k,ok,f'extents={tuple(round(float(x),4) for x in e)} volume={m.volume:.4f} mm³; unvalidated study only')
    except Exception as ex: add('optional_outsole_study',r['size']+':'+r['component'],False,str(ex))
# Compile source for three sizes x three widths x heel/toe.
for size in (42,44,46):
 for width in ('1.00','1.04','1.08'):
  for part in ('heel','toe'):
   with tempfile.TemporaryDirectory(prefix='apex_final_csg_') as td:
    dst=Path(td)/'p.csg'; cmd=['openscad','-o',str(dst),'-D',f'eu_size={size}','-D',f'width_scale={width}','-D',f'part="{part}"',str(SRC)]
    try:
     cp=run(cmd,45); ok=cp.returncode==0 and dst.exists() and dst.stat().st_size>100 and 'ERROR:' not in cp.stdout
     add('native_csg_compile',f'EU{size}_W{width}_{part}',ok,f'return={cp.returncode}; bytes={dst.stat().st_size if dst.exists() else 0}; {cp.stdout[-250:].replace(chr(10)," | ")}')
    except Exception as ex: add('native_csg_compile',f'EU{size}_W{width}_{part}',False,str(ex))
# Invalid parameter guards: check assertion message; CSG export can return zero even when assertion logged.
for item,defs,expected in [
 ('invalid_size',['eu_size=40','width_scale=1.00','part="heel"'],'Choose eu_size = 42, 44, or 46'),
 ('invalid_width',['eu_size=42','width_scale=1.02','part="heel"'],'Choose width_scale = 1.00, 1.04, or 1.08')]:
 with tempfile.TemporaryDirectory(prefix='apex_final_guard_') as td:
  dst=Path(td)/'guard.csg'; cmd=['openscad','-o',str(dst)]
  for d in defs: cmd += ['-D',d]
  cmd += [str(SRC)]
  cp=run(cmd,45); add('parameter_guard',item,expected in cp.stdout,cp.stdout[-500:].replace('\n',' | '))
# Print-prep selector compiles.
for part in ('bridge_rear','bridge_front','rail_left','rail_right','pin_through_solid','pin_retaining_clip','outsole_heel_pad','outsole_toe_pad','outsole_flex_connector','footbed_heel_print_piece','footbed_toe_print_piece'):
 with tempfile.TemporaryDirectory(prefix='apex_final_psel_') as td:
  dst=Path(td)/'part.csg'; cmd=['openscad','-o',str(dst),'-D','eu_size=44','-D','width_scale=1.00','-D',f'part="{part}"',str(PSRC)]
  cp=run(cmd,45); ok=cp.returncode==0 and dst.exists() and dst.stat().st_size>100 and 'ERROR:' not in cp.stdout
  add('printprep_selector_compile',part,ok,f'return={cp.returncode}; bytes={dst.stat().st_size if dst.exists() else 0}')
# Current geometry interface intersection screens: no positive volume expected except outsole flex overlap into pads.
pairs=[
 ('heel_vs_left_rail','heel_deck()','side_rail_local(-rail_y)','NO'),('heel_vs_right_rail','heel_deck()','side_rail_local(rail_y)','NO'),
 ('heel_vs_rear_bridge','heel_deck()','bridge_rear_strap()','NO'),('toe_vs_front_bridge','translate([extension,0,0]) toe_deck_local()','translate([extension,0,0]) bridge_front_strap()','NO'),
 ('left_rail_vs_pin','side_rail_local(-rail_y)','positioned_pin(extension)','NO'),('right_rail_vs_pin','side_rail_local(rail_y)','positioned_pin(extension)','NO'),
 ('pin_vs_ring','positioned_pin(extension)','positioned_retaining_ring(extension)','NO'),
 ('heel_outsole_vs_connector','outsole_heel_pad()','outsole_flex_connector()','YES'),('toe_outsole_vs_connector','outsole_toe_pad()','outsole_flex_connector()','YES')]
inter_rows=[]
for size in (42,44,46):
 for name,a,b,expect in pairs:
  with tempfile.TemporaryDirectory(prefix='apex_intersection_') as td:
   wrapper=Path(td)/'pair.scad'; dst=Path(td)/'pair.stl'
   wrapper.write_text(f'include <{SRC.as_posix()}>;\nintersection() {{ {a}; {b}; }}\n',encoding='utf-8')
   cp=run(['openscad','--export-format','binstl','-o',str(dst),'-D',f'eu_size={size}','-D','width_scale=1.00','-D','part="audit_no_part"',str(wrapper)],60)
   vol=0.; has=False
   if dst.exists() and dst.stat().st_size>84:
    try:
     mm=trimesh.load_mesh(dst,force='mesh',process=True); has=bool(len(mm.faces) and mm.is_watertight); vol=abs(float(mm.volume)) if has else 0.
    except Exception: pass
   ok=(vol<=1e-4) if expect=='NO' else (vol>1e-4)
   inter_rows.append({'size':f'EU{size}','interface':name,'expected_intersection':expect,'intersection_volume_mm3':f'{vol:.6f}','result':'PASS' if ok else 'FAIL','interpretation':'positive-volume CSG screen only; does not prove tolerance clearance or strength'})
   add('interface_intersection',f'EU{size}:{name}',ok,f'volume={vol:.6f} mm³; expectation={expect}')
with (OUT/'REV_O_FINAL_INTERSECTION_RECHECK.csv').open('w',newline='',encoding='utf-8') as f:
 w=csv.DictWriter(f,fieldnames=list(inter_rows[0]));w.writeheader();w.writerows(inter_rows)
# Supplemental current-revision tests: 61-position kinematic screen, exact CSG stop/rail tests, and analytical load-screen arithmetic.
kin_path=ROOT/'revision/verification_results/revP_mass_audit/kinematic_sweep/REV_P_61_POSITION_KINEMATIC_CLEARANCE_SWEEP.csv'
with kin_path.open(newline='',encoding='utf-8') as f: kin_rows=list(csv.DictReader(f))
for r in kin_rows:
    item=f"position_{r['position_index']}_ext_{r['extension_mm']}mm"
    add('kinematic_clearance',item+':rail_engagement',float(r['rail_channel_engagement_mm'])>0,f"engagement={r['rail_channel_engagement_mm']} mm")
    add('kinematic_clearance',item+':stop_no_interference',float(r['stop_clearance_to_contact_mm'])>=-1e-6,f"stop clearance={r['stop_clearance_to_contact_mm']} mm; 0 means contact")
    add('kinematic_clearance',item+':groove_covers_lug',float(r['stop_groove_overrun_past_lug_end_mm'])>=-1e-6,f"slot extension past lug={r['stop_groove_overrun_past_lug_end_mm']} mm")
    add('kinematic_clearance',item+':bridge_overlap',float(r['bridge_strap_overlap_mm'])>0,f"bridge overlap={r['bridge_strap_overlap_mm']} mm")
reg_path=ROOT/'revision/verification_results/revP_mass_audit/kinematic_sweep/REV_P_DISCRETE_LOCK_REGISTRATION_RECHECK.csv'
with reg_path.open(newline='',encoding='utf-8') as f: regs=list(csv.DictReader(f))
for r in regs:
    add('lock_registration',r['size']+':rail_pin_index',abs(float(r['rail_pin_index_error_mm']))<1e-8,f"index error={r['rail_pin_index_error_mm']} mm")
    add('lock_registration',r['size']+':bridge_lock_pair',abs(float(r['bridge_lock_pair_error_mm']))<1e-8,f"pair error={r['bridge_lock_pair_error_mm']} mm")
exact_path=ROOT/'revision/verification_results/revP_mass_audit/exact_csg/REV_P_EXACT_TOE_RAIL_INTERSECTION_TEST.csv'
with exact_path.open(newline='',encoding='utf-8') as f: exact_rows=list(csv.DictReader(f))
for r in exact_rows:
    add('exact_toe_rail_csg',r['size']+':'+r['side'],r['result']=='PASS',f"exit={r['exit_code']}; mesh={r['intersection_mesh_exists']}; empty={r['empty_intersection_message']}")
before_after_path=ROOT/'revision/verification_results/revP_mass_audit/exact_csg/REV_P_C1_TO_REVP_STOP_FIX_REGRESSION.csv'
with before_after_path.open(newline='',encoding='utf-8') as f: before_after_rows=list(csv.DictReader(f))
for r in before_after_rows:
    add('stop_fix_regression',r['state']+':'+r['rail_side'],r['result']=='PASS',f"size={r['size']}; volume={r['intersection_volume_mm3']} mm^3; empty={r['empty_intersection_message']}")
analytic_path=ROOT/'revision/verification_results/revP_mass_audit/analytical_screen/STRUCTURAL_ANALYTICAL_SCREENING_GEOMETRY_CHECKS.csv'
with analytic_path.open(newline='',encoding='utf-8') as f: analytic_rows=list(csv.DictReader(f))
for r in analytic_rows:
    add('analytical_geometry_arithmetic',r['check'],r['result']=='PASS',r['detail'])
# Verify regenerated native mass results have expected complete row counts and components.
with (ROOT/'revision/verification_results/revP_mass_audit/REVK_REVP_FRESH_COMPONENT_MASS.csv').open(newline='',encoding='utf-8') as f: mass_rows=list(csv.DictReader(f))
with (ROOT/'revision/verification_results/revP_mass_audit/REVK_REVP_FRESH_MASS_SUMMARY.csv').open(newline='',encoding='utf-8') as f: summary=list(csv.DictReader(f))
add('mass_outputs','57 component-size rows, each native mesh PASS',len(mass_rows)==57 and all(r.get('mesh_result')=='PASS' for r in mass_rows),f'rows={len(mass_rows)}; fresh current native export record; see REVK_REVP_FRESH_COMPONENT_MASS.csv and Rev O C2 stop-groove before/after record')
add('mass_outputs','3 sizes in summary',len(summary)==3 and {r['size'] for r in summary}=={'EU42','EU44','EU46'},f'rows={len(summary)}')
for r in summary:
  k=float(r['RevK_baseline_g']); o=float(r['RevP_default_g']); st=float(r['RevP_study_platform_g'])
  expected_delta=o-k
  add('mass_outputs',r['size']+': arithmetic',abs(expected_delta-float(r['default_delta_g']))<1e-5 and abs((st-o)-float(r['study_vs_default_g']))<1e-5,f'baseline={k:.6f}; default={o:.6f}; study={st:.6f}')
# Original archive integrity.
orig=ROOT/'baseline_original/Apex_Stride_Pro_FINAL_CAD_Package_uploaded_original.zip'
h=hashlib.sha256(orig.read_bytes()).hexdigest() if orig.exists() else 'missing'
add('baseline_preservation','original uploaded ZIP hash',h=='e873fa6a1399eb4321d112c73e04fbaa920f409c53d2e136a1ca74bb32379d64',h)
# Save audit.
with (OUT/'FINAL_CLOSURE_VALIDATION.csv').open('w',newline='',encoding='utf-8') as f:
 w=csv.DictWriter(f,fieldnames=['group','item','result','detail']);w.writeheader();w.writerows(records)
groups={}
for r in records:
 d=groups.setdefault(r['group'],{'checks':0,'pass':0,'fail':0});d['checks']+=1;d['pass']+=r['result']=='PASS';d['fail']+=r['result']!='PASS'
summary={'revision':'Rev P final closure','checks':len(records),'pass':sum(r['result']=='PASS' for r in records),'fail':sum(r['result']!='PASS' for r in records),'elapsed_s':round(time.time()-t0,2),'groups':groups,'not_in_scope_or_not_run':['material-specific FEA','physical proof-load/impact/fatigue/pin retention/outsole grip and bond/fit/human trials','FreeCAD FCStd creation: FreeCAD unavailable','STEP creation: OpenSCAD has no STEP export; no verified B-rep converter available']}
(OUT/'FINAL_CLOSURE_VALIDATION.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
print(json.dumps(summary,indent=2))
if summary['fail']:
 print('FAILED RECORDS:')
 for r in records:
  if r['result']!='PASS':print(r)
 sys.exit(2)
