#!/usr/bin/env python3
"""Compile matrix for authoritative Rev P and print-prep source; also tests invalid-setting guards."""
from pathlib import Path
import subprocess,tempfile,csv,json,time
ROOT=Path(__file__).resolve().parents[2]
SOURCES=[('authoritative','revision/Apex_Stride_Pro_RevP.scad'),('printprep','PRINT_READY_BENCH_FIT_KIT_REV_P/source/Apex_Stride_Pro_RevP_PrintPrep.scad')]
rows=[]
t0=time.time()
with tempfile.TemporaryDirectory(prefix='apex_revp_compile_') as td:
 td=Path(td)
 for source_name,rel in SOURCES:
  src=ROOT/rel
  for size in (42,44,46):
   for width in (1.00,1.04,1.08):
    out=td/f'{source_name}_{size}_{width}.csg'
    cmd=['openscad','-o',str(out),'-D',f'eu_size={size}','-D',f'width_scale={width:.2f}','-D','part="assembly_fixed"',str(src)]
    cp=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=55)
    ok=cp.returncode==0 and out.exists() and out.stat().st_size>50 and 'ERROR:' not in cp.stdout
    rows.append({'check':f'{source_name}_EU{size}_width{width:.2f}','result':'PASS' if ok else 'FAIL','exit':cp.returncode,'output_bytes':out.stat().st_size if out.exists() else 0,'log_tail':cp.stdout[-250:].replace('\n','\\n')})
 # Expected-invalid user settings: exact assertion error required, not an exit-code assumption.
 for label,defs in [('invalid_size',['eu_size=40','width_scale=1.00']),('invalid_width',['eu_size=42','width_scale=1.02'])]:
  out=td/f'{label}.csg'
  cmd=['openscad','-o',str(out),'-D',defs[0],'-D',defs[1],'-D','part="assembly_fixed"',str(ROOT/SOURCES[0][1])]
  cp=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=55)
  expected='Assertion' in cp.stdout and 'ERROR:' in cp.stdout
  rows.append({'check':label,'result':'PASS' if expected else 'FAIL','exit':cp.returncode,'output_bytes':out.stat().st_size if out.exists() else 0,'log_tail':cp.stdout[-250:].replace('\n','\\n')})
outdir=ROOT/'revision/verification_results/revP_mass_audit';outdir.mkdir(parents=True,exist_ok=True)
with (outdir/'REVP_SOURCE_COMPILE_AND_GUARD_MATRIX.csv').open('w',newline='',encoding='utf-8') as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
summary={'checks':len(rows),'pass':sum(r['result']=='PASS' for r in rows),'fail':sum(r['result']=='FAIL' for r in rows),'seconds':round(time.time()-t0,2),'methods':'OpenSCAD CSG compile for assembly_fixed over 3 sizes×3 width presets and both source files; invalid size/width require explicit assertion log','rows':rows}
(outdir/'REVP_SOURCE_COMPILE_AND_GUARD_MATRIX.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({k:v for k,v in summary.items() if k!='rows'},indent=2))
raise SystemExit(1 if summary['fail'] else 0)
