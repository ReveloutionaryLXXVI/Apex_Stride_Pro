#!/usr/bin/env python3
"""Recalculate matched-density material scenario from fresh RevK/RevP mesh-volume export table.
This does not measure mass or claim PA2200 is approved. Requires only Python standard library.
"""
from pathlib import Path
import csv
ROOT=Path(__file__).resolve().parents[2]
AUDIT=ROOT/'revision/verification_results/revP_mass_audit'
IN=AUDIT/'REVK_REVP_FRESH_COMPONENT_MASS.csv'
SUM=AUDIT/'REVK_REVP_FRESH_MASS_SUMMARY.csv'
OUT=AUDIT/'MASS_BY_MATERIAL_CANDIDATE.csv'
with IN.open(newline='',encoding='utf-8') as f: comps=list(csv.DictReader(f))
with SUM.open(newline='',encoding='utf-8') as f: sums={r['size']:r for r in csv.DictReader(f)}
rows=[]
for size in ('EU42','EU44','EU46'):
 s=sums[size]
 parts=[r for r in comps if r['size']==size]
 volumes={rev:sum(float(r['volume_mm3']) for r in parts if r['revision']==rev and r['component'] in ('heel_deck','toe_carriage')) for rev in ('RevK','RevP')}
 masses={rev:float(s['RevK_baseline_g'] if rev=='RevK' else s['RevP_default_g']) for rev in ('RevK','RevP')}
 # Change only deck/toe density from legacy generic 1.01 to EOS PA2200 Balance stated 0.93 g/cm3.
 matched={rev:masses[rev]-(1.01-.93)*volumes[rev]/1000.0 for rev in ('RevK','RevP')}
 optional=float(s['RevP_study_platform_g'])-(1.01-.93)*volumes['RevP']/1000.0
 rows.append({
  'size':size,
  'RevK_legacy_assumptions_g':f"{masses['RevK']:.6f}",
  'RevP_legacy_assumptions_g':f"{masses['RevP']:.6f}",
  'RevP_minus_RevK_legacy_g':f"{masses['RevP']-masses['RevK']:+.6f}",
  'RevK_decks_PA2200_candidate_g':f"{matched['RevK']:.6f}",
  'RevP_decks_PA2200_candidate_g':f"{matched['RevP']:.6f}",
  'RevP_minus_RevK_matched_PA2200_g':f"{matched['RevP']-matched['RevK']:+.6f}",
  'RevP_mass_change_vs_legacy_estimate_g':f"{matched['RevP']-masses['RevP']:+.6f}",
  'RevP_optional_3p2_outsole_study_PA2200_decks_g':f"{optional:.6f}",
  'study_vs_RevP_default_PA2200_decks_g':f"{optional-matched['RevP']:+.6f}",
  'deck_volume_RevK_mm3':f"{volumes['RevK']:.3f}",
  'deck_volume_RevP_mm3':f"{volumes['RevP']:.3f}",
  'assumptions':'fresh native CAD mesh volumes; deck/toe = 0.93 g/cm3 EOS PA2200 Balance candidate; rails/bridges=2.70; pin/ring=7.90; outsole=1.20; footbed=0.20; estimated not measured'
 })
with OUT.open('w',newline='',encoding='utf-8') as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
assert all(abs(float(r['RevP_mass_change_vs_legacy_estimate_g']) + .08*float(r['deck_volume_RevP_mm3'])/1000)<1e-5 for r in rows)
print(f'PASS: wrote material-density scenario for {len(rows)} sizes from {len(comps)} fresh mesh component records -> {OUT}')
for r in rows: print(r['size'],r['RevP_decks_PA2200_candidate_g'],r['RevP_minus_RevK_matched_PA2200_g'],r['study_vs_RevP_default_PA2200_decks_g'])
