#!/usr/bin/env python3
"""Build current Rev Q release/closure documents from the already-generated source checks."""
from pathlib import Path
import csv, json, hashlib, os, subprocess, shutil
ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / 'revision/verification_results/revQ_material_integration'
MASS = OUT / 'REVK_VS_REVQ_MATERIAL_CARD_MASS_SUMMARY.csv'
rows = list(csv.DictReader(MASS.open(newline='', encoding='utf-8')))
checks = json.loads((OUT/'REVQ_SOURCE_COMPILE_AND_PACKAGE_CHECKS.json').read_text())
kin = json.loads((OUT/'kinematic_sweep/REV_Q_61_POSITION_KINEMATIC_CLEARANCE_SWEEP.json').read_text())
csg = json.loads((OUT/'exact_csg/REV_Q_EXACT_TOE_RAIL_INTERSECTION_TEST.json').read_text())
mass_sum = json.loads((OUT/'REVQ_MASS_AUDIT_SUMMARY.json').read_text())
# Native OpenSCAD preview is produced by the separate verified command in README.
preview = ROOT/'reports/REVQ_FULL_MOCKUP_EU44_FRESH.png'

def g(r, k): return float(r[k])

mass_lines = []
for r in rows:
    mass_lines.append(f"| {r['size']} | {g(r,'RevK_full_modeled_platform_g_outsole_1p20'):.3f} g | {g(r,'RevQ_full_modeled_platform_g_outsole_1p20'):.3f} g | {g(r,'RevQ_delta_platform_g'):+.3f} g |")

report = f'''# Apex Stride Pro — Rev Q material integration and engineering report

**Status: digital engineering package for review and non-wearable bench-fit mockup only. Not cleared for human wear.**

## Scope

Rev Q continues the existing Apex Stride Pro adjustable captured-rail architecture. It integrates the provided candidate material cards, a removable sliding EVA-footbed geometry, a material/hardware BOM, interface schedule, conceptual pneumatic circuit and pressure schedule, structural screening calculations, and a finite 20-item physical validation checklist. It does not replace Rev K or claim the absent spring/pneumatic assembly exists.

## Current authoritative files

- `revision/Apex_Stride_Pro_RevQ.scad` — authoritative editable CAD source.
- `PRINT_READY_BENCH_FIT_KIT_REV_Q/source/Apex_Stride_Pro_RevQ_PrintPrep.scad` — same geometry/selectors, plus a print-prep header.
- `revision/docs/ASSEMBLY_MANUAL_REV_Q.md` — bench/mockup procedure and future production sequence.
- `revision/docs/ASSEMBLY_FILE_MAP_REV_Q.csv` — 72 exact paths to the 42 fit-kit STL, 21 upper concept STL, and 9 optional outsole-study STL files.
- `revision/docs/BILL_OF_MATERIALS_REV_Q.csv` — size-specific modeled parts and purchased/unresolved candidates.
- `revision/docs/MATERIAL_PROPERTY_TABLE_REV_Q.csv` — source, orientation, process and missing property data.
- `revision/docs/COMPONENT_INTERFACE_FASTENER_SCHEDULE_REV_Q.csv` — interface dimensions/critical checks.
- `revision/docs/PNEUMATIC_CIRCUIT_REV_Q.svg` and `revision/docs/PNEUMATIC_CIRCUIT_PRESSURE_SCHEDULE_REV_Q.csv` — concept circuit and pressure-rating placeholders.
- `revision/docs/LOAD_ASSESSMENT_66KG_REV_Q.md` — documented analytical screening.
- `revision/docs/PHYSICAL_VALIDATION_CHECKLIST_REV_Q.csv` — 20 component-specific physical gates (not run).

Older revisions and reports remain in the archive for traceability. Rev Q documents above are the current deliverables; legacy report names in older revisions should be treated as historical, not current release state.

## Material inputs integrated

### Structural candidate: Materialise PA 12 SLS

Density 0.95 g/cm³ (950 kg/m³), tensile modulus 1650 MPa, tensile strength 48 MPa, flexural strength 41 MPa, flexural modulus 1500 MPa, elongation at break 20%, Shore D75, and HDT 86°C. The current published Materialise values say actual values vary with build/process, geometry and orientation. The tensile strength is **not** yield strength and is not used as a yield allowable. This material card is not transferable to generic FDM or to an unspecified MJF grade. Source: https://www.materialise.com/en/industrial/3d-printing-materials/pa12-sls .

### Flexible candidate: UltiMaker TPU 95A FFF data

The property table records the supplied manufacturer's orientation-specific data: XY-flat modulus 67±6 MPa, Z-up modulus 56±3 MPa; stress at break 23.7±2.1 MPa XY-flat and 6.4±0.5 MPa Z-up. These are FFF coupon results for that specific material/process; TPU is assigned only to non-primary protective/compliant parts. It is not treated as airtight, pressure-rated or the sole structural spring. Source: https://um-support-files.ultimaker.com/materials/2.85mm/tds/TPU-95A/TDS-TPU95A-V2.01-250915.pdf .

### Mechanical and moving hardware candidates

17-7 PH / UNS S17700 spring steel to the appropriate spring-wire specification is a material-family candidate only; actual spring geometry, heat-treatment condition, rate, preload, solid height, travel and fatigue data are absent. A commercial metal pin and a supplier-rated DIN 471 size-8 ring are required; the current meshes are envelopes/gauges only. Metal rails and bridges are assigned a *candidate* 6061-T6 density of 2.70 g/cm³ for mass estimates; alloy, temper, thread design, surface condition and supplier certificate remain unresolved. No torque values are invented.

## Mass calculation

Mass is calculated from fresh OpenSCAD-exported component volumes multiplied by the explicitly recorded candidate densities. The outsole mass uses 1.20 g/cm³ strictly as a placeholder; EVA density is unresolved, retaining-ring mass is not inferred from the schematic ring mesh, and fasteners/upper/spring/bladder/tubing/fittings/regulator/adhesives are excluded. This is **not total finished-shoe mass**.

| Size | Rev K comparable modeled platform | Rev Q comparable modeled platform | Rev Q minus Rev K |
|---|---:|---:|---:|
{chr(10).join(mass_lines)}

The default geometry therefore does **not** reduce like-for-like modeled mass versus Rev K under these material assumptions; it is roughly 3.0 g heavier in the stated scope. Do not claim a successful default mass reduction. The optional 3.2 mm outsole-study savings are 16.380 g (EU42), 17.020 g (EU44), and 17.661 g (EU46) relative to the 4.0 mm default using the same placeholder rubber density. That is an **unvalidated study only**; the 4.0 mm outsole stays default because traction, bond, tear and fatigue properties are not established.

## 66 kg load assessment

`F = m g = 66 × 9.81 = 647.46 N`. Ideal equal bilateral static load is 323.73 N per foot; a single foot may carry approximately 647.46 N before transient gait/impact loads. The load assessment includes explicitly illustrative (not measured) 1.5×/2×/3× sensitivities, a simplified deck-strip model, a conditional lock-pin beam demand, spring rate `k=F/δ` sensitivities, and pneumatic `p=F/A` demand scenarios. None is a material-specific validated factor of safety.

The simplified deck-strip model (28 mm nominal span, 4.1 mm roof, assumed contact widths 20/30/40/60 mm) gives one-foot nominal bending stress sensitivities of about 56.6/25.2/14.2/6.3 MPa. The 20 mm spread case exceeds the 41 MPa published flexural-strength reference. This is a **credible structural concern**, not proof of exact failure: the actual 3D load sharing and contact are unknown, but the model does not support a safety declaration. Materialise's tensile strength must not be treated as yield. Material-specific FEA and physical proof/fatigue testing are still required.

For a conditional horizontal pin load equal to one-foot body weight, the current simple split-rail beam model estimates about 159.1 MPa nominal bending on the unnotched 8 mm shaft; groove stress concentration, contact, ring capacity and fatigue are not modeled. It is not the vertical deck-load case.

The pneumatic `F/A` figures (up to 5.12 bar at a hypothetical 1265 mm² area for 647.46 N) are demand sensitivities only, **not safe pressure recommendations**. No operating pressure is assigned; select ratings for the bladder, tube, connectors, regulator, gauges, check/relief/dump valves and establish a whole-system pressure limit before guarded tests.

## Current test evidence

- Main Rev Q source/print-prep consistency and package suite: **{checks['pass']}/{checks['check_count']} PASS, {checks['fail']} FAIL**; 42 fit-kit parts, 21 upper concept meshes and 9 optional outsole-study meshes are included, and all 72 assembly-map paths resolve.
- Size/width/selector compile matrix is part of that suite (18 combinations); all 42 fitting STLs and 30 concept/study STLs passed topology/volume checks.
- Locked stop/toe-rail exact CSG: **{csg['pass']}/{csg['checks']} PASS** across EU42/EU44/EU46 and both rails; no positive-volume intersection detected. End-of-travel face contact is intentional, and manufacturing tolerance robustness is not established.
- Kinematic/source-coordinate sweep: **{kin['position_rows_pass']}/{kin['positions']} adjustment positions PASS**, {kin['checks']} arithmetic/geometry checks, all 3 discrete lock stations pass; minimum nominal rail/channel engagement {kin['min_rail_channel_engagement_mm']:.3f} mm and minimum bridge overlap {kin['min_bridge_overlap_mm']:.1f} mm. This is source geometry math, not a tolerance/deformation analysis.
- Fresh native mass exports: **{mass_sum['fresh_native_mesh_exports']}**, all reported watertight, winding-consistent, finite and positive-volume.
- Native full mockup preview: {'generated' if preview.exists() else 'not found'} at `reports/REVQ_FULL_MOCKUP_EU44_FRESH.png`.
- Earlier revisions are preserved. The original Rev K legacy suite remains historical baseline evidence; Rev Q current checks are above.

## Not run / unsupported in this environment

- No FreeCAD executable, CalculiX/CCX solver or Gmsh was available; no `.FCStd` document, valid analytic STEP export or material-specific FEA is claimed. OpenSCAD `.scad` is the editable source; STL exports are tessellated meshes only.
- No physical material coupons, manufactured shoe, real spring, bladder, valves, rated fittings, upper or bonded rubber outsole are present. Therefore no physical load, impact, fatigue, spring, pressure/leak, pin-pullout, sole adhesion, slip, fit or human-wear test has been conducted.
- The 55×23×15.1 mm spring/bladder envelope is a packaging study that intersects deck-pocket rib geometry; it is **not a free continuous cavity** and the actual spring/bladder system is absent. Integration requires a new clearance-resolved core design before production.
- Upper STLs are conceptual shapes and not stitched footwear patterns. Fit/retention is not validated.

## Exact procurement/technical gates

1. Order an exact Materialise PA 12 SLS production build (or substitute a different manufacturer's/process card and rerun analysis); obtain build orientation, lot, dimensions and traceability.
2. Obtain certified rail/bridge alloy/temper and approve tapped-thread design, M4 fastener length/grade/engagement, washers/locking method and torque from calculation/manufacturer data.
3. Select a commercial metal 8 mm pin and exact DIN 471 ring/groove drawing; confirm pin stack length, tolerance, thrust rating and retention.
4. Select a 17-7 PH spring with supplier-provided rate/load curve, preload, free/solid height, travel, condition and fatigue rating; engineer positive seats/retainers and a pressure-loss failsafe.
5. Select a flex-rated TPU bladder with drawing/effective area/working-burst-cycle data, compatible 4 mm OD PU tubing (including ID/wall rating), push fittings, check valve, regulator/gauges, relief and dump; then set operating pressure based on weakest component and guarded testing.
6. Select EVA foam (density, compression-deflection, compression set), textile cover and approved removable attachment method.
7. Select rubber compound with 60–70 Shore A target and actual abrasion/tear/flex/traction data; approve PA12-compatible outsole bond/primer or design positive retention. Test whole shoe slip using ASTM F2913-24; use ISO 17707 only if its rigidity criterion is applicable and ISO 17708 for upper/sole adhesion as appropriate.
8. Develop the last-matched polyester/engineered mesh upper with nylon overlays, counter, collar/tongue foam, closures and reinforced sewn anchors; perform retention and seam tests.
9. Complete all 20 entries in `revision/docs/PHYSICAL_VALIDATION_CHECKLIST_REV_Q.csv` in controlled fixtures and obtain independent footwear/mechanical engineering approval before any human wear trial.

**Release decision: digital integration is substantially complete for review and non-wearable fitting mockups. Human wear is NOT CLEARED.**
'''
(ROOT/'FINAL_ENGINEERING_REPORT_REV_Q.md').write_text(report, encoding='utf-8')
(ROOT/'FINAL_ENGINEERING_CLOSURE_REPORT.md').write_text(report, encoding='utf-8')

register = f'''# Rev Q material integration test register

Date of package generation: 2026-10-16 (UTC+04 package environment). Only results actually present in the test artefacts are reported.

| Group | Result | Evidence | Meaning/limit |
|---|---:|---|---|
| Current source/document/compile/mesh/package check | {checks['pass']} PASS / {checks['fail']} FAIL | `revision/verification_results/revQ_material_integration/REVQ_SOURCE_COMPILE_AND_PACKAGE_CHECKS.csv` and JSON | Includes 18 compile/selector variants, 42 fit-kit STLs, 21 upper concept meshes, 9 outsole-study meshes, exact source parity, mass arithmetic, required docs and 72 file references. |
| Exact toe-carriage vs rail CSG | {csg['pass']}/{csg['checks']} PASS | `revision/verification_results/revQ_material_integration/exact_csg/REV_Q_EXACT_TOE_RAIL_INTERSECTION_TEST.csv` | Three sizes × two rails; confirms no positive-volume intersection in nominal geometry, not tolerance safety. |
| Kinematic/registration sweep | {kin['position_rows_pass']}/{kin['positions']} positions pass; {kin['checks']} checks | `revision/verification_results/revQ_material_integration/kinematic_sweep/REV_Q_61_POSITION_KINEMATIC_CLEARANCE_SWEEP.csv` | Nominal coordinate arithmetic; no flex/tolerance/wear/dynamic effects. |
| Discrete lock registration | 3/3 size stations pass | `revision/verification_results/revQ_material_integration/kinematic_sweep/REV_Q_DISCRETE_LOCK_REGISTRATION_RECHECK.csv` | Mathematical hole registration only. |
| Native mesh-volume calculation | {mass_sum['fresh_native_mesh_exports']} exports pass | `revision/verification_results/revQ_material_integration/REVQ_COMPONENT_MASS_MATERIAL_CARD.csv` | Volume/mass estimates; omitted components and placeholder outsole density documented. |
| Full CAD preview | {'PASS' if preview.exists() else 'NOT RUN'} | `reports/REVQ_FULL_MOCKUP_EU44_FRESH.png` | Visual preview only. Not a printable monolithic solid. |
| 66 kg arithmetic / analytic screens | PASS as calculations only | `revision/docs/LOAD_ASSESSMENT_66KG_REV_Q.md`; `reports/REVQ_DECK_SCREENING_SENSITIVITY.csv`; `reports/REVQ_PNEUMATIC_PRESSURE_DEMAND_SENSITIVITY.csv`; `reports/REVQ_SPRING_RATE_DEMAND_SENSITIVITY.csv` | Simplified sensitivity equations, not FEA, physical proof or safety certification. One narrow-contact deck case exceeds the 41 MPa flexural reference. |
| FEA | NOT RUN | No FreeCAD/CalculiX/Gmsh installed | No native solver results. |
| FreeCAD `.FCStd` / STEP | NOT RUN | FreeCAD not available; OpenSCAD emits CSG and STL, not native feature tree/STEP | No fabricated surrogate exports. |
| Physical proof/impact/fatigue/pin/pressure/sole/upper/fit tests | NOT RUN | No manufactured specimen or test fixtures | See 20-item physical checklist. |
| Human walking/running tests | NOT RUN / NOT AUTHORIZED | Not independently qualified | Must wait until all physical gates pass and independent approval exists. |

## Known issue / release blockers

1. The default Rev Q estimated platform is 3.006884–3.077285 g heavier than Rev K on the comparable mass scope, despite the supplied PA12 density being used. The default weight-reduction target therefore **fails**. The 3.2 mm outsole study saves an estimated 16.380–17.661 g relative to 4.0 mm default but is unvalidated and remains opt-in.
2. The simplified deck-strip sensitivity at 20 mm contact spread calculates 56.6 MPa nominal versus a 41 MPa published flexural-strength reference. This simplified model is not a precise prediction, but it is a structural concern requiring full analysis and physical verification.
3. The spring/bladder envelope intersects deck pocket ribs and is not a continuous usable cavity. Actual spring and pneumatic components are not modeled.
4. Upper meshes are visual concepts, not stitched patterns.
5. Monolithic aggregate platform mesh must not be used as a print file; use only indexed individual component files for non-wearable fit/mockup.

Status categories are kept separate: CAD/geometry checks are not material strength tests; analytic sensitivity is not FEA; neither is a physical test.
'''
(ROOT/'FINAL_CLOSURE_TEST_REGISTER.md').write_text(register, encoding='utf-8')
(ROOT/'FINAL_TEST_REGISTER_REV_Q.md').write_text(register, encoding='utf-8')

speed = '''# Apex Stride Pro Rev Q — staged speed-comparison protocol

**Not authorized for human footwear trials until all physical release gates and independent approval pass.** The current files cannot establish a speed benefit; mass reduction alone does not imply improved running speed or energy return.

## Stage 0 — prerequisite design/test release

Complete material/process selection, production geometry, upper and closure design, qualified metal pin/ring, spring and seat/retainer, rated bladder/circuit and pressure protection, outsole compound/bond, fit envelope, material-specific structural analysis, proof-load/fatigue/pin-retention/pressure/leak/traction/bond/seam/fit checks. Freeze the exact hardware and build. Any failure resets to engineering review; no subject trials until approval.

## Stage 1 — bench characterization (no human)

Equipment: calibrated force/load frame; displacement sensors; high-speed video; pressure transducers at the chamber and regulator output; temperature sensor; cycle actuator/impact apparatus in a guarded enclosure; leak-test tools; slip/traction equipment for whole footwear; mass scale; inspection magnification. Record serial/lot, CAD hash, print job orientation, post-processing, all hardware, calibration and ambient conditions.

At minimum measure: mass by component; static force-displacement curve; left/right rail and pin registration; lock retention and axial pull-out; spring load-deflection and preload; bladder effective area and pressure-force curve; pressure-loss collapse behavior; maximum stops; permanent set; leakage; dynamic force/deflection/rebound; cyclic stiffness and damage; outsole peel/shear, flex, abrasion and slip resistance. Engineer defines load waveform, load multipliers, cycles, acceptable permanent set and failure criteria before tests; do not borrow illustrative 1.5×/2×/3× values from the screening report as acceptance requirements.

## Stage 2 — footwear compliance and controlled fit

Use ASTM F2913-24 whole-shoe slip method and ISO 17708 upper/sole adhesion where applicable; use ISO 17707 outsole flex resistance only if the product falls within the standard's applicable rigidity scope. Define dry/wet/contaminated flooring and pass thresholds before testing. Complete expert fitting/pressure/heel-retention/closure/clearance review for intended sizes. Only proceed if independent engineering and footwear review records signed approval.

## Stage 3 — supervised walking comparison

After approval only. Randomized crossover comparing Rev Q against ordinary footwear matched for fit and size. Minimum preliminary design: 12 participants across intended sizes, 2 sessions each, at least 3 valid trials per footwear condition per session; final sample size should be determined by an a priori power analysis. Use same socks, floor, temperature and standardized speed/metronome. Collect body mass, footwear mass, instrumented insole pressure/force, 3D motion capture or validated IMUs, step length/cadence, ground contact time, comfort/pressure survey and any instability/failure. Randomize order and provide rest. Stop immediately for pain, loss of balance, lock migration, noise/crack, pressure loss, sole movement or adverse event.

## Stage 4 — running/sprint comparison (only after walking gate)

Do not initiate running or sprinting based on a successful walk-only test. Obtain separate written approval, repeat the sample-size/power calculation, use instrumented treadmill/track, force plates, timing gates/high-speed video and kinematics. Preregister primary outcomes (e.g., 20 m/30 m time, speed, cadence, contact time and metabolic cost if available), randomization, familiarization, minimum trial count (at least 5 valid trials/condition/session), rest, fatigue controls and stopping criteria. Report individual data, means, confidence intervals and adverse events; no post-hoc selection of fastest trials. Speed or performance improvement requires statistically and practically meaningful between-footwear differences, not just a lighter part.

## Calculations and reporting

For each condition calculate mean and SD over valid trials, paired participant-level difference, percentage change `100×(RevQ−control)/control`, 95% confidence intervals and preregistered paired statistical test. Publish all excluded trials and reasons. No speed results exist yet; all human stages are NOT RUN.
'''
(ROOT/'revision/docs/SPEED_TEST_PROTOCOL_REV_Q.md').write_text(speed, encoding='utf-8')

readme = '''# Apex Stride Pro — Rev Q material integration package

## Authoritative files

- Editable main CAD: `revision/Apex_Stride_Pro_RevQ.scad`
- Matching print-prep source: `PRINT_READY_BENCH_FIT_KIT_REV_Q/source/Apex_Stride_Pro_RevQ_PrintPrep.scad`
- Final current engineering report: `FINAL_ENGINEERING_REPORT_REV_Q.md`
- Consolidated check register: `FINAL_CLOSURE_TEST_REGISTER.md`
- Assembly: `revision/docs/ASSEMBLY_MANUAL_REV_Q.md`
- Exact path/component map: `revision/docs/ASSEMBLY_FILE_MAP_REV_Q.csv`
- BOM: `revision/docs/BILL_OF_MATERIALS_REV_Q.csv`
- Material card/property source list: `revision/docs/MATERIAL_PROPERTY_TABLE_REV_Q.csv`
- Interface/fastener schedule: `revision/docs/COMPONENT_INTERFACE_FASTENER_SCHEDULE_REV_Q.csv`
- Pneumatic circuit + pressure schedule: `revision/docs/PNEUMATIC_CIRCUIT_REV_Q.svg`, `revision/docs/PNEUMATIC_CIRCUIT_PRESSURE_SCHEDULE_REV_Q.csv`
- 66 kg load assessment: `revision/docs/LOAD_ASSESSMENT_66KG_REV_Q.md`
- Physical validation checklist: `revision/docs/PHYSICAL_VALIDATION_CHECKLIST_REV_Q.csv` (20 line items; physical results remain NOT RUN)
- Speed comparison protocol: `revision/docs/SPEED_TEST_PROTOCOL_REV_Q.md`
- Mass outputs: `revision/verification_results/revQ_material_integration/`
- Preview and rendered diagrams: `reports/`
- Untouched input baseline: `baseline_original/`

Older revision sources/reports are preserved for provenance, but Rev Q is the current source. Do not use historical reports as the current release state.

## Included native/print files

- 42 individual size-specific bench-fit/mocks (14 each for EU42/EU44/EU46) in `PRINT_READY_BENCH_FIT_KIT_REV_Q/stl/`.
- 21 upper-concept STL envelopes in `PRINT_READY_BENCH_FIT_KIT_REV_Q/upper_concept_not_wearable/`. These are not fitted/stitchable footwear patterns.
- 9 optional 3.2 mm outsole study meshes in `PRINT_READY_BENCH_FIT_KIT_REV_Q/optional_3p2mm_outsole_study/`. Study only; do not substitute for the 4.0 mm baseline without validation.
- These are fit/geometry mockups, not approved structural production parts. Rails/bridges/pin/ring STLs are visual gauges; production parts must be metal or suitable purchased components.

## Dependencies verified in the build environment

- OpenSCAD executable `openscad`
- Python 3
- NumPy and trimesh for mesh/property checking
- CairoSVG for rendering SVG schematics to PNG

FreeCAD, CalculiX/CCX and Gmsh were not available in the build environment, so no `.FCStd`, proper analytic STEP, or FEA output is claimed. OpenSCAD `.scad` is the editable native design source, and STL is a tessellated mesh.

## Regenerate / verify

Run from package root:

```bash
python3 revision/tools/create_revq_material_integration.py
python3 revision/tools/export_print_fit_kit_revQ.py
python3 revision/tools/export_upper_concepts_revQ.py
python3 revision/tools/export_optional_outsole_study_revQ.py
python3 revision/tools/recalculate_mass_materials_revQ.py
python3 revision/tools/run_revq_kinematic_clearance_sweep.py
python3 revision/tools/test_revq_locked_stop_intersections.py
python3 revision/tools/run_revq_source_compile_checks.py
python3 revision/tools/build_revq_release_report.py
```

Native OpenSCAD preview, if xvfb is available:

```bash
xvfb-run -a openscad --imgsize=1400,1000 --viewall --autocenter \
  -o reports/REVQ_FULL_MOCKUP_EU44_FRESH.png \
  -D 'eu_size=44' -D 'width_scale=1.0' -D 'part="full_mockup"' \
  revision/Apex_Stride_Pro_RevQ.scad
```

These commands verify editable source, exported mesh geometry, nominal interference/registration and calculations. They do not validate material strength or a wearable product. No physical tests or human trials are represented as performed.

## Material/weight notes

The main structural deck candidate is the specific Materialise PA 12 SLS card, not generic FDM/MJF material. TPU 95A uses the referenced UltiMaker specimen/process card and is only proposed for non-primary flexible components. The spring, rails, bridges, pin/ring, real pneumatic bladder/circuit, EVA density, outsole rubber compound and upper construction remain supplier/process candidates until an exact product is selected.

Fresh native-geometry mass estimates use 0.95 g/cm³ PA12, 2.70 g/cm³ provisional 6061-T6 density for metal rail/bridge candidates, 7.75 g/cm³ pin candidate, and placeholder 1.20 g/cm³ rubber. EVA, actual ring, fasteners, upper, spring, bladder/tubing/fittings, regulator and adhesive are excluded. On this like-for-like scope, Rev Q is about 3 g heavier than Rev K; the default geometry has not achieved the mass-reduction target. The optional 3.2 mm outsole savings are not validated.

## Release status

**Suitable for engineering review and non-wearable fit mockup only. Not cleared for human wear.** The core spring/bladder envelope overlaps pocket ribs and is not a valid continuous cavity; actual spring/bladder/rated pneumatic circuit are absent. The deck screening model includes a 20 mm contact-spread case whose estimated strip stress exceeds the nominal PA12 flexural-strength reference. Resolve with a qualified engineer, exact manufacturing/card inputs, 3D FEA and guarded physical tests before wear trials.
'''
(ROOT/'README.md').write_text(readme, encoding='utf-8')

status = '''# Project status and release gate — Rev Q

## Digital work completed

- Existing Rev K baseline and historical revisions preserved.
- Rev Q editable OpenSCAD design and mirrored print-prep source integrated.
- 42 individual fitting/mockup STLs, 21 upper concept meshes and 9 optional outsole-study meshes exported and checked.
- Material candidate table, 60-row BOM, 72-row file map, interface/fastener schedule, assembly manual, pneumatic circuit/pressure schedule, 66 kg load screen, speed protocol, and 20-item physical validation checklist created.
- Native preview rendered; 66 actual geometry-volume exports used in mass audit.
- Current-source validator: 115 PASS, 0 FAIL; exact toe-rail CSG 6/6; 61-position kinematic sweep and three lock-registration stations pass. See test register for scope/limits.

## Explicit design failures/concerns

- Like-for-like modeled platform mass is 3.007–3.077 g higher than Rev K under the documented density scope; default weight reduction objective is not met.
- Simplified deck-strip sensitivity for 20 mm load spread estimates 56.6 MPa nominal stress versus the 41 MPa Materialise PA12 SLS flexural-strength reference. This is not accurate enough to declare failure of the actual 3D deck, but it is a risk flag requiring 3D contact FEA and physical proof testing.
- Actual spring/bladder envelope is not a usable cavity because it overlaps ribs. Real bladder, spring, spring seats, hard stops, retention, tubing, check valve, regulator, relief/dump, gauges, and failsafe are not selected or modeled.
- The monolithic lower-platform export is not a valid printable single solid and is not included as a manufacturing file. Use component STLs only for non-wearable geometry/mockup.

## NOT RUN

No FEA solver in available environment, no FreeCAD FCStd/STEP export, no physical loads/impact/fatigue/traction/adhesion/pressure/fit tests, no finished upper, no human walking/running trials. Test tasks appear individually in `revision/docs/PHYSICAL_VALIDATION_CHECKLIST_REV_Q.csv`.

## Release decision

Rev Q is an engineering-review and non-wearable mockup package. **NOT cleared for human wear.** Do not infer safety from passing software geometry checks. A qualified engineering review and all defined physical qualification gates remain required.
'''
(ROOT/'PROJECT_STATUS_AND_RELEASE_GATE.md').write_text(status, encoding='utf-8')

verification = f'''# Package verification — Rev Q material integration

- Authoritative source: `revision/Apex_Stride_Pro_RevQ.scad`
- Print-prep source: `PRINT_READY_BENCH_FIT_KIT_REV_Q/source/Apex_Stride_Pro_RevQ_PrintPrep.scad`
- Current source/mesh/docs validator: {checks['pass']} PASS / {checks['fail']} FAIL.
- Exact locked-stop/toe-rail CSG checks: {csg['pass']}/{csg['checks']} PASS.
- Adjustment kinematic sweep: {kin['position_rows_pass']}/{kin['positions']} positions pass; {kin['checks']} geometry/arithmetic checks; 3/3 size lock-station registrations pass.
- Fresh native volume exports: {mass_sum['fresh_native_mesh_exports']} checked; all finite/positive volume and watertight under trimesh audit.
- Full OpenSCAD preview exists: {preview.exists()}.
- Main source and print-prep source geometry/selectors match exactly after the documented five-line print-prep banner.
- Assembly map paths: {len(list(csv.DictReader((ROOT/'revision/docs/ASSEMBLY_FILE_MAP_REV_Q.csv').open(newline='',encoding='utf-8'))))}, all resolve under package root.
- Original baseline folder preserved: {(ROOT/'baseline_original').exists()}.

No FEA, physical test, FCStd or proper STEP is claimed. Final archive-level CRC/SHA verification is performed by the packaging step and recorded in the external `.sha256` sidecar.

**Wear release: NOT CLEARED.**
'''
(ROOT/'FINAL_PACKAGE_VERIFICATION.md').write_text(verification, encoding='utf-8')
print('Wrote current README/status/reports; main checks', checks['pass'], 'PASS; exact CSG', csg['pass'], '/', csg['checks'], '; kinematic', kin['position_rows_pass'], '/', kin['positions'])
