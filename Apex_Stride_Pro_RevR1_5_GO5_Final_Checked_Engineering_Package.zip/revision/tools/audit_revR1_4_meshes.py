#!/usr/bin/env python3
"""Fresh audit of all active R1.4 fit-kit meshes; reports raw and topology-processed import states."""
from pathlib import Path
import csv, json, math
import numpy as np
import trimesh
ROOT=Path(__file__).resolve().parents[2]
FIT=ROOT/'PRINT_READY_BENCH_FIT_KIT_REV_R'
OUT=ROOT/'revision/verification_results/revR1_4_go1_go2'
OUT.mkdir(parents=True,exist_ok=True)
files=sorted([*FIT.glob('stl/**/*.stl'),*FIT.glob('upper_concept_not_wearable/**/*.stl'),*FIT.glob('optional_3p2mm_outsole_study/**/*.stl')])
# deduplicate if path patterns overlap
files=sorted(set(files))
rows=[]
for p in files:
    rel=p.relative_to(ROOT).as_posix()
    raw=trimesh.load_mesh(p, process=False, force='mesh')
    raw_finite=bool(np.isfinite(raw.vertices).all()) and bool(np.isfinite(raw.faces).all())
    raw_pos=bool(raw.volume>0) if raw.is_watertight else bool(raw.area>0)
    welded=raw.copy()
    welded.merge_vertices()
    # API compatibility across installed trimesh versions
    if hasattr(welded,'remove_duplicate_faces'): welded.remove_duplicate_faces()
    elif hasattr(welded,'unique_faces'):
        mask=welded.unique_faces(); welded.update_faces(mask)
    if hasattr(welded,'remove_degenerate_faces'): welded.remove_degenerate_faces()
    elif hasattr(welded,'nondegenerate_faces'):
        mask=welded.nondegenerate_faces(); welded.update_faces(mask)
    welded.remove_unreferenced_vertices()
    if len(welded.faces): trimesh.repair.fix_normals(welded, multibody=True)
    bounds=np.asarray(welded.bounds)
    ext=bounds[1]-bounds[0]
    volume=float(welded.volume)
    # expected artifacts: actual solids may intentionally be multi-body? all should be valid after weld.
    rows.append({
      'file':rel, 'bytes':p.stat().st_size, 'vertices_raw':int(len(raw.vertices)), 'faces_raw':int(len(raw.faces)),
      'raw_watertight':bool(raw.is_watertight), 'raw_finite':raw_finite,
      'vertices_after_weld':int(len(welded.vertices)), 'faces_after_weld':int(len(welded.faces)),
      'watertight_after_weld':bool(welded.is_watertight), 'winding_consistent_after_weld':bool(welded.is_winding_consistent),
      'finite_after_weld':bool(np.isfinite(welded.vertices).all()), 'positive_volume_or_area':bool(volume>0 or welded.area>0),
      'degenerate_faces_after_weld':int((welded.area_faces<=1e-10).sum()),
      'components_after_weld':int(len(welded.split(only_watertight=False))), 'volume_mm3_after_weld':volume,
      'x_extent_mm':float(ext[0]),'y_extent_mm':float(ext[1]),'z_extent_mm':float(ext[2]),
      'z_min_mm':float(bounds[0,2]), 'z_max_mm':float(bounds[1,2])})
# all mesh files plus one map audit
p_csv=OUT/'REV_R1_4_ALL_72_MESH_AUDIT.csv'
with p_csv.open('w',newline='',encoding='utf-8') as f:
    w=csv.DictWriter(f,fieldnames=list(rows[0].keys()),lineterminator='\n');w.writeheader();w.writerows(rows)
summary={
 'revision':'Rev R1.4', 'method':'Fresh read of all active STL files; topology checks first on imported raw facets, then after welding duplicate triangle vertices and removing duplicate/degenerate faces without changing intended geometry.',
 'mesh_count':len(rows), 'raw_finite_pass':sum(r['raw_finite'] for r in rows), 'raw_watertight':sum(r['raw_watertight'] for r in rows),
 'welded_watertight_pass':sum(r['watertight_after_weld'] for r in rows), 'welded_winding_pass':sum(r['winding_consistent_after_weld'] for r in rows),
 'welded_finite_pass':sum(r['finite_after_weld'] for r in rows), 'positive_volume_or_area_pass':sum(r['positive_volume_or_area'] for r in rows),
 'zero_degenerate_faces':sum(r['degenerate_faces_after_weld']==0 for r in rows),
 'non_watertight_after_weld':[r['file'] for r in rows if not r['watertight_after_weld']],
 'inconsistent_winding_after_weld':[r['file'] for r in rows if not r['winding_consistent_after_weld']],
 'nonfinite':[r['file'] for r in rows if not r['finite_after_weld']],
 'nonpositive':[r['file'] for r in rows if not r['positive_volume_or_area']],
 'limitations':['Topology processing is a software interpretation of STL facets; the source STL bytes are not rewritten by this audit. Manufacturing mesh acceptance and slicer/toolpath checks remain separate.', 'Watertightness and non-zero mesh volume do not establish part strength, tolerance fit or wear safety.']}
(OUT/'REV_R1_4_ALL_72_MESH_AUDIT.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
print(json.dumps(summary,indent=2))
