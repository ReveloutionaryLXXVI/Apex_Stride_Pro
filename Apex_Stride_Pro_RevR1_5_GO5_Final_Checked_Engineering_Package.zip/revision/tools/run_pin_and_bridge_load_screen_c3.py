#!/usr/bin/env python3
"""Corrected Rev P C3 lock-pin/rail/bridge analytical demand screen.
This is a simplified beam and section calculation, not FEA, physical test, or safety approval.
"""
from pathlib import Path
import math,csv,json,re
ROOT=Path(__file__).resolve().parents[2]
SRC=ROOT/'revision/Apex_Stride_Pro_RevP.scad'
OUT=ROOT/'revision/verification_results/REV_P_C3_SAFETY_CORRECTION'
OUT.mkdir(parents=True,exist_ok=True)
s=SRC.read_text()
def num(k):
 m=re.search(r'^\s*'+re.escape(k)+r'\s*=\s*([-+0-9.]+)\s*;',s,re.M)
 if not m: raise ValueError(f'Missing parameter {k}')
 return float(m.group(1))
body_mass=66.0; g=9.81; F=body_mass*g
pin_d=num('lock_pin_d'); root_d=num('pin_groove_root_d'); pin_entry=num('pin_entry_y'); rail_y=num('rail_y'); head_width=num('rail_head_width'); index_d=num('rail_index_hole_d'); pitch=2*num('mm_per_eu_size'); bridge_width=num('bridge_flange_width'); bridge_t=num('bridge_flange_thickness'); hole_d=num('bolt_hole_d'); groove_y=-pin_entry-num('pin_tail_extension')+num('pin_groove_end_margin')+num('pin_groove_width')/2.0
# Pin beam: two equal longitudinal rail loads at ±rail_y; side-boss support points approximated at ±pin_entry.
# Max moment lies between the two rail loads and is M=(H/2)*(pin_entry-rail_y); the Ø8 mm shaft there is unnotched.
lever=pin_entry-rail_y
Zshaft=math.pi*pin_d**3/32.0
Zroot=math.pi*root_d**3/32.0
Aroot=math.pi*root_d**2/4.0
Ashaft=math.pi*pin_d**2/4.0
rail_bearing_area=pin_d*head_width
between_hole_ligament=pitch-index_d
half_hole_ligament=between_hole_ligament/2.0
rail_tear_area=2*head_width*half_hole_ligament
bridge_net=(bridge_width-2*hole_d)*bridge_t
# User-load fractions are transparent sensitivities, not real-world measured loads or specified acceptance criteria.
rows=[]
for frac in (0.10,0.20,0.50,1.00):
 H=F*frac; rail_load=H/2.0; moment=rail_load*lever
 sig_shaft=moment/Zshaft
 # Groove is at y≈-44.25 mm; a point support at the side face would give this small nominal moment,
 # but the groove lies within the 5.5 mm boss and contact stress needs an actual bearing/contact model.
 groove_offset=pin_entry-abs(groove_y)
 sig_groove_point=(rail_load*groove_offset)/Zroot
 tau_avg=rail_load/Aroot
 tau_max=4*rail_load/(3*Aroot)
 rows.append({
  'horizontal_load_fraction_of_body_weight':frac,'horizontal_load_N':H,'total_body_weight_reference_N':F,
  'assumed_rail_load_each_N':rail_load,'assumed_support_to_rail_load_lever_mm':lever,
  'pin_max_bending_moment_Nmm':moment,'pin_max_unnotched_shaft_bending_stress_MPa':sig_shaft,
  'pin_groove_root_d_mm':root_d,'groove_point_support_bending_stress_MPa_NOT_VALIDATED':sig_groove_point,
  'pin_root_average_shear_MPa':tau_avg,'pin_root_max_circular_shear_MPa':tau_max,
  'reference_17_4PH_H900_yield_MPa':1170.0,
  'reference_yield_ratio_unnotched_midspan_only':1170.0/sig_shaft,
  'rail_projected_bearing_area_mm2_per_rail':rail_bearing_area,
  'rail_pin_bearing_stress_MPa_per_rail':rail_load/rail_bearing_area,
  'index_hole_pitch_mm':pitch,'ligament_between_adjacent_index_holes_mm':between_hole_ligament,
  'rail_tearout_area_mm2_per_rail_assumed':rail_tear_area,
  'rail_adjacent_hole_average_tearout_shear_MPa_per_rail':rail_load/rail_tear_area,
  'bridge_net_tension_area_one_strap_mm2':bridge_net,
  'bridge_net_tension_stress_MPa_one_strap_all_H':H/bridge_net,
  'bridge_net_tension_stress_MPa_two_straps_equal_share':H/(2*bridge_net),
  'interpretation':'All H assigned to pin; two symmetric rail loads share H equally. Beam supports at side-boss outer faces are a simplified model. Bridge screws also lock the carriage, so real load share is unspecified.'})
with (OUT/'C3_HORIZONTAL_LOCK_PIN_LOAD_SCREEN.csv').open('w',newline='',encoding='utf-8') as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
# Separate axial extraction demand sensitivity at the retaining ring/groove.
shoulder_area=math.pi*(pin_d**2-root_d**2)/4.0
pull_rows=[]
for P in (50.0,100.0,250.0,500.0):
 pull_rows.append({'hypothetical_axial_pin_pull_N':P,'groove_shoulder_annular_area_mm2':shoulder_area,
                   'nominal_shoulder_bearing_stress_MPa':P/shoulder_area,
                   'ring_axial_capacity_known':False,
                   'status':'DEMAND ONLY — retaining-ring capacity and boss retention unverified'})
with (OUT/'C3_AXIAL_PIN_RETENTION_SENSITIVITY.csv').open('w',newline='',encoding='utf-8') as f:
 w=csv.DictWriter(f,fieldnames=list(pull_rows[0]));w.writeheader();w.writerows(pull_rows)
lines=['# C3 corrected lock-pin, rail and bridge load screen','',
       '**Analytical screening only — not FEA, physical load testing, or wear-release approval.**','',
       f'66 kg × 9.81 m/s² = **{F:.2f} N** total body weight. An equal bilateral static split is {F/2:.2f} N/foot. A single-foot static load can reach {F:.2f} N before transient effects. Horizontal-load fractions below are transparent sensitivity values, not measured gait data.','',
       '## Cross-pin bending sensitivity','',
       f'Model assumption: total horizontal force H splits equally to two rail holes at ±{rail_y:.2f} mm; simple pin supports are placed at side faces ±{pin_entry:.2f} mm. The lever arm is {lever:.2f} mm. Maximum bending is between the rail loads, on the **unnotched Ø{pin_d:.1f} mm shaft**, not at the retaining groove near the side boss. `M=(H/2)×lever`; `σ=M/(πd³/32)`. The groove lies about {pin_entry-abs(groove_y):.2f} mm from the outside-face support in this simplified model, but it sits inside the 5.5 mm boss; local contact/groove stress cannot be determined from point supports.','',
       '| Horizontal H / body weight | H (N) | Max unnotched shaft bending (MPa) | Reference yield ratio* | Rail bearing each (MPa) | Adjacent-hole tear-out shear each (MPa) | One bridge strap net tension (MPa) |','|---:|---:|---:|---:|---:|---:|---:|']
for r in rows:
 lines.append(f'| {r["horizontal_load_fraction_of_body_weight"]:.0%} | {r["horizontal_load_N"]:.2f} | {r["pin_max_unnotched_shaft_bending_stress_MPa"]:.2f} | {r["reference_yield_ratio_unnotched_midspan_only"]:.2f} | {r["rail_pin_bearing_stress_MPa_per_rail"]:.3f} | {r["rail_adjacent_hole_average_tearout_shear_MPa_per_rail"]:.3f} | {r["bridge_net_tension_stress_MPa_one_strap_all_H"]:.2f} |')
lines += ['', '*Reference yield ratio uses 1170 MPa typical/reference yield listed for wrought 17-4PH H900 candidate stock, not a design allowable or lot-certified property. It applies only to nominal unnotched pin bending, not ring groove, impact, fatigue, corrosion, support contact, or actual load-sharing.','',
          '## Retaining-ring axial extraction sensitivity','',
          f'The theoretical annular shoulder area at shaft Ø{pin_d:.1f}/groove root Ø{root_d:.1f} is {shoulder_area:.3f} mm². The companion CSV calculates nominal shoulder stress for hypothetical 50/100/250/500 N pin-pull loads. These are **not capacity checks**: the purchased DIN 471 ring rating, installation clearances, ring deformation and plastic boss response are unknown.','',
          '## What this screen can and cannot establish','',
          'It identifies the pin bending, rail bearing/tear-out and bridge strap net-section demand for a simple horizontal lock load. It does not solve the vertical deck/rail contact problem, material anisotropy, stress concentration at the retaining groove, threaded fastening, pin/bridge load sharing, fatigue or impact. The 2.15 mm polymer web, 4.1 mm nominal deck roof and 0.4 mm vertical rail-channel clearance still require a validated FE contact model and physical proof/fatigue testing. Current tooling has no installed FEA solver or FreeCAD B-rep export tool. No physical test was run; the shoe remains not cleared for human wear.']
(OUT/'C3_CORRECTIVE_STRUCTURAL_SCREEN.md').write_text('\n'.join(lines)+'\n')
summary={'body_mass_kg':body_mass,'gravity_m_s2':g,'body_weight_N':F,'pin_section_modulus_unnotched_mm3':Zshaft,'pin_section_modulus_groove_mm3':Zroot,'beam_lever_mm':lever,'groove_position_from_outer_face_mm':pin_entry-abs(groove_y),'horizontal_sensitivity_cases':len(rows),'retention_pull_sensitivity_cases':len(pull_rows),'material_specific_fea_run':False,'physical_tests_run':False,'report':'revision/verification_results/REV_P_C3_SAFETY_CORRECTION/C3_CORRECTIVE_STRUCTURAL_SCREEN.md'}
(OUT/'C3_LOAD_SCREEN_SUMMARY.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
