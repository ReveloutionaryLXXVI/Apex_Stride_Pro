#!/usr/bin/env python3
"""Export separated 3.2 mm outsole study components; not a wear-approved outsole."""
from pathlib import Path
import subprocess,tempfile,csv
import numpy as np
import trimesh
ROOT=Path(__file__).resolve().parents[2]
SRC=ROOT/'PRINT_READY_BENCH_FIT_KIT_REV_Q/source/Apex_Stride_Pro_RevQ_PrintPrep.scad'
OUT=ROOT/'PRINT_READY_BENCH_FIT_KIT_REV_Q/optional_3p2mm_outsole_study'
parts=[('outsole_heel_pad','outsole_heel_pad_3p2mm_study_only.stl'),('outsole_toe_pad','outsole_toe_pad_3p2mm_study_only.stl'),('outsole_flex_connector','outsole_flex_connector_3p2mm_study_only.stl')]
rows=[]
for size in (42,44,46):
 for selector,filename in parts:
  out=OUT/f'EU{size}'/filename;out.parent.mkdir(parents=True,exist_ok=True)
  with tempfile.TemporaryDirectory(prefix='apex_revp_outsole_') as td:
   native=Path(td)/'native.stl'
   cmd=['openscad','--export-format','binstl','-o',str(native),'-D',f'eu_size={size}','-D','width_scale=1.00','-D','outsole_weight_study=true','-D',f'part="{selector}"',str(SRC)]
   proc=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=45)
   if proc.returncode or not native.exists() or native.stat().st_size<300 or 'ERROR:' in proc.stdout:
    rows.append({'size':f'EU{size}','selector':selector,'file':str(out.relative_to(ROOT)),'result':'FAIL','detail':proc.stdout[-500:]});continue
   mesh=trimesh.load_mesh(native,force='mesh',process=True)
   original_volume=float(mesh.volume)
   if not mesh.is_watertight or not mesh.is_winding_consistent or not np.isfinite(mesh.vertices).all() or original_volume<=0:
    rows.append({'size':f'EU{size}','selector':selector,'file':str(out.relative_to(ROOT)),'result':'FAIL','detail':'native mesh topology/volume invalid'});continue
   bounds=mesh.bounds
   mesh.apply_translation([-float((bounds[0,0]+bounds[1,0])/2),-float((bounds[0,1]+bounds[1,1])/2),-float(bounds[0,2])])
   mesh.export(out,file_type='stl')
   m2=trimesh.load_mesh(out,force='mesh',process=True); b=m2.bounds;e=m2.extents
   tests={'watertight':m2.is_watertight,'winding':m2.is_winding_consistent,'finite':np.isfinite(m2.vertices).all(),'positive_volume':m2.volume>0,'centered':max(abs((b[0,0]+b[1,0])/2),abs((b[0,1]+b[1,1])/2))<1e-3,'z0':abs(b[0,2])<1e-3,'fits_220':max(e[0],e[1])<=220.001,'volume_match':abs(m2.volume-original_volume)<=max(.02,original_volume*1e-6)}
   rows.append({'size':f'EU{size}','selector':selector,'file':str(out.relative_to(ROOT)),'result':'PASS' if all(tests.values()) else 'FAIL','volume_mm3':round(float(m2.volume),4),'mass_at_1p20_g':round(float(m2.volume)*1.2/1000,4),'extents_mm':','.join(f'{x:.3f}' for x in e),'tests':';'.join(f'{k}={v}' for k,v in tests.items()),'status':'UNVALIDATED 3.2mm study; not for wear'})
with (OUT/'OUTSOLE_STUDY_EXPORT_AUDIT_REV_Q.csv').open('w',newline='',encoding='utf-8') as f:
 fields=sorted(set().union(*(r.keys() for r in rows)));w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rows)
print(f'checks={len(rows)}; pass={sum(r.get("result")=="PASS" for r in rows)}; fail={sum(r.get("result")=="FAIL" for r in rows)}')
if any(r.get('result')!='PASS' for r in rows):raise SystemExit(1)
