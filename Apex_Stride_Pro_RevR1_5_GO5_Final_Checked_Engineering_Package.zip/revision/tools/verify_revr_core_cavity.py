#!/usr/bin/env python3
"""Rev R native-geometry check for the actual under-deck spring/bladder reserve cavity."""
from pathlib import Path
import subprocess,tempfile,json,csv
import numpy as np, trimesh
ROOT=Path(__file__).resolve().parents[2]
SRC=ROOT/'revision/Apex_Stride_Pro_RevR.scad'
OUT=ROOT/'revision/verification_results/revR_core_integration'
OUT.mkdir(parents=True,exist_ok=True)
def ray_hits(mesh, point, direction=np.array([0.,0.,1.])):
    tri=mesh.vertices[mesh.faces]; O=np.asarray(point,float); D=np.asarray(direction,float)
    e1=tri[:,1]-tri[:,0]; e2=tri[:,2]-tri[:,0]
    h=np.cross(np.broadcast_to(D,e2.shape),e2); a=np.einsum('ij,ij->i',e1,h)
    mask=np.abs(a)>1e-10; f=np.zeros_like(a); f[mask]=1/a[mask]
    ss=O-tri[:,0]; u=f*np.einsum('ij,ij->i',ss,h); q=np.cross(ss,e1)
    v=f*np.einsum('ij,j->i',q,D); t=f*np.einsum('ij,ij->i',e2,q)
    ok=mask&(u>=-1e-9)&(v>=-1e-9)&(u+v<=1+1e-9)&(t>1e-6)
    unique=[]
    for x in np.sort(t[ok]):
        if not unique or abs(float(x)-unique[-1])>1e-4: unique.append(float(x))
    return unique
rows=[]
for size in (42,44,46):
  results=[]
  for light in ('true','false'):
    with tempfile.TemporaryDirectory(prefix='revr_cavity_') as td:
      stl=Path(td)/'heel.stl'
      cmd=['openscad','--export-format','binstl','-o',str(stl),'-D',f'eu_size={size}','-D','width_scale=1.0','-D',f'lightening_enabled={light}','-D','part="heel"',str(SRC)]
      cp=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=60)
      if cp.returncode or not stl.exists() or 'ERROR:' in cp.stdout: raise RuntimeError(f'Export failed {size}/{light}: {cp.stdout[-1000:]}')
      m=trimesh.load_mesh(stl,force='mesh',process=True)
      hits_void=ray_hits(m,[-100,0,-15]); hits_roof=ray_hits(m,[-100,0,-3]); hits_outside=ray_hits(m,[-130,0,-15])
      passed=bool(m.is_watertight and m.is_winding_consistent and len(hits_void)==2 and len(hits_roof)==1 and len(hits_outside)==1 and np.isfinite(m.volume) and m.volume>0)
      result={'size':size,'lightening_enabled':light,'watertight':bool(m.is_watertight),'winding_consistent':bool(m.is_winding_consistent),'volume_mm3':float(m.volume),'cavity_ray_intersections':hits_void,'roof_material_ray_intersections':hits_roof,'solid_outside_cavity_ray_intersections':hits_outside,'pass':passed}
      rows.append(result);results.append(result)
  # It is a required cavity, so disabling optional lightening must not alter the heel's volume.
  delta=abs(results[0]['volume_mm3']-results[1]['volume_mm3'])
  guard={'size':size,'volume_delta_true_vs_false_mm3':delta,'independent_of_lightening_toggle':delta<0.01}
  rows.append(guard)
  if not guard['independent_of_lightening_toggle'] or any(not x['pass'] for x in results): raise SystemExit(f'FAIL {guard} {results}')
(OUT/'REVR_CORE_CAVITY_GEOMETRY_CHECKS.json').write_text(json.dumps(rows,indent=2)+'\n')
with (OUT/'REVR_CORE_CAVITY_GEOMETRY_CHECKS.csv').open('w',newline='',encoding='utf-8') as f:
  w=csv.DictWriter(f,fieldnames=['size','lightening_enabled','watertight','winding_consistent','volume_mm3','cavity_ray_intersections','roof_material_ray_intersections','solid_outside_cavity_ray_intersections','volume_delta_true_vs_false_mm3','independent_of_lightening_toggle','pass']);w.writeheader()
  for x in rows:
    row={k:x.get(k,'') for k in w.fieldnames}
    for k in ('cavity_ray_intersections','roof_material_ray_intersections','solid_outside_cavity_ray_intersections'):
      if row[k]!='': row[k]=';'.join(map(str,row[k]))
    w.writerow(row)
print(json.dumps({'size_size_toggle_checks':len(rows),'size_cases':[42,44,46],'result':'PASS','cavity_dimensions_mm':[55,23,10.5],'nominal_roof_mm':10.1,'nominal_rail_web_mm':2.5,'method':'native OpenSCAD STL; vertical triangle-ray probes distinguish open cavity from solid roof; watertightness and lightening-toggle invariance'},indent=2))
