# Rev R1 consolidated verification and component specification register

**Digital checks: 126/126 PASS.** This is not a physical safety qualification.

| Verification | Latest result | What it establishes / limitation |
|---|---:|---|
| Source/print-prep parity + compile/package suite | 126/126 PASS | Supported CAD selectors/configurations, source parity, documents, map and mesh/package logic; no strength claim |
| Core-cavity geometry | 9/9 PASS | EU42/44/46 and optional-lightening states; continuous cavity/roof exists in current geometry |
| Fit/mockup export | 42/42 PASS | Size-specific meshes pass watertight/winding/finite-volume/plate checks |
| Adjustment sweep | 61/61 positions; 250 checks | Nominal coordinates/registration arithmetic only; manufacturing tolerances and loaded deformation not modeled |
| Rail/stop exact CSG | 6/6 PASS | Expected-empty positive-volume intersection checks at three sizes, both rails |
| Mass calculation | 66/66 native exports | Volume × listed density assumptions; not finished shoe mass |
| Assembly map | 72/72 paths resolve | No missing mapped file references |
| Load arithmetic | 66 kg = 647.46 N; equal bilateral static share = 323.73 N/foot | No measured gait load; 1.5×/2×/3× are only sensitivity factors |
| Sourced BOM | 64 unique BOM lines; 36 sourced candidate/interface entries; 29 procurement items | Catalog products named where sufficiently identified; unresolved items explicit as procurement holds |

## Rev R1 CAD interfaces changed and checked

- Bridge M4 button-head recesses Ø7.9×2.2 mm; rail counterbores Ø8.0×2.2 mm; source head is nominal Ø7.6×2.2 mm.
- Nut pockets nominal AF7.35 with 3.6/3.45 mm depths for standard ISO4032 M4 nuts.
- Toe anchor head relief added to moving front strap, preserving alignment while the shoe is adjusted.
- Two Ø5.5×0.72 mm underside EVA clearances added at moving M4×16 screw tips. Geometric estimate: screw tip z≈+0.60 mm; EVA bottom z=+0.15 mm; nominal overlap ≈0.45 mm, relieved region top z≈+0.86 mm, about 0.26 mm clearance and ≈4.3 mm remaining foam above relief. Physical assembly/cover/compression must still be gauged.

## Sourced candidate disposition

- **Conditional spring candidate:** Lee Spring LHP 030B 04S / LHP030B04S; rate 5.126 N/mm, listed OD 4.57 mm, free 19.05 mm, solid 10.11 mm, calculated 8.94 mm travel, listed load at solid 45.77 N. Bore ≈3.05 mm is derived from OD−2×wire Ø0.76, not separately supplier-quoted. Assumed 4–6 mm return compression gives 20.5–30.8 N; mechanism stroke/preload/seats/guide/fatigue are unresolved.
- **Bladder:** DERFLEX custom OEM RFQ only, not a finished rated part or exact catalog SKU. No operating pressure assigned.
- **Air circuit:** SMC T0425 tube and KQ2H04 fittings, ARX20-F01BG regulator and AP20-D relief family identified; exact check direction, relief suffix/port, gauge/tee, manual 3/2 dump valve and bladder port remain open. 1.0 MPa KQ2 operating rating caps the fitting candidate; pressure is not cleared.
- **Fasteners:** Würth screw length SKUs and K&K M4 A2-70 nuts identified; source warns button-head shape is for limited loads. CAD fit does not qualify joint strength.
- **Pin/bushing:** custom 17-4PH pin drawing path; no bushing SKU selected because of interference/engagement uncertainty in Ø8.8 passage.
- **Upper/footbed/outsole:** exact mesh/webbing/counter-sheet/EVA/rubber-sheet/thread/prototype closure candidates recorded; broad nylon overlay fabric, sewn pattern/seam validation, outsole hardness/fatigue data, and production adhesive remain on hold.

## Structural/pressure results that prevent a release claim

The simplified 5.5 mm cavity-roof strip calculation is highly sensitive to assumed load-spread width and exceeds the PA12 41 MPa coupon flexural-strength reference in some cases; it is not an actual 3D stress result. The simple pin beam sensitivity reaches ≈339 MPa at one-foot static load and ≈1,017 MPa at 3× using the groove-root section and assumed span; the 3× sensitivity exceeds the approx. 725 MPa minimum-proof reference for the candidate 17-4PH condition. The bladder-only pressure lower bound over maximum 1,265 mm² projected area is 0.512 MPa for one-foot static, 1.024 MPa at 2× and 1.535 MPa at 3×. Actual effective area could be smaller; the 2× lower bound already exceeds the KQ2 candidate fittings' 1.0 MPa max operating pressure. No pressure setpoint is selected.

## Not run / release status

- Material-specific 3D FEA, mesh convergence/contact model, tolerance/strain analysis: **NOT RUN**.
- Hardware physical gauging, spring fatigue, bladder pressure/burst/leak/cycle and pressure-loss trials, proof/impact/fatigue loading, pin/ring retention, outsole bond/slip, sewn upper seam/fit tests: **NOT RUN**.
- No finished sewn upper pattern or human-wear test exists.

**Release: engineering review + non-wearable dimensional fit mockup only. Human wear NOT CLEARED.** For actual purchase decisions use `revision/docs/REV_R1_PROCUREMENT_LIST.csv`; for all product properties, dimensions, sources and gates use `revision/docs/SOURCED_COMPONENT_REGISTER_REV_R1.csv`.
