# Rev Q material integration test register

Date of package generation: 2026-10-16 (UTC+04 package environment). Only results actually present in the test artefacts are reported.

| Group | Result | Evidence | Meaning/limit |
|---|---:|---|---|
| Current source/document/compile/mesh/package check | 115 PASS / 0 FAIL | `revision/verification_results/revQ_material_integration/REVQ_SOURCE_COMPILE_AND_PACKAGE_CHECKS.csv` and JSON | Includes 18 compile/selector variants, 42 fit-kit STLs, 21 upper concept meshes, 9 outsole-study meshes, exact source parity, mass arithmetic, required docs and 72 file references. |
| Exact toe-carriage vs rail CSG | 6/6 PASS | `revision/verification_results/revQ_material_integration/exact_csg/REV_Q_EXACT_TOE_RAIL_INTERSECTION_TEST.csv` | Three sizes × two rails; confirms no positive-volume intersection in nominal geometry, not tolerance safety. |
| Kinematic/registration sweep | 61/61 positions pass; 250 checks | `revision/verification_results/revQ_material_integration/kinematic_sweep/REV_Q_61_POSITION_KINEMATIC_CLEARANCE_SWEEP.csv` | Nominal coordinate arithmetic; no flex/tolerance/wear/dynamic effects. |
| Discrete lock registration | 3/3 size stations pass | `revision/verification_results/revQ_material_integration/kinematic_sweep/REV_Q_DISCRETE_LOCK_REGISTRATION_RECHECK.csv` | Mathematical hole registration only. |
| Native mesh-volume calculation | 66 exports pass | `revision/verification_results/revQ_material_integration/REVQ_COMPONENT_MASS_MATERIAL_CARD.csv` | Volume/mass estimates; omitted components and placeholder outsole density documented. |
| Full CAD preview | PASS | `reports/REVQ_FULL_MOCKUP_EU44_FRESH.png` | Visual preview only. Not a printable monolithic solid. |
| 66 kg arithmetic / analytic screens | PASS as calculations only | `revision/docs/LOAD_ASSESSMENT_66KG_REV_Q.md`; `reports/REVQ_DECK_SCREENING_SENSITIVITY.csv`; `reports/REVQ_PNEUMATIC_PRESSURE_DEMAND_SENSITIVITY.csv`; `reports/REVQ_SPRING_RATE_DEMAND_SENSITIVITY.csv` | Simplified sensitivity equations, not FEA, physical proof or safety certification. One narrow-contact deck case exceeds the 41 MPa flexural reference. |
| FEA | NOT RUN | No FreeCAD/CalculiX/Gmsh installed | No native solver results. |
| FreeCAD `.FCStd` / STEP | NOT RUN | FreeCAD not available; OpenSCAD emits CSG and STL, not native feature tree/STEP | No fabricated surrogate exports. |
| Physical proof/impact/fatigue/pin/pressure/sole/upper/fit tests | NOT RUN | No manufactured specimen or test fixtures | See 20-item physical checklist. |
| Human walking/running tests | NOT RUN / NOT AUTHORIZED | Not independently qualified | Must wait until all physical gates pass and independent approval exists. |

## Known issue / release blockers

1. The default Rev Q estimated platform is 3.006884–3.077285 g heavier than Rev K on the comparable mass scope, despite the supplied PA12 density being used. The default weight-reduction target therefore **fails**. The 3.2 mm outsole study saves an estimated 16.380–17.661 g relative to 4.0 mm default but is unvalidated and remains opt-in.
2. The simplified deck-strip sensitivity at 20 mm contact spread calculates 56.6 MPa nominal versus a 41 MPa published flexural-strength reference. This simplified model is not a precise prediction, but it is a structural concern requiring full analysis and physical verification.
3. The spring/bladder envelope intersects deck pocket ribs and is not a continuous usable cavity. Actual spring and pneumatic components are not modeled.
4. Upper meshes are visual concepts, not stitched patterns.
5. Monolithic aggregate platform mesh must not be used as a print file; use only indexed individual component files for non-wearable fit/mockup.

Status categories are kept separate: CAD/geometry checks are not material strength tests; analytic sensitivity is not FEA; neither is a physical test.

## Repeated mass-export rerun (not a pass)

The last repeated invocation of `recalculate_mass_materials_revQ.py` timed out after printing EU42 and EU44 Rev Q summary lines, before writing CSV outputs. The previous complete native-export result set (66 exports) remains included; source geometry did not change after that run (later changes were comments and output filename tags only), and the post-edit 115-check compile/mesh audit passed. The repeated invocation is **TIMED OUT**, not a new successful run.


Final inventory audit: **15/15 checks passed** for assembly-map path resolution (72 entries), BOM row/ID uniqueness (60 unique IDs), sourced-material table (15 families), physical checklist (20 items), completed mass-audit record (66 native mesh exports), main source/print-prep parity, 66 kg load arithmetic, and required reports/PNG diagrams. The BOM now explicitly carries `estimated_cost` and `cost_basis` fields; every line is “Not estimated” because no exact supplier/SKU/quote is selected, avoiding fabricated prices.
