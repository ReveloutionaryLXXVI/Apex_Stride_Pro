# Rev R1.5 GO5 final release gate

**Digital test result: PASS for the tests listed here. Structural qualification: OPEN. No manufacturing release; not approved for human wear.**

## Current source identity
`revision/Apex_Stride_Pro_RevR.scad` SHA-256: `664f2858f85ac5eba0be335d8d0e89a64b769ca5985a37d5bf286ad4aa19d5c0`. Standalone and print-preparation CAD copies are byte-identical.

## Final-source checks passed
- Source/package regression: 130/130.
- Heel cavity: 9/9.
- Kinematic/registration arithmetic: 250/250 across 61 positions.
- Rail/end-stop CSG: 6/6.
- Bridge/fastener CSG: 18/18.
- Lock-tip/deck CSG: 4/4.
- Standard meshes freshly exported: 42/42; optional outsole study exports: 9/9.
- Active STL topology audit: 72/72 pass after in-memory welding/cleanup; delivered STL files were not rewritten by audit.
- Native mass export: 24/24. Weight remains modeled from assumed densities, not measured.
- Structural screen: 82 rows, 14 guardrails PASS, 0 explicit FAIL, 4 UNVERIFIED supplier/system gates.
- Active component interface schedule now agrees with 2.5 mm standard skin, 1.8 mm optional study skin, and 10.1 mm nominal roof.
- SMC catalog ranges reviewed: AP20-D standard 0.05–0.8 MPa; ARX20 standard 0.05–0.85 MPa. Exact order configuration and system safety still open; current tubing catalogs conflict on the T0425 pressure rating, so the 1.5 MPa screen input remains a conservative provisional value.

## Blocking gates before a wearable design or manufacturing release
- Material-specific FEA or a competent, independently reviewed equivalent analysis using actual geometry, build/process-specific material data, contacts and realistic constraints.
- Pin lock-force, bearing, groove/ring retention, impact/fatigue and bridge-joint strength/preload calculations and physical proof/fatigue tests.
- Exact M4×22 rear-anchor and M4×14 lock fastener SKUs, grades, engagement, torque/preload and anti-loosening qualification.
- Exact AP20-D order code/thread/options; relief flow, response/overshoot at actual chamber volume; bladder OEM pressure/burst/cycle rating; pressure-loss safe state.
- Guarded physical proof-load, impact, cycling, pin retention, leak/relief, traction, abrasion, tear, flex and bondline tests, plus fit verification against a measured last.
- Final actual materials, manufacturing process, tolerances, masses, BOM and procurement confirmation.

The open structural/pneumatic gates are not paperwork-only issues. No FEA solver was available and no physical tests were carried out during GO5. Do not wear, body-load or pressurize this prototype.
