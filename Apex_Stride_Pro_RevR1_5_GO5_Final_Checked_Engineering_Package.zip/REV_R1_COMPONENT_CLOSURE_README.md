# Apex Stride Pro Rev R1 component closure package

Start here:

1. `FINAL_ENGINEERING_REPORT_REV_R.md` — executive summary, current geometry, sourced component candidates, calculations, release gates.
2. `revision/docs/BILL_OF_MATERIALS_REV_R.csv` — master BOM, 64 lines including size variants.
3. `revision/docs/SOURCED_COMPONENT_REGISTER_REV_R1.csv` — manufacturer/part IDs, dimensions, ratings, prices, links, fit verdict and open gate per candidate.
4. `revision/docs/REV_R1_PROCUREMENT_LIST.csv` — prioritized buy/quote/hold list.
5. `revision/docs/PROCUREMENT_AND_MANUFACTURING_SPEC_REV_R1.md` — build/material/process and interface specification.
6. `revision/verification_results/revR_component_closure/COMPONENT_FIT_AUDIT_REV_R1.csv` and `PRESSURE_RETURN_FORCE_CALCULATIONS_REV_R1.csv` — part-by-part geometry and 66 kg return/pressure calculations.
7. `revision/docs/ASSEMBLY_MANUAL_REV_R.md` — assembly flow, exact nominal interfaces and stop conditions.

The main CAD architecture is still Rev R. Rev R1 only adds source-based screw/nut recesses and toe-footbed reliefs. Latest geometry/source tests passed; no physical testing or FEA is claimed. Three purchase groups are explicitly held: finished rated bladder and pressure safety circuit; pin/bushing interface; broad upper overlay panel/pattern; and the production outsole adhesive/compound certification. This is not a wearable release.
