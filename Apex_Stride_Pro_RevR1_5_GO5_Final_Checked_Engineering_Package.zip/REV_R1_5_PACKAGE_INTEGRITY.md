# Rev R1.5 GO5 package integrity

`REV_R1_5_SHA256_Manifest.txt` is the active manifest. It covers every regular file in the package root and subdirectories except itself; historical `ARCHIVE_REV_*` manifests are retained for traceability and are not the active manifest.

Before distribution, the GO5 build process checks all three items:
1. ZIP CRC (`ZipFile.testzip()`) has no failing members.
2. Every manifest path has matching SHA-256 bytes after extraction.
3. ZIP members equal the manifest paths plus the manifest itself; no missing or unmanifested files.

The delivery-side `Apex_Stride_Pro_RevR1_5_GO5_Integrity_Audit.md` records the result against the exact packaged archive. These checks establish file consistency only; they do not qualify physical strength, material/process capability or wearer safety.
