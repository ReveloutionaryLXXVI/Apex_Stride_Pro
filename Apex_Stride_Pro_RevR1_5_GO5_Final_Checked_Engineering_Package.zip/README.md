# Apex Stride Pro — Rev R1.5 GO5 final audit

**Current status: final digital design candidate; not a manufacturing release and not cleared for human wear.**

## Source of truth
1. `Apex_Stride_Pro_RevR1_5_Full_Audit_Report.md` — independent GO5 final audit.
2. `PROJECT_STATUS_AND_RELEASE_GATE_REV_R1_5.md` — release status and open gates.
3. `revision/Apex_Stride_Pro_RevR.scad` — authoritative editable CAD. `Apex_Stride_Pro_RevR1_5_Corrected.scad` and the print-prep source are byte-identical. SHA-256: `664f2858f85ac5eba0be335d8d0e89a64b769ca5985a37d5bf286ad4aa19d5c0`.
4. `REV_R1_5_STRUCTURAL_SCREEN.csv` / `REV_R1_5_STRUCTURAL_SCREEN_QA.json` — 82 pressure/load/joint screen rows, 14/18 quantitative/geometry guardrails pass, 0 explicit fails, 4 unverified supplier/system gates.
5. `REV_R1_5_MASS_SUMMARY_BY_SIZE.csv` — fresh aggregate outsole and modeled lower-platform estimates; use assumed density caveat.
6. `REV_R1_5_ALL_72_MESH_AUDIT.csv` / `.json` — current 72-mesh audit; watertightness is assessed after in-memory duplicate-vertex welding, with no STL file rewritten by the audit.
7. `REV_R1_5_QA.json` and `REV_R1_5_SHA256_Manifest.txt` — QA tied to current source hash and active package integrity manifest.

## GO5 results
Fresh final-source tests passed: source/package 130/130; cavity 9/9; kinematic 250/250; rail/stop 6/6; bridge/fastener 18/18; lock-tip 4/4; standard fit-kit exports 42/42; optional study exports 9/9; active mesh audit 72/72 after in-memory topology cleanup; native mass exports 24/24.

## Current geometry
The default outsole retains 4.0 mm external thickness and now has a 2.5 mm nominal skin. The optional 3.2 mm study has 1.8 mm skin and is not approved for wear. Live interface schedule and current engineering report were reconciled to these dimensions and the 10.1 mm nominal roof.

## Still open
No material-specific FEA, static/proof load, impact, fatigue, fastener/pin retention, pneumatic relief-flow/overshoot/pressure-loss, outsole traction/tear/abrasion/bonding or human fit/wear tests were completed. Pin, bridge joints, chassis materials/allowables and pneumatic fail-safe function remain unqualified. Do not wear, body-load or pressurize this prototype.
