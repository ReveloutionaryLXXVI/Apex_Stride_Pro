# Apex Stride Pro Rev R1.1 — pressure input and load-path correction

**Change type:** actual design-input and calculation correction; not a wearable release.

## Mistake corrected

The earlier independent load screen divided force by the entire 55×23 mm cavity (1,265 mm²), even though the specified bladder body envelope was only 27×22×9 mm. The target rectangle is 594 mm², so the previous ideal pressure estimates were understated by 1265/594 = 2.1296×. The calculation script and stored result files have been corrected to use the target bladder footprint; the full cavity area remains recorded separately as geometry only.

## Corrective pressure design input

- Provisional working-pressure target: **0.40 MPa**.
- Provisional nominal chamber relief-setpoint target: **0.50 MPa**.
- Candidate ratings: SMC ARX20 regulator output range 0.05–0.85 MPa; AP20-D set range 0.05–0.8 MPa (maximum operating pressure 0.85 MPa); KQ2 fittings max operating 1.0 MPa; T0425 tube max operating 1.5 MPa at 20 °C.
- This is a low-pressure **auxiliary** bladder, not the sole body-load support. At 594 mm², nominal bladder force is 237.6 N at 0.40 MPa and 297 N at 0.50 MPa. The chassis must safely carry the remaining load and the complete external load when the bladder is depressurized.
- At the 0.50 MPa relief target, the required structural residual is 350.46 N for the 647.46 N one-foot static case, 997.92 N at 2×, and 1,645.38 N at 3×. These are arithmetic loads, not test acceptance values.

## Recomputed bladder-only demand (not recommended operating pressure)

| Load case | Force | Pressure demand over 594 mm² if bladder alone carried load |
|---|---:|---:|
| Equal bilateral static share | 323.73 N | 0.545 MPa |
| One-foot 66 kg static | 647.46 N | 1.090 MPa |
| 1.5× sensitivity | 971.19 N | 1.635 MPa |
| 2× sensitivity | 1,294.92 N | 2.180 MPa |
| 3× sensitivity | 1,942.38 N | 3.270 MPa |

## Guardrails added to editable CAD

The native SCAD and print-prep source now carry explicit nominal parameters/assertions for (a) the 24 mm spring reserve + 3 mm separator + 28 mm bladder reserve; (b) the 27×22×9 mm target bladder body; (c) 0.40/0.50 MPa target hierarchy; and (d) nominal pressure hierarchy below the candidate AP20-D, regulator, fitting and tubing limits. Source geometry is otherwise unchanged by these parameter/guardrail edits. The separate M4 recess geometry correction remains in place.

## Remaining proof needed before any pressure or wear testing

The finished bladder has no OEM-confirmed effective area, working/burst pressure, cycle rating, port or force-height curve. Confirm AP20-D suitability as a protective relief device, exact part suffix, capacity/response/overshoot, correct check-valve direction, chamber-side gauge and dump topology. Verify measured chamber transients stay below every component rating. The frame/deck must carry the whole required load with zero bladder pressure; current roof-strip and pin checks are only sensitivities and do not prove it. The small spring candidate produces only about 20.5–30.8 N at an assumed 4–6 mm stroke and is not a body-load spring. No FEA or physical testing was performed, and human wear remains not cleared.

## Manufacturer references

- SMC KQ2 fitting series: https://www.smcworld.com/newproducts/en/pdf/kq2.pdf
- SMC AP20-D relief/pressure-control family: https://static.smc.eu/pdf/AP20-D-A_EU.pdf
- SMC T-series tubing: https://static.smc.eu/pdf/Tubing.pdf
- SMC ARX20 regulator: https://www.smc.eu/et-ee/products/arx20-regulator-for-2mpa~15019~cfg?partNumber=ARX20-F01BG


## Rev R1.2 structural geometry change

The local heel-core roof is now 10.1 mm rather than 5.5 mm; the cavity depth is 10.5 mm while the outer sole thickness stays 20.6 mm. The custom bladder height target is reduced to 9 mm, leaving 1.5 mm nominal clearance. This adds 5,819 mm³ of PA12 (about 5.53 g at 0.95 g/cm³) and reduces the one-way roof-strip sensitivity by (5.5/10.1)² ≈ 0.297 for the same load/spread assumptions. This is a geometry improvement only, not certification.
