# Rev O print-preparation and wear-release status

## Approved use of these files

These STLs are regenerated, 1:1, build-plate-normalized **non-wearable dimensional mockup parts only**. They can be sliced using your printer/material profile after reviewing the listed dimensions and slicer preview. They are not approved as a load-bearing shoe. Do not put a foot into the mockup or wear/run in the prototype.

## Parts and sizes

For EU42/EU44/EU46 see `PRINT_PARTS_INDEX.csv`. Every part is centered in X/Y and translated so minimum Z=0. The script only rotates and translates meshes; it does not scale. The export audit checks 220 × 220 mm XY envelopes, but not margin for skirts/brims, supports or printer-specific keepout. Always verify bed limits in your slicer. No G-code is included because printer, nozzle, filament brand and slicer settings were not supplied.

`01_chassis` comprises deck, toe carriage, bridge fit pieces and split footbed silhouettes. The footbed split is a plain butt-joint, without a mechanical joining feature, and is not cushioning. `02_outsole_fit_only` consists of the heel pad, toe pad and flex connector; these do not define production bonding or grip. `03_hardware_mockup_ONLY` has solid polymer rails with rail-relief cavities disabled, a pin silhouette and retaining-ring silhouette. They must not be used as load-bearing/retention hardware. The actual production rails/bridge/pin/ring require controlled drawings, selected material and physical qualification. `upper_concept_not_wearable/` holds rigid envelope meshes, not textile patterns, seams, lining or a fitted upper.

## Suggested mockup slicing setup only

- Import units in mm, scale 100%, confirm extents against CSV.
- Use 0.4 mm nozzle and 0.20 mm layers as initial dimensional-mockup settings; inspect first-layer placement and any required supports.
- Chassis/bridge/solid rails: PETG for mockup only. The model's polymer rails are solid fit surrogates, not representative production rails.
- Outsole shape: TPU around 95A for a shape mockup only; use its manufacturer's filament settings. No claims about grip, wear, bond or fatigue.
- Footbed silhouette: PETG for shape only; not cushioning.
- Do not print/use pin or retaining-ring STL as hardware. Buy actual catalog ring and manufacture pin to a reviewed drawing.

No generic torque values are provided; actual fasteners and joint materials are unresolved. Stop bench assembly if rails bind, holes do not align without force, pin/ring do not seat fully, any part cracks/delaminates, or the outsole shifts. These stop rules do not grant permission for human wear.

## Wear release gate

**NOT CLEARED for human wear.** Physical material/strength/retention/outsole/fit validation and independent review remain outstanding; see root `PROJECT_STATUS_AND_RELEASE_GATE.md`.
