> **HISTORICAL / SUPERSEDED by Rev R1.1.** This historical Rev Q report contains superseded pressure arithmetic. The current bladder body area proxy is 594 mm² (27×22 mm), not the 1,265 mm² full cavity. Current provisional bench-only targets are 0.40 MPa working / 0.50 MPa nominal relief; see `REV_R1_PRESSURE_AND_LOAD_PATH_CORRECTION.md` and `revision/verification_results/revR1_fresh_validation/`. These targets do not clear the product for pressurization or human wear.

# Apex Stride Pro — Rev Q material integration and engineering report

**Status: digital engineering package for review and non-wearable bench-fit mockup only. Not cleared for human wear.**

## Scope

Rev Q continues the existing Apex Stride Pro adjustable captured-rail architecture. It integrates the provided candidate material cards, a removable sliding EVA-footbed geometry, a material/hardware BOM, interface schedule, conceptual pneumatic circuit and pressure schedule, structural screening calculations, and a finite 20-item physical validation checklist. It does not replace Rev K or claim the absent spring/pneumatic assembly exists.

## Current authoritative files

- `revision/Apex_Stride_Pro_RevQ.scad` — authoritative editable CAD source.
- `PRINT_READY_BENCH_FIT_KIT_REV_Q/source/Apex_Stride_Pro_RevQ_PrintPrep.scad` — same geometry/selectors, plus a print-prep header.
- `revision/docs/ASSEMBLY_MANUAL_REV_Q.md` — bench/mockup procedure and future production sequence.
- `revision/docs/ASSEMBLY_FILE_MAP_REV_Q.csv` — 72 exact paths to the 42 fit-kit STL, 21 upper concept STL, and 9 optional outsole-study STL files.
- `revision/docs/BILL_OF_MATERIALS_REV_Q.csv` — size-specific modeled parts and purchased/unresolved candidates.
- `revision/docs/MATERIAL_PROPERTY_TABLE_REV_Q.csv` — source, orientation, process and missing property data.
- `revision/docs/COMPONENT_INTERFACE_FASTENER_SCHEDULE_REV_Q.csv` — interface dimensions/critical checks.
- `revision/docs/PNEUMATIC_CIRCUIT_REV_Q.svg` and `revision/docs/PNEUMATIC_CIRCUIT_PRESSURE_SCHEDULE_REV_Q.csv` — concept circuit and pressure-rating placeholders.
- `revision/docs/LOAD_ASSESSMENT_66KG_REV_Q.md` — documented analytical screening.
- `revision/docs/PHYSICAL_VALIDATION_CHECKLIST_REV_Q.csv` — 20 component-specific physical gates (not run).

Older revisions and reports remain in the archive for traceability. Rev Q documents above are the current deliverables; legacy report names in older revisions should be treated as historical, not current release state.

## Material inputs integrated

### Structural candidate: Materialise PA 12 SLS

Density 0.95 g/cm³ (950 kg/m³), tensile modulus 1650 MPa, tensile strength 48 MPa, flexural strength 41 MPa, flexural modulus 1500 MPa, elongation at break 20%, Shore D75, and HDT 86°C. The current published Materialise values say actual values vary with build/process, geometry and orientation. The tensile strength is **not** yield strength and is not used as a yield allowable. This material card is not transferable to generic FDM or to an unspecified MJF grade. Source: https://www.materialise.com/en/industrial/3d-printing-materials/pa12-sls .

### Flexible candidate: UltiMaker TPU 95A FFF data

The property table records the supplied manufacturer's orientation-specific data: XY-flat modulus 67±6 MPa, Z-up modulus 56±3 MPa; stress at break 23.7±2.1 MPa XY-flat and 6.4±0.5 MPa Z-up. These are FFF coupon results for that specific material/process; TPU is assigned only to non-primary protective/compliant parts. It is not treated as airtight, pressure-rated or the sole structural spring. Source: https://um-support-files.ultimaker.com/materials/2.85mm/tds/TPU-95A/TDS-TPU95A-V2.01-250915.pdf .

### Mechanical and moving hardware candidates

17-7 PH / UNS S17700 spring steel to the appropriate spring-wire specification is a material-family candidate only; actual spring geometry, heat-treatment condition, rate, preload, solid height, travel and fatigue data are absent. A commercial metal pin and a supplier-rated DIN 471 size-8 ring are required; the current meshes are envelopes/gauges only. Metal rails and bridges are assigned a *candidate* 6061-T6 density of 2.70 g/cm³ for mass estimates; alloy, temper, thread design, surface condition and supplier certificate remain unresolved. No torque values are invented.

## Mass calculation

Mass is calculated from fresh OpenSCAD-exported component volumes multiplied by the explicitly recorded candidate densities. The outsole mass uses 1.20 g/cm³ strictly as a placeholder; EVA density is unresolved, retaining-ring mass is not inferred from the schematic ring mesh, and fasteners/upper/spring/bladder/tubing/fittings/regulator/adhesives are excluded. This is **not total finished-shoe mass**.

| Size | Rev K comparable modeled platform | Rev Q comparable modeled platform | Rev Q minus Rev K |
|---|---:|---:|---:|
| EU42 | 566.254 g | 569.261 g | +3.007 g |
| EU44 | 570.104 g | 573.146 g | +3.042 g |
| EU46 | 573.953 g | 577.031 g | +3.077 g |

The default geometry therefore does **not** reduce like-for-like modeled mass versus Rev K under these material assumptions; it is roughly 3.0 g heavier in the stated scope. Do not claim a successful default mass reduction. The optional 3.2 mm outsole-study savings are 16.380 g (EU42), 17.020 g (EU44), and 17.661 g (EU46) relative to the 4.0 mm default using the same placeholder rubber density. That is an **unvalidated study only**; the 4.0 mm outsole stays default because traction, bond, tear and fatigue properties are not established.

## 66 kg load assessment

`F = m g = 66 × 9.81 = 647.46 N`. Ideal equal bilateral static load is 323.73 N per foot; a single foot may carry approximately 647.46 N before transient gait/impact loads. The load assessment includes explicitly illustrative (not measured) 1.5×/2×/3× sensitivities, a simplified deck-strip model, a conditional lock-pin beam demand, spring rate `k=F/δ` sensitivities, and pneumatic `p=F/A` demand scenarios. None is a material-specific validated factor of safety.

The simplified deck-strip model (28 mm nominal span, 4.1 mm roof, assumed contact widths 20/30/40/60 mm) gives one-foot nominal bending stress sensitivities of about 56.6/25.2/14.2/6.3 MPa. The 20 mm spread case exceeds the 41 MPa published flexural-strength reference. This is a **credible structural concern**, not proof of exact failure: the actual 3D load sharing and contact are unknown, but the model does not support a safety declaration. Materialise's tensile strength must not be treated as yield. Material-specific FEA and physical proof/fatigue testing are still required.

For a conditional horizontal pin load equal to one-foot body weight, the current simple split-rail beam model estimates about 159.1 MPa nominal bending on the unnotched 8 mm shaft; groove stress concentration, contact, ring capacity and fatigue are not modeled. It is not the vertical deck-load case.

The pneumatic `F/A` figures (up to 5.12 bar at a hypothetical 1265 mm² area for 647.46 N) are demand sensitivities only, **not safe pressure recommendations**. No operating pressure is assigned; select ratings for the bladder, tube, connectors, regulator, gauges, check/relief/dump valves and establish a whole-system pressure limit before guarded tests.

## Current test evidence

- Main Rev Q source/print-prep consistency and package suite: **115/115 PASS, 0 FAIL**; 42 fit-kit parts, 21 upper concept meshes and 9 optional outsole-study meshes are included, and all 72 assembly-map paths resolve.
- Size/width/selector compile matrix is part of that suite (18 combinations); all 42 fitting STLs and 30 concept/study STLs passed topology/volume checks.
- Locked stop/toe-rail exact CSG: **6/6 PASS** across EU42/EU44/EU46 and both rails; no positive-volume intersection detected. End-of-travel face contact is intentional, and manufacturing tolerance robustness is not established.
- Kinematic/source-coordinate sweep: **61/61 adjustment positions PASS**, 250 arithmetic/geometry checks, all 3 discrete lock stations pass; minimum nominal rail/channel engagement 63.833 mm and minimum bridge overlap 85.0 mm. This is source geometry math, not a tolerance/deformation analysis.
- Fresh native mass exports: **66**, all reported watertight, winding-consistent, finite and positive-volume.
- Native full mockup preview: generated at `reports/REVQ_FULL_MOCKUP_EU44_FRESH.png`.
- Earlier revisions are preserved. The original Rev K legacy suite remains historical baseline evidence; Rev Q current checks are above.

## Not run / unsupported in this environment

- No FreeCAD executable, CalculiX/CCX solver or Gmsh was available; no `.FCStd` document, valid analytic STEP export or material-specific FEA is claimed. OpenSCAD `.scad` is the editable source; STL exports are tessellated meshes only.
- No physical material coupons, manufactured shoe, real spring, bladder, valves, rated fittings, upper or bonded rubber outsole are present. Therefore no physical load, impact, fatigue, spring, pressure/leak, pin-pullout, sole adhesion, slip, fit or human-wear test has been conducted.
- The 55×23×15.1 mm spring/bladder envelope is a packaging study that intersects deck-pocket rib geometry; it is **not a free continuous cavity** and the actual spring/bladder system is absent. Integration requires a new clearance-resolved core design before production.
- Upper STLs are conceptual shapes and not stitched footwear patterns. Fit/retention is not validated.

## Exact procurement/technical gates

1. Order an exact Materialise PA 12 SLS production build (or substitute a different manufacturer's/process card and rerun analysis); obtain build orientation, lot, dimensions and traceability.
2. Obtain certified rail/bridge alloy/temper and approve tapped-thread design, M4 fastener length/grade/engagement, washers/locking method and torque from calculation/manufacturer data.
3. Select a commercial metal 8 mm pin and exact DIN 471 ring/groove drawing; confirm pin stack length, tolerance, thrust rating and retention.
4. Select a 17-7 PH spring with supplier-provided rate/load curve, preload, free/solid height, travel, condition and fatigue rating; engineer positive seats/retainers and a pressure-loss failsafe.
5. Select a flex-rated TPU bladder with drawing/effective area/working-burst-cycle data, compatible 4 mm OD PU tubing (including ID/wall rating), push fittings, check valve, regulator/gauges, relief and dump; then set operating pressure based on weakest component and guarded testing.
6. Select EVA foam (density, compression-deflection, compression set), textile cover and approved removable attachment method.
7. Select rubber compound with 60–70 Shore A target and actual abrasion/tear/flex/traction data; approve PA12-compatible outsole bond/primer or design positive retention. Test whole shoe slip using ASTM F2913-24; use ISO 17707 only if its rigidity criterion is applicable and ISO 17708 for upper/sole adhesion as appropriate.
8. Develop the last-matched polyester/engineered mesh upper with nylon overlays, counter, collar/tongue foam, closures and reinforced sewn anchors; perform retention and seam tests.
9. Complete all 20 entries in `revision/docs/PHYSICAL_VALIDATION_CHECKLIST_REV_Q.csv` in controlled fixtures and obtain independent footwear/mechanical engineering approval before any human wear trial.

**Release decision: digital integration is substantially complete for review and non-wearable fitting mockups. Human wear is NOT CLEARED.**


**Repeated-export note (audit transparency):** during final packaging, a second invocation of `recalculate_mass_materials_revQ.py` timed out after printing the EU42 and EU44 Rev Q summaries, before writing outputs. The script writes its CSVs only after all exports finish, so this attempt did not overwrite them. The included mass tables are from the earlier completed 66-native-export run. No geometry-affecting source change occurred after that completed run; subsequent source edits were comment-only and export-audit filename corrections, and the post-edit compile/mesh validator passed. This second invocation is marked timed out, not counted as another pass.


Supplier/product selections that remain open are itemized in `revision/docs/SUPPLIER_DECISION_REGISTER_REV_Q.csv`; no item is held open merely because a purchase has not yet been made.


Final inventory audit: **15/15 checks passed** for assembly-map path resolution (72 entries), BOM row/ID uniqueness (60 unique IDs), sourced-material table (15 families), physical checklist (20 items), completed mass-audit record (66 native mesh exports), main source/print-prep parity, 66 kg load arithmetic, and required reports/PNG diagrams. The BOM now explicitly carries `estimated_cost` and `cost_basis` fields; every line is “Not estimated” because no exact supplier/SKU/quote is selected, avoiding fabricated prices.
