# Rev R1.5 correction index — GO5 final audit and freeze

- Confirmed standard outsole: 4.0 mm external thickness, 1.5 mm mechanism relief, 2.5 mm nominal residual tread skin; optional 3.2 mm study stays at 1.8 mm skin and remains experimental.
- Corrected stale active component-interface schedule: standard tread skin 2.5 mm and nominal heel/forefoot roof 10.1 mm now agree with native CAD.
- Reconciled AP20-D and ARX20 family adjustment ranges against current SMC catalog references. Numeric family range checks pass; exact relief code/options, actual flow/overshoot, bladder pressure/cycle rating and loss-of-pressure safe state remain unverified.
- Fresh final-source verification completed: source/package regression 130/130; cavity 9/9; kinematic sweep 250/250; rail-stop CSG 6/6; bridge/fastener CSG 18/18; lock-tip CSG 4/4; standard exports 42/42; optional study exports 9/9; 72 meshes audited after in-memory topology cleanup; 24 native mass exports.
- Current structural screen: 82 rows, 14/18 guardrails passed, 0 explicit guardrail failures, 4 unverified supplier/system-safety gates. The active screen conservatively uses 1.5 MPa for SMC T0425 pending supplier resolution of conflicting old/new tube catalog ratings. The pin's severe unsupported-span sensitivity exceeds the candidate proof-strength reference; pin and structure remain unqualified.
- Source SHA-256 (all three current CAD copies byte-identical): `664f2858f85ac5eba0be335d8d0e89a64b769ca5985a37d5bf286ad4aa19d5c0`.

See `Apex_Stride_Pro_RevR1_5_Full_Audit_Report.md`, `REV_R1_5_QA.json`, the structural screen, and integrity receipt for the full record.
