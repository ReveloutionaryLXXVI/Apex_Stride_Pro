> HISTORICAL RECORD — superseded by the current Rev P C3 source and reports. Retained only for revision traceability; do not use this file as the current release status.

> **HISTORICAL ARCHIVE NOTE — Historical Rev L package README (superseded).** This document belongs to an earlier intermediate package. For the consolidated closure results, use `FINAL_ENGINEERING_CLOSURE_REPORT.md`, `FINAL_CLOSURE_TEST_REGISTER.md`, and `FINAL_PACKAGE_VERIFICATION.md`.

# Apex Stride Pro — Complete Engineering Revision Package (Rev L)

**Project intent:** develop an adjustable shoe for eventual wearable use. **Rev L handoff status:** the CAD revision, analysis documents, assembly manual, and digital regression artifacts are packaged for engineering review. **Wear-release status:** not cleared yet; the required independent material, structural, retention, outsole, and fit validations have not been completed. This is a continuation of Rev K, not a new architecture. The original ZIP and a full extracted copy of the source package are preserved under `baseline_original/`. All revised deliverables are under `revision/`.

## Start here

1. `revision/REV_L_REVISION_NOTES.md` — revision rationale and summary.
2. `revision/Apex_Stride_Pro_RevL.scad` — editable Rev L source. The default preserves the Rev K 4.0 mm outsole. The 3.2 mm outsole study is opt-in and is not approved for wear.
3. `revision/verification_results/REVL_REGRESSION_TEST_REPORT.md` — automated check status and untested physical validations.
4. `revision/verification_results/REVL_MASS_BASELINE_VS_STUDY.csv` and `REVL_MASS_COMPONENT_BREAKDOWN.csv` — size-by-size, component-level volume/density mass estimate.
5. `revision/docs/LOAD_ASSESSMENT_66KG.md` — 66 kg load calculation and limitations.
6. `revision/docs/SPEED_TEST_PROTOCOL.md` — staged speed-testing protocol with human testing blocked pending independent safety release.
7. `revision/docs/ASSEMBLY_MANUAL_REV_L.md` — BOM, tool list, mockup procedure, missing prototype requirements, inspection and stop conditions.
8. `revision/docs/REV_L_ASSEMBLY_DIAGRAM.png` and `revision/REV_L_CAD_PREVIEW_EU44.png` — assembly and CAD illustrations. These are conceptual, not manufacturing drawings.

## Summary

- For a 66 kg body mass, gravitational force is **647.46 N**. This is not a dynamic load rating and does not prove the shoe supports a 66 kg person while running.
- Estimated lower-platform masses use actual STL volumes and assumed density scenarios, not physical weighing or selected production materials. Lower-platform scope is the modeled chassis + outsole + simple footbed insert; fasteners, real upper textiles, final cushioning, adhesive/sole retention and manufacturing allowances are excluded.
- The opt-in 3.2 mm outsole study estimates 16.284 g (2.73%) saved in EU42, 16.911 g (2.81%) in EU44, and 17.539 g (2.89%) in EU46 relative to the 4.0 mm outsole baseline at assumed outsole density 1.20 g/cm³. Totals and savings are calculated before rounding; the summary CSV displays platform totals and reductions to 0.001 g, while individual component estimates remain rounded to 0.01 g. The chassis geometry is unchanged. The thinner outsole has unvalidated traction, wear, tear, compression, fatigue and attachment performance.
- The toe carriage is the largest estimated chassis component (~211.10 g), followed by heel deck (~110.32 g), rail pair (~96.68 g), bridge pair (~38.82 g) and solid pin (~38.52 g), under the specified assumed densities. No unsubstantiated thinning of load-bearing decks, rails, bridges or pin was made.

## Test disposition

**PASS:** 27/27 Rev L default geometry comparisons to Rev K; core export/topology checks; 3/3 lightweight study mesh checks; the existing 50/50 core topology checks, 65/65 bundled STL audit, 60/60 interior slider checks plus 24 intended end-stop contacts, 12/12 outsole relief probes, size/lock/bridge registration arithmetic, connector/coverage checks, URDF references and tolerance arithmetic. A Matplotlib mesh-derived preview was generated.

**NOT RUN:** native OpenSCAD GUI preview export (headless OpenGL context unavailable); physical weighing; material-specific FEA; physical proof/eccentric loading; fatigue and adjustment cycling; pin retention/end-stop impact; outsole traction/abrasion/tear/flex; strap pull-out; last/fit validation; and human walking/running/speed tests. These are called out explicitly in the regression report.

The project remains a wearable-shoe development effort; the CAD edit has not changed that intended purpose. Digital geometry passes do not establish structural capacity, durability, fit or speed improvement. A physical build must not be worn or human-tested until the required independent engineering, guarded physical validation and footwear-fit gates are passed.

## Traceability

- Original uploaded ZIP SHA-256: see `baseline_original/SHA256SUMS.txt`.
- Rev K source hash and Rev L source hash: see `revision/SHA256SUMS_REV_L.txt`.
- The baseline `Apex_Stride_Pro_RevK.scad` is preserved unchanged in the baseline package and in the revision workspace as a reference copy.
