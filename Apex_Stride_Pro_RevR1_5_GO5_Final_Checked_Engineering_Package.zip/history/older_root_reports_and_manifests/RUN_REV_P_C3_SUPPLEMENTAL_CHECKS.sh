#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT"
python revision/tools/run_safety_correction_c3.py
python revision/tools/run_pin_and_bridge_load_screen_c3.py
python revision/tools/validate_c3_load_screen.py
python revision/tools/validate_document_asset_closure.py
