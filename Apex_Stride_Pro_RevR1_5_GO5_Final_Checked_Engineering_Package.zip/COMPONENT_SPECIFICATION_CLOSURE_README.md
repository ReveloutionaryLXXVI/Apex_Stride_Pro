> **CURRENT REVISION — Rev R1.3 (2026-10-16).** Active CAD: `revision/Apex_Stride_Pro_RevR.scad` (identical to `Apex_Stride_Pro_RevR1_3_Corrected.scad` and the print-prep source). Start with `REV_R1_3_FULL_AUDIT_REPORT.md`, `REV_R1_3_CORRECTION_INDEX.md`, `REV_R1_3_QA.json`, and `REV_R1_3_STRUCTURAL_SCREEN.csv`. The forefoot pocket roof is 10.1 mm with a 5 mm center web. The design remains **NOT CLEARED FOR HUMAN WEAR**; no material-specific FEA or physical qualification has occurred. Previous R1.2 reports are historical snapshots.


# Apex Stride Pro Rev R — Component specification closure

Date: 2026-10-16

This package preserves Rev R, applies a small fastener-interface correction and adds real supplier candidates with exact part numbers, source links and observed prices where publicly available. It distinguishes orderable catalog parts from custom RFQ components. No product page is treated as proof that its part is safe for footwear loads.

Primary deliverables (the prior component sourcing work remains relevant; geometry/structural status is superseded by Rev R1.3):
- `revision/docs/BILL_OF_MATERIALS_REV_R.csv` — updated procurement BOM with exact candidate, price/link and fit gate columns.
- `revision/docs/SOURCED_COMPONENT_REGISTER_REV_R1.csv` — catalog candidates/internal drawing IDs and distinct dimensional/rating fields.
- `revision/docs/REV_R1_PROCUREMENT_LIST.csv` — prioritized buy / quote / hold register with public price snapshots and exact purchasing gates.
- `revision/docs/REV_R_VENDOR_DATASHEET_LINKS.md` — direct vendor/datasheet/order links.
- `revision/docs/PROCUREMENT_AND_MANUFACTURING_SPEC_REV_R1.md` — CAD envelopes, calculations, manufacturing process/material schedule, compatibility and procurement holds.
- `revision/verification_results/revR_component_closure/COMPONENT_FIT_AUDIT_REV_R1.csv` and `PRESSURE_RETURN_FORCE_CALCULATIONS_REV_R1.csv` — fit audit and numerical screens.
- `revision/docs/ASSEMBLY_MANUAL_REV_R.md` and `FINAL_ENGINEERING_REPORT_REV_R.md` — updated instructions and engineering report.

Public prices are snapshots only; no quotes/orders have been placed. Order quantities and sheet yields need final manufacturing quote. Finished bladder, pressure operating point, exact check-valve flow-direction SKU, manual dump valve, broad upper-panel nylon, and production outsole adhesive remain explicit purchasing holds rather than fabricated product selections.


## Rev R1.3 current geometry/validation pointer

The current source has a 10.1 mm forefoot pocket roof, 5 mm center web, and assertion-backed nominal index-hole/stop-lug separation. See root `REV_R1_3_FULL_AUDIT_REPORT.md` and `REV_R1_3_CORRECTION_INDEX.md` for exact check provenance. This update does not close the structural or physical validation gates.
