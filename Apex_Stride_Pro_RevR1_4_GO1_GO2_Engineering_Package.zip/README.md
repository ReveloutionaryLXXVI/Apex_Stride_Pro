# Apex Stride Pro — Rev R1.4 GO 1 + GO 2

**Current package purpose:** revised digital engineering candidate. It is not a manufacturing release and is not cleared for human wear.

## Start here

1. `REV_R1_4_GO1_GO2_STRUCTURAL_JOINT_REPORT.md` — current load-path and joint redesign, calculations, test scope, and open risks.
2. `PROJECT_STATUS_AND_RELEASE_GATE_REV_R1_4.md` — current release gate.
3. `Apex_Stride_Pro_RevR1_4_Corrected.scad` / `revision/Apex_Stride_Pro_RevR.scad` — corrected editable CAD; the `PRINT_READY_BENCH_FIT_KIT_REV_R/source/Apex_Stride_Pro_RevR_PrintPrep.scad` is byte-identical.
4. `revision/verification_results/revR1_4_go1_go2/` — regression evidence, joint CSG outputs, load/joint screen, 66 mass exports, and 72-mesh audit.
5. `revision/docs/BILL_OF_MATERIALS_REV_R.csv`, `SOURCED_COMPONENT_REGISTER_REV_R1.csv`, `COMPONENT_INTERFACE_FASTENER_SCHEDULE_REV_R.csv` and `REV_R1_PROCUREMENT_LIST.csv` — active component definitions. Exact M4×22 rear-anchor and M4×14 lock-screw SKUs remain TBD.
6. `REV_R1_4_SHA256_MANIFEST.txt` — current project-file hashes, excluding the manifest itself.

## GO 1 / GO 2 changes

- Defines the zero-pressure mechanical chassis as the body-load path; the pneumatic bladder is auxiliary, not the primary load-bearing member.
- Bridge strap candidates revised from 23×3 mm to 23×4.5 mm; recess stack coordinated from 6 to 9 mm.
- Paired anchor/counterbore positions staggered ±2 mm in X; nominal residual material cap behind the Ø7.9×2.2 mm recess increases from 0.8 to 2.3 mm.
- Coordinates nominal M4×22 rear-anchor, M4×16 toe-anchor and M4×14 indexed lock lengths. Adds/asserts 0.25 mm toe screw/footbed nominal clearance and 0.10 mm lock-tip-relief margin.
- Old nominal toe-footbed screw reliefs are removed; the CAD clearance rather than a cutout avoids the screw/foam overlap.

## Current verification snapshot

- 130/130 source/package checks pass.
- 61/61 nominal adjustment positions; 250/250 kinematic arithmetic checks pass.
- Rail/stop CSG 6/6; bridge-joint CSG/guardrails 18/18; lock-tip/toe-deck CSG 4/4 pass.
- 42/42 fit-kit parts freshly exported; 66 fresh mass variants; 72 active STL paths audited after topology processing; zero missing assembly-map paths.

These are software/nominal analytical checks. No material-specific FEA or physical load, impact, fatigue, pin-retention, pressure-loss, traction or wear tests were performed. The custom pin's actual axial lock loads and retention/groove design remain open for GO 3. **Do not wear this revision.**
