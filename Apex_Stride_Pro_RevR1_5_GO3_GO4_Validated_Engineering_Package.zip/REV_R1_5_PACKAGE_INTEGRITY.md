# Rev R1.5 package integrity procedure

`REV_R1_5_SHA256_Manifest.txt` is the current package manifest. It lists SHA-256 hashes for all project files except the manifest itself; this self-exclusion prevents circular hashing. `ARCHIVE_REV_R1_4_SHA256_MANIFEST.txt`, `ARCHIVE_REV_Q_PACKAGE_MANIFEST.sha256`, and `ARCHIVE_REV_R_PACKAGE_MANIFEST.sha256` are historical records from earlier revisions and are not the active R1.5 manifest.

The final ZIP must pass both checks before distribution:

1. `ZipFile.testzip()` returns no bad member.
2. Every line in `REV_R1_5_SHA256_Manifest.txt` hashes to the exact bytes of the corresponding file extracted from the final ZIP, and the ZIP member set is identical to the manifest paths plus the manifest itself.

The integrity check establishes digital file consistency only. It does not establish physical strength, manufacturing tolerances, material qualification or wearer safety.
