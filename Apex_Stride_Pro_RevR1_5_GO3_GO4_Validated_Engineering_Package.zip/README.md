# Apex Stride Pro — Rev R1.5 GO 3 + GO 4

**Current release: digitally checked engineering candidate. Not a manufacturing release and not cleared for human wear.**

## Start here
1. `Apex_Stride_Pro_RevR1_5_Full_Audit_Report.md` — current full GO3/GO4 audit and limitations.
2. `PROJECT_STATUS_AND_RELEASE_GATE_REV_R1_5.md` — current release gate.
3. `Apex_Stride_Pro_RevR1_5_Corrected.scad` / `revision/Apex_Stride_Pro_RevR.scad` — current editable native source; print-prep source is byte-identical.
4. `REV_R1_5_STRUCTURAL_SCREEN.csv` and `REV_R1_5_STRUCTURAL_SCREEN_QA.json` — 79 analytical load/joint/pneumatic rows.
5. `REV_R1_5_MASS_SUMMARY_BY_SIZE.csv` — fresh aggregate outsole and estimated lower-platform mass, with assumed material densities.
6. `REV_R1_5_ALL_72_MESH_AUDIT.csv` / `.json` — full active mesh audit.
7. `REV_R1_5_QA.json` and `REV_R1_5_SHA256_Manifest.txt` — current QA and integrity records.

## Actual GO3/GO4 design change
The standard 4.0 mm outsole keeps its external thickness and now has 1.5 mm mechanism relief, giving 2.5 mm nominal residual tread skin. The optional 3.2 mm mass study remains at 1.8 mm skin and is not approved for wear. No tread material or adhesive is selected, so this does not establish grip or fatigue life.

## Tests and open gates
Fresh exports: 42/42 standard kit and 9/9 optional study meshes. Current 72-mesh topology audit: 72/72 valid after in-memory topology processing. Previously completed geometry regressions: cavity 9/9, kinematic 250/250, rail/stop 6/6, bridge/fastener 18/18, lock-tip 4/4. The prior 130-check source/package regression also passed on geometry-identical R1.5 source before two comment-only pneumatic rating clarifications; a replay timed out, but all 42+9 mesh selectors were freshly compiled/exported against the final source. The report accurately separates those results.

No material-specific FEA or physical load/fatigue/retention/pneumatic/traction tests were completed. The pin and joints remain structurally unqualified. Do not wear or body-load this version.
