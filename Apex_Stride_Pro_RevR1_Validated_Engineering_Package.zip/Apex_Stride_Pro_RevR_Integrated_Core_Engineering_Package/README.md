# Apex Stride Pro — Rev R integrated core-cavity package

## Current release files

- Editable OpenSCAD: `revision/Apex_Stride_Pro_RevR.scad`
- Synchronized print-prep source: `PRINT_READY_BENCH_FIT_KIT_REV_R/source/Apex_Stride_Pro_RevR_PrintPrep.scad`
- Engineering report: `FINAL_ENGINEERING_REPORT_REV_R.md`
- Consolidated tests: `FINAL_CLOSURE_TEST_REGISTER.md`
- Quick package verification: `FINAL_PACKAGE_VERIFICATION.md`
- Release gate: `PROJECT_STATUS_AND_RELEASE_GATE_REV_R.md`
- Consolidated validation register: `FINAL_CLOSURE_TEST_REGISTER.md`
- Assembly/manual: `revision/docs/ASSEMBLY_MANUAL_REV_R.md`
- 72-row file map: `revision/docs/ASSEMBLY_FILE_MAP_REV_R.csv`
- 60-row BOM: `revision/docs/BILL_OF_MATERIALS_REV_R.csv`
- Material, interface/fastener and pneumatic schedules: `revision/docs/MATERIAL_PROPERTY_TABLE_REV_R.csv`, `revision/docs/COMPONENT_INTERFACE_FASTENER_SCHEDULE_REV_R.csv`, `revision/docs/PNEUMATIC_CIRCUIT_PRESSURE_SCHEDULE_REV_R.csv`
- 66 kg load screen: `revision/docs/LOAD_ASSESSMENT_66KG_REV_R.md`
- 20-item component physical validation checklist: `revision/docs/PHYSICAL_VALIDATION_CHECKLIST_REV_R.csv`
- Native verification records: `revision/verification_results/revR_core_integration/` and `reports/REV_R_CORE_INTEGRATION/`

## Geometry change

Rev R replaces the earlier ribbed under-deck reserve with a continuous **55×23×15.1 mm** cavity in the fixed heel deck (nominal top roof 5.5 mm; nominal side web to rail channel 2.5 mm). Native OpenSCAD geometry tests verify cavity/roof ray intersections and show that the cavity remains when optional lightening is disabled. This is a geometric integration fix only; no real spring, bladder, pneumatic ports or valves are selected or validated.

## Included mesh assets

- **42 fit/mockup parts** (14 per size EU42/EU44/EU46) under `PRINT_READY_BENCH_FIT_KIT_REV_R/stl/`.
- **21 upper concept meshes**; not sewn patterns and not foot-retention components.
- **9 optional 3.2 mm outsole study meshes**; non-wearable study only. The default modeled outsole stays 4.0 mm.
- Polymer rail/pin/ring meshes are gauges only. Do not use them as load-bearing hardware.

## Material basis and estimates

Rigid heel/toe deck candidate is the specified Materialise PA12 SLS process/card, not generic FDM or MJF. TPU 95A data apply only to the cited manufacturer/process and non-primary flexible items. Metal, spring, actual bladder/circuit, EVA, outsole compound and upper construction still need exact supplier decisions. The fresh CAD mass table includes only modeled rigid parts plus outsole using an explicitly illustrative 1.20 g/cm³ density; it excludes footbed, actual ring, fasteners, upper, spring, bladder/lines/fittings/valves and adhesive. It shows Rev R approximately 4.5–4.6 g heavier than Rev K in the comparable scope; no default mass reduction is claimed.

## Reproduce / verify

Requires OpenSCAD, Python 3, NumPy and trimesh. From package root:

```bash
python3 revision/tools/export_print_fit_kit_revR.py
python3 revision/tools/recalculate_mass_materials_revR.py
python3 revision/tools/run_revr_kinematic_clearance_sweep.py
python3 revision/tools/test_revr_locked_stop_intersections.py
python3 revision/tools/verify_revr_core_cavity.py
python3 revision/tools/run_revr_source_compile_checks.py
```

The checks cover source/print-prep parity, CAD exports, mesh integrity, nominal kinematics/CSG intersections, cavity geometry, file map and mass arithmetic. They do **not** establish structural capacity, fatigue, pneumatic safety or wear authorization. No material-specific FEA, `.FCStd`, validated STEP or physical test is included. The original uploaded baseline and historical revisions are retained for traceability.

## Release status

**Non-wearable engineering-review and dimensional mockup only. Human wear is NOT CLEARED.** Complete supplier-specific design, structural/tolerance analysis, guarded load/fatigue/retention/pneumatic/outsole/upper tests and independent sign-off before any human walking or running trial.
