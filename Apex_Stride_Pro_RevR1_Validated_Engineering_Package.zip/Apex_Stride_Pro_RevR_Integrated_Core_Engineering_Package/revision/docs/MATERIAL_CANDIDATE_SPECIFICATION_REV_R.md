# Rev R1 material/process and sourced component specification

**Current baseline is Rev R with the Rev R1 component-interface corrections.** This file records supplier-backed candidate data and actual holds. It replaces earlier generic statements that the spring material family was chosen but the spring itself was not selected. The Lee Spring catalog spring is now a specific conditional candidate; the bladder remains an OEM RFQ and pressure is not selected.

## Structural PA12 SLS — selected manufacturing route

Use **Materialise industrial PA 12 SLS** for the fixed heel deck, moving toe carriage and suitable rigid housings. Published card: density 0.95 g/cm³, tensile modulus 1650 MPa, tensile strength 48 MPa, flexural strength 41 MPa, flexural modulus 1500 MPa, elongation at break 20%, Shore D75, HDT 86°C. Source/material service: https://www.materialise.com/en/industrial/3d-printing-materials/pa12-sls

This is a specific industrial SLS route, not an approval of an arbitrary PA12 grade. Obtain the supplier's build orientation, lot/process certificate, critical dimension report and part-specific property/allowable advice. Do not transfer the card to generic FDM or MJF. Tensile strength is not yield strength. The 5.5 mm cavity roof / 2.5 mm channel web remain structurally unqualified.

## Flexible non-primary TPU

UltiMaker TPU 95A FFF TDS reports tensile modulus of 67±6 MPa XY-flat and 56±3 MPa Z-up; stress at break 23.7±2.1 MPa XY-flat and 6.4±0.5 MPa Z-up. Source: https://um-support-files.ultimaker.com/materials/2.85mm/tds/TPU-95A/TDS-TPU95A-V2.01-250915.pdf

This evidence is only for that filament/process and specimen orientation. TPU 95A is not thereby an airtight, burst-rated or fatigue-qualified pressure bladder. The chamber path is a DERFLEX OEM RFQ only.

## Specific spring candidate — conditional return duty

Lee Spring **LHP 030B 04S / LHP030B04S**, Type 17-7 PH stainless compression spring: https://www.leespring.com/product/compression-spring-lhp030b04s-stainless-steel-type-17-7-ph

Supplier listing gives OD 4.57 mm, free length 19.05 mm, solid height 10.11 mm, wire Ø0.76 mm, spring rate 5.126 N/mm, listed load at solid 45.77 N, calculated free-to-solid travel 8.94 mm and listed guide-rod dimension 2.38 mm. A bore of ≈3.05 mm is derived from `OD − 2×wire`; it is **not separately quoted by the manufacturer**, so the catalog drawing must be confirmed before manufacturing the guide. It fits the reserve envelope only when its axis follows the 24 mm cavity dimension. Under an analyst-assumed, unverified 4–6 mm return compression and zero preload, `F=kδ` estimates 20.5–30.8 N, with nominal remaining travel to solid of 2.94 mm at 6 mm compression. The actual linkage stroke/return force, preload, positive end seats, guide, tolerance stack, fatigue life and supplier load-deflection curve remain open. This is not a primary body-load spring.

## Air components and pressure limits

- **Tube:** SMC T0425 Nylon 12, 4 mm OD × 2.5 mm ID; 13 mm minimum bend radius and cited 1.5 MPa max operating at 20°C (derate for temperature/medium). No tube route exists in CAD.
- **Fittings:** SMC KQ2H04-M5A (M5×0.8 port) and KQ2H04-G01A (G1/8 port), for 4 mm OD tube; candidate KQ2 max operating 1.0 MPa / proof 3 MPa. Fit/port/route to the final custom bladder remains open.
- **Regulator:** SMC ARX20-F01BG external bench-panel candidate, output range 0.05–0.85 MPa, inlet max 2 MPa, proof 3 MPa. Not shoe-mounted.
- **Relief:** SMC AP20-D family, nominal set range 0.05–0.8 MPa, operating max 0.85 MPa and proof 1.3 MPa; exact order suffix/port must be confirmed.
- **Check, gauge and dump:** check-valve flow-direction SKU, chamber-side gauge/tee code and 3/2 isolate-and-vent valve remain purchasing holds. AKH04A-M5 is one documented flow direction and must not be ordered blindly.
- **Bladder:** DERFLEX fabric bladder OEM RFQ reference APX-BLD-RR1; nominal target body ≤27×22×14 mm is a fit/RFQ envelope, not a finished product SKU. Must obtain dimensioned body and port drawing, fold/weld layout, working pressure, burst pressure, effective area/load-height curve, leakage and cyclic-flex/cycle rating, and pressure-loss behavior before CAD closeout.

Maximum nominal cavity projected area is 55×23 = 1265 mm². Under an idealized whole-load/whole-area assumption, `p=F/A` gives 0.512 MPa at one-foot static (647.46 N), 1.024 MPa at the 2× sensitivity and 1.535 MPa at the 3× sensitivity. Effective bladder area may be smaller and spring share is unknown; the 2× lower-bound estimate exceeds the KQ2 1.0 MPa operating rating. **No safe operating pressure or regulator/relief setpoint is selected.** Analyst multipliers are sensitivity cases, not measured gait loads.

## Metal rail, bridge, pin and fasteners

- Rails/bridges are custom CNC 6061-T6 candidates from internal drawings APX-RAIL-L-R1, APX-RAIL-R-R1, APX-BRG-REAR-R1 (130×23×3 mm) and APX-BRG-FRONT-R1 (85×23×3 mm). McMaster aluminum stock is a raw-material sourcing path, not a finished part SKU. Require certified alloy/temper, thread drawings, surface finish and fit/load review.
- Cross-pin: custom turned UNS S17400 / 17-4PH H1150D candidate, APX-PIN-RR1; shaft Ø8 mm, approx. 90.3 mm span, Ø12×3 mm head, Ø7.6×0.9 mm retaining-ring groove. Manufacturer material page: https://www.langleyalloys.com/materials/stainless/17-4-ph/ . This is an internal custom drawing, not a finished catalog pin; proof/fatigue/contact/retention and material certificate remain required.
- Ring: Lawson 41580 external 18-8 stainless DIN 471 size 8 mm: https://www.lawsonproducts.com/products/retaining-ring-external-18-8-stainless-steel-8mm-41580 . Confirm detailed supplier groove drawing, capacity and fit to modeled Ø7.6×0.9 mm groove.
- Screws: Würth 009801412 M4×12, 009801418 M4×18, 009801416 M4×16, 00980148 M4×8, ISO 7380-1 A2-070; nominal Ø7.6×2.2 mm head. Manufacturer warnings limit head loading. CAD now has Ø7.9 mm bridge recesses and Ø8.0 mm rail counterbores, 2.2 mm deep; no joint allowable is inferred.
- Nuts: Keller & Kalmbach 5240324 ISO 4032 M4 A2-70, AF7 mm, about 3.2 mm high; current traps AF7.35 mm with the stated depths. No approved torque is assigned.
- Bushing: no exact SKU chosen. A full sleeve can obstruct transverse rail-index engagement in the Ø8.8 mm carriage passage; resolve bearing lands/seat/load path before purchase or geometry change.

## Footbed, upper and outsole candidates

- **Footbed:** GISMA EVA-50; 5 mm forefoot sheet candidate, 7 mm heel by custom/laminated stack. Published candidate properties: 50 kg/m³, 52±3 Shore C, rebound ≥60%, stated ≥1.2M flex cycles without collapse. GISMA EVA-38 (38 kg/m³, 38±3 Shore C, rebound ≥65%, stated ≥0.8M cycles) for 3 mm collar/tongue padding. Compression-deflection and compression-set curves are not in the listing; obtain them and confirm cover/bond/stack.
- **Upper mesh:** Spacermesh 2BC2-8A, 3 mm / 340 g/m² / 150 cm width, polyester; listing conflicts 30D vs 33D middle-yarn specification. Resolve this before roll order and obtain tear/abrasion/colorfastness/sewability/seam data. This does not provide a cut/sew pattern.
- **Reinforcement:** Strapworks WSR-NYL-M37-034-BLK, 19.05 mm nylon webbing, USD 0.89/ft or USD 24.56/30 ft roll listing. Breaking load not published; use prototype strap/edge reinforcement only. It is not broad overlay fabric. A high-tenacity woven nylon panel SKU and sewn pattern remain open.
- **Heel counter:** Avetco Poliflex P2080 SKU PO.016.2080.8MM, 0.8 mm sheet; retail snapshot USD 27, process guidance 110–130°C, 4–6 kg/cm², 4–10 s. Requires a last-matched pattern and formed trial; it is not the finished 3D CAD shell.
- **Thread/closure:** Coats Dabond Tex90/Ticket20 candidate, listed average strength 8085 cN (80.85 N) and elongation 16–28%; exact spool/color open. VELCRO One-Wrap VEL-OW64511, 20×200 mm, is only a prototype closure; source reports peel 1.8 N/cm², shear 32 N/cm² and medium cycle description. No footwear-retention proof.
- **Outsole:** Vibram Cherry 7175CHERRYSHT4MMBLK, 4 mm sheet, 36×11 in; price snapshot USD 45. Retail listing does not confirm 60–70 Shore A, fatigue, tear or abrasion; that range remains a target, not a verified product property. No PA12 SLS-to-this-compound production adhesive/primer is selected. LOCTITE 406 is coupon-trial reference only.
- **Unresolved overlay fabric:** high-tenacity broad nylon panel and last-matched upper pattern still lack exact product number and TDS; hold rather than substituting 19 mm webbing.

## Explicit release limits

The updated CAD is source/mesh validated. **No physical test was run and material-specific FEA was NOT RUN.** No supplier components have been physically gauged; no pressure/leak/burst/cycle test, proof/fatigue, pin/ring retention, outsole adhesion/slip, sewn upper anchor/seam or human-wear trial has been performed. These are evidence gaps, not a substitute for sourcing: the candidate list is populated, while only components without a compatible, documented finished part are left as exact purchase holds in `REV_R1_PROCUREMENT_LIST.csv`.
