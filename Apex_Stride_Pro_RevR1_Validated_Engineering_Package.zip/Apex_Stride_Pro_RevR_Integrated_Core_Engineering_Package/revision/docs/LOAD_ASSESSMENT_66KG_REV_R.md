# Apex Stride Pro Rev R1 — 66 kg load and component operating-envelope assessment

**Status: analytical screening for design decisions only. Material-specific FEA was NOT RUN; no physical test was run; this is not an allowable stress calculation, proof test, or wearable release.** Rev R’s source now contains the continuous core cavity and the Rev R1 screw/foam-clearance edits.

## Body-weight datum and load scenarios

`F = m g = 66 kg × 9.81 m/s² = 647.46 N`. An ideal equal bilateral static share is `323.73 N per foot`. A single-support static scenario applies `647.46 N` to one shoe. The factors below are sensitivity cases chosen by the analyst, not measured gait force, medical/biomechanical data, standards acceptance factors, or a proposed safe load.

| One-shoe scenario | Force |
|---|---:|
| Equal bilateral static share | 323.73 N |
| Single-foot static full-body weight | 647.46 N |
| 1.5× sensitivity | 971.19 N |
| 2× sensitivity | 1,294.92 N |
| 3× sensitivity | 1,942.38 N |

## Structural PA12 candidate

Materialise industrial PA12 SLS reference card: density 950 kg/m³, tensile modulus 1650 MPa, tensile strength 48 MPa, flexural strength 41 MPa, flexural modulus 1500 MPa, elongation at break 20%, Shore D75 and HDT 86°C. Supplier card: https://www.materialise.com/en/industrial/3d-printing-materials/pa12-sls. These are process/card reference values; build orientation, lot, part geometry and conditioning affect parts. **48 MPa tensile strength is not yield strength and neither value is a design allowable.** Do not transfer these values to generic FDM or an unspecified MJF grade.

## Current cavity roof strip sensitivity

Rev R has a real continuous 55×23×15.1 mm underside cavity in the fixed heel deck, nominal roof 5.5 mm and side web 2.5 mm to the rail-channel envelope. A deliberately simplified one-way roof strip assumes `L=23 mm`, `h=5.5 mm`, and an effective longitudinal load-spread width `b`. The screening expression used in the accompanying analysis is `σ = 3 F L / (2 b h²)` for a central-load idealization. The actual 3D deck/rail/contact field differs; the width is an unknown assumption.

| Assumed load-spread width | 1× single-foot force | 1.5× | 2× | 3× |
|---:|---:|---:|---:|---:|
| 20 mm | 36.92 MPa | 55.38 MPa | 73.84 MPa | 110.76 MPa |
| 30 mm | 24.61 MPa | 36.92 MPa | 49.23 MPa | 73.84 MPa |
| 40 mm | 18.46 MPa | 27.69 MPa | 36.92 MPa | 55.38 MPa |
| 60 mm | 12.31 MPa | 18.46 MPa | 24.61 MPa | 36.92 MPa |

These are **load-demand sensitivities**, not failure predictions or design factors. Several narrow-width or higher-load cases exceed the reference flexural-strength value of 41 MPa; this is a warning that the design cannot be cleared by a simple screening formula. The roof, web, rail channels, contact distribution, build orientation, notches, fatigue and impact need material-specific structural analysis.

## Pin / rail retention sensitivity

Internal pin drawing target is an Ø8 mm 17-4PH H1150D custom pin with a nominal Ø7.6 mm retaining-ring groove root; the finished catalog part is not selected. A conservative simple-beam screen assumes a centre point load over a 90.3 mm span and treats the minimum Ø7.6 mm groove section as if it spanned the whole beam. That deliberately crude model gives:

| Scenario | Screened nominal bending stress |
|---|---:|
| Bilateral static share, 323.73 N | 169.58 MPa |
| Single-foot static, 647.46 N | 339.16 MPa |
| 1.5× | 508.73 MPa |
| 2× | 678.31 MPa |
| 3× | 1,017.47 MPa |

A listed reference minimum proof strength for 17-4PH H1150D is approximately 725 MPa (confirm exact supplier material certification/condition). The 3× sensitivity exceeds that number, and the 2× case has little nominal margin before accounting for groove stress concentration, fatigue, contacts and uncertainty. This is not an approval of the pin; the actual load path may be very different and must be calculated. Printed polymer pins are not acceptable for the critical joint.

## Spring candidate and derived return force

Lee Spring LHP 030B 04S / LHP030B04S is the selected **conditional return-function bench candidate**: Type 17-7 PH stainless; listed OD 4.57 mm, free length 19.05 mm, solid height 10.11 mm, rate 5.126 N/mm, listed load at solid 45.77 N; free-to-solid travel computed from lengths is 8.94 mm. The listed guide-rod dimension is 2.38 mm. For wire Ø0.76 mm, the nominal bore inferred from OD−2×wire is approximately 3.05 mm; this bore is **derived, not a separate supplier-quoted dimension**, and the actual drawing must be obtained before designing a guide.

No spring working stroke is derivable from the bounding cavity. For a stated, analyst-selected return-only scenario of 4–6 mm compression with no preload, `F=kδ` gives about 20.50–30.76 N. At 6 mm, the nominal remaining travel to the calculated solid height is 2.94 mm before tolerances/end effects. This is not a full-body-weight spring. Linkage travel, actual return force, preload, seat retention, guide, load-deflection tolerances and fatigue duty remain selection gates.

## Pneumatic lower-bound pressure scenario

The maximum projected rectangle of the cavity is 55×23 = 1,265 mm². If the bladder alone carried the whole load uniformly over that entire maximum area, `p=F/A` yields a *lower-bound pressure estimate*:

| Scenario | Pressure at 1,265 mm² max projected area |
|---|---:|
| Bilateral static share, 323.73 N | 0.256 MPa |
| Single-foot static, 647.46 N | 0.512 MPa |
| 1.5× | 0.768 MPa |
| 2× | 1.024 MPa |
| 3× | 1.535 MPa |

Real effective area is likely less than the bounding rectangle and spring load share is unknown, so actual pressure demand could be higher. SMC KQ2 fitting candidate max operating pressure is 1.0 MPa, SMC ARX20-F01BG regulator output max is 0.85 MPa, and the selected SMC relief family’s exact suffix/port and setpoint are unresolved. Thus even the idealized 2× lower bound exceeds the KQ2 operating rating; the circuit cannot be approved/set from body weight alone. **No safe operating pressure is selected.** Require a finished bladder’s working/burst ratings, effective area/load-height data, fittings/valves/line limits, pressure-loss behavior and a complete controlled-dump circuit before choosing any setpoint.

## Current sourced interfaces and limits

- **Rigid platform:** Materialise industrial PA12 SLS only, with lot/build orientation, critical dimension report and design allowables to be confirmed. Main deck/toe are custom SLS parts, not an off-the-shelf component.
- **Rails/bridges:** custom CNC 6061-T6 parts under internal drawings APX-RAIL-L-R1, APX-RAIL-R-R1, APX-BRG-REAR-R1 and APX-BRG-FRONT-R1; stock supplier is not the finished part manufacturer. Thread engagement, contact/wear, rail straightness and bridge fatigue require shop drawings and testing.
- **Fasteners:** proposed Würth M4 button-head lengths match nominal recess envelopes after Rev R1 edits; their source warns the head style is for limited loads. Check joint loads, thread engagement, anti-loosening, torque and corrosion compatibility.
- **Bushing:** no catalog bushing can yet be confirmed to fit the Ø8.8 mm carriage passage without blocking transverse rail-index engagement. Do not buy a generic sleeve until seat/land geometry is resolved.
- **Spring:** Lee Spring LHP030B04S is a conditional return-only candidate, not a completed fit/function selection.
- **Bladder:** DERFLEX is a custom OEM RFQ path, not a product SKU with working/burst/cycle ratings. Target body envelope ≤27×22×14 mm remains a supplier RFQ target, not a finished-part fit claim.
- **Air circuit:** SMC T0425 Nylon 12 tube is 4.0 mm OD × 2.5 mm ID and has a 13 mm minimum bend radius at its referenced condition. SMC KQ2H04 fittings match 4 mm OD tube, but line/port routing is not modeled. Check-valve direction SKU, AP20-D relief suffix, gauge/tee and 3/2 isolation/dump valve are purchasing holds. Components intended for a bench panel are not shoe-internal parts.
- **Upper/sole:** mesh, formed heel-counter sheet, EVA, rubber sheet, thread and prototype closure candidates have been identified; broad overlay-panel fabric/pattern, actual compound hardness/fatigue rating and production adhesive/primer are not closed.

## Status and next decision gates

Automation verifies source behavior, geometry consistency, adjustment states, mesh integrity and nominal calculations only. It does not measure the physical printed/machined parts. No material-specific FEA, tolerance simulation, cyclic/fatigue test, bladder pressure/leak test, proof load, outsole bond/slip test, sewn-upper retention test, or human-wear trial has been performed. Human wear is not cleared. Outstanding procurement decisions are enumerated in `revision/docs/REV_R1_PROCUREMENT_LIST.csv`; the precise sourced candidates and gates are in `revision/docs/SOURCED_COMPONENT_REGISTER_REV_R1.csv` and `revision/docs/PROCUREMENT_AND_MANUFACTURING_SPEC_REV_R1.md`.
