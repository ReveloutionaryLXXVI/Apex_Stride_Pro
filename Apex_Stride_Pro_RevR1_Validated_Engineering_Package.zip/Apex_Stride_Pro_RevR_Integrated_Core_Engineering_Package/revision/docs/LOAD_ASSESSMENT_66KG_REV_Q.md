# Apex Stride Pro Rev Q — 66 kg analytical load assessment

**Status: preliminary analytical screening; not FEA, proof testing, or wear clearance.**

## Body load

`F = m g = 66 kg × 9.81 m/s² = 647.46 N`. Ideal equal bilateral static distribution is `323.73 N per foot`. Single-foot standing can transfer about `647.46 N` to one shoe before transient gait loads, accelerations, and ground-reaction effects. No measured gait data exists for this prototype.

| Sensitivity case | Force on one shoe |
|---|---:|
| 1.0× static body-weight reference | 647.46 N |
| 1.5× illustrative transient sensitivity | 971.19 N |
| 2.0× illustrative transient sensitivity | 1294.92 N |
| 3.0× illustrative transient sensitivity | 1942.38 N |

These multipliers are analyst-selected sensitivity cases, not measured walking/running forces, regulatory load factors or acceptance criteria.

## PA12 card used for provisional screening

For a specific Materialise PA 12 SLS reference card: density 950 kg/m³, tensile modulus 1650 MPa, tensile strength 48 MPa, flexural strength 41 MPa, flexural modulus 1500 MPa, elongation at break 20%, Shore D75, HDT 86°C. These are typical supplier card values, dependent on processing, build orientation and geometry. **48 MPa tensile strength is not yield strength and is not used as an allowable.** Do not transfer this card to FDM or to an unspecified MJF grade. Source: https://www.materialise.com/en/industrial/3d-printing-materials/pa12-sls

## Simplified deck strip sensitivity

A deliberately simplified one-way beam screen assumes an unsupported span `L=28.0 mm` between approximate channel supports, roof thickness `t=4.1 mm`, and force distributed uniformly over an assumed longitudinal contact width `b`.

`q = F / b`, `M_max = q L² / 8`, `Z = b t² / 6`, therefore `σ = 3 F L² / (4 b² t²)`. The result varies strongly with the unspecified contact distribution; see `reports/REVQ_DECK_SCREENING_SENSITIVITY.csv`. For one-foot force at 1×, nominal bending demands are about 56.6 MPa for b=20mm, 25.2 MPa for b=30mm, 14.2 MPa for b=40mm, and 6.3 MPa for b=60mm. At least one narrow-spread sensitivity exceeds the published PA12 flexural strength value; even lower values are not a safety pass because this is not the actual 3D ribbed/chassis stress field. Actual pressure distribution, heel impact, rail contacts, fasteners, material anisotropy, fatigue and local stress concentrations need material-specific FEA and physical tests.

## Lock pin / rails / bridge

A previous corrected simple beam screen uses a candidate Ø8 mm metal pin, supports at ±45mm and two horizontal rail loads at ±20.3mm. For horizontal lock force equal to the full one-foot load, the nominal unnotched shaft bending demand is about 159.1 MPa. This is a conditional horizontal-load sensitivity only, not the vertical deck case or a validated allowable. Groove notch stress, contact, retaining-ring capacity, fatigue, wear, rail bearing/tear-out, M4 thread engagement, bridge slip and real load share remain unverified. The published PA12 card cannot be used to certify any fit-kit polymer pin or rail as a safety-critical part.

## Spring stiffness sensitivity

If a spring alone carried the full one-foot load, linear-rate sensitivities would be `k=F/δ`: for assumed deflection 3, 5, 8, 10 mm, `k=215.82`, `129.49`, `80.93`, `64.75 N/mm`. These are not a spring specification: spring share, preload, free length, solid height, travel, coil geometry, seat, and cycle rating are unknown. The 55×23×15.1 mm CAD core envelope is only a bounding study and intentionally overlaps discontinuous deck-pocket ribs; it is not a real cavity.

## Pneumatic pressure demand sensitivity

Idealized pressure `p=F/A` if the bladder alone carried the load produces 0.512 MPa (5.12 bar) for the *maximum envelope area* 1265 mm²; at a notional 900 mm² it is 0.719 MPa, and at 600 mm² it is 1.079 MPa. Smaller area and dynamic multipliers increase demand. These are load-over-area calculations **not safe operating pressures**; actual effective area, spring load share, bladder rating, fittings, tubing, regulator, relief valve and local contact geometry are unknown. No safe setpoint is assigned. Pressure relief must be set only after every element's rating and tested burst margin are established.

## What can be concluded

- Geometry tests can detect collisions, fit envelopes, mesh defects, and size-position issues; they do not validate strength.
- The current source does not contain actual pneumatic bladder, tubing, valve, regulator, gauge, relief valve, or spring solids.
- No installed FEA solver/material-contact model or physical specimen is available in this environment. No FEA was run. No physical test was run.
- The deck-strip sensitivity raises a credible load-bearing concern and must be resolved by a qualified engineer using the exact SLS manufacturer/process card, mesh/contact, realistic load cases and then guarded physical proof/fatigue testing.
- This is not clearance for body loading, walking, or running.
