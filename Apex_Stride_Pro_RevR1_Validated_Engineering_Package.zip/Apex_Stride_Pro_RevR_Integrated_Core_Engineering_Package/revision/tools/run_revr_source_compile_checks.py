#!/usr/bin/env python3
"""Rev R source, fit-kit, material-table and export checks; geometry-only, not strength testing."""
from pathlib import Path
import csv,json,subprocess,tempfile,math,re
import numpy as np
import trimesh
ROOT=Path(__file__).resolve().parents[2]
SRC=ROOT/'revision/Apex_Stride_Pro_RevR.scad'
PP=ROOT/'PRINT_READY_BENCH_FIT_KIT_REV_R/source/Apex_Stride_Pro_RevR_PrintPrep.scad'
KIT=ROOT/'PRINT_READY_BENCH_FIT_KIT_REV_R'
OUT=ROOT/'revision/verification_results/revR_core_integration'; OUT.mkdir(parents=True,exist_ok=True)
rows=[]
def add(group,case,passed,detail=''):
 rows.append({'group':group,'case':case,'result':'PASS' if passed else 'FAIL','detail':detail})
# Exact source parity excluding the five-line print-prep banner.
s=SRC.read_text(encoding='utf-8').splitlines()
pp=PP.read_text(encoding='utf-8').splitlines()
add('source parity','PrintPrep matches main CAD geometry/selectors',pp[-len(s):]==s,'PrintPrep contains only a labelled header followed by exact main-source text')
# Compile/export 18 selector/size/width combinations; native watertight component mesh checks.
for size in (42,44,46):
 for width in (1.0,1.04,1.08):
  for selector in ('heel','toe'):
   with tempfile.TemporaryDirectory(prefix='apex_revr_matrix_') as td:
    dst=Path(td)/'part.stl';cmd=['openscad','--export-format','binstl','-o',str(dst),'-D',f'eu_size={size}','-D',f'width_scale={width:.2f}','-D',f'part="{selector}"',str(SRC)]
    try: cp=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=75)
    except subprocess.TimeoutExpired:
     add('native compile matrix',f'EU{size} W{width:.2f} {selector}',False,'OpenSCAD export timed out');continue
    ok=cp.returncode==0 and dst.exists() and dst.stat().st_size>500 and 'ERROR:' not in cp.stdout
    detail=cp.stdout[-300:].replace('\n',' | ')
    if ok:
     try:
      m=trimesh.load_mesh(dst,force='mesh',process=True);ok=bool(m.is_watertight and m.is_winding_consistent and np.isfinite(m.vertices).all() and np.isfinite(m.volume) and m.volume>0)
      detail+=f' ; water={m.is_watertight}; volume={m.volume:.3f} mm3'
     except Exception as e:ok=False;detail+=f' ; mesh load error {e}'
    add('native compile matrix',f'EU{size} W{width:.2f} {selector}',ok,detail)
# Fit-kit index and all generated STL properties, including centered plate orientation.
with (KIT/'PRINT_PARTS_INDEX_REV_R.csv').open(newline='',encoding='utf-8') as f: index=list(csv.DictReader(f))
add('fit-kit inventory','42 rows, 14 per supported size',len(index)==42 and all(sum(r['size']==f'EU{s}' for r in index)==14 for s in (42,44,46)),f'{len(index)} index rows')
for r in index:
 path=KIT/'stl'/r['file']
 ok=path.exists()
 detail='file missing' if not ok else ''
 if ok:
  try:
   m=trimesh.load_mesh(path,force='mesh',process=True);bounds=m.bounds;ext=m.extents
   checks=[m.is_watertight,m.is_winding_consistent,np.isfinite(m.vertices).all(),np.isfinite(m.volume) and m.volume>0,max(abs((bounds[0,0]+bounds[1,0])/2),abs((bounds[0,1]+bounds[1,1])/2))<1e-3,abs(bounds[0,2])<1e-3,max(ext[0],ext[1])<=220.001,abs(float(m.volume)-float(r['normalized_volume_mm3']))<=max(.02,abs(float(r['normalized_volume_mm3']))*1e-6)]
   ok=all(checks); detail=f'tests={checks}; extents={ext.round(3).tolist()}'
  except Exception as e:ok=False;detail=str(e)
 add('fit-kit STL',r['file'],bool(ok),detail)
# Upper and optional outsole study mesh checks, no reposition for upper concepts.
for folder,expected,label in [('upper_concept_not_wearable',21,'upper concept mesh'),('optional_3p2mm_outsole_study',9,'optional outsole study mesh')]:
 files=list((KIT/folder).rglob('*.stl'))
 add('concept export inventory',folder, len(files)==expected, f'{len(files)} STL files; expected {expected}')
 for path in files:
  try:
   m=trimesh.load_mesh(path,force='mesh',process=True);ok=bool(m.is_watertight and m.is_winding_consistent and np.isfinite(m.vertices).all() and np.isfinite(m.volume) and m.volume>0)
   detail=f'watertight={m.is_watertight}; volume={m.volume:.3f} mm3'
  except Exception as e:ok=False;detail=str(e)
  add(label,path.relative_to(ROOT).as_posix(),ok,detail)
# Material-mass sum / output sanity
massdir=OUT
with (massdir/'REVR_COMPONENT_MASS_MATERIAL_CARD.csv').open(newline='',encoding='utf-8') as f: massrows=list(csv.DictReader(f))
with (massdir/'REVK_VS_REVR_MATERIAL_CARD_MASS_SUMMARY.csv').open(newline='',encoding='utf-8') as f: summ=list(csv.DictReader(f))
with (massdir/'REVR_OPTIONAL_OUTSOLE_STUDY_MASS.csv').open(newline='',encoding='utf-8') as f: st=list(csv.DictReader(f))
for r in summ:
 size=r['size'];revr=[x for x in massrows if x['revision']=='RevR' and x['size']==size and x['component']!='retaining_ring_schematic_only' and x['estimated_mass_g'] not in ('','TBD')]
 subtotal=sum(float(x['estimated_mass_g']) for x in revr if x['component']!='outsole_assembly')
 outsole=float(next(x['estimated_mass_g'] for x in revr if x['component']=='outsole_assembly'))
 recorded=float(r['RevR_chassis_pin_mass_g']); recorded_total=float(r['RevR_full_modeled_platform_g_outsole_1p20'])
 add('mass reconciliation',size,abs(subtotal-recorded)<1e-5 and abs(subtotal+outsole-recorded_total)<1e-5,f'component subtotal={subtotal:.6f}; outsole={outsole:.6f}; total={subtotal+outsole:.6f}')
for r in st:
 add('outsole mass study',r['size'],abs(float(r['estimated_saved_g'])-float(r['RevR_default_platform_g_excluding_footbed_fasteners_core'])+float(r['RevR_optional_3p2_platform_g_same_scope']))<1e-5,f"delta={r['mass_delta_study_minus_default_g']} g; unvalidated")
# Check required documentation exists and rows valid.
required=[ROOT/'FINAL_ENGINEERING_REPORT_REV_R.md',ROOT/'revision/docs/ASSEMBLY_MANUAL_REV_R.md',ROOT/'revision/docs/ASSEMBLY_FILE_MAP_REV_R.csv',ROOT/'revision/docs/BILL_OF_MATERIALS_REV_R.csv',ROOT/'revision/docs/MATERIAL_PROPERTY_TABLE_REV_R.csv',ROOT/'revision/docs/COMPONENT_INTERFACE_FASTENER_SCHEDULE_REV_R.csv',ROOT/'revision/docs/PNEUMATIC_CIRCUIT_PRESSURE_SCHEDULE_REV_R.csv',ROOT/'revision/docs/LOAD_ASSESSMENT_66KG_REV_R.md',ROOT/'revision/docs/PHYSICAL_VALIDATION_CHECKLIST_REV_R.csv',ROOT/'revision/docs/UPPER_FOOTBED_OUTSOLE_AND_HEEL_CORE_REV_R.md',ROOT/'revision/docs/PNEUMATIC_CIRCUIT_REV_R.svg',ROOT/'revision/docs/REV_R_ASSEMBLY_EXPLODED_SCHEMATIC.svg',ROOT/'revision/verification_results/revR_core_integration/REVR_CORE_CAVITY_GEOMETRY_CHECKS.csv']
for p in required: add('required document',p.relative_to(ROOT).as_posix(),p.exists() and p.stat().st_size>100,f'{p.stat().st_size if p.exists() else 0} bytes')
with (ROOT/'revision/docs/ASSEMBLY_FILE_MAP_REV_R.csv').open(newline='',encoding='utf-8') as f: fmap=list(csv.DictReader(f))
missing=[]
for r in fmap:
 path=ROOT/r['filename']
 if not path.exists():missing.append(str(r['filename']))
add('assembly map references','all component file references resolve',not missing,f'{len(fmap)} map rows; missing={missing[:10]}')
# Validate load calculations and explicit physical limitations in report.
F=66*9.81
add('load calculation','body weight 647.46 N',abs(F-647.46)<1e-8,f'{F:.3f} N; bilateral={F/2:.3f} N')
for p in [ROOT/'revision/docs/LOAD_ASSESSMENT_66KG_REV_R.md',ROOT/'revision/docs/MATERIAL_CANDIDATE_SPECIFICATION_REV_R.md']:
 text=p.read_text(encoding='utf-8')
 add('honesty gate',p.name,'NOT RUN' in text or 'not run' in text.lower() or 'no physical test was run' in text.lower(), 'checks for unrun/unvalidated caveat present')
# Summary and CSV
with (OUT/'REVR_SOURCE_COMPILE_AND_PACKAGE_CHECKS.csv').open('w',newline='',encoding='utf-8') as f:
 w=csv.DictWriter(f,fieldnames=['group','case','result','detail']);w.writeheader();w.writerows(rows)
# Current Rev R cavity tests: native meshes are ray-probed through the cavity and roof, and compared with optional lightening disabled.
with (OUT/'REVR_CORE_CAVITY_GEOMETRY_CHECKS.csv').open(newline='',encoding='utf-8') as f: cavity_rows=list(csv.DictReader(f))
for r in cavity_rows:
    if r.get('pass') in ('True','False'):
        ok=(r.get('pass')=='True' and r.get('watertight')=='True' and r.get('winding_consistent')=='True')
        add('core cavity geometry',f"EU{r['size']} lightening={r['lightening_enabled']}",ok,f"cavity-ray={r.get('cavity_ray_intersections')}; roof-ray={r.get('roof_material_ray_intersections')}; outside-ray={r.get('solid_outside_cavity_ray_intersections')}")
    else:
        ok=(r.get('independent_of_lightening_toggle')=='True' and abs(float(r.get('volume_delta_true_vs_false_mm3') or 1))<0.01)
        add('core cavity guard',f"EU{r['size']} cavity independent of optional lightening",ok,f"volume delta true/false={r.get('volume_delta_true_vs_false_mm3')} mm3")
passed=sum(r['result']=='PASS' for r in rows);failed=sum(r['result']=='FAIL' for r in rows)
summary={'revision':'Rev R1 component-specification closure (CAD baseline Rev R)','check_count':len(rows),'pass':passed,'fail':failed,'result':'PASS' if failed==0 else 'FAIL','source_printprep_exact_match':pp[-len(s):]==s,'fitkit_rows':len(index),'upper_concept_stls':len(list((KIT/'upper_concept_not_wearable').rglob('*.stl'))),'optional_outsole_stls':len(list((KIT/'optional_3p2mm_outsole_study').rglob('*.stl'))),'assembly_map_rows':len(fmap),'missing_map_paths':missing,'limitations':['Mesh/compile/interface checks do not prove structural strength or wear safety.','All physical qualification items in PHYSICAL_VALIDATION_CHECKLIST_REV_R.csv are NOT RUN.','A full FEA was not run: no FEA solver was installed. A conditional catalogue spring candidate is identified, but seats/stroke are unresolved; the bladder has no finished supplier drawing or pressure/cycle rating.','The Rev R cavity is geometrically continuous and clears the old pocket ribs; spring fit is bounding-envelope-only, bladder is an OEM RFQ, and port routing/structural strength are not validated.','No physical tests or human wear trials were performed.']}
(OUT/'REVR_SOURCE_COMPILE_AND_PACKAGE_CHECKS.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
raise SystemExit(1 if failed else 0)
