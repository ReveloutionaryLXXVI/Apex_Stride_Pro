#!/usr/bin/env python3
"""Independent arithmetic cross-check for 66 kg load, cavity roof, pin, and pressure.

This script does not run FEA and does not assign an allowable stress or safety factor.
Every beam/strip calculation is a sensitivity model whose load path must be confirmed.
"""
from pathlib import Path
import csv, json, math, re, shutil, importlib.util
ROOT=Path(__file__).resolve().parents[2]
SRC=ROOT/'revision/Apex_Stride_Pro_RevR.scad'
OUT=ROOT/'revision/verification_results/revR1_fresh_validation'
OUT.mkdir(parents=True,exist_ok=True)
txt=SRC.read_text(encoding='utf-8')
def value(name):
    m=re.search(rf'(?m)^\s*{re.escape(name)}\s*=\s*([-+]?(?:\d+\.?\d*|\.\d+))\s*;',txt)
    if not m: raise KeyError(f'missing CAD parameter: {name}')
    return float(m.group(1))

mass_kg=66.0; g=9.81; F0=mass_kg*g
load_case=('Conservative single-support sensitivity: entire 66 kg gravitational load assigned to one shoe; not the equal bilateral static average (323.73 N/foot). The 1.0/1.5/2.0/3.0 multipliers scale this one-shoe force and are not measured gait loads.')
area=value('heel_core_envelope_length')*value('heel_core_envelope_width')
roof_h=abs(value('lightening_roof_z'))
roof_span=value('heel_core_envelope_width')
rail_spacing=2*value('rail_y')
pin_d=value('pin_groove_root_d')
# These references are documented candidate/card values, not approved design allowables.
pa12_flexural_reference_mpa=value('pa12_flexural_strength_mpa')
h1150d_proof_reference_mpa=725.0
multipliers=[1.0,1.5,2.0,3.0]
rows=[]
for mult in multipliers:
    force=F0*mult
    pressure=force/area # N/mm^2 = MPa
    rows.append({'check':'bladder pressure sensitivity','load_case':load_case,'multiplier':mult,'assumed_span_or_width_mm':area,'force_N':force,'result_value':pressure,'unit':'MPa','reference_value':1.0,'comparison':'candidate KQ2 fitting maximum operating pressure; force assumed entirely borne by bladder over maximum projected area','result':'EXCEEDS' if pressure>1.0 else 'below candidate rating, conditional on ideal area/force assumptions'})
    for width in [20.0,30.0,40.0,60.0]:
        sigma=3*force*roof_span/(2*width*roof_h**2)
        rows.append({'check':'cavity roof one-way strip sensitivity','load_case':load_case,'multiplier':mult,'assumed_span_or_width_mm':width,'force_N':force,'result_value':sigma,'unit':'MPa','reference_value':pa12_flexural_reference_mpa,'comparison':'simple central-load strip model vs published PA12 flexural-strength reference; not an allowable','result':'above reference' if sigma>pa12_flexural_reference_mpa else 'not above reference'})
    for span in [rail_spacing,90.3]:
        moment=force*span/4
        sigma=32*moment/(math.pi*pin_d**3)
        rows.append({'check':'pin centre-load beam span sensitivity','load_case':load_case,'multiplier':mult,'assumed_span_or_width_mm':span,'force_N':force,'result_value':sigma,'unit':'MPa','reference_value':h1150d_proof_reference_mpa,'comparison':'simple centre point load, round Ø7.6 mm groove-root section; compare to candidate H1150D proof reference only','result':'above reference' if sigma>h1150d_proof_reference_mpa else 'not above reference'})
with (OUT/'REV_R1_INDEPENDENT_LOAD_SCREEN.csv').open('w',newline='',encoding='utf-8') as f:
    w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
# Explicit arithmetic consistency gates.
assert abs(F0-647.46)<1e-8
assert abs(F0/2-323.73)<1e-8
assert abs(F0/area-0.5118260870)<1e-8
assert abs(F0*2/area-1.0236521739)<1e-8
# Compare source-export source parity and current fresh results (when already present).
pp=ROOT/'PRINT_READY_BENCH_FIT_KIT_REV_R/source/Apex_Stride_Pro_RevR_PrintPrep.scad'
main_lines=SRC.read_text(encoding='utf-8').splitlines()
pp_lines=pp.read_text(encoding='utf-8').splitlines()
parity=pp_lines[-len(main_lines):]==main_lines
assert parity, 'print-prep source diverges from authoritative CAD source'
solver_checks={name:shutil.which(name) for name in ['ccx','calculix','gmsh','FreeCAD','freecad','abaqus','code_aster']}
solver_modules={name:bool(importlib.util.find_spec(name)) for name in ['sfepy','fenics','dolfinx','calfem','pyNastran']}
summary={
 'revision':'Rev R1 fresh independent load arithmetic (CAD geometry Rev R with a 0.01 mm counterbore cutter correction)',
 'body_mass_kg':mass_kg,'gravity_m_s2':g,'body_force_N':F0,'equal_bilateral_static_force_per_foot_N':F0/2,'load_case':load_case,
 'projected_cavity_area_mm2':area,'nominal_roof_thickness_mm':roof_h,'pin_groove_root_diameter_mm':pin_d,
 'rail_centerline_spacing_mm':rail_spacing,'whole_pin_span_sensitivity_mm':90.3,
 'pressure_1x_MPa':F0/area,'pressure_2x_MPa':2*F0/area,'pressure_3x_MPa':3*F0/area,'pressure_equal_bilateral_static_share_MPa':(F0/2)/area,
 'roof_strip_formula':'sigma = 3*F*L/(2*b*h^2), L=23 mm, h=5.5 mm, b=20/30/40/60 mm assumed',
 'pin_formula':'sigma = 32*(F*span/4)/(pi*d^3), d=7.6 mm, span=40.6 and 90.3 mm sensitivity only',
 'pa12_flexural_reference_MPa':pa12_flexural_reference_mpa,'candidate_pin_proof_reference_MPa':h1150d_proof_reference_mpa,
 'printprep_source_parity':parity,'fea_solver_executables_found':{k:v for k,v in solver_checks.items() if v},
 'fea_solver_executables_checked':list(solver_checks.keys()),'python_fea_modules_found':[k for k,v in solver_modules.items() if v],
 'result':'PASS_ARITHMETIC_ONLY','limitations':[
   'No finite-element solver/workflow was available or run in this environment.',
   'The cavity-roof one-way strip and pin centre-load beam are analyst-defined sensitivity models, not a validated load path or allowable-stress analysis.',
   'Load multipliers assign the entire 66 kg gravitational load to one shoe (647.46 N at 1x), deliberately unlike the equal bilateral static average of 323.73 N per foot. The pressure table assumes the bladder alone carries that scenario force over the full maximum projected cavity area; actual gait loads, load sharing and effective area are unresolved.',
   'Candidate material reference values are not design allowables; process/lot/build direction, notches, contacts, fatigue and impact are not modeled.',
   'No physical test or wear qualification was performed.'
 ]
}
(OUT/'REV_R1_INDEPENDENT_LOAD_SCREEN.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
print(json.dumps(summary,indent=2))
