#!/usr/bin/env python3
"""Build the current Rev R1 digital validation report and QA summary after rerunning checks."""
from pathlib import Path
import csv, json, hashlib
ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'revision/verification_results/revR1_fresh_validation'
OUT.mkdir(parents=True,exist_ok=True)
def readj(path): return json.loads(path.read_text(encoding='utf-8'))
def readcsv(path):
    with path.open(newline='',encoding='utf-8') as f: return list(csv.DictReader(f))
source=readj(ROOT/'revision/verification_results/revR_core_integration/REVR_SOURCE_COMPILE_AND_PACKAGE_CHECKS.json')
cavity=readj(ROOT/'revision/verification_results/revR_core_integration/REVR_CORE_CAVITY_GEOMETRY_CHECKS.json')
sweep=readj(ROOT/'revision/verification_results/revR_material_integration/kinematic_sweep/REV_R_61_POSITION_KINEMATIC_CLEARANCE_SWEEP.json')
csg=readj(ROOT/'revision/verification_results/revR_material_integration/exact_csg/REV_R_EXACT_TOE_RAIL_INTERSECTION_TEST.json')
mass=readj(ROOT/'revision/verification_results/revR_core_integration/REVR_MASS_AUDIT_SUMMARY.json')
mass_rows=readcsv(ROOT/'revision/verification_results/revR_core_integration/REVK_VS_REVR_MATERIAL_CARD_MASS_SUMMARY.csv')
interface=readj(ROOT/'revision/verification_results/revR_component_closure/REV_R1_TOE_ANCHOR_INTERFACE_CSG.json')
load=readj(OUT/'REV_R1_INDEPENDENT_LOAD_SCREEN.json')
part_index=readcsv(ROOT/'PRINT_READY_BENCH_FIT_KIT_REV_R/PRINT_PARTS_INDEX_REV_R.csv')
required_names=['cavity','kinematic','csg','fitkit','mass','sourcecheck','interface_csg','load_screen']
exit_codes={}
for n in required_names:
    p=Path('/mnt/data/apex_work/rerun')/f'fresh_{n}.exit'
    if p.exists(): exit_codes[n]=int(p.read_text().strip())
all_exit_ok=len(exit_codes)==len(required_names) and all(v==0 for v in exit_codes.values())
source_path=ROOT/'revision/Apex_Stride_Pro_RevR.scad'
source_sha=hashlib.sha256(source_path.read_bytes()).hexdigest()
summary={
 'revision':'Rev R1 fresh validation / CAD counterbore-clearance correction',
 'date':'2026-10-16',
 'authoritative_cad':'revision/Apex_Stride_Pro_RevR.scad',
 'authoritative_cad_sha256':source_sha,
 'fresh_run_exit_codes':exit_codes,
 'all_fresh_checks_exit_zero':all_exit_ok,
 'source_package_checks':{'checks':source.get('check_count'), 'pass':source.get('pass'), 'fail':source.get('fail'), 'result':source.get('result')},
 'cavity_checks':{'row_count':len(cavity),'result':'PASS' if all((r.get('pass') is True) or (r.get('independent_of_lightening_toggle') is True) for r in cavity) else 'CHECK'},
 'kinematic_sweep':{'positions':sweep.get('positions'),'checks':sweep.get('checks'),'position_rows_pass':sweep.get('position_rows_pass'),'position_rows_fail':sweep.get('position_rows_fail'),'result':sweep.get('result')},
 'rail_stop_csg':{'checks':csg.get('checks'),'pass':csg.get('pass'),'fail':csg.get('fail'),'result':csg.get('result')},
 'toe_anchor_interface_csg':{'checks':interface.get('checks'),'pass':interface.get('pass'),'fail':interface.get('fail'),'result':interface.get('result')},
 'fitkit_mesh_exports':{'rows':len(part_index),'pass':sum(r.get('result')=='PASS' for r in part_index),'fail':sum(r.get('result')!='PASS' for r in part_index)},
 'fresh_native_mass_exports':mass.get('fresh_native_mesh_exports'),
 'assembly_map_rows':source.get('assembly_map_rows'),'missing_assembly_map_paths':source.get('missing_map_paths'),
 'mass_by_size':mass_rows,
 'independent_load_screen':load,
 'structural_fea':'NOT RUN; no compatible FEA solver/workflow found or run in this environment',
 'physical_tests':'NOT RUN',
 'wear_release':'NOT CLEARED',
 'disposition':'digital geometry/interface checks pass only; not structurally qualified or wearable'
}
(OUT/'REV_R1_FRESH_VALIDATION_QA.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
# Readable standalone validation report.
report=f'''# Apex Stride Pro — Rev R1 fresh validation and corrective pass

**Date:** 2026-10-16  
**Baseline:** Rev R CAD architecture, with the Rev R1 component-fit and procurement specification  
**Disposition:** Digital geometry checks pass after a small interface correction. **This remains a non-wearable fit/mockup and engineering-review package; structural capacity, pressure safety, and human wear are not cleared.**

## Concrete defect found and corrected

An exact OpenSCAD CSG intersection test was added for the nominal M4 screw envelopes against the actual strap and footbed geometry. The first run passed the six toe-screw-to-EVA checks but failed all six toe button-head/strap checks: the recess cutter started 0.01 mm below the strap face but was only 2.20 mm high, ending 0.01 mm short of the 2.20 mm head envelope. That left a tiny positive-volume overlap in the nominal CAD.

**Fix:** all three M4 button-head recess cutters in `revision/Apex_Stride_Pro_RevR.scad` now use `bridge_screw_head_depth + 0.01` cutter height. Since each cutter starts 0.01 mm below the external face, the recess into the actual strap stays 2.20 mm deep; the cutter simply reaches the intended head top plane. The authoritative CAD, print-prep source, and standalone CAD copy were synchronized. The toe screw / EVA clearances were not changed.

The new exact-interface suite checks the 16 mm moving toe anchors, 18 mm heel anchors, and indexed rear-strap locking screw envelopes at EU42/EU44/EU46. Latest result: **{interface.get('pass')}/{interface.get('checks')} PASS, {interface.get('fail')} FAIL**. Nominal cylinder models prove geometric non-interference only; they are not manufacturer CAD or physical fit tests.

## Fresh software verification results

| Check | Fresh result | What it establishes |
|---|---:|---|
| Source/package/mesh suite | {source.get('pass')}/{source.get('check_count')} PASS | Selectors/configurations, source parity, component mesh integrity, documentation/map checks and arithmetic gates |
| Continuous heel-core cavity | {len(cavity)}/9 rows | Cavity ray probes, watertightness, and invariance to the optional lightening switch across EU42/44/46 |
| Adjustment sweep | {sweep.get('position_rows_pass')}/{sweep.get('positions')} positions; {sweep.get('checks')} checks | Nominal slider/stop/bridge arithmetic only |
| Rail/stop exact CSG | {csg.get('pass')}/{csg.get('checks')} PASS | No positive-volume intersection at indexed positions for both rails across EU42/44/46 |
| New M4/EVA/bridge interface CSG | {interface.get('pass')}/{interface.get('checks')} PASS | Empty exact CSG overlap for nominated screw/head envelopes with actual strap/footbed geometry |
| Non-wearable fit-kit STL export | {sum(r.get('result')=='PASS' for r in part_index)}/{len(part_index)} PASS | Watertight/winding/finite-volume/plate-orientation mesh checks |
| Native mesh mass recomputation | {mass.get('fresh_native_mesh_exports')} exports | CAD mesh volumes multiplied by explicitly assumed material densities; excludes important real parts |
| Assembly-file map | {source.get('assembly_map_rows')} entries, {len(source.get('missing_map_paths') or [])} missing | All mapped file paths resolve |

The adjustment sweep reports no nominal arithmetic failures. These checks do **not** model manufacturing tolerances, part deformation, fatigue, physical contact pressure, or load-rated performance.

## Recomputed modeled platform mass

| Size | Rev K modeled platform | Rev R modeled platform | Delta |
|---|---:|---:|---:|
'''
for r in mass_rows:
    report+=f"| {r['size']} | {float(r['RevK_full_modeled_platform_g_outsole_1p20']):.3f} g | {float(r['RevR_full_modeled_platform_g_outsole_1p20']):.3f} g | {float(r['RevR_delta_platform_g']):+.3f} g |\n"
report+='''
These figures are partial model estimates—not measured finished-shoe mass. They exclude EVA/footbed mass, actual retaining ring, production fasteners, upper, return spring, bladder, tubing/fittings/regulator, adhesive and other unmodeled parts. Outsole mass assumes an illustrative 1.20 g/cm³ density. The modeled mass-reduction target remains unmet.

## 66 kg structural / pneumatic screen

The full 66 kg gravitational load is **647.46 N** (`66 × 9.81`). The load-screen multipliers intentionally assign that entire load to **one shoe** as a conservative single-support sensitivity case; they do not use the average two-foot stance. The ideal equal bilateral static share is **323.73 N per foot** (which would mean half the listed force/stress/pressure values before any multiplier if that were the chosen load case). The 1.5×/2×/3× cases are analyst sensitivities, not measured gait loads or safety factors.

- **Pneumatics:** maximum projected cavity area is 1,265 mm². If a bladder alone carried the full 647.46 N single-shoe load uniformly over that entire area, the calculated pressure is 0.512 MPa at 1×, 1.024 MPa at 2× and 1.535 MPa at 3×; the equal-bilateral static comparison would be 0.256 MPa before multipliers. The 2× idealized figure exceeds the candidate SMC KQ2 fitting's 1.0 MPa operating rating; a smaller effective bladder area increases pressure for a fixed bladder-carried force, while spring/frame load sharing may reduce the bladder-carried force. The actual bladder and circuit remain unspecified, so **no working pressure or relief setpoint is approved**.
- **Cavity roof:** the 5.5 mm PA12 roof's one-way strip screen is sensitive to assumed load-spread width. At 20 mm spread width it estimates 36.92 MPa at 1×, 73.84 MPa at 2× and 110.76 MPa at 3×, compared with a 41 MPa published flexural-strength reference. The formula is not a 3D stress solution and 41 MPa is not a design allowable.
- **Pin:** the simple point-load beam screen depends strongly on assumed effective span: 40.6 mm rail-center spacing gives 152.49 MPa at 1× and 457.47 MPa at 3×; using a 90.3 mm whole-pin span gives 339.16 MPa at 1× and 1,017.47 MPa at 3×. The true support/load distribution is unresolved; neither is a validated pin stress. A 725 MPa candidate H1150D proof reference is just a material comparison, not a design allowable or fatigue limit.

No compatible FEA solver/workflow was found or run in this environment. No material-specific 3D FEA, mesh convergence/contact analysis, tolerance/strain simulation, pressure/leak/burst test, static proof load, impact/fatigue cycle, pin/ring retention test, outsole bond/slip test, sewn upper fit test, or human-wear test was performed. The CSV/JSON load screen records all scenarios and limitations at `revision/verification_results/revR1_fresh_validation/`.

## Release decision

**Digital source/mesh/interface checks: PASS after the 0.01 mm cutter correction. Structural qualification and human wear: NOT CLEARED.** Keep the shoe non-wearable until the production material/process and exact hardware are fixed, the load/contact path is independently analyzed with approved allowables, the bladder/circuit has rated hardware and fail-safe dump behavior, and appropriate guarded physical proof/fatigue/fit/traction tests pass.

Reproduce the validation with the source scripts under `revision/tools/`; the current report and machine-readable QA summary are `REV_R1_FRESH_VALIDATION_REPORT.md` and `revision/verification_results/revR1_fresh_validation/REV_R1_FRESH_VALIDATION_QA.json`.
'''
(ROOT/'REV_R1_FRESH_VALIDATION_REPORT.md').write_text(report,encoding='utf-8')
# Put a compact fresh-status notice at the top of the existing project status file.
status_path=ROOT/'PROJECT_STATUS_AND_RELEASE_GATE.md'
status=status_path.read_text(encoding='utf-8')
start='<!-- FRESH REV R1 VALIDATION UPDATE BEGIN -->'
end='<!-- FRESH REV R1 VALIDATION UPDATE END -->'
notice=f'''{start}
## Fresh validation/correction pass — 2026-10-16

- Found a **0.01 mm nominal CSG clash** between the M4 button-head envelope and all six moving front-strap recesses. Corrected the three button-head cutter heights by +0.01 mm (without changing the 2.20 mm depth into the plate); synchronized source and print-prep CAD.
- Exact interface CSG suite: **{interface.get('pass')}/{interface.get('checks')} PASS** across EU42/EU44/EU46, checking toe EVA reliefs, moving-front-strap screw heads, fixed rear-anchor heads, and indexed rear locking-screw heads.
- Fresh core suite: **{source.get('pass')}/{source.get('check_count')} PASS**; cavity checks **{len(cavity)}/9**; adjustment sweep **{sweep.get('position_rows_pass')}/{sweep.get('positions')}**; rail/stop CSG **{csg.get('pass')}/{csg.get('checks')}**; fit-kit meshes **{sum(r.get('result')=='PASS' for r in part_index)}/{len(part_index)}**; native mesh mass recomputation **{mass.get('fresh_native_mesh_exports')}** exports.
- This is still **not FEA or physical qualification**. No material-specific FEA, physical proof/fatigue/pressure/traction/fit tests, or human-wear test has run. Human wear remains **NOT CLEARED**. See `REV_R1_FRESH_VALIDATION_REPORT.md` for the load sensitivities and release gates.
{end}

'''
if start in status and end in status:
    a=status.index(start); b=status.index(end)+len(end)
    status=status[:a]+notice.rstrip()+status[b:]
else:
    status=notice+status
status_path.write_text(status,encoding='utf-8')
print(json.dumps({'qa_path':str(OUT/'REV_R1_FRESH_VALIDATION_QA.json'),'report_path':str(ROOT/'REV_R1_FRESH_VALIDATION_REPORT.md'),'source_suite':source.get('result'),'interface_csg':interface.get('result'),'all_exit_zero':all_exit_ok},indent=2))
