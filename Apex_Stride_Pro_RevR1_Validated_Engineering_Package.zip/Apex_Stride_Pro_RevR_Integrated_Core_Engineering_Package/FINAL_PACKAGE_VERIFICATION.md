# Rev R1 package verification

- Main editable CAD and print-prep source are synchronized.
- Current BOM has 64 unique line items; supplier register has 36 rows; prioritized procurement list has 29 items.
- Source/package validator: 126 checks, 126 PASS, 0 FAIL.
- Core cavity native geometry: 9/9 PASS across three supported sizes and optional-lightening states.
- Print fit kit: all 42 indexed STLs regenerated and mesh-checked successfully.
- Adjustment sweep: 61/61 positions, 250 arithmetic/coordinate checks.
- Exact rail/stop CSG: 6/6 expected-empty intersection checks.
- Native mass exports: 66/66; assembly map 72/72 paths resolve.
- Latest like-for-like modeled mass is 4.079 g / 4.114 g / 4.149 g heavier than Rev K at EU42/44/46, respectively. Footbed, production hardware, upper, spring/bladder/circuit/adhesive excluded; outsole density is illustrative only.
- ZIP integrity and package manifest are verified after current files are finalized.

**Component and pressure status:** Lee Spring LHP030B04S is a conditional return candidate; DERFLEX is only an OEM bladder RFQ; pressure line/filter/fill/check/dump details and allowable pressure are not closed; a bushing SKU and broad upper overlay fabric/pattern remain on hold. No FEA or physical qualification is claimed; human wear is not cleared.
