<!-- FRESH REV R1 VALIDATION UPDATE BEGIN -->
## Fresh validation/correction pass — 2026-10-16

- Found a **0.01 mm nominal CSG clash** between the M4 button-head envelope and all six moving front-strap recesses. Corrected the three button-head cutter heights by +0.01 mm (without changing the 2.20 mm depth into the plate); synchronized source and print-prep CAD.
- Exact interface CSG suite: **24/24 PASS** across EU42/EU44/EU46, checking toe EVA reliefs, moving-front-strap screw heads, fixed rear-anchor heads, and indexed rear locking-screw heads.
- Fresh core suite: **126/126 PASS**; cavity checks **9/9**; adjustment sweep **61/61**; rail/stop CSG **6/6**; fit-kit meshes **42/42**; native mesh mass recomputation **66** exports.
- This is still **not FEA or physical qualification**. No material-specific FEA, physical proof/fatigue/pressure/traction/fit tests, or human-wear test has run. Human wear remains **NOT CLEARED**. See `REV_R1_FRESH_VALIDATION_REPORT.md` for the load sensitivities and release gates.
<!-- FRESH REV R1 VALIDATION UPDATE END -->

# Project status and release gate — Rev R1 component-specification closure

## Completed digitally in this pass

- Preserved Rev R adjustable captured-rail, stop and continuous heel-core cavity geometry.
- Updated CAD/print-prep parity to source the M4 button-head and nut-pocket dimensions; added the moving toe-strap recess and two moving EVA underside clearances for the M4×16 toe anchors.
- Identified concrete manufacturer/product candidates for spring, tube, fittings, regulator, relief family, fasteners, retaining ring, mesh, webbing, heel-counter sheet, EVA, thread, prototype closure and 4 mm outsole sheet. Candidate facts, derived values, prices and purchase gates are separately recorded.
- Published 64-line BOM, 36-row sourced component register, 29-line procurement list, interface audit, load/pressure/return-force table, manufacturing material/process schedule, vendor link matrix and component closure report.
- Re-exported 42 size-specific fit/mockup STL components and reran the source/package suite, cavity check, adjustment sweep, exact stop/rail CSG and mass calculation.

## Latest digital validation

- Automated source/package suite 126/126 PASS; no failed checks.
- Current cavity continuity checks 9/9 PASS.
- Print fit kit 42/42 mesh exports PASS.
- 61/61 adjustment positions, 250 arithmetic/coordinate checks PASS.
- Exact rail/stop intersection checks 6/6 PASS.
- Native mass exports 66/66 PASS; assembly map 72/72 paths resolve.

## Explicit purchasing holds—not generic review items

1. **Spring:** Lee Spring LHP030B04S is a conditional return spring candidate (5.126 N/mm, 8.94 mm free-to-solid travel); linkage stroke/preload/return-force target and fatigue need supplier drawing/confirmation before final seat/guide design.
2. **Bladder:** DERFLEX is an OEM RFQ path only. Require finished envelope/port/folds, working and burst pressure, effective area/load-height force curve, leak/fatigue cycles and pressure-loss behavior. No stock bladder with all necessary ratings has been confirmed.
3. **Pneumatics:** SMC tube/fitting/regulator and relief-family candidates identified; exact check-valve direction, relief suffix, gauge/tee and a 3/2 isolating dump-valve SKU remain open. No safe working pressure or setpoint selected.
4. **Pin/bushing:** custom 17-4PH pin drawing candidate; sleeve/bushing SKU held because a through sleeve could block transverse rail-index engagement. Resolve seat and load path first.
5. **Upper:** Spacermesh mesh and hardware are real candidates, but a broad high-tenacity overlay textile SKU, last-matched pattern, stitch/seam specifications and strap retention geometry remain open.
6. **Outsole bonding:** 4 mm Vibram sheet candidate fits nominal thickness only; exact compound hardness/fatigue data and PA12 SLS bond/primer compatibility remain unverified. Adhesive not selected for production.

## Status decision

Rev R1 is a specific sourced candidate/procurement and non-wearable fit kit. It is not an authorized final production build. Current mass model is about 4.08–4.15 g heavier than Rev K; reduction target remains unmet. No material-specific FEA, hardware dimensional gauging, pressure/leak testing, proof/fatigue validation, footwear slip/bond tests, sewn-upper tests, or human-wear trial has been run. Keep human wear prohibited until appropriate independent structural review and physical qualification are complete.
