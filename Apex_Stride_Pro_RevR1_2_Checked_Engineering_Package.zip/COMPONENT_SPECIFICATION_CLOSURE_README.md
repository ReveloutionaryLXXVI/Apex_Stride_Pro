> **CURRENT REVISION — Rev R1.2 (2026-10-16).** This current package supersedes earlier 5.5 mm heel-core roof and 27×22×14 mm bladder-envelope notes. Active CAD: `revision/Apex_Stride_Pro_RevR.scad`; current validation: `REV_R1_FRESH_VALIDATION_REPORT.md`; correction index: `REV_R1_2_CORRECTION_INDEX.md`. The physical-release status remains **NOT CLEARED FOR HUMAN WEAR**. See the current report for the revised roof, corrected 594 mm² bladder-area calculation, pressure target, and actual validation provenance.

# Apex Stride Pro Rev R — Component specification closure

Date: 2026-10-16

This package preserves Rev R, applies a small fastener-interface correction and adds real supplier candidates with exact part numbers, source links and observed prices where publicly available. It distinguishes orderable catalog parts from custom RFQ components. No product page is treated as proof that its part is safe for footwear loads.

Primary deliverables:
- `revision/docs/BILL_OF_MATERIALS_REV_R.csv` — updated procurement BOM with exact candidate, price/link and fit gate columns.
- `revision/docs/SOURCED_COMPONENT_REGISTER_REV_R1.csv` — catalog candidates/internal drawing IDs and distinct dimensional/rating fields.
- `revision/docs/REV_R1_PROCUREMENT_LIST.csv` — prioritized buy / quote / hold register with public price snapshots and exact purchasing gates.
- `revision/docs/REV_R_VENDOR_DATASHEET_LINKS.md` — direct vendor/datasheet/order links.
- `revision/docs/PROCUREMENT_AND_MANUFACTURING_SPEC_REV_R1.md` — CAD envelopes, calculations, manufacturing process/material schedule, compatibility and procurement holds.
- `revision/verification_results/revR_component_closure/COMPONENT_FIT_AUDIT_REV_R1.csv` and `PRESSURE_RETURN_FORCE_CALCULATIONS_REV_R1.csv` — fit audit and numerical screens.
- `revision/docs/ASSEMBLY_MANUAL_REV_R.md` and `FINAL_ENGINEERING_REPORT_REV_R.md` — updated instructions and engineering report.

Public prices are snapshots only; no quotes/orders have been placed. Order quantities and sheet yields need final manufacturing quote. Finished bladder, pressure operating point, exact check-valve flow-direction SKU, manual dump valve, broad upper-panel nylon, and production outsole adhesive remain explicit purchasing holds rather than fabricated product selections.
