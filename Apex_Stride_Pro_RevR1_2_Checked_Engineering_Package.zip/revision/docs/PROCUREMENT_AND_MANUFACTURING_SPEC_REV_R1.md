# Apex Stride Pro — Rev R1 component specification closure and procurement/manufacturing plan

**Baseline retained:** Rev R. This is a controlled component-interface patch and procurement addendum, not a design restart. Date: 2026-10-16. The prior Rev R source was preserved under `revision/baseline/`; active source and print-prep copy are synchronized.

## 1. Procurement status at a glance

The updated BOM now carries exact candidate SKUs and vendor links when a purchasable item exists. Custom-made rails, bridge straps, lock pin and bladder are assigned internal RFQ/drawing IDs, not fictitious catalog numbers. Price values are only those displayed by the cited page; otherwise the BOM says quote required.

**Specific selected catalogue candidates:** Lee Spring `LHP 030B 04S`; SMC tube `T0425`; SMC regulator `ARX20-F01BG`; SMC relief family `AP20-D` (final thread/order suffix open); SMC KQ2 fittings `KQ2H04-M5A` / `KQ2H04-G01A`; SMC check-valve family at 4 mm/M5 with flow direction still requiring SKU confirmation; Würth `009801412` M4×12, `009801418` M4×18, `009801416` M4×16, and `00980148` M4×8; Keller & Kalmbach `5240324` M4 ISO4032 A2-70 nuts; Lawson `41580` external DIN471 ring; Spacermesh `2BC2-8A`; Avetco `PO.016.2080.8MM`; GISMA `EVA-50` / `EVA-38`; Vibram sheet `7175CHERRYSHT4MMBLK`; Strapworks `WSR-NYL-M37-034-BLK` for edge/strap reinforcement only; VELCRO `VEL-OW64511` for prototype closure only; Coats Dabond Tex90 thread candidate.

**Not represented as production-selected:** finished pneumatic bladder, its safe pressure, manual dump-valve SKU, broad nylon overlay fabric, production PA12-to-rubber adhesive/primer, exact upper sewn pattern, spring seats and working stroke. Their exact purchase gaps are itemized in the BOM and supplier register.

## 2. Derived component envelope from Rev R CAD

Rev R1.2 heel-core cavity is a continuous underside cut-out at x=−125 to −70 mm, y=±11.5 mm, z=−20.6 to −10.1 mm: **55×23×10.5 mm**, with a **10.1 mm local roof** and approximately **2.5 mm nominal web to the rail-channel envelope**. The outside sole thickness stays 20.6 mm. The schematic split uses a **24×23×10.5 mm spring reserve**, a **3 mm longitudinal separator**, and a **28×23×10.5 mm bladder reserve**. The target bladder body height is reduced to **9.0 mm**, preserving 1.5 mm nominal cavity-height clearance; the local PA12 roof is **10.1 mm** (up from 5.5 mm), adding approximately 5.53 g per heel deck at the 0.95 g/cm³ material-card density assumption; length/width clearances, folds, port and seam must be confirmed by OEM. The reserve regions are bounding boxes, not available strokes or finished internal component models. The cavity is open on the underside; it has no supplier-specific spring seats/retainer, bladder seam/port, or tube centerline.

For first bladder RFQ only, the proposed body-envelope target is **≤27×22×9 mm** inside the 28×23×10.5 mm reserve, leaving roughly 0.5 mm per side and 1.1 mm vertical envelope margin. This is not an approved bladder geometry: seams, ports, folding/bowing, installation direction and retainers may consume that margin. Do not modify cavity dimensions until the OEM delivers a finished part drawing.

The rail set nominal dimensions from CAD are 155 mm length, 11 mm T-head width, 6.5 mm stem width, 2.3 mm neck height and 16.1 mm overall height, two rails centered at y=±20.3 mm. Index holes are Ø8.3 mm, at 13.333 mm pitch for three positions. Carriage pin passage is Ø8.8 mm; target pin shaft Ø8.0 mm. A single-headed pin is nominal 90.3 mm shaft span, Ø12×3 mm head, Ø7.6×0.9 mm retention-ring groove near y=−44.25 mm. Lawson 41580's published DIN471 ring geometry nominally matches the ring/groove envelope.

Bridge straps are nominal 130×23×3 mm fixed rear and 85×23×3 mm moving front, with a 6 mm stacked underside recess. The CAD uses Ø4.8 mm screw clearances and paired holes at y=±5 mm. Standard ISO4032 M4 nuts were selected as 7.0 mm across flats and ~3.2 mm thickness for fit calculations.

Fresh same-scope lower-platform mass audit (outsole density 1.20 g/cm³ placeholder; footbed foam mass, upper, actual fasteners, ring, spring/bladder/circuit and adhesive excluded): EU42 Rev K 566.254 g vs Rev R 570.333 g (+4.079 g); EU44 570.104 g vs 574.218 g (+4.114 g); EU46 573.953 g vs 578.103 g (+4.150 g). **The mass-reduction target remains unmet.**

## 3. 66 kg load cases and what can be derived

Body force = 66×9.81 = **647.46 N**. Equal bilateral static sharing is **323.73 N per foot**. Single-foot full body static load is **647.46 N**. The 1.5×, 2× and 3× figures in `PRESSURE_RETURN_FORCE_CALCULATIONS_REV_R1.csv` are analyst-selected sensitivities, **not measured dynamic gait loads**.

**Corrected area:** the RFQ bladder body target is ≤27×22×9 mm, so the nominal projected footprint is 594 mm², not the entire 55×23 mm (1265 mm²) cavity. If it alone carried the load, calculated pressure demand is 1.090 MPa at one-foot static, 1.635 MPa at 1.5×, 2.180 MPa at 2×, and 3.270 MPa at 3×; the real effective area may be smaller. The design target is therefore a low-pressure auxiliary bladder, with 0.40 MPa provisional working target and 0.50 MPa nominal relief target. At 594 mm² this supplies about 237.6 N at target and 297 N at nominal relief, so the chassis must carry the remainder—and the complete load with the bladder depressurized. These settings remain provisional until the OEM declares bladder working/burst/cycle rating, the relief's flow/overshoot is validated, and chamber transients are measured. They are not authorization to pressurize or wear.

Lee Spring `LHP 030B 04S` is the preferred conditional return-spring candidate. Published dimensions: OD 4.57 mm, derived bore ≈3.05 mm (=OD−2×wire Ø0.76; supplier drawing required), free length 19.05 mm, solid height 10.11 mm, wire Ø0.76 mm; rate 5.126 N/mm; load at solid 45.77 N; free-to-solid travel 8.94 mm. It fits the 24×23×10.5 mm reserve only if oriented along its 24 mm axis. Under an explicit, unvalidated 4–6 mm return-stroke assumption with no preload, estimated spring force is 20.5–30.8 N; at 6 mm compression there is ≈2.94 mm nominal travel to solid. This is a testable preliminary candidate, not a final selection, because the actual linkage stroke, preload, force requirement, seats, guide and fatigue duty remain undefined. It is not a primary body-load spring.

Pin sensitivity uses a simplified beam model: full load applied as a central point load to an unsupported 90.3 mm span, with section modulus based on Ø7.6 mm throughout. It gives nominal stress screens about 339 MPa at 647.46 N, 509 MPa at 1.5×, 678 MPa at 2×, and 1017 MPa at 3×. These are intentionally simple upper-envelope sensitivities, not the actual multi-bearing joint analysis. The Langley 17-4PH H1150D page reports minimum proof stress725 MPa and tensile860 MPa for its listed condition; the 3× screen exceeds that proof stress and the 2× screen has little reserve before groove/notch, impact and fatigue effects. Pin design remains a structural engineering gate, not certified by this arithmetic.

## 4. CAD changes made to close sourceable hardware interfaces

A real fit mismatch was corrected in the active Rev R SCAD and print-prep source, without changing the chassis architecture or cavity envelope:

- Sourced Würth ISO7380-1 M4 button heads are Ø7.6×2.2 mm; older bridge head pockets were Ø7.5 mm (0.1 mm nominal diametral interference). Active pockets are now **Ø7.9×2.2 mm** (0.3 mm diametral clearance).
- Moving front-strap toe-anchor holes now carry a **moving Ø7.9×2.2 mm head recess**. A static pocket in the rear strap would align at one extension only; the correction is applied to the moving front strap, which tracks all three size settings.
- Rail-mount head counterbores now provide **2.2 mm effective depth** with Ø8.0 mm diameter for the Ø7.6×2.2 mm screw head.
- Captive nut traps now target standard M4 ISO4032 nut geometry: **7.35 mm across flats** (7.0 mm nut +0.35 mm clearance), **3.6 mm anchor pocket depth**, and **3.45 mm lock pocket depth**.
- Fastener length is split by actual bearing height: M4×12 on rail mounting; M4×18 on fixed rear bridge anchors; M4×16 on moving toe anchors (whose bearing plane is 3 mm higher in the stack); M4×8 on selected-setting bridge locks. The moving M4×16 tip nominally overlaps the 5 mm toe foam by ~0.45 mm (tip z≈+0.60 mm; EVA begins at z=+0.15 mm); the toe footbed requires a matching shallow relief/physical pressure-point inspection before final release.

Immutable pre-closure copies are in `revision/baseline/`. `revision/Apex_Stride_Pro_RevR.scad` and `PRINT_READY_BENCH_FIT_KIT_REV_R/source/Apex_Stride_Pro_RevR_PrintPrep.scad` remain synchronized, and all 42 indexed fit-kit parts were regenerated from the active source. This patch does not claim a metal hardware assembly has been physically gauged.

## 5. Manufacturing material / process schedule

| Part | Selected route/material | Orientation or build notes | Purchasing/qualification gate |
|---|---|---|---|
| Heel deck + toe carriage | Materialise industrial PA12 SLS, using the vendor’s exact PA12 SLS card/process | Request a quote with candidate edge orientation so in-use deck Z compression lies in machine XY; ask supplier to choose/approve final orientation for warpage and measured critical fits. Do not transpose the PA12 SLS card to MJF/FDM. | Process cert, lot, build orientation, critical dimension report, worst-direction material allowables and structural assessment. |
| Rails L/R | CNC-machined certified 6061-T6; 155 mm, T profile per CAD; tapped M4×0.7 | Do not use polymer gauge STLs as rails. Surface finish/coating only after the mating channel tolerance is agreed. | Shop drawing/metal certificate, bore/groove coordinates, slide wear test, thread engagement and proof load. |
| Bridges rear/front | CNC 6061-T6 plate, 130×23×3 and 85×23×3 | Edges deburred, hole positions made to released drawing; not printed nylon. | Joint/bearing/edge-distance and anti-loosening qualification; button-head load warning considered. |
| Cross pin | Custom turned 17-4PH UNS S17400, H1150D condition candidate | Internal part drawing APX-PIN-RR1; finish/groove/root fillet per ring supplier drawing; no printed pin. | Material cert, measured pin, notch/fatigue/shear/bearing/retention analysis. |
| External ring | Lawson 41580 18-8 DIN471 | Purchased ring; no printed ring. | Verify detailed supplier drawing and capacity, installation/inspection. |
| Spring | Lee Spring LHP030B04S (LHP 030B 04S), Type 17-7 PH | OD4.57, free19.05, solid10.11, rate5.126 N/mm, travel8.94 mm; estimated20.5–30.8 N at assumed4–6 mm stroke. | Axis/seat/guide not in CAD; stroke/return force is still an assumption; obtain fatigue/working-load data. Not a body-load spring. |
| Bladder | DERFLEX OEM custom welded TPU-coated textile | Target max body envelope 27×22×9 mm only as an RFQ envelope. Port/retainer/fold details are not modeled. | Finished part drawing, W.P./burst, cycles, leakage, effective area/load-height curve, port and seam strength. |
| Tube and pneumatics | SMC T0425 + KQ2 4mm fittings + ARX20-F01BG + AP20-D relief family + direction-appropriate check valve + gauge and dump | External guarded panel only. T0425 min bend radius13 mm; no line route exists in CAD. Keep pressure protection at bladder side. | Confirm direction-B check SKU, AP20-D port suffix, gauge/tee, dump valve, final circuit and weakest-component limit. No pressure setpoint until bladder rating known. |
| Footbed | GISMA EVA-50; forefoot 5 mm; heel 7 mm custom | Cut cover included only after compressed/covered stack measured; no interference with slider, anchors or spring. | 7 mm heel supply method, force-deflection, compression set, cover/adhesive and lap cycle. |
| Tongue/collar padding | GISMA EVA-38, 3 mm cut parts | Sewn/laminated within the upper pattern; never enters moving channels. | Skin-facing cover, pressure distribution, compression set, seam migration. |
| Upper textile | Spacermesh 2BC2-8A (3mm) candidate; Strapworks 3/4-in webbing only for strap/edge reinforcement; Coats Dabond Tex90 candidate thread; VELCRO 20×200 strap prototype | Current upper meshes are visual concepts, not panels or stitch patterns. P2080 heel counter is a 0.8mm formed sheet. | Vendor resolve yarn spec mismatch; get overlay-panel fabric, real last/pattern, seam/bartack/anchor strength, closure length and wear tests. |
| Heel counter | Avetco Poliflex P2080 0.8mm sheet | Cut a 2D last-matched counter pattern, form into upper; do not print 3mm shell. | Full TDS and heat-process compatibility with selected fabrics/adhesive. |
| Outsole | Vibram Cherry sheet 7175CHERRYSHT4MMBLK, 4 mm | Cut default 4mm geometry, test tread layout and flex; keep 3.2mm study non-default. | Confirm Shore A/compound/flex/abrasion and source-compatible adhesive/primer or add a designed positive retention interface. |
| Outsole adhesive/primer | No production product selected; LOCTITE 406 is coupon-trial reference only | Do not bond production part by assumption. | Supplier must explicitly confirm PA12 SLS to actual Vibram 7175 compound, plus peel/flex/humidity/heat aging coupons. |

## 6. Compatibility cross-check

- **Fasteners ↔ CAD:** catalog dimensions now match nominal head and nut pockets. The moving front strap needed its own moving head recess; this was fixed. The M4×16 moving-anchor tip nominally overlaps the forefoot EVA by 0.45 mm; two Ø5.5×0.72 mm underside reliefs are modeled. Gauge the physical screw, foam, cover and compression stack. The manufacturer warns these button-head screws are for limited loads; geometry fit alone does not qualify their load path.
- **Fasteners ↔ rails:** only the M4×12 rail screws enter a metal rail; use a real M4×0.7 tapped hole with material-appropriate engagement, not printed PA12 threads. The updated nominal geometry gives ~9.7 mm thread engagement, which must be checked against actual rail drawing and stress. Stainless screws in aluminum and humid/salty use require a corrosion/anti-seize/isolation decision that does not compromise torque or thread friction.
- **Spring ↔ mechanism:** the selected candidate fits its bounding box only with its axis along the 24 mm reserve; no installed seat/guide/preload or return mechanism exists. Conditional target is 20.5–30.8 N over assumed4–6 mm, not a body-load spring. Mechanical stop and pressure-loss/failsafe must be independently resolved.
- **Pneumatics ↔ cavity:** regulator/relief are external, 4mm tubing is an external route, and the custom bladder port still has no CAD connection. Fitting max pressure1.0MPa is below the tube's 1.5MPa limit; the weakest part governs. The corrected target bladder area is 594 mm²; if it alone bore the 2× full-body force, demand would be 2.180 MPa, far above the KQ2 1.0 MPa rating. The provisional pressure-limited design therefore assigns the bladder only auxiliary force and requires a separately qualified chassis load path that is safe with zero bladder pressure.
- **PA12 ↔ rubber outsole:** Vibram sheet thickness matches the 4mm geometry, but no hardness/compound data or bond system is verified. LOCTITE 406 is only a test-coupon reference; it is not selected as production adhesive. Get vendor written compatibility for exact materials or design mechanical retention.
- **Upper ↔ closure:** polyester mesh can be sewn with bonded polyester thread in principle, but exact mesh yarn spec has a source discrepancy and there are no last-matched patterns or seam pull ratings. The Velcro one-wrap strap is only a prototype closure, not footwear-rated by the source page. Broad nylon overlay panel material remains unselected; the 19mm Strapworks webbing is not a panel substitute.
- **Footbed ↔ fasteners:** the 5mm forefoot stack is nominally matched by GISMA EVA-50, but the moving M4×16 anchor screw tip nominally overlaps it by 0.45mm; two matching underside reliefs are now modeled. CAD now has two Ø5.5×0.72 mm underside toe-footbed reliefs; tip z≈+0.60 mm, relief top≈+0.86 mm, nominal tip clearance≈0.26 mm and foam above relief≈4.3 mm. Gauge screw tip, actual EVA and cover, and pressure/comfort before closing the footbed.

## 7. Explicit purchasing holds

1. Do not buy or pressurize a finished bladder until DERFLEX (or an alternate OEM) provides finished drawing, working/burst pressure, effective area/load-height curve, leak and cycle data, a defined port, and sample acceptance criteria.
2. Do not set the regulator or relief setting from body weight alone. Maximum available area is only an upper bound; actual bladder effective area and load share are unspecified.
3. Confirm the SMC check valve free-flow direction and exact order code. The sourced `AKH04A-M5` listing flows from male thread to tube; the selected fill line requires the opposite direction depending on valve placement. Do not order the A-direction part blindly.
4. Select the exact SMC AP20-D thread/options, separate chamber gauge/tee and a 3/2 manual isolation/dump valve compatible with the finalized port layout.
5. Get a local quote and drawing for custom 6061-T6 rails/bridge, the 17-4PH pin, Materialise PA12 SLS build, custom 7mm heel EVA and the finished TPU bladder.
6. Ask Vibram-sheet reseller for the actual rubber compound/Shore A/abrasion/tear/flex info, and a footwear-adhesive vendor for PA12-SLS-to-that-rubber compatibility.
7. Resolve Spacermesh 2BC2-8A’s 30D-versus-33D middle yarn discrepancy and source rated broad-panel nylon, actual upper pattern and exact thread spool/color.
8. Before any human wear, physically gauge hardware, build the sewn upper, check forefoot foam relief, complete load/fatigue and pressure system qualification and confirm pressure-loss behavior.

## 8. Files changed/added

- Updated BOM: `revision/docs/BILL_OF_MATERIALS_REV_R.csv` (64-row BOM including size-specific variants and sourced candidate columns).
- Added source register: `revision/docs/SOURCED_COMPONENT_REGISTER_REV_R1.csv`.
- Added part/interface audit: `revision/verification_results/revR_component_closure/COMPONENT_FIT_AUDIT_REV_R1.csv`.
- Added calculations: `revision/verification_results/revR_component_closure/PRESSURE_RETURN_FORCE_CALCULATIONS_REV_R1.csv`.
- Added vendor-link file: `revision/docs/REV_R_VENDOR_DATASHEET_LINKS.md`.
- Added prioritized purchase/quote/hold list: `revision/docs/REV_R1_PROCUREMENT_LIST.csv`.
- Updated supplier register, pneumatic circuit schedule and component interface schedule.
- Updated assembly manual and engineering report with this Rev R1 closure addendum.
- Updated CAD fastener pockets and moved front-strap head relief; regenerated all 42 indexed fit-kit STLs.
