# Apex Stride Pro — Rev R1 component-specification closure

**Baseline preserved: Rev R.** This is a sourced preliminary procurement/manufacturing package and non-wearable fit kit, not a safety-certified or human-wear release. The existing adjustable captured-rail architecture, prior rail/stop corrections and the continuous heel-deck reserve are preserved. Rev R1 adds source-matched fastener recesses and moving footbed reliefs; no wholesale redesign was made.

## Deliverables and source of truth

- Editable CAD: [`revision/Apex_Stride_Pro_RevR.scad`](revision/Apex_Stride_Pro_RevR.scad)
- Synchronized print-prep CAD: [`PRINT_READY_BENCH_FIT_KIT_REV_R/source/Apex_Stride_Pro_RevR_PrintPrep.scad`](PRINT_READY_BENCH_FIT_KIT_REV_R/source/Apex_Stride_Pro_RevR_PrintPrep.scad)
- Current BOM (64 unique line items including size variants): [`revision/docs/BILL_OF_MATERIALS_REV_R.csv`](revision/docs/BILL_OF_MATERIALS_REV_R.csv)
- Sourced candidate/interface register (36 rows): [`revision/docs/SOURCED_COMPONENT_REGISTER_REV_R1.csv`](revision/docs/SOURCED_COMPONENT_REGISTER_REV_R1.csv)
- Prioritized purchasing / quote / hold list (29 line items): [`revision/docs/REV_R1_PROCUREMENT_LIST.csv`](revision/docs/REV_R1_PROCUREMENT_LIST.csv)
- Manufacturing and procurement spec: [`revision/docs/PROCUREMENT_AND_MANUFACTURING_SPEC_REV_R1.md`](revision/docs/PROCUREMENT_AND_MANUFACTURING_SPEC_REV_R1.md)
- Vendor datasheet/order link matrix: [`revision/docs/REV_R_VENDOR_DATASHEET_LINKS.md`](revision/docs/REV_R_VENDOR_DATASHEET_LINKS.md)
- Component fit audit: [`revision/verification_results/revR_component_closure/COMPONENT_FIT_AUDIT_REV_R1.csv`](revision/verification_results/revR_component_closure/COMPONENT_FIT_AUDIT_REV_R1.csv)
- 66 kg load / return-force / pressure calculations: [`revision/verification_results/revR_component_closure/PRESSURE_RETURN_FORCE_CALCULATIONS_REV_R1.csv`](revision/verification_results/revR_component_closure/PRESSURE_RETURN_FORCE_CALCULATIONS_REV_R1.csv)
- Unified load assessment: [`revision/docs/LOAD_ASSESSMENT_66KG_REV_R.md`](revision/docs/LOAD_ASSESSMENT_66KG_REV_R.md)
- Assembly steps and nominal interfaces: [`revision/docs/ASSEMBLY_MANUAL_REV_R.md`](revision/docs/ASSEMBLY_MANUAL_REV_R.md)

## CAD changes and revalidation

Rev R1.2 retains the **55 × 23 mm** continuous core footprint at x=−125…−70 mm and y=±11.5 mm, but reduces cavity height to **10.5 mm** (z=−20.6…−10.1 mm) to increase the local PA12 roof from 5.5 to **10.1 mm** without changing the 20.6 mm outside sole thickness. Nominal web to rail-channel envelope remains 2.5 mm. The custom bladder body target height is now 9 mm, leaving 1.5 mm nominal vertical clearance. Within the existing structure, Rev R1 made these real geometry edits:

1. Würth ISO 7380-1 M4 button-head screws have a sourced nominal Ø7.6×2.2 mm head. The relevant CAD counterbores were updated to Ø7.9 mm (bridge) / Ø8.0 mm (rail) and 2.2 mm depth.
2. Captive M4 nut pockets were changed to AF7.35 mm with 3.6/3.45 mm depth to accept a standard ISO 4032 M4 A2-70 nut (AF7 mm, approx. 3.2 mm high), with a small nominal clearance allowance.
3. The toe-anchor head relief was placed on the moving front strap, not the fixed rear strap, so it remains aligned across adjustment states.
4. The moving M4×16 toe screw tip nominally reaches z≈+0.60 mm while the 5 mm EVA starts at z=+0.15 mm: calculated EVA overlap ~0.45 mm. Two Ø5.5×0.72 mm underside footbed reliefs leave about 4.3 mm foam above the relieved pocket and about 0.26 mm nominal relief-over-tip clearance. This is a geometric calculation; the physical screw/foam/cover and compression must be gauged.

Latest available execution results after those CAD changes: source/print-prep suite **126/126 PASS**, cavity continuity **9/9 PASS**, fit-kit export **42/42 PASS**, rail/stop CSG **6/6 PASS**, adjustment sweep **61/61 positions** with 250 coordinate/arithmetic checks, native mass exports **66/66 PASS**, and assembly map **72/72 paths resolve**. These are source and mesh checks—not a real-hardware fit test, structural analysis or physical test. Baseline/pre-closure source snapshots remain in `revision/baseline/`.

## Specific component candidates selected

| System | Selected purchasable candidate / drawing | Known interface or rating | Disposition |
|---|---|---|---|
| Structural print | Materialise industrial PA12 SLS material/service; custom heel deck/toe carriage | Published card: density 950 kg/m³, E 1650 MPa, tensile strength 48 MPa, flexural strength 41 MPa, flexural modulus 1500 MPa, elongation 20%, Shore D75, HDT 86°C | Preferred process-specific print route. Obtain quote, lot/process data, orientation and critical dimensional report. Do not transfer to FDM/MJF; tensile strength is not yield/allowable. |
| Rails/bridges | Custom drawings APX-RAIL-L-R1, APX-RAIL-R-R1, APX-BRG-REAR-R1 (130×23×3), APX-BRG-FRONT-R1 (85×23×3); 6061-T6 CNC | Rail length 155 mm, T head 11 mm, stem 6.5 mm, height 16.1 mm, Ø8.3 index holes on 13.333 mm pitch | Actual finished part is made-to-drawing; source is not an off-the-shelf matching rail. Quote/certify alloy, inspect fits and calculate wear/load. |
| Return spring | Lee Spring **LHP 030B 04S / LHP030B04S**, 17-7 PH | Listed OD 4.57 mm, free 19.05 mm, solid 10.11 mm, k=5.126 N/mm, load-at-solid listing 45.77 N, calculated travel 8.94 mm, listed guide-rod size 2.38 mm. Bore estimate ~3.05 mm is OD−2×wire Ø0.76 and **not separately supplier-quoted**. | Envelope fits if oriented along the 24 mm cavity axis. Assumed 4–6 mm return compression yields 20.5–30.8 N; this is a trial assumption, not a derived mechanism requirement. Seats, guide, preload, load curve and fatigue still open; not a body-load spring. |
| Flexible chamber | DERFLEX custom-welded TPU-coated textile OEM RFQ; internal procurement reference APX-BLD-RR1 | RFQ body target ≤27×22×9 mm inside 28×23×10.5 mm reserve; no finished SKU/port/pressure/cycle rating available | **Not a finished selected bladder.** Supplier must produce a drawing, port, pressure/burst rating, load-height/effective-area curve, leak/cycle and fold/pinch data. Do not change CAD to a guessed bag. |
| Pneumatic tube | SMC **T0425**, Nylon 12 | 4.0 mm OD × 2.5 mm ID; published min bend radius 13 mm; cited max operating 1.5 MPa at 20°C with derating | OD candidate chosen, but there is no CAD routing or compatibility proof to a yet-unspecified bladder port. |
| Push-in fittings | SMC **KQ2H04-M5A**, **KQ2H04-G01A** | 4 mm OD tube; M5×0.8 and G1/8 thread variants; KQ2 series max operating 1.0 MPa / proof 3 MPa | External bench-circuit candidates. Final port/tee layout unresolved; 1.0 MPa operating limit governs over tubing. |
| Regulator | SMC **ARX20-F01BG** with gauge accessory per SMC configuration | G1/8 family; stated output range 0.05–0.85 MPa, inlet max 2 MPa, proof 3 MPa; approx. 35×80 mm package | External guarded bench panel only—not a shoe-contained part. Setpoint blocked pending bladder specification and system rating. |
| Relief | SMC **AP20-D** family, final suffix/port open | Family set range 0.05–0.8 MPa, maximum operating 0.85 MPa, proof 1.3 MPa | Exact order code/port unresolved; no pressure setting selected. |
| Check / dump / gauge | Direction-correct 4 mm/M5 check valve, chamber-side gauge/tee, and 3/2 isolation-dump valve | SMC AKH04A-M5 reference is known to flow from male thread toward tube; final circuit direction may require opposite orientation | **Purchasing hold** until circuit drawing and direction are fixed. Do not purchase AKH04A blindly; dump must isolate supply and vent bladder downstream volume. |
| Rail screws | Würth **009801412**, M4×12, ISO 7380-1 A2-070 | Button head nominal Ø7.6×2.2 mm; listing snapshot EUR 5.90 per 100 | 4 per shoe; intended for metal rail holes, not printed PA12 threads. Exact thread engagement, torque and corrosion strategy still require approval. |
| Bridge anchors/locks | Würth **009801418** M4×18 ×2, **009801416** M4×16 ×2, **00980148** M4×8 ×2 | A2-070 button heads; current CAD head recesses updated | Geometry candidate only. Würth warns this head type is for limited load. Joint strength/locking/torque remain open. Exact unit prices not verified. |
| Nuts / retaining ring | Keller & Kalmbach **5240324**, ISO 4032 M4 A2-70 ×6; Lawson **41580**, external DIN 471 8 mm ×1 | M4 nut AF7 mm, about 3.2 mm high; ring is 18-8/stainless listed pack of five, verify detailed drawing/groove fit | Quantity defined for prototype. Purchase pack is not the same as individual quantity; retention capacity and physical groove fit need verification. |
| Pin / bush | Custom pin APX-PIN-RR1 (17-4PH UNS S17400 H1150D candidate); bushing interface APX-PBUSH-R1 | Pin target Ø8 shaft, approx 90.3 mm spanning, Ø12×3 head, Ø7.6×0.9 groove; current carriage passage Ø8.8 mm | Finished pin supplier/stock availability and final drawing/certification open. **No bushing SKU chosen**: a sleeve may block transverse rail-index engagement; the bearing seat/load path must be solved before buying. |
| Upper mesh/strap/counter | Spacermesh **2BC2-8A** 3 mm polyester spacer mesh; Strapworks **WSR-NYL-M37-034-BLK** 19.05 mm nylon webbing; Avetco Poliflex **PO.016.2080.8MM** 0.8 mm formed-sheet counter candidate | Mesh listing has a 30D/33D middle-yarn data discrepancy; Strapworks item is webbing, not broad fabric panel; Poliflex sheet is not a CAD-finished counter shell | Exact broad nylon panel fabric and last-matched sewn pattern remain on hold. Counter requires pattern/heat-form validation. |
| Upper stitch/closure | Coats Dabond Tex90/Ticket20 candidate; VELCRO Brand One-Wrap **VEL-OW64511**, 20×200 mm | Thread listing average tensile strength approx. 80.85 N, elongation 16–28%; closure is prototype One-Wrap with limited retention documentation | Exact spool/color, seam/bartack strength, closure length and human-fit pattern are not closed. |
| Footbed | GISMA **EVA-50** forefoot 5 mm and heel target 7 mm; GISMA **EVA-38** padding candidate | EVA-50 reference density 50 kg/m³, 52±3 Shore C, rebound ≥60%, flex ≥1.2M cycles without collapse stated by supplier; compression-deflection/set curve not found | Toe piece can use 5 mm stock; 7 mm heel requires custom/laminated quote. Measure cover/bond and compression-set before release. |
| Outsole | Vibram Cherry sheet **7175CHERRYSHT4MMBLK**, 4 mm | Retail listing price snapshot USD 45 per 36×11 in sheet; retail listing did not provide Shore A, compound flex-fatigue, tear or abrasion data | Thickness fits current default. 60–70 Shore A remains a target, not a verified property of this specific SKU. No PA12 SLS-to-rubber production adhesive/primer has been selected; LOCTITE 406 is coupon-only. |
| Broad overlay / adhesive | APX-UPPER-PANEL-R1 internal panel spec and outsole bond qualification | No exact broad high-tenacity nylon panel SKU, no last-matched pattern, and no adhesive with written exact-material compatibility | Hold; request fabric panel TDS and run bond/peel/flex/humidity/heat-aging coupons or design mechanical outsole retention. |

Datasheet and order links and price evidence are in the BOM, register and vendor link matrix rather than being inferred here. Prices are snapshots only where shown; all unverified prices explicitly say quote/login/not verified.

## 66 kg loads and working pressure: what is actually derived

`66 kg × 9.81 = 647.46 N`; ideal equal bilateral static load is 323.73 N per foot. Analyst-selected 1.5× / 2× / 3× factors are only sensitivity scenarios, not measured gait loads.

The previous pressure arithmetic had a geometry error: it used the full 55×23 mm cavity (1,265 mm²) as bladder area. The specified bladder body RFQ envelope is ≤27×22×9 mm, whose maximum projected rectangle is **594 mm²** before subtracting folds/seams/port. If the bladder alone carried load, ideal demand is 0.545 MPa for equal two-foot static share, 1.090 MPa for 647.46 N one-foot static, 1.635 MPa at 1.5×, 2.180 MPa at 2× and 3.270 MPa at 3×. Actual effective area may be smaller. This rules out using the bladder as the sole body-load support with the candidate 1.0 MPa SMC KQ2 fittings.

**Design correction:** a bounded low-pressure auxiliary circuit is now encoded in the CAD/source schedule at 0.40 MPa provisional working target and 0.50 MPa nominal relief-setpoint target. On the 594 mm² proxy area, that corresponds to 237.6 N target bladder force / 297 N at nominal relief. The chassis must carry the residual load and the complete prescribed load when the bladder is depressurized; the small 5.126 N/mm spring is only a return spring. The candidate ARX20 regulator range and AP20-D set range can span these targets; KQ2 fittings are rated 1.0 MPa and T0425 tubing 1.5 MPa at 20 °C. This hierarchy is compatible on paper, not qualified: AP20-D suitability/flow response, relief overshoot, actual chamber pressure, final bladder working/burst/cycle rating and pressure-effective area still require supplier confirmation and guarded bench tests. No user-wear or pressurization release is implied.

The Rev R1.2 10.1 mm heel-core roof lowers the one-way strip stress sensitivity versus the former 5.5 mm roof (about 32.85 MPa at the 3× case for the 20 mm assumed spread width), but that simple model and the 41 MPa flexural reference are not design allowables; the simple pin beam sensitivity reaches ~339 MPa at one-foot static load and ~1,017 MPa at the 3× scenario using a 7.6 mm groove-root diameter over an assumed 90.3 mm span. These screens highlight loads needing engineering, they do not predict actual stresses or prove a failure mode. No material-specific FEA has been run.

## Verification and release gates

- Automated source/package checks rerun after the pressure-input correction; use the current QA JSON for the updated count and exact pass/fail total.
- Core cavity continuity checks 9/9 PASS.
- 42/42 fit-kit STL exports pass mesh checks.
- Adjustment sweep 61/61 positions; 250 coordinate/arithmetic checks.
- Exact rail/stop CSG intersection checks 6/6 pass.
- 66 native mesh exports validated for current mass calculations.
- Assembly map 72/72 paths resolve.
- Like-for-like model mass: EU42 Rev K 566.254 g vs Rev R 570.333 g (+4.079 g); EU44 570.104 vs 574.218 (+4.114 g); EU46 573.953 vs 578.103 (+4.149 g). These are partial model mass only; omit EVA, real ring, production fasteners, upper, spring/bladder/line/components/adhesive and use illustrative outsole density 1.20 g/cm³. Mass-reduction target remains unmet.

No FEA, physically gauged supplier components, pressure/leak test, proof/impact/fatigue trial, pin/ring retention test, outsole bond/slip test, sewn upper pull/fit test or human-wear trial is claimed. The exact unresolved purchasing decisions—finished bladder rating/port, check-valve direction, dump valve, relief suffix, gauge/tee, bushing geometry, broad overlay fabric/pattern and production adhesive—are called out as explicit holds in the procurement list. **Do not treat the candidate BOM as permission to build a wearable shoe or pressurize an unqualified bladder.**
